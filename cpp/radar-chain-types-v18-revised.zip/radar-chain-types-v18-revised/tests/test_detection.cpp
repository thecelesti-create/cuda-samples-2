/** @file test_detection.cpp @brief Host detection values and optional angles. */
#include <gtest/gtest.h>
#include <radar/Detection.hpp>
#include <cmath>
#include <complex>
#include <limits>
#include <optional>

/** @brief One host record keeps the five detector values together. */
TEST(DetectionTests, ValuesAndSetters) {
    radar::Detection detection(5, 2, 4.0f, 12.0f, {3.0f, 4.0f});
    EXPECT_EQ(detection.getRangeIndex(), 5U);
    EXPECT_EQ(detection.getDopplerIndex(), 2U);
    EXPECT_FLOAT_EQ(detection.getAmplitude(), 4.0f);
    EXPECT_FLOAT_EQ(detection.getSnrDb(), 12.0f);
    EXPECT_EQ(detection.getComplexPair(), std::complex<float>(3.0f, 4.0f));
    detection.setRangeIndex(6);
    detection.setDopplerIndex(3);
    detection.setAmplitude(7.0f);
    detection.setSnrDb(-2.0f);
    detection.setComplexPair({1.0f, -1.0f});
    EXPECT_EQ(detection.getRangeIndex(), 6U);
    EXPECT_EQ(detection.getDopplerIndex(), 3U);
    EXPECT_FLOAT_EQ(detection.getAmplitude(), 7.0f);
    EXPECT_FLOAT_EQ(detection.getSnrDb(), -2.0f);
    EXPECT_EQ(detection.getComplexPair(), std::complex<float>(1.0f, -1.0f));
}

/** @brief An absent angle differs from a present numerical NaN. */
TEST(DetectionTests, OptionalAngles) {
    radar::Detection detection;
    EXPECT_FALSE(detection.getAzimuthRadians());
    EXPECT_FALSE(detection.getElevationRadians());
    detection.setAzimuthRadians(0.2f);
    ASSERT_TRUE(detection.getAzimuthRadians());
    EXPECT_FLOAT_EQ(*detection.getAzimuthRadians(), 0.2f);
    EXPECT_FALSE(detection.getElevationRadians());
    detection.setElevationRadians(std::numeric_limits<float>::quiet_NaN());
    ASSERT_TRUE(detection.getElevationRadians());
    EXPECT_TRUE(std::isnan(*detection.getElevationRadians()));
    detection.setAzimuthRadians(std::nullopt);
    detection.setElevationRadians(std::nullopt);
    EXPECT_FALSE(detection.getAzimuthRadians());
    EXPECT_FALSE(detection.getElevationRadians());
}
