/** @file test_range_pulse_buffer.cpp @brief Range calibration and pulse layout. */
#include <gtest/gtest.h>
#include <arrayfire.h>
#include <radar/CPI_Metadata.hpp>
#include <radar/RangePulseBuffer.hpp>
#include <radar/SamplePulseBuffer.hpp>
#include <array>
#include <cstddef>

/** @brief Range crops adjust the origin; pulse crops adjust the timestamp. */
TEST(RangePulseBufferTests, StandaloneCalibrationAndSlices) {
    const radar::RangePulseBuffer ranges(
        af::constant(2.0f, af::dim4(6, 4, 2), c32),
        radar::CPI_Metadata(10e6, 2000.0, 10e9, 5e6), 100.0, 10.0);
    EXPECT_EQ(ranges.getData().type(), c32);
    EXPECT_EQ(ranges.getRangeBinCount(), 6);
    EXPECT_EQ(ranges.getPulseCount(), 4);
    EXPECT_EQ(ranges.getElementCount(), 2);
    EXPECT_EQ(ranges.getLinearIndex(2, 1, 1), 32U);
    EXPECT_DOUBLE_EQ(ranges.getRangeMeters(2), 120.0);
    const auto cropped = ranges.sliceRanges(2, 3).slicePulses(1, 2);
    EXPECT_EQ(cropped.getRangeBinCount(), 3);
    EXPECT_EQ(cropped.getPulseCount(), 2);
    EXPECT_DOUBLE_EQ(cropped.getFirstRangeMeters(), 120.0);
    EXPECT_NEAR(cropped.getPulseTimeSeconds(0), 0.0005, 1e-12);
}

/** @brief A small non-square reorder preserves every IQ value in the right order. */
TEST(RangePulseBufferTests, ReorderForDoppler) {
    std::array<af::cfloat, 12> iq{};
    for (std::size_t i = 0; i < iq.size(); ++i) iq[i] = {static_cast<float>(i), 0};
    const radar::RangePulseBuffer ranges(af::array(af::dim4(3, 2, 2), iq.data(), afHost),
        radar::CPI_Metadata(10e6, 2000.0, 10e9, 5e6), 0.0, 15.0);
    const af::array reordered = ranges.reorderForDoppler();
    EXPECT_EQ(reordered.dims(0), 2);
    EXPECT_EQ(reordered.dims(1), 3);
    EXPECT_EQ(reordered.dims(2), 2);
    std::array<af::cfloat, 12> actual{};
    reordered.host(actual.data());
    const std::array<float, 12> expected{0, 3, 1, 4, 2, 5, 6, 9, 7, 10, 8, 11};
    for (std::size_t i = 0; i < actual.size(); ++i) EXPECT_FLOAT_EQ(actual[i].real, expected[i]);
}

/** @brief Stage adoption propagates CPI metadata; replacement and calibration remain explicit. */
TEST(RangePulseBufferTests, AdoptAndReplace) {
    const auto samples = radar::SamplePulseBuffer::zeros(
        6, 4, 2, radar::CPI_Metadata(10e6, 2000.0, 10e9, 5e6, 42));
    radar::RangePulseBuffer ranges(samples, samples.getData());
    EXPECT_EQ(ranges.getMetadata().getCpiId(), 42U);
    EXPECT_NEAR(ranges.getRangeBinSpacingMeters(), 14.9896229, 1e-9);
    auto copy = ranges.clone();
    copy.setData(af::constant(2.0f, copy.getDimensions(), c32));
    copy.setFirstRangeMeters(50.0);
    copy.setRangeBinSpacingMeters(5.0);
    EXPECT_DOUBLE_EQ(copy.getRangeMeters(2), 60.0);
    EXPECT_FLOAT_EQ(copy.computePower().scalar<float>(), 4.0f);
    EXPECT_FLOAT_EQ(ranges.toHost().front().real, 0.0f);
}
