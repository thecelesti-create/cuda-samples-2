/** @file test_cpi_metadata.cpp @brief Small CPI value and derived-unit tests. */
#include <gtest/gtest.h>
#include <radar/CPI_Metadata.hpp>
#include <radar/types.hpp>

/** @brief Required values and acquisition timing survive construction. */
TEST(CpiMetadataTests, ValuesAndTiming) {
    const radar::CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6, 42, 2e-6, 10.0);
    EXPECT_DOUBLE_EQ(metadata.getSampleRateHz(), 10e6);
    EXPECT_DOUBLE_EQ(metadata.getPrfHz(), 2000.0);
    EXPECT_DOUBLE_EQ(metadata.getCarrierFrequencyHz(), 10e9);
    EXPECT_DOUBLE_EQ(metadata.getBandwidthHz(), 5e6);
    EXPECT_EQ(metadata.getCpiId(), 42U);
    EXPECT_DOUBLE_EQ(metadata.getFirstPulseTimeSeconds(), 10.0);
    EXPECT_NEAR(metadata.getSamplePeriodSeconds(), 1e-7, 1e-15);
    EXPECT_NEAR(metadata.getPulsePeriodSeconds(), 0.0005, 1e-12);
    EXPECT_NEAR(metadata.getFirstSampleRangeMeters(), 299.792458, 1e-9);
    EXPECT_NEAR(metadata.getSampleRangeSpacingMeters(), 14.9896229, 1e-9);
}

/** @brief PRF and bandwidth describe different ambiguity/resolution limits. */
TEST(CpiMetadataTests, AmbiguityAndResolution) {
    const radar::CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6);
    EXPECT_NEAR(metadata.getWavelengthMeters(), 0.0299792458, 1e-12);
    EXPECT_NEAR(metadata.getUnambiguousRangeMeters(), 74948.1145, 1e-7);
    EXPECT_DOUBLE_EQ(metadata.getMinUnambiguousDopplerHz(), -1000.0);
    EXPECT_DOUBLE_EQ(metadata.getMaxUnambiguousDopplerHz(), 1000.0);
    EXPECT_DOUBLE_EQ(metadata.getUnambiguousDopplerSpanHz(), 2000.0);
    EXPECT_NEAR(metadata.getMaxUnambiguousSpeedMps(), 14.9896229, 1e-9);
    EXPECT_NEAR(metadata.getNominalRangeResolutionMeters(), 29.9792458, 1e-9);
}

/** @brief Derived values immediately reflect setters, including velocity sign. */
TEST(CpiMetadataTests, SettersUpdateDerivedValues) {
    radar::CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6);
    EXPECT_LT(metadata.getRadialVelocityMps(1000.0), 0.0);
    metadata.setPositiveDoppler(radar::PositiveDoppler::Receding);
    metadata.setSampleRateHz(20e6);
    metadata.setPrfHz(4000.0);
    metadata.setBandwidthHz(10e6);
    metadata.setCarrierFrequencyHz(5e9);
    metadata.setCpiId(8);
    metadata.setFirstSampleDelaySeconds(1e-6);
    metadata.setFirstPulseTimeSeconds(5.0);
    EXPECT_GT(metadata.getRadialVelocityMps(1000.0), 0.0);
    EXPECT_DOUBLE_EQ(metadata.getMaxUnambiguousDopplerHz(), 2000.0);
    EXPECT_NEAR(metadata.getSampleRangeSpacingMeters(), 7.49481145, 1e-9);
    EXPECT_NEAR(metadata.getNominalRangeResolutionMeters(), 14.9896229, 1e-9);
    EXPECT_NEAR(metadata.getWavelengthMeters(), 0.0599584916, 1e-12);
    EXPECT_EQ(metadata.getCpiId(), 8U);
    EXPECT_DOUBLE_EQ(metadata.getFirstSampleDelaySeconds(), 1e-6);
    EXPECT_DOUBLE_EQ(metadata.getFirstPulseTimeSeconds(), 5.0);
}
