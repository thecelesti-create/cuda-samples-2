/** @file test_range_doppler_map.cpp @brief Small spectra, calibration, and FFT-order tests. */
#include <gtest/gtest.h>
#include <arrayfire.h>
#include <radar/CPI_Metadata.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/types.hpp>
#include <vector>

/** @brief FFT length and actual integrated pulses remain separate quantities. */
TEST(RangeDopplerMapTests, StandaloneLayoutAndPower) {
    const std::vector<af::cfloat> iq(8 * 3 * 2, {3, 4});
    const radar::RangeDopplerMap map(af::array(af::dim4(8, 3, 2), iq.data(), afHost),
        radar::CPI_Metadata(10e6, 2000.0, 10e9, 5e6), 100.0, 10.0, 4);
    EXPECT_EQ(map.getData().type(), c32);
    EXPECT_EQ(map.getDopplerBinCount(), 8);
    EXPECT_EQ(map.getRangeBinCount(), 3);
    EXPECT_EQ(map.getElementCount(), 2);
    EXPECT_EQ(map.getIntegratedPulseCount(), 4);
    EXPECT_DOUBLE_EQ(map.getDopplerBinSpacingHz(), 250.0);
    EXPECT_DOUBLE_EQ(map.getCoherentIntervalSeconds(), 0.002);
    EXPECT_DOUBLE_EQ(map.getDopplerHz(7), -250.0);
    EXPECT_DOUBLE_EQ(map.getRangeMeters(2), 120.0);
    EXPECT_FLOAT_EQ(map.computePower().scalar<float>(), 25.0f);
    EXPECT_FLOAT_EQ(map.computePowerSumElements().scalar<float>(), 50.0f);
}

/** @brief One odd and one even length cover shifting and the signed Nyquist convention. */
TEST(RangeDopplerMapTests, OddEvenDopplerOrdering) {
    for (dim_t count : {4, 5}) {
        SCOPED_TRACE(count);
        std::vector<af::cfloat> iq(static_cast<std::size_t>(count));
        for (dim_t k = 0; k < count; ++k) iq[k] = {static_cast<float>(k), 0};
        const radar::RangeDopplerMap map(af::array(count, iq.data(), afHost),
            radar::CPI_Metadata(10e6, 2000.0, 10e9, 5e6), 0.0, 15.0, count);
        auto centered = map.withDopplerOrder(radar::DopplerOrder::Centered);
        const auto shiftedIq = centered.toHost();
        for (dim_t k = 0; k < count; ++k) {
            const dim_t shifted = (k + count / 2) % count;
            const dim_t signedBin = k < (count + 1) / 2 ? k : k - count;
            EXPECT_EQ(map.getSignedDopplerBin(k), signedBin);
            EXPECT_EQ(centered.getSignedDopplerBin(shifted), signedBin);
            EXPECT_FLOAT_EQ(shiftedIq[shifted].real, static_cast<float>(k));
        }
        centered.setDopplerOrder(radar::DopplerOrder::Unshifted);
        const auto restored = centered.toHost();
        for (dim_t k = 0; k < count; ++k) EXPECT_FLOAT_EQ(restored[k].real, static_cast<float>(k));
    }
}

/** @brief Crops and replacement preserve ownership while changing only the requested wrapper. */
TEST(RangeDopplerMapTests, CropReorderAndReplacement) {
    const radar::RangeDopplerMap map(af::constant(1.0f, af::dim4(8, 6, 2), c32),
        radar::CPI_Metadata(10e6, 2000.0, 10e9, 5e6), 100.0, 10.0, 4);
    const auto cropped = map.sliceRanges(2, 3);
    EXPECT_EQ(cropped.getRangeBinCount(), 3);
    EXPECT_DOUBLE_EQ(cropped.getFirstRangeMeters(), 120.0);
    EXPECT_EQ(map.reorderToRangeFirst().dims(0), 6);
    EXPECT_EQ(map.getElementVector(2, 1).elements(), 2);
    auto copy = map.clone();
    copy.setData(af::constant(0.0f, copy.getDimensions(), c32));
    EXPECT_FLOAT_EQ(copy.toHost().front().real, 0.0f);
    EXPECT_FLOAT_EQ(map.toHost().front().real, 1.0f);
}
