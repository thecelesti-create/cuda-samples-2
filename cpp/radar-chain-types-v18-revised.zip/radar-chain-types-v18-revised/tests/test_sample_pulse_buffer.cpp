/** @file test_sample_pulse_buffer.cpp @brief Small raw-IQ buffer checks. */
#include <gtest/gtest.h>
#include <arrayfire.h>
#include <radar/CPI_Metadata.hpp>
#include <radar/SamplePulseBuffer.hpp>
#include <array>
#include <vector>

/** @brief Direct construction caches the physical dimensions and logical offset. */
TEST(SamplePulseBufferTests, StandaloneLayout) {
    const radar::SamplePulseBuffer samples(
        af::constant(1.0f, af::dim4(3, 2, 2), c32),
        radar::CPI_Metadata(10e6, 2000.0, 10e9, 5e6, 42));
    EXPECT_EQ(samples.getData().type(), c32);
    EXPECT_EQ(samples.getSampleCount(), 3);
    EXPECT_EQ(samples.getPulseCount(), 2);
    EXPECT_EQ(samples.getElementCount(), 2);
    EXPECT_EQ(samples.getLinearIndex(2, 1, 1), 11U);
    EXPECT_EQ(samples.getBytes(), 96U);
    EXPECT_EQ(samples.getMetadata().getCpiId(), 42U);
    EXPECT_EQ(samples.getPulse(1, 0).elements(), 3);
    EXPECT_EQ(samples.getElement(0).elements(), 6);
}

/** @brief Cropping updates counts and timestamps without changing the source. */
TEST(SamplePulseBufferTests, UploadAndSlices) {
    const std::vector<af::cfloat> iq(8 * 4 * 2, {2.0f, 1.0f});
    const auto samples = radar::SamplePulseBuffer::fromHost(
        iq, 8, 4, 2, radar::CPI_Metadata(10e6, 2000.0, 10e9, 5e6));
    const auto cropped = samples.sliceSamples(2, 3).slicePulses(1, 2);
    EXPECT_EQ(cropped.getSampleCount(), 3);
    EXPECT_EQ(cropped.getPulseCount(), 2);
    EXPECT_EQ(samples.getSampleCount(), 8);
    EXPECT_NEAR(cropped.getSampleDelaySeconds(0), 2e-7, 1e-15);
    EXPECT_NEAR(cropped.getPulseTimeSeconds(0), 0.0005, 1e-12);
    const auto values = cropped.toHost();
    ASSERT_EQ(values.size(), 12U);
    EXPECT_FLOAT_EQ(values.front().real, 2.0f);
    EXPECT_FLOAT_EQ(values.front().imag, 1.0f);
}

/** @brief A replacement and metadata edit on a clone do not alter the input. */
TEST(SamplePulseBufferTests, ZerosCloneAndReplacement) {
    const auto samples = radar::SamplePulseBuffer::zeros(
        4, 2, 1, radar::CPI_Metadata(10e6, 2000.0, 10e9, 5e6, 1));
    auto copy = samples.clone();
    copy.setData(af::constant(3.0f, copy.getDimensions(), c32));
    copy.setMetadata(radar::CPI_Metadata(10e6, 2000.0, 10e9, 6e6, 2));
    EXPECT_FLOAT_EQ(samples.toHost().front().real, 0.0f);
    EXPECT_FLOAT_EQ(copy.toHost().front().real, 3.0f);
    EXPECT_EQ(samples.getMetadata().getCpiId(), 1U);
    EXPECT_EQ(copy.getMetadata().getCpiId(), 2U);
}

/** @brief Power includes quadrature, including large finite float values. */
TEST(SamplePulseBufferTests, ComplexPower) {
    const std::array<af::cfloat, 3> iq{{{3, 4}, {-5, 12}, {1e15f, -1e15f}}};
    const auto samples = radar::SamplePulseBuffer::fromHost(
        iq, 3, 1, 1, radar::CPI_Metadata(10e6, 2000.0, 10e9, 5e6));
    const af::array power = samples.computePower();
    std::array<float, 3> values{};
    power.host(values.data());
    EXPECT_EQ(power.type(), f32);
    EXPECT_FLOAT_EQ(values[0], 25.0f);
    EXPECT_FLOAT_EQ(values[1], 169.0f);
    EXPECT_NEAR(values[2], 2e30f, 2e24f);
}
