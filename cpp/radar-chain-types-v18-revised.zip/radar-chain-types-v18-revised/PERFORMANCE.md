# Performance notes — corrected v18

Corrected v18 separates library tests; production code is unchanged. The retained
phase-centered RDM path has the same correlation, gather, scaling, batching and
azimuth-only output operations as v16. This is an API simplification, not a claim
of improved kernel latency or peak GPU memory.

No ArrayFire runtime is installed in the generation environment; no CPU/CUDA
latency, speedup, bandwidth or device-memory measurements were obtained here.

## Retained implementation choices

| Path | Behavior |
|---|---|
| Cube construction | Query dimensions once; cache named scalar counts |
| Power | Real `I*I + Q*Q` expression |
| Phase-centered RDM gather | Prepare `[cell,element]` view once per estimate |
| Spatial scale | Wavelength/(2*pi*spacing), once per estimate |
| IQ extraction | Internal lookup/reorder of selected cells in bounded batches |
| Output | One f32 azimuth column; no elevation allocation/fill |
| Phase zero handling | Component test, no squaring of tiny correlations |
| Explicit list evaluation | Group compatible same-type/same-shape columns |

These choices retain the source-level work reductions from previous releases.
The actual kernels, allocations and execution policy are controlled by ArrayFire;
only measurements on the deployed backend can establish performance.

## What intentionally stays

Large buffers are c32, and normal passes retain/move ArrayFire handles rather than
cloning data. Detection fields/angles stay on the selected backend. Only explicit
`toHost()` and `recordsToHost()` export values. `synchronize()` is an explicit
caller boundary. Interferometry has no host/scalar numerical reads or explicit
fences. It still gathers selected cells in bounded blocks instead of doing angle
work for every RDM cell. It has no persistent device cache or native CUDA buffer.

Each principal IQ block uses `8 * elementCount * min(K,batchSize)` logical bytes.
The single azimuth column uses `4*K` bytes. No elevation allocation is made by this estimator. Lookup/reorder/reduction/JIT
intermediates and asynchronous memory pools add to this; it is **not** a hard
peak-memory bound. There is no collection-of-maps host vector or public
pre-gathered input route. The detector never needs elemental IQ; it supplies
sum-beam detections and the estimator owns the selected-cell gather.

Contiguous RDMs are the low-memory precondition: flattening strided views can
materialize larger allocations. A transpose/reorder is real data movement.
Avoid keeping needless cube clones/old pipeline stages alive. No automatic cache
clears or synchronization calls were added to force allocator behavior.

Release optimization is still selected by the build. No global `-ffast-math`,
finite-math-only or precision reduction was added; NaNs remain meaningful outputs.
There is no process-global thread, backend, allocator or JIT configuration change.

## Opt-in measurements on your machine

Two disabled GoogleTest cases live in their respective library test runners. They add no
library dependencies beyond ArrayFire and no default application targets.
They use three warmups and twenty timed calls with a device fence after each call.
Reported mean milliseconds include host launch/allocation and synchronization
overhead; they are not kernel-only timings or PCIe transfer measurements.
Input materialization is outside the timed region; correctness readback is after.
No fixed speed threshold is asserted.

Build with `RADAR_BUILD_TESTS=ON` and `RADAR_TEST_BACKEND=cuda`, then run (Linux/WSL):

```sh
./build-tests/tests/radar_arrayfire_tests --gtest_also_run_disabled_tests --gtest_filter='ArrayFirePerformance.*'
./build-tests/interferometry/tests/radar_interferometry_tests --gtest_also_run_disabled_tests --gtest_filter='InterferometryPerformance.*'
```

Windows / Visual Studio:

```powershell
.\build-tests\tests\Release\radar_arrayfire_tests.exe --gtest_also_run_disabled_tests --gtest_filter="ArrayFirePerformance.*"
.\build-tests\interferometry\tests\Release\radar_interferometry_tests.exe --gtest_also_run_disabled_tests --gtest_filter="InterferometryPerformance.*"
```

Use the CMake default or the `RADAR_TEST_BACKEND` environment variable to select
cpu/cuda/opencl in a unified build. There is no positional backend argument; unset
the environment override in direct-linked builds. First run the correctness suites. Timings print to stdout and
are recorded as GoogleTest properties for an optional `--gtest_output=xml:...`.

The power test compares the prior conjugate expression with v14 power on a
resident 10000x800x5 cube, and times the Doppler reorder separately. These
measurements are executed sequentially, not randomized; repeat runs and control
thermal/power settings before drawing conclusions.
The interferometry test reports the sole phase-centered RDM path for 8192
sum-beam detections, 12 phase centers and batch size 4096. Internal gathering is
INSIDE the timed call; sum-beam detector-fixture construction is outside it.
The XML property is `phase_centered_rdm_ms`. This is **not** a comparison with
v16 or an obsolete pre-gathered path. Its case name is
`InterferometryPerformance.DISABLED_DeviceResidentAzimuthEstimation`. It uses boresight synthetic IQ to exercise
the operation path, not to validate real-scene radar performance.

## API references used for the review

- JIT fusion/materialization: https://arrayfire.org/docs/jit.htm
- Simultaneous array evaluation: https://arrayfire.org/docs/group__data__mat.htm
- Reshape semantics: https://arrayfire.org/docs/group__manip__func__moddims.htm
- Reduction interface: https://arrayfire.org/docs/group__reduce__func__sum.htm
- Timing and synchronization: https://arrayfire.org/docs/timing.htm

Documentation review is not an SDK compile or execution test.

## Correctness-run timing versus algorithm timing

Each library executable runs its selected cases in one process. CTest discovery
still registers individual cases and starts a process for each, so merely sharing
one binary does not eliminate cold-start overhead in CTest. Use direct execution
with `--gtest_repeat=10` to diagnose first-use effects. The revised
`RangeDopplerMapTests.OddEvenDopplerOrdering` uses only lengths 4 and 5 and four
bulk map readbacks. Detection-index remapping has a separate small test; the
three-record export-tail test is separate again. These are correctness tests,
not reorder benchmarks. Fewer test readbacks do not change production latency.
