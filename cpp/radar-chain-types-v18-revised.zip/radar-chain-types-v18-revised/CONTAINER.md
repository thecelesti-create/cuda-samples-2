# ArrayFire 3.10 container build and tests — corrected v18

The existing Dockerfile provides a `cpu` target (source-built ArrayFire 3.10.0) and
`cuda` target (official ArrayFire 3.10.0 binary SDK with the configured CUDA 12.8.1
base image). Both explicitly enable `RADAR_BUILD_TESTS=ON`. They are development
and test environments, not minimized deployment images.

**The Docker images have not been built/run in this revision's execution
environment.** See `VALIDATION.md`. Installation recipes and upstream dependency
versions are inherited; this revision separates the library tests, not
the SDK installation strategy. The recipes remain unexecuted here.

## Build and run

From the extracted repository root:

```sh
docker build --platform linux/amd64 --target cpu -t radar-af:cpu .
docker run --rm radar-af:cpu

docker build --platform linux/amd64 --target cuda -t radar-af:cuda .
docker run --rm --gpus all radar-af:cuda
```

The GPU target requires a compatible host NVIDIA driver and container GPU access.
On Windows use Docker Desktop's Linux/WSL2 GPU setup. The Dockerfile does not grant
GPU access to a host without it. Internet access is needed to fetch base images,
packages and the SDK. For lower build-memory use pass `--build-arg BUILD_JOBS=1`.

Both image builds run CTest on the CPU backend because normal image builds do not
expose a GPU. CUDA tests are requested at runtime with `--gpus all`. A missing
requested backend is a failure, not a successful CPU fallback.

## Test organization

Both Docker targets install the base distribution's `libgtest-dev` package.
That package is not pinned to exactly 1.11: these images are not an exact-1.11
compatibility test. The source/CMake minimum is now 1.11. All test executables use the real
GoogleTest library; no private assertion framework is retained. The image build
uses CTest to discover and run each case on CPU. The runtime script runs the same
GoogleTest executables with the requested backend. The container script still accepts cpu/cuda; it now selects the test backend
through the RADAR_TEST_BACKEND environment variable, not a binary argument.


The default non-container library build has tests OFF. Containers opt in because
their purpose is to test the libraries. There are three runners:

```text
/opt/radar/build/tests/radar_metadata_tests                 CPI_Metadata and host Detection
/opt/radar/build/tests/radar_arrayfire_tests                Radar types and both pipelines
/opt/radar/build/interferometry/tests/radar_interferometry_tests  All interferometry tests
```

There are no demo executables or separate custom main.cpp. The runtime script
runs all three and sets RADAR_TEST_BACKEND for each ArrayFire runner. Datatype
tests are short per-class files; interferometry has one test source of its own.

To run only one runner on the GPU:

```sh
docker run --rm --gpus all -e RADAR_TEST_BACKEND=cuda --entrypoint /opt/radar/build/tests/radar_arrayfire_tests radar-af:cuda
```

For tests that do not need a backend:

```sh
docker run --rm --entrypoint ctest radar-af:cpu --test-dir /opt/radar/build -L unit --no-tests=error --output-on-failure
```

## Logs

Build-time logs are at `/opt/radar/build/validation/`. Runtime logs default to
`/tmp/radar-test-logs/` and are lost with `--rm` unless mounted out.

```sh
mkdir -p test-logs
docker run --rm --gpus all -v "$PWD/test-logs:/results" -e RADAR_TEST_LOG_DIR=/results radar-af:cuda
```

PowerShell:

```powershell
New-Item -ItemType Directory -Force test-logs | Out-Null
$logs = (Resolve-Path test-logs).Path
docker run --rm --gpus all --mount "type=bind,source=$logs,target=/results" -e RADAR_TEST_LOG_DIR=/results radar-af:cuda
```

Do not mount over `/opt/radar`, which would hide the built files. Container runtime
scripts write only logs through the specified results mount. Default correctness tests are not GPU benchmarks or validations against measured radar scenes.
The two disabled timing cases require explicit GoogleTest flags; see PERFORMANCE.md.

SDK reference locations are retained in `API_REFERENCES.md` and the installer
scripts. OS packages and image digests are not fully pinned; bit-for-bit container
reproducibility is not claimed.
