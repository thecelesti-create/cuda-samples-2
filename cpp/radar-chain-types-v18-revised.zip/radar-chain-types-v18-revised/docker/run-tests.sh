#!/usr/bin/env bash
set -Eeuo pipefail
if (( $# > 1 )); then echo 'Usage: run-tests.sh [cpu|cuda]' >&2; exit 2; fi
backend="${1:-${RADAR_DEFAULT_BACKEND:-cpu}}"
case "$backend" in cpu|cuda) ;; *) echo 'Backend must be cpu or cuda' >&2; exit 2;; esac
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
logs="${RADAR_TEST_LOG_DIR:-/tmp/radar-test-logs}"
mkdir -p "$logs"
# Each library runner selects the requested backend; no fallback.
# Radar chains and interferometry remain in separate test executables.
printf 'Requested backend: %s\n' "$backend" | tee "$logs/requested-backend.txt"
"$root/build/tests/radar_metadata_tests" 2>&1 | tee "$logs/metadata.txt"
RADAR_TEST_BACKEND="$backend" "$root/build/tests/radar_arrayfire_tests" 2>&1 | tee "$logs/arrayfire-$backend.txt"
RADAR_TEST_BACKEND="$backend" "$root/build/interferometry/tests/radar_interferometry_tests" 2>&1 | tee "$logs/interferometry-$backend.txt"
printf 'All requested %s tests passed. Logs: %s\n' "$backend" "$logs"
