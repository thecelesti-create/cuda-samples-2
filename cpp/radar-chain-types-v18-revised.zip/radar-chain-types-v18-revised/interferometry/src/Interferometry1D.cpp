#include <radar/interferometry/Interferometry1D.hpp>
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/types.hpp>
#include "device_helpers.hpp"
#include <cstddef>

namespace radar::interferometry {
Interferometry1D::Interferometry1D(double elementSpacingMeters, std::size_t detectionBatchSize) noexcept
    : elementSpacingMeters_(elementSpacingMeters), detectionBatchSize_(detectionBatchSize) {}

af::array Interferometry1D::computeAzimuth(const af::array& elementIq, float azimuthScale) const {
    const auto elementCount = static_cast<std::size_t>(elementIq.dims(0));
    const af::array lower = elementIq(detail::sequence(0, elementCount - 1), af::span);
    const af::array upper = elementIq(detail::sequence(1, elementCount - 1), af::span);
    const af::array correlation = af::sum(af::conjg(lower) * upper, 0);
    // Fixed positive-exponent, horizontal-plane convention. No elevation output.
    return af::asin(detail::phase(correlation) * azimuthScale);
}

DetectionList Interferometry1D::estimate(const RangeDopplerMap& phaseCenteredRdm,
                                        const DetectionList& detections) const {
    const float azimuthScale = static_cast<float>(detections.getMetadata().getWavelengthMeters() /
        (2.0 * radar::pi * elementSpacingMeters_));
    af::array planes;
    if (!detections.getIsEmpty()) {
        planes = af::moddims(phaseCenteredRdm.getData(),
                            phaseCenteredRdm.getDopplerBinCount() * phaseCenteredRdm.getRangeBinCount(),
                            phaseCenteredRdm.getElementCount());
    }
    return detail::estimateAzimuthBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return detail::gather(planes, detections, first, count); },
        [&](const af::array& iq) { return computeAzimuth(iq, azimuthScale); });
}
} // namespace radar::interferometry
