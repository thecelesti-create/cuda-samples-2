#pragma once
#include <cstddef>
#include <radar/DetectionList.hpp>
#include <algorithm>
#include <limits>
#include <utility>

namespace radar::interferometry::detail {
/** @brief Make an unchecked inclusive ArrayFire sequence from first/count; count must be positive. */
inline af::seq sequence(std::size_t first, std::size_t count) {
    return af::seq(static_cast<double>(first), static_cast<double>(first + count - 1));
}
/** @brief Build u32 flattened range-Doppler indices for one block on device. */
inline af::array cellIndices(const DetectionList& detections, dim_t dopplerBinCount,
                              std::size_t first, std::size_t count) {
    const auto bins = sequence(first, count);
    // Explicit u32 operands avoid f32 rounding of integer indices above 2^24.
    const af::array stride = af::constant(static_cast<unsigned>(dopplerBinCount),
                                         af::dim4(static_cast<dim_t>(count)), u32);
    return detections.getDopplerIndices()(bins) + detections.getRangeIndices()(bins) * stride;
}
/** @brief Gather selected c32 phase-center values from a prepared [cell,element] view. */
inline af::array gather(const af::array& planes, const DetectionList& detections,
                        std::size_t first, std::size_t count) {
    const auto indices = cellIndices(detections, detections.getDopplerBinCount(), first, count);
    return af::reorder(af::lookup(planes, indices, 0), 1, 0, 2, 3);
}
// A zero complex correlation has no defined phase: emit NaN, not false boresight.
// Elementwise device math only, no reductions to host / shape or value scans.
/** @brief Get principal correlation phase in radians; zero correlation produces a device NaN. */
inline af::array phase(const af::array& correlation) {
    // Flatten the already-reduced input, not the output expression: keep phase,
    // scaling and inverse trigonometry in the same downstream JIT expression.
    const af::array values = af::flat(correlation);
    const af::array nonzero = (af::real(values) != 0.0f) || (af::imag(values) != 0.0f);
    return af::select(nonzero, af::arg(values), std::numeric_limits<float>::quiet_NaN());
}

// Chunk only IQ scratch; the single output column is O(K). Evaluation bounds
// expression lifetimes, not peak allocator usage, without an explicit host fence.
/** @brief Attach only azimuth to a shallow list copy, discarding stale output angles. */
template<class Gather, class Compute>
DetectionList estimateAzimuthBatched(const DetectionList& detections, std::size_t batchSize,
                                     Gather&& gatherBlock, Compute&& computeBlock) {
    const std::size_t detectionCount = detections.getDetectionCount();
    auto result = detections; // Retain base column handles and small metadata, not a deep copy.
    result.clearAngles();     // Never pass an old elevation off as part of this estimate.
    if (detectionCount == 0) { result.setAzimuthRadians({}); return result; }
    if (detectionCount <= batchSize) {
        af::array azimuth = computeBlock(gatherBlock(0, detectionCount));
        azimuth.eval();
        result.setAzimuthRadians(std::move(azimuth));
        return result;
    }
    af::array azimuth(af::dim4(static_cast<dim_t>(detectionCount)), f32);
    for (std::size_t first = 0; first < detectionCount;) {
        const std::size_t count = std::min(batchSize, detectionCount - first);
        af::array azimuthBlock = computeBlock(gatherBlock(first, count));
        azimuthBlock.eval();
        azimuth(sequence(first, count)) = azimuthBlock;
        first += count;
    }
    result.setAzimuthRadians(std::move(azimuth));
    return result;
}
} // namespace radar::interferometry::detail
