# Corrected v18 — separate library tests and short per-type files

This replaces the first v18 archive. The CMake version is 0.18.1; the folder/ZIP
suffix `-revised` distinguishes it. Extract into a fresh directory to avoid stale
sources, registered tests and executables. Production APIs and implementations
are unchanged.

## Fixed library boundary

`radar_arrayfire_tests` links ONLY `radar::chain_types` and `GTest::gtest_main`.
It has no interferometry includes, compile switch, or linkage. It is available
with `RADAR_BUILD_INTERFEROMETRY=OFF`.

`radar_interferometry_tests` is restored under `interferometry/tests`, links
`radar::interferometry` and `GTest::gtest_main`, and compiles exactly ONE file:
`interferometry/tests/test_interferometry.cpp`. This includes its scalar reference
cases; `radar_interferometry_reference_tests` is no longer a separate target.
The interferometry suite now requires the ArrayFire-enabled build.

No user main.cpp or new shared test-support header is introduced. The two
ArrayFire binaries have independent program-level GoogleTest Environments in
`test_arrayfire.cpp` and `test_interferometry.cpp` respectively. Registration does
not initialize the GPU, and --gtest_list_tests performs no explicit device setup.

## Source organization

```
tests/
    test_cpi_metadata.cpp         -> radar_metadata_tests
    test_detection.cpp           -> radar_metadata_tests
    test_sample_pulse_buffer.cpp  -> radar_arrayfire_tests
    test_range_pulse_buffer.cpp   -> radar_arrayfire_tests
    test_range_doppler_map.cpp    -> radar_arrayfire_tests
    test_detection_list.cpp      -> radar_arrayfire_tests
    test_arrayfire.cpp           -> radar_arrayfire_tests (chains / misc / setup)

interferometry/tests/
    test_interferometry.cpp       -> radar_interferometry_tests
```

All case sources follow test_*.cpp. The previous arrayfire_tests.cpp,
metadata_tests.cpp and reference_math_tests.cpp are removed.

## Deliberately simpler datatype checks

The six class test files contain focused cases with small arrays. The old mixed
megacases are not all preserved: their overlapping assertions are replaced by
short construction, layout, calibration, replacement, selection and angle tests.
Odd/even map ordering and detection-index remapping are tested separately for
lengths 4 and 5. The small-batch export check is a separate three-record example,
not part of a 16-length ordering sweep. No performance gain in the library is
claimed; only the test workload was reduced.

The two pipeline case bodies, both disabled timing cases, and every existing
interferometry/scalar-reference case body are retained. The known numerical
expectations of the chain and azimuth tests are unchanged.

## Running the revised targets

Build configuration/backend selection remains unchanged. No positional cuda/cpu
argument is accepted; use the RADAR_TEST_BACKEND CMake option or environment.

```sh
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release --no-tests=error --output-on-failure
```

Linux/WSL paths:
- `build-tests/tests/radar_metadata_tests`
- `build-tests/tests/radar_arrayfire_tests`
- `build-tests/interferometry/tests/radar_interferometry_tests`

Visual Studio adds `Release/` before each executable filename and `.exe`.
CTest prefixes are radar_metadata., radar_arrayfire., and radar_interferometry.
Interferometry filters must use its restored prefix, not radar_arrayfire.

C++20, ArrayFire 3.10+, GoogleTest 1.11+, optional tests, c32 data, unchecked
helpers and the single phase-centered-RDM estimation API are retained. See
VALIDATION.md for source comparisons and the actual scope of local validation.
