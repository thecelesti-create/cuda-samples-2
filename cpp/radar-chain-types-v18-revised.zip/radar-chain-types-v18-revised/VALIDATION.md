# Validation — corrected v18 (0.18.1)

This replaces the first v18 report. Its old command logs were removed and the
commands listed below were executed again on this revised tree. No real
ArrayFire/GoogleTest test-run pass is claimed.

## Executed checks

| Check | Result |
|---|---|
| Metadata-only C++20 Release configure/build, GCC 14.2 | Passed |
| Metadata-only C++20 Release configure/build, Clang 17 | Passed |
| Parent add_subdirectory build with BUILD_TESTING=ON and project tests off | Passed; no radar test targets leaked into the parent |
| Independent unchanged host-value/scalar program, GCC | 806 checks passed |
| Same program, Clang | 806 checks passed |
| Same program, GCC ASan + UBSan with leak/error checking | 806 checks passed |
| Production comparison to original v18 | 17/17 files byte-for-byte identical |
| Core radar comparison to the user's v15 baseline | 14/14 files byte-for-byte identical |
| Source/test layout and retained-body comparison | Passed (static audit only) |
| Four Docker scripts, bash -n | Passed (syntax, not execution) |

The host program compiles the actual CPI_Metadata/Detection classes and an
independent scalar azimuth model. It does NOT compile or execute the new GoogleTest
translation units, the ArrayFire-backed classes or the interferometry estimator.
Its archived source is validation/host-checks-source.txt, not another test framework
or a project executable. Sanitizers exercised that host program only.

The parent and metadata-only configurations use real compiler/CMake builds with
ArrayFire targets disabled. They do not establish that the full test targets can
link against the missing SDKs.

## Source organization and dependency audit

All eight test translation units use test_*.cpp. Each of the six radar value/buffer
classes has its own test file (45–121 lines). tests/test_arrayfire.cpp contains the
two pipeline tests, the disabled core timing case and this executable's local
GoogleTest Environment. It contains no interferometry include or test case.

The radar ArrayFire test target links only radar::chain_types and GTest::gtest_main.
It has no RADAR_TEST_WITH_INTERFEROMETRY conditional or radar::interferometry link.
The interferometry runner is restored under interferometry/tests and compiles
exactly one test_interferometry.cpp, containing all 21 of that library's cases.
The reference runner is folded into this file rather than retained as a second
interferometry test file/executable.

Every original pipeline, disabled timing and interferometry/reference TEST body
was compared with the first v18: 24/24 retained bodies match. The datatype cases
were intentionally replaced with short focused tests; exhaustive old mixed-case
assertion counts are NOT preserved. Odd/even map and list checks now have four
small readbacks per case, separately from the three-record export-tail check.

The actual test inventory is SOURCE COUNTS, not executed GoogleTest results:

| Runner | Cases | Disabled |
|---|---:|---:|
| radar_metadata_tests | 5 | 0 |
| radar_arrayfire_tests | 18 | 1 |
| radar_interferometry_tests | 21 | 1 |
| Total | 44 | 2 |

Static public API audit: 7 production classes, 52 private fields, 197 documented
function declarations; unchanged production source. This is not an AST/type-check
or an SDK compilation. The dependency audit is a static CMake link-list inspection.

## Attempts and remaining limitations

A real full configure failed because ArrayFire 3.10's config package is absent.
A tests-enabled host-only configure failed because GoogleTest 1.11's config
package is absent. A network probe of the official GoogleTest archive failed at
DNS resolution. See real-arrayfire-configure.txt, real-gtest-configure.txt and
network-probe.txt under validation/ for the exact output.

**The rewritten datatype tests and separated GoogleTest executables have not been
compiled, linked or run against real GoogleTest/ArrayFire in this environment.**
No proxy SDK, fake backend, or stand-in assertion library was used. No CPU/CUDA/
OpenCL integration, Windows/MSVC build, test-discovery/Environment execution,
Docker build, device timing or GPU-memory validation is claimed.

On a machine with the real dependencies, first build/run with
RADAR_BUILD_INTERFEROMETRY=OFF to exercise the radar-only configuration, then build
and run the complete project. Exact commands are in tests/README.md. All binary
entry points come from GTest::gtest_main, not user-supplied main.cpp files.

## Logs and archive

validation/commands.json contains command exit statuses. Compiler/build, host,
sanitizer, scope, production-comparison and shell logs describe this revision.
SHA256SUMS lists every packaged file except itself. Verify after extraction with:

```sh
sha256sum -c SHA256SUMS
```

The new archive was reopened and its CRCs and each SHA-256 entry verified before
delivery. No build products, downloaded dependencies or original v18 test files
are included. Extract into a new directory so stale files cannot remain in a
previous checkout.
