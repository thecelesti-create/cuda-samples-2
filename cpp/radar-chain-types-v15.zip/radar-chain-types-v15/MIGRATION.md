# Migration: v14 -> v15

## GoogleTest 1.11 compatibility

The project version is now 0.15.0. Tests remain OFF by default; enabling tests no
longer requires upgrading GoogleTest from 1.11 to 1.12.

```cmake
find_package(GTest 1.11 CONFIG REQUIRED)
```

The version is a minimum, not `EXACT`: an existing 1.11 installation is accepted,
and a newer installation is not deliberately rejected. To select a particular
installation, use `GTest_DIR` (directory containing `GTestConfig.cmake`) or add its
prefix to `CMAKE_PREFIX_PATH`. The build never downloads or upgrades GoogleTest.
Parent-provided `GTest::gtest` and `GTest::gtest_main` targets are still supported.

The shared ArrayFire test runner replaces the newer flag accessor:

```cpp
// v14
if (GTEST_FLAG_GET(list_tests)) {
    return RUN_ALL_TESTS();
}
// v15: GoogleTest 1.11-compatible
if (::testing::GTEST_FLAG(list_tests)) {
    return RUN_ALL_TESTS();
}
```

Test discovery remains ahead of ArrayFire device selection. The same backend
argument parsing, failure behavior, GoogleTest assertions, disabled timing tests,
filters, XML properties, and per-case CTest registrations are retained. The CMake
`GoogleTest` module's `PRE_TEST` option is supported by the project's CMake 3.20
minimum; it does not require upgrading the GoogleTest library itself.

## No production changes

All radar and interferometry headers/implementations are byte-for-byte identical
to v14. All test case bodies and the three test-directory/interferometry CMake
files are unchanged. Only the shared test runner, root package/version settings,
and release documentation differ; no compatibility header or additional runtime
checks are added.

## Build and run

From a clean extraction with ArrayFire 3.10 and GoogleTest 1.11 discoverable:

```sh
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release --no-tests=error --output-on-failure
# Only the two pipeline cases:
ctest --test-dir build-tests -C Release -R "PipelineTests" -V --no-tests=error
```

Replace `cuda` with `cpu` for the CPU backend. Select your installed SDK/package
paths as usual; no new tools or dependencies are required by v15. Consult
`VALIDATION.md` before interpreting this source update as a completed 1.11
compile/link or ArrayFire backend test.
