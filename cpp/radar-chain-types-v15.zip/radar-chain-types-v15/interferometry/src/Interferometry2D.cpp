#include <radar/interferometry/Interferometry2D.hpp>
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/types.hpp>
#include "device_helpers.hpp"
#include <cstddef>
#include <span>
#include <vector>

namespace radar::interferometry {
Interferometry2D::Interferometry2D(std::size_t azimuthElementCount, std::size_t elevationElementCount,
                                 double azimuthSpacingMeters, double elevationSpacingMeters,
                                 std::size_t detectionBatchSize) noexcept
    : azimuthElementCount_(azimuthElementCount), elevationElementCount_(elevationElementCount),
      azimuthSpacingMeters_(azimuthSpacingMeters), elevationSpacingMeters_(elevationSpacingMeters),
      detectionBatchSize_(detectionBatchSize) {}

void Interferometry2D::computeAngles(const af::array& elementIq, float azimuthScale,
                                    float elevationScale,
                                    af::array& azimuthRadians, af::array& elevationRadians) const {
    const af::array grid = af::moddims(elementIq, static_cast<dim_t>(azimuthElementCount_),
                                     static_cast<dim_t>(elevationElementCount_), elementIq.dims(1));
    const af::array lowerY = grid(detail::sequence(0, azimuthElementCount_ - 1), af::span, af::span);
    const af::array upperY = grid(detail::sequence(1, azimuthElementCount_ - 1), af::span, af::span);
    const af::array lowerZ = grid(af::span, detail::sequence(0, elevationElementCount_ - 1), af::span);
    const af::array upperZ = grid(af::span, detail::sequence(1, elevationElementCount_ - 1), af::span);
    // Each product array is dense after evaluation. Merge only baseline axes:
    // one reduction per spatial direction rather than two successive reductions.
    const dim_t detectionCount = elementIq.dims(1);
    const af::array correlationY = af::sum(af::moddims(af::conjg(lowerY) * upperY,
        static_cast<dim_t>((azimuthElementCount_ - 1) * elevationElementCount_), detectionCount), 0);
    const af::array correlationZ = af::sum(af::moddims(af::conjg(lowerZ) * upperZ,
        static_cast<dim_t>(azimuthElementCount_ * (elevationElementCount_ - 1)), detectionCount), 0);
    const af::array u = detail::phase(correlationY) * azimuthScale;
    const af::array v = detail::phase(correlationZ) * elevationScale;
    // Forward (+x) hemisphere; preserve azimuth/elevation coupling. No phase unwrapping
    // or clipping: an invalid direction cosine remains an invalid numerical result.
    azimuthRadians = af::atan2(u, af::sqrt(1.0f - u*u - v*v));
    elevationRadians = af::asin(v);
}

DetectionList Interferometry2D::estimate(const RangeDopplerMap& map, const DetectionList& detections) const {
    const double wavelengthMeters = detections.getMetadata().getWavelengthMeters();
    const float azimuthScale = static_cast<float>(wavelengthMeters / (2.0 * radar::pi * azimuthSpacingMeters_));
    const float elevationScale = static_cast<float>(wavelengthMeters / (2.0 * radar::pi * elevationSpacingMeters_));
    af::array planes;
    if (!detections.getIsEmpty()) {
        planes = af::moddims(map.getData(), map.getDopplerBinCount() * map.getRangeBinCount(),
                            map.getElementCount());
    }
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return detail::gather(planes, detections, first, count); },
        [&](const af::array& iq, af::array& azimuth, af::array& elevation) {
            computeAngles(iq, azimuthScale, elevationScale, azimuth, elevation);
        });
}

DetectionList Interferometry2D::estimate(std::span<const RangeDopplerMap> maps, const DetectionList& detections) const {
    const double wavelengthMeters = detections.getMetadata().getWavelengthMeters();
    const float azimuthScale = static_cast<float>(wavelengthMeters / (2.0 * radar::pi * azimuthSpacingMeters_));
    const float elevationScale = static_cast<float>(wavelengthMeters / (2.0 * radar::pi * elevationSpacingMeters_));
    // O(elementCount) local handles only; no persistent cache or full-map join.
    const auto planes = detections.getIsEmpty() ? std::vector<af::array>{} : detail::preparePlanes(maps);
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) {
            return detail::gather(std::span<const af::array>(planes), detections, first, count);
        },
        [&](const af::array& iq, af::array& azimuth, af::array& elevation) {
            computeAngles(iq, azimuthScale, elevationScale, azimuth, elevation);
        });
}

DetectionList Interferometry2D::estimate(const af::array& elementIq, const DetectionList& detections) const {
    const double wavelengthMeters = detections.getMetadata().getWavelengthMeters();
    const float azimuthScale = static_cast<float>(wavelengthMeters / (2.0 * radar::pi * azimuthSpacingMeters_));
    const float elevationScale = static_cast<float>(wavelengthMeters / (2.0 * radar::pi * elevationSpacingMeters_));
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return elementIq(af::span, detail::sequence(first, count)); },
        [&](const af::array& iq, af::array& azimuth, af::array& elevation) {
            computeAngles(iq, azimuthScale, elevationScale, azimuth, elevation);
        });
}
} // namespace radar::interferometry
