#include <radar/interferometry/Interferometry1D.hpp>
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/types.hpp>
#include "device_helpers.hpp"
#include <cstddef>
#include <span>
#include <vector>
#include <cmath>

namespace radar::interferometry {
Interferometry1D::Interferometry1D(double elementSpacingMeters, double assumedElevationRadians,
                                 std::size_t detectionBatchSize) noexcept
    : elementSpacingMeters_(elementSpacingMeters),
      assumedElevationRadians_(assumedElevationRadians), detectionBatchSize_(detectionBatchSize) {}

void Interferometry1D::computeAngles(const af::array& elementIq, float azimuthScale,
                                    af::array& azimuthRadians, af::array& elevationRadians) const {
    // Infer count from the actual gathered input; no duplicate count to keep in sync.
    const auto elementCount = static_cast<std::size_t>(elementIq.dims(0));
    const af::array lower = elementIq(detail::sequence(0, elementCount - 1), af::span);
    const af::array upper = elementIq(detail::sequence(1, elementCount - 1), af::span);
    const af::array correlation = af::sum(af::conjg(lower) * upper, 0);
    // Fixed positive-exponent convention. A line cannot independently measure elevation.
    azimuthRadians = af::asin(detail::phase(correlation) * azimuthScale);
    elevationRadians = af::constant(static_cast<float>(assumedElevationRadians_),
                                    azimuthRadians.dims(), f32);
}

DetectionList Interferometry1D::estimate(const RangeDopplerMap& map, const DetectionList& detections) const {
    const float azimuthScale = static_cast<float>(detections.getMetadata().getWavelengthMeters() /
        (2.0 * radar::pi * elementSpacingMeters_ * std::cos(assumedElevationRadians_)));
    af::array planes;
    if (!detections.getIsEmpty()) {
        planes = af::moddims(map.getData(), map.getDopplerBinCount() * map.getRangeBinCount(),
                            map.getElementCount());
    }
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return detail::gather(planes, detections, first, count); },
        [&](const af::array& iq, af::array& azimuth, af::array& elevation) {
            computeAngles(iq, azimuthScale, azimuth, elevation);
        });
}

DetectionList Interferometry1D::estimate(std::span<const RangeDopplerMap> maps, const DetectionList& detections) const {
    const float azimuthScale = static_cast<float>(detections.getMetadata().getWavelengthMeters() /
        (2.0 * radar::pi * elementSpacingMeters_ * std::cos(assumedElevationRadians_)));
    // O(elementCount) local handles only; no persistent cache or full-map join.
    const auto planes = detections.getIsEmpty() ? std::vector<af::array>{} : detail::preparePlanes(maps);
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) {
            return detail::gather(std::span<const af::array>(planes), detections, first, count);
        },
        [&](const af::array& iq, af::array& azimuth, af::array& elevation) {
            computeAngles(iq, azimuthScale, azimuth, elevation);
        });
}

DetectionList Interferometry1D::estimate(const af::array& elementIq, const DetectionList& detections) const {
    const float azimuthScale = static_cast<float>(detections.getMetadata().getWavelengthMeters() /
        (2.0 * radar::pi * elementSpacingMeters_ * std::cos(assumedElevationRadians_)));
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return elementIq(af::span, detail::sequence(first, count)); },
        [&](const af::array& iq, af::array& azimuth, af::array& elevation) {
            computeAngles(iq, azimuthScale, azimuth, elevation);
        });
}
} // namespace radar::interferometry
