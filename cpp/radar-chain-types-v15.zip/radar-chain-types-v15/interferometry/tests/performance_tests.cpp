#include <gtest/gtest.h>
#include <arrayfire.h>
#include <radar/CPI_Metadata.hpp>
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/interferometry/Interferometry1D.hpp>
#include <radar/interferometry/Interferometry2D.hpp>
#include <chrono>
#include <iostream>
#include <string>

namespace {
/** @brief Test-only warm timing of completed ArrayFire calls; not a GPU kernel-only timer. */
template<class Operation>
double meanMilliseconds(Operation&& operation) {
    constexpr int warmups=3, repetitions=20;
    for(int i=0;i<warmups;++i) { operation(); af::sync(); }
    const auto start=std::chrono::steady_clock::now();
    for(int i=0;i<repetitions;++i) { operation(); af::sync(); }
    const auto stop=std::chrono::steady_clock::now();
    return std::chrono::duration<double,std::milli>(stop-start).count()/repetitions;
}
}

/** @brief Opt-in 1D/2D timings: resident packed RDM gathers versus pre-gathered IQ. */
TEST(InterferometryPerformance, DISABLED_DeviceResidentAngleEstimation) {
    constexpr dim_t dopplers=128,ranges=2048,elements=12,detectionCount=8192;
    const radar::CPI_Metadata metadata(10e6,2000.0,10e9,5e6);
    const radar::RangeDopplerMap map(
        af::constant(1.0f,af::dim4(dopplers,ranges,elements),c32),metadata,0.0,15.0,dopplers);
    const af::array cells=af::range(af::dim4(detectionCount),0,u32);
    const auto detections=radar::DetectionList::fromMap(map,cells,
        af::constant(1.0f,cells.dims(),f32),af::constant(20.0f,cells.dims(),f32));
    const af::array gathered=af::reorder(
        af::lookup(af::moddims(map.getData(),dopplers*ranges,elements),cells,0),1,0,2,3);
    map.evaluate(); detections.evaluate(); gathered.eval(); af::sync();
    const double spacing=metadata.getWavelengthMeters()/2.0;
    const radar::interferometry::Interferometry1D linear(spacing);
    const radar::interferometry::Interferometry2D planar(4,3,spacing,spacing);
    auto output=detections;
    const double linearPacked=meanMilliseconds([&] { output=linear.estimate(map,detections); output.evaluate(); });
    const double linearGathered=meanMilliseconds([&] { output=linear.estimate(gathered,detections); output.evaluate(); });
    const double planarPacked=meanMilliseconds([&] { output=planar.estimate(map,detections); output.evaluate(); });
    const double planarGathered=meanMilliseconds([&] { output=planar.estimate(gathered,detections); output.evaluate(); });
    EXPECT_EQ(output.getDetectionCount(),static_cast<std::size_t>(detectionCount));
    EXPECT_TRUE(output.getHasAngles());
    EXPECT_NEAR(output.getAzimuthRadians().scalar<float>(),0.0f,1e-6f);
    EXPECT_NEAR(output.getElevationRadians().scalar<float>(),0.0f,1e-6f);
    RecordProperty("linear_packed_ms",std::to_string(linearPacked));
    RecordProperty("linear_gathered_ms",std::to_string(linearGathered));
    RecordProperty("planar_packed_ms",std::to_string(planarPacked));
    RecordProperty("planar_gathered_ms",std::to_string(planarGathered));
    std::cout << "8192 detections, 12 phase centers, batch 4096, mean ms/call including fence: "
              << "1D packed=" << linearPacked << ", 1D gathered=" << linearGathered
              << ", 2D packed=" << planarPacked << ", 2D gathered=" << planarGathered << '\n';
}
