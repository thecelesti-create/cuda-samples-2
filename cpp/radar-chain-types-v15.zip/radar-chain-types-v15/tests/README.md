# GoogleTest suites — v15

Tests are OFF by default. Enable RADAR_BUILD_TESTS=ON and supply GoogleTest 1.11+
through an installed config package or existing parent-provided targets. No
custom assertion framework, examples or automatic downloads are included.

## GoogleTest 1.11 baseline

The installed package requirement is `find_package(GTest 1.11 CONFIG REQUIRED)`.
The shared ArrayFire runner reads `::testing::GTEST_FLAG(list_tests)`, not the
newer `GTEST_FLAG_GET` macro. Discovery still returns before device initialization.
Existing parent-provided `GTest::gtest` / `GTest::gtest_main` targets are accepted;
the parent is responsible for supplying version 1.11 or newer. No FetchContent,
vendored framework, compatibility shim, or automatic upgrade is introduced.

Tests use `TEST`, basic `ASSERT_*` / `EXPECT_*`, `ASSERT_NO_FATAL_FAILURE`,
`SCOPED_TRACE`, `testing::Message`, and `Test::RecordProperty`. The disabled timing
tests and CLI filters are retained. CMake's `gtest_discover_tests` / `PRE_TEST`
are CMake features (the project requires CMake 3.20), not GoogleTest 1.12 features.
See `../VALIDATION.md` for the distinction between source review and executed tests.

| Runner | Cases | CTest prefix |
|---|---:|---|
| radar_metadata_tests | 3 | radar_metadata. |
| radar_arrayfire_tests | 15 (1 disabled) | radar_arrayfire. |
| radar_interferometry_reference_tests | 5 | radar_interferometry_reference. |
| radar_interferometry_tests | 14 (1 disabled) | radar_interferometry. |

Case counts describe source inventory, not execution status. See ../VALIDATION.md.

The chain runs in radar_arrayfire_tests:

- PipelineTests.ThreeFakeAlgorithms in simple_pipeline_tests.cpp: gain, reorder,
  fabricated cell zero, expected amplitude 2, SNR 6.0206 dB, I/Q 2+0i.
- PipelineTests.MatchedFilterDopplerDetection in reference_pipeline_tests.cpp:
  deterministic Barker echo at range sample 18 / Doppler bin 3, amplitude 112.

The actual angle estimator's synthetic fixture remains
InterferometryTests.SyntheticRectangularArray. New tests cover direct scalar
calibration, range crops, actual pulse count versus FFT padding, PRF propagation,
odd/even data shifts and sparse index remapping, whole-list replacement,
batched final export and explicit assignment of device-angle results. Angle tests retain packed,
separate-map and already-gathered c32 input cases, fixed-sign input, empty lists
and NaNs. New cases cover direct constructor parameters, inferred linear element
count, unequal rectangular spacing, CPI wavelength, and independence of spatial
phase convention from the CPI Doppler-sign setting.
The existing named-factory, action-name, component zero-test and tiny-signal
cases remain. v14 adds direct array construction without precursor objects,
complex power with nonzero quadrature, grouped optional-column evaluation, and
rectangular baseline reductions against an independent scalar model at distinct
cells. These cases cover all three angle-input forms and multiple block sizes.
The phase helper is included only by a test translation unit, not a public API.

There are 37 source cases: 35 default correctness cases and two disabled timing
cases. This is inventory, not execution status. See ../VALIDATION.md. The disabled
`ArrayFirePerformance.*` and `InterferometryPerformance.*` cases run only with
`--gtest_also_run_disabled_tests`; see ../PERFORMANCE.md for commands and what is
being timed. No standalone benchmark/example executable is introduced.

All checks run only in tests, including in Release mode.

```sh
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release --no-tests=error --output-on-failure
ctest --test-dir build-tests -C Release -R "PipelineTests" -V --no-tests=error
```

Use cpu/opencl instead of cuda for other installed backends. CMake's unified
configuration passes that argument to the ArrayFire test main; explicit backend
failure is not skipped or changed to a fallback. Direct-linked builds take no
backend argument. GTest discovery lists cases before backend initialization but
still requires shared libraries on the loader path.

```sh
./build-tests/tests/radar_arrayfire_tests cuda --gtest_filter="PipelineTests.*"
```

Visual Studio:

```powershell
.\build-tests\tests\Release\radar_arrayfire_tests.exe cuda --gtest_filter="PipelineTests.*"
```

Without ArrayFire, RADAR_BUILD_ARRAYFIRE_TYPES=OFF enables building the numeric
metadata library (there is no geometry library). With GTest installed and tests opted in, that
configuration also builds the metadata and independent phase-model suites.
Those are not substitutes for execution of the actual ArrayFire implementation.
