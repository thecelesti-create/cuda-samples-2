#include <gtest/gtest.h>
#include <arrayfire.h>
#include <radar/CPI_Metadata.hpp>
#include <radar/RangePulseBuffer.hpp>
#include <chrono>
#include <iostream>
#include <string>

namespace {
/** @brief Test-only mean call time after warmup; includes a device fence per call. */
template<class Operation>
double meanMilliseconds(Operation&& operation) {
    constexpr int warmups=3, repetitions=20;
    for (int i=0;i<warmups;++i) { operation(); af::sync(); }
    const auto start=std::chrono::steady_clock::now();
    for (int i=0;i<repetitions;++i) { operation(); af::sync(); }
    const auto stop=std::chrono::steady_clock::now();
    return std::chrono::duration<double,std::milli>(stop-start).count()/repetitions;
}
}

/** @brief Opt-in device-resident timings; no speed assertion or production benchmark dependency. */
TEST(ArrayFirePerformance, DISABLED_PowerAndDopplerReorder) {
    const radar::CPI_Metadata metadata(10e6,2000.0,10e9,5e6);
    const radar::RangePulseBuffer ranges(
        af::constant(1.0f,af::dim4(10000,800,5),c32),metadata,0.0,15.0);
    ranges.synchronize(); // Allocation/materialization is outside the timed region.
    af::array output;
    const double reference=meanMilliseconds([&] {
        output=af::real(ranges.getData()*af::conjg(ranges.getData()));
        output.eval();
    });
    output=af::array{};
    const double power=meanMilliseconds([&] { output=ranges.computePower(); output.eval(); });
    EXPECT_EQ(output.type(),f32);
    EXPECT_FLOAT_EQ(output.scalar<float>(),1.0f); // Test-only readback, AFTER timing.
    output=af::array{};
    const double reorder=meanMilliseconds([&] { output=ranges.reorderForDoppler(); output.eval(); });
    EXPECT_EQ(output.type(),c32);
    EXPECT_EQ(output.dims(0),800);
    EXPECT_EQ(output.dims(1),10000);
    RecordProperty("reference_power_ms",std::to_string(reference));
    RecordProperty("power_ms",std::to_string(power));
    RecordProperty("reorder_ms",std::to_string(reorder));
    std::cout << "Device-resident [10000,800,5], mean ms/call including fence: "
              << "reference power=" << reference << ", power=" << power
              << ", reorder=" << reorder << '\n';
}
