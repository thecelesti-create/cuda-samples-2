#include <utility>
#include <vector>
#include <radar/CPI_Metadata.hpp>
#include <radar/SamplePulseBuffer.hpp>
#include <radar/RangePulseBuffer.hpp>
#include "array_helpers.hpp"

namespace radar {
RangePulseBuffer::RangePulseBuffer(af::array iq, CPI_Metadata metadata,
                                   double firstRangeMeters, double rangeBinSpacingMeters)
    : iq_(std::move(iq)), metadata_(metadata), firstRangeMeters_(firstRangeMeters),
      rangeBinSpacingMeters_(rangeBinSpacingMeters) {
    const auto shape = iq_.dims();
    rangeBinCount_ = shape[0]; pulseCount_ = shape[1]; elementCount_ = shape[2];
}
RangePulseBuffer::RangePulseBuffer(const SamplePulseBuffer& source, af::array iq,
                                   double firstRangeMeters, double rangeBinSpacingMeters)
    : RangePulseBuffer(std::move(iq), source.getMetadata(),
                       firstRangeMeters, rangeBinSpacingMeters) {}
RangePulseBuffer::RangePulseBuffer(const SamplePulseBuffer& source, af::array iq)
    : RangePulseBuffer(std::move(iq), source.getMetadata(),
                       source.getMetadata().getFirstSampleRangeMeters(),
                       source.getMetadata().getSampleRangeSpacingMeters()) {}
af::array RangePulseBuffer::getPulse(dim_t pulseIndex, dim_t elementIndex) const {
    return iq_(af::span, detail::sequence(pulseIndex, 1), detail::sequence(elementIndex, 1));
}
af::array RangePulseBuffer::getElement(dim_t elementIndex) const {
    return iq_(af::span, af::span, detail::sequence(elementIndex, 1));
}
af::array RangePulseBuffer::getSlowTime(dim_t rangeBin, dim_t elementIndex) const {
    return iq_(detail::sequence(rangeBin, 1), af::span, detail::sequence(elementIndex, 1));
}
RangePulseBuffer RangePulseBuffer::sliceRanges(dim_t firstRangeBin, dim_t rangeBinCount) const {
    auto result = *this;
    result.iq_ = iq_(detail::sequence(firstRangeBin, rangeBinCount), af::span, af::span);
    result.firstRangeMeters_ = getRangeMeters(firstRangeBin);
    result.rangeBinCount_ = rangeBinCount;
    return result;
}
RangePulseBuffer RangePulseBuffer::slicePulses(dim_t firstPulse, dim_t pulseCount) const {
    auto result = *this;
    result.iq_ = iq_(af::span, detail::sequence(firstPulse, pulseCount), af::span);
    result.metadata_.setFirstPulseTimeSeconds(getPulseTimeSeconds(firstPulse));
    result.pulseCount_ = pulseCount;
    return result;
}
af::array RangePulseBuffer::reorderForDoppler() const { return af::reorder(iq_, 1, 0, 2, 3); }
af::array RangePulseBuffer::computePower() const { return detail::computePower(iq_); }
void RangePulseBuffer::setData(af::array iq) {
    iq_ = std::move(iq);
}
void RangePulseBuffer::setMetadata(CPI_Metadata metadata) {
    metadata_ = std::move(metadata);
}
RangePulseBuffer RangePulseBuffer::clone() const {
    auto result = *this;
    result.iq_ = iq_.copy();
    return result;
}
std::vector<af::cfloat> RangePulseBuffer::toHost() const { return detail::toHost(iq_); }
void RangePulseBuffer::evaluate() const { iq_.eval(); }
void RangePulseBuffer::synchronize() const { detail::synchronize(iq_); }
} // namespace radar
