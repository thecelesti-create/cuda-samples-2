# Performance review — v14 changes retained in v15

v15 changes only GoogleTest integration and release documentation. The library
implementation and both disabled performance tests are unchanged from v14.

This is a source-level optimization pass, **not a measured CPU/GPU certification**.
No ArrayFire runtime is installed in the generation environment; no latency,
speedup, bandwidth or device-memory measurements were obtained there.

## Changes actually made

| Path | Source-level change | Why it can help |
|---|---|---|
| Cube construction | One dims() query instead of three | Less host API overhead; no new scan |
| Power | I*I + Q*Q | Avoid a general complex multiplication/conjugate expression |
| Packed interferometry gather | Prepare [cell,element] view once | Reuse metadata/handle setup across blocks |
| Separate-map gather | Flatten each map once | Reuse per-map handles across blocks, without concatenation |
| 1D/2D scale factors | Compute once per estimate | Avoid repeated divisions/cosine in block processing |
| 2D correlations | Flatten baseline axes, then sum once per direction | Two array-reduction calls instead of four; kernel count is backend-dependent |
| Phase expression | Flatten input correlation, not output phase | Avoid an unnecessary materialization boundary in the lazy angle expression |
| Angle evaluation | af::eval(azimuth,elevation) | Allow shared JIT expressions to be evaluated together |
| Explicit list evaluation | Group equal-dtype, equal-shape columns | Permit common-subexpression reuse without mixing dtypes |

ArrayFire JIT can fuse elementwise arithmetic, but it controls the exact kernels
and allocation policy. A source-level removal does not prove a latency reduction;
for example, a compiler may already simplify part of the old complex expression.
The 2D summation order changes, so do not require bitwise equality. The tests use
numerical tolerances and retain NaN behavior for undefined directions.

## What intentionally stays

Large buffers are c32, and normal passes retain/move ArrayFire handles rather than
cloning data. Detection fields/angles stay on the selected backend. Only explicit
`toHost()` and `recordsToHost()` export values. `synchronize()` is an explicit
caller boundary. Interferometry has no host/scalar numerical reads or explicit
fences. It still gathers selected cells in bounded blocks instead of doing angle
work for every RDM cell. It has no persistent device cache or native CUDA buffer.

Each principal IQ block uses `8 * elementCount * min(K,batchSize)` logical bytes.
The complete two angle columns use `8*K` bytes. Lookup/reorder/reduction/JIT
intermediates and asynchronous memory pools add to this; it is **not** a hard
peak-memory bound. Separate input maps use a small O(elementCount) host vector of
ArrayFire handles. Pre-gathered input skips gather work entirely.

Contiguous RDMs are the low-memory precondition: flattening strided views can
materialize larger allocations. A transpose/reorder is real data movement.
Avoid keeping needless cube clones/old pipeline stages alive. No automatic cache
clears or synchronization calls were added to force allocator behavior.

Release optimization is still selected by the build. No global `-ffast-math`,
finite-math-only or precision reduction was added; NaNs remain meaningful outputs.
There is no process-global thread, backend, allocator or JIT configuration change.

## Opt-in measurements on your machine

Two disabled GoogleTest cases live in the existing test runners. They add no
library dependencies beyond ArrayFire and no default application targets.
They use three warmups and twenty timed calls with a device fence after each call.
Reported mean milliseconds include host launch/allocation and synchronization
overhead; they are not kernel-only timings or PCIe transfer measurements.
Input materialization is outside the timed region; correctness readback is after.
No fixed speed threshold is asserted.

Build with `RADAR_BUILD_TESTS=ON`, then run (unified backend, Linux/WSL):

```sh
./build-tests/tests/radar_arrayfire_tests cuda --gtest_also_run_disabled_tests --gtest_filter='ArrayFirePerformance.*'
./build-tests/tests/radar_interferometry_tests cuda --gtest_also_run_disabled_tests --gtest_filter='InterferometryPerformance.*'
```

Windows / Visual Studio:

```powershell
.\build-tests\tests\Release\radar_arrayfire_tests.exe cuda --gtest_also_run_disabled_tests --gtest_filter="ArrayFirePerformance.*"
.\build-tests\tests\Release\radar_interferometry_tests.exe cuda --gtest_also_run_disabled_tests --gtest_filter="InterferometryPerformance.*"
```

Use cpu/opencl for another backend, or omit the backend argument in a direct-linked
build. First run the ordinary correctness suites. Timings print to stdout and
are recorded as GoogleTest properties for an optional `--gtest_output=xml:...`.

The power test compares the prior conjugate expression with v14 power on a
resident 10000x800x5 cube, and times the Doppler reorder separately. These
measurements are executed sequentially, not randomized; repeat runs and control
thermal/power settings before drawing conclusions.
The interferometry test reports packed versus pre-gathered 1D and 2D calls for
8192 detections, 12 elements and batch size 4096. It is **not** a before/after
v13 interferometry speed comparison. It uses boresight synthetic IQ to exercise
the operation path, not to validate real-scene radar performance.

## API references used for the review

- JIT fusion/materialization: https://arrayfire.org/docs/jit.htm
- Simultaneous array evaluation: https://arrayfire.org/docs/group__data__mat.htm
- Reshape semantics: https://arrayfire.org/docs/group__manip__func__moddims.htm
- Reduction interface: https://arrayfire.org/docs/group__reduce__func__sum.htm
- Timing and synchronization: https://arrayfire.org/docs/timing.htm

Documentation review is not an SDK compile or execution test.
