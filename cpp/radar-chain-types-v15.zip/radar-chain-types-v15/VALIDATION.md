# Validation report — v15

## Scope

v15 lowers the GoogleTest package minimum to 1.11 and replaces the shared runner's
newer `GTEST_FLAG_GET(list_tests)` expression with
`::testing::GTEST_FLAG(list_tests)`. No library algorithms or APIs changed.

**No GoogleTest suite or ArrayFire backend was compiled/run here.** Neither SDK
is installed. An attempt to fetch the GoogleTest 1.11 source failed at DNS
resolution. Compatibility was assessed from the code's API usage; it is not a
verified build against the 1.11 headers/library. No fake framework, declaration
substitute, compatibility shim, or mocked ArrayFire runtime was used.

## Executed on this revision

| Check | Actual result |
|---|---|
| Metadata-only C++20 Release configure/build, GCC 14.2 | Passed |
| Metadata-only C++20 Release configure/build, Clang 17 | Passed |
| Independent host smoke/phase checks, GCC | 613 checks passed |
| Independent host smoke/phase checks, Clang | 613 checks passed |
| Same independent checks, GCC address + undefined-behavior sanitizers | 613 checks passed; no sanitizer errors |
| Existing source-organization / Doxygen-comment text audit | Passed |
| Four existing Docker shell scripts, `bash -n` | Passed (syntax only) |
| v14/v15 production-byte comparison | All 19 headers/implementation/helper files unchanged |
| v14/v15 test-case-byte comparison | All 9 test-case source files unchanged |
| GoogleTest API inventory | 37 source cases preserved: 35 default, 2 disabled |

The independent smoke program predates this compatibility change; its source is
retained as `validation/host-checks-source.txt` for reproducibility. It is not a
GoogleTest replacement and is not added to the normal project build. Its checks
exercise host metadata/record values and a separate scalar mathematical model,
not the actual ArrayFire library/estimators or their device memory behavior.

All command output and exit statuses were regenerated for v15. See
`validation/commands.json`, `gcc-*.txt`, `clang-*.txt`, `sanitizers-*.txt`,
`source-audit.txt`, `unchanged-source-audit.txt`, and `gtest-api-audit.txt`.

## API review

The source inventory uses native `TEST`, the ordinary equality/boolean/near
assertions, `ASSERT_NO_FATAL_FAILURE`, `SCOPED_TRACE`, `testing::Message`,
`Test::RecordProperty`, `InitGoogleTest`, and `RUN_ALL_TESTS`. There are no remaining
`GTEST_FLAG_GET` or `GTEST_FLAG_SET` uses in C++ code. The flag access in the shared
runner now uses the 1.11-style `GTEST_FLAG` interface.

CMake's per-case `gtest_discover_tests` registration is unchanged. The configured
`PRE_TEST` discovery mode is available in the CMake 3.20 baseline; it is not a
requirement for GoogleTest 1.12. Test labels, resource locks, timeouts, disabled
performance cases, backend arguments, and filters are retained.

The source audit does not establish actual 1.11 overload resolution, linking,
flag parsing, CTest discovery, or execution. A real 1.11 build is still required.

## Failed dependency attempts

- Tests enabled, ArrayFire disabled: CMake requests **GTest 1.11** and fails because
  no installed `GTestConfig.cmake` is present (`real-gtest-configure.txt`).
- Libraries enabled, tests disabled: CMake fails to find ArrayFire 3.10
  (`real-arrayfire-configure.txt`).
- Fetch exact GoogleTest 1.11 source: curl exits 6, unable to resolve
  `codeload.github.com` (`gtest-download-attempt.txt`). Web retrieval of the tagged
  headers was also unavailable; reference locations are not presented as fetched
  source evidence.

The Dockerfile is unchanged and unexecuted. It installs its base distribution's
`libgtest-dev`, not an exact-pinned 1.11 package. No native Windows/MSVC, CUDA,
OpenCL, ArrayFire CPU, GPU timing, or GPU allocation result is claimed.

## Run in the team's environment

With GoogleTest 1.11 and ArrayFire 3.10 discoverable:

```sh
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release --no-tests=error --output-on-failure
```

To select one of several installed GoogleTest packages, pass `GTest_DIR` pointing
to the desired installation's `GTestConfig.cmake` directory. A metadata-only
GoogleTest run can use `-DRADAR_BUILD_ARRAYFIRE_TYPES=OFF` with tests ON; that
exercises two real GoogleTest runners without needing ArrayFire.
