#include <radar/Detection.hpp>
#include <cstdint>
namespace radar {
Detection::Detection(std::uint32_t rangeIndex, std::uint32_t dopplerIndex,
                     float amplitude, float snrDb, std::complex<float> complexPairC32,
                     std::optional<float> azimuthRadians, std::optional<float> elevationRadians) noexcept
    : rangeIndex_(rangeIndex), dopplerIndex_(dopplerIndex), amplitude_(amplitude), snrDb_(snrDb),
      complexPairC32_(complexPairC32), azimuthRadians_(azimuthRadians), elevationRadians_(elevationRadians) {}
} // namespace radar
