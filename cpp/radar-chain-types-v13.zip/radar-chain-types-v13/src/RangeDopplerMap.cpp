#include <utility>
#include <vector>
#include <radar/CPI_Metadata.hpp>
#include <radar/RangePulseBuffer.hpp>
#include <radar/types.hpp>
#include <radar/RangeDopplerMap.hpp>
#include "array_helpers.hpp"

namespace radar {
RangeDopplerMap::RangeDopplerMap(af::array iqC32, CPI_Metadata metadata,
                                 double firstRangeMeters, double rangeBinSpacingMeters,
                                 dim_t integratedPulseCount, DopplerOrder order)
    : iqC32_(std::move(iqC32)), metadata_(metadata), firstRangeMeters_(firstRangeMeters),
      rangeBinSpacingMeters_(rangeBinSpacingMeters), integratedPulseCount_(integratedPulseCount),
      dopplerOrder_(order), dopplerBinCount_(iqC32_.dims(0)), rangeBinCount_(iqC32_.dims(1)),
      elementCount_(iqC32_.dims(2)) {}
RangeDopplerMap::RangeDopplerMap(const RangePulseBuffer& source, af::array iqC32, DopplerOrder order)
    : RangeDopplerMap(std::move(iqC32), source.getMetadata(), source.getFirstRangeMeters(),
                      source.getRangeBinSpacingMeters(), source.getPulseCount(), order) {}
af::array RangeDopplerMap::getElementC32(dim_t elementIndex) const {
    return iqC32_(af::span, af::span, detail::sequence(elementIndex, 1));
}
af::array RangeDopplerMap::getDopplerSpectrumC32(dim_t rangeBin, dim_t elementIndex) const {
    return iqC32_(af::span, detail::sequence(rangeBin, 1), detail::sequence(elementIndex, 1));
}
af::array RangeDopplerMap::getRangeProfileC32(dim_t dopplerBin, dim_t elementIndex) const {
    return iqC32_(detail::sequence(dopplerBin, 1), af::span, detail::sequence(elementIndex, 1));
}
af::array RangeDopplerMap::getElementVectorC32(dim_t rangeBin, dim_t dopplerBin) const {
    return af::flat(iqC32_(detail::sequence(dopplerBin, 1), detail::sequence(rangeBin, 1), af::span));
}
af::array RangeDopplerMap::computePower() const { return detail::computePower(iqC32_); }
af::array RangeDopplerMap::computePowerSumElements() const { return af::sum(computePower(), 2); }
RangeDopplerMap RangeDopplerMap::sliceRanges(dim_t firstRangeBin, dim_t rangeBinCount) const {
    auto result = *this;
    result.iqC32_ = iqC32_(af::span, detail::sequence(firstRangeBin, rangeBinCount), af::span);
    result.firstRangeMeters_ = getRangeMeters(firstRangeBin);
    result.rangeBinCount_ = rangeBinCount;
    return result;
}
void RangeDopplerMap::setDopplerOrder(DopplerOrder order) {
    if (order == dopplerOrder_) return;
    const int half = static_cast<int>(getDopplerBinCount() / 2); // Must fit int.
    af::array shifted = af::shift(iqC32_, order == DopplerOrder::Centered ? half : -half, 0, 0, 0);
    iqC32_ = std::move(shifted);
    dopplerOrder_ = order;
}
RangeDopplerMap RangeDopplerMap::withDopplerOrder(DopplerOrder order) const {
    auto result = *this;
    result.setDopplerOrder(order);
    return result;
}
af::array RangeDopplerMap::reorderToRangeFirstC32() const { return af::reorder(iqC32_, 1, 0, 2, 3); }
void RangeDopplerMap::setDataC32(af::array iqC32) {
    iqC32_ = std::move(iqC32);
}
void RangeDopplerMap::setMetadata(CPI_Metadata metadata) {
    metadata_ = std::move(metadata);
}
RangeDopplerMap RangeDopplerMap::clone() const {
    auto result = *this;
    result.iqC32_ = iqC32_.copy();
    return result;
}
std::vector<af::cfloat> RangeDopplerMap::toHost() const { return detail::toHost(iqC32_); }
void RangeDopplerMap::evaluate() const { iqC32_.eval(); }
void RangeDopplerMap::synchronize() const { detail::synchronize(iqC32_); }
} // namespace radar
