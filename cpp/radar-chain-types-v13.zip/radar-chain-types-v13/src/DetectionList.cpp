#include <cstddef>
#include <algorithm>
#include <complex>
#include <optional>
#include <utility>
#include <vector>
#include <radar/CPI_Metadata.hpp>
#include <radar/Detection.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/types.hpp>
#include <radar/DetectionList.hpp>
#include <cstdint>
#include "array_helpers.hpp"
namespace radar {
DetectionList::DetectionList(const RangeDopplerMap& source)
    : DetectionList(source.getMetadata(), source.getFirstRangeMeters(),
                    source.getRangeBinSpacingMeters(), source.getDopplerBinCount(),
                    source.getIntegratedPulseCount(), source.getDopplerOrder()) {}
DetectionList::DetectionList(CPI_Metadata metadata, double firstRangeMeters,
                             double rangeBinSpacingMeters, dim_t dopplerBinCount,
                             dim_t integratedPulseCount, DopplerOrder order)
    : metadata_(metadata), firstRangeMeters_(firstRangeMeters),
      rangeBinSpacingMeters_(rangeBinSpacingMeters), dopplerBinCount_(dopplerBinCount),
      integratedPulseCount_(integratedPulseCount), dopplerOrder_(order) {}
DetectionList::DetectionList(const RangeDopplerMap& source, af::array rangeIndices,
                             af::array dopplerIndices, af::array amplitudes,
                             af::array snrDb, af::array complexPairsC32)
    : DetectionList(source.getMetadata(), source.getFirstRangeMeters(),
                    source.getRangeBinSpacingMeters(), source.getDopplerBinCount(),
                    source.getIntegratedPulseCount(), source.getDopplerOrder(),
                    std::move(rangeIndices), std::move(dopplerIndices), std::move(amplitudes),
                    std::move(snrDb), std::move(complexPairsC32)) {}
DetectionList::DetectionList(CPI_Metadata metadata, double firstRangeMeters,
                             double rangeBinSpacingMeters, dim_t dopplerBinCount,
                             dim_t integratedPulseCount, DopplerOrder order,
                             af::array rangeIndices, af::array dopplerIndices,
                             af::array amplitudes, af::array snrDb, af::array complexPairsC32)
    : metadata_(metadata), firstRangeMeters_(firstRangeMeters),
      rangeBinSpacingMeters_(rangeBinSpacingMeters), dopplerBinCount_(dopplerBinCount),
      integratedPulseCount_(integratedPulseCount), dopplerOrder_(order),
      detectionCount_(static_cast<std::size_t>(rangeIndices.elements())),
      rangeIndices_(std::move(rangeIndices)), dopplerIndices_(std::move(dopplerIndices)),
      amplitudes_(std::move(amplitudes)), snrDb_(std::move(snrDb)),
      complexPairsC32_(std::move(complexPairsC32)) {}
DetectionList DetectionList::fromCells(const RangeDopplerMap& source, af::array linearCellIndices,
                                      af::array amplitudes, af::array snrDb, af::array complexPairsC32) {
    if (linearCellIndices.isempty()) return DetectionList(source);
    const af::array stride = af::constant(static_cast<unsigned>(source.getDopplerBinCount()),
                                         linearCellIndices.dims(), u32);
    af::array ranges = linearCellIndices / stride;
    af::array dopplers = linearCellIndices - ranges * stride;
    return {source, std::move(ranges), std::move(dopplers), std::move(amplitudes),
            std::move(snrDb), std::move(complexPairsC32)};
}
DetectionList DetectionList::fromMap(const RangeDopplerMap& source, af::array linearCellIndices,
                                    af::array amplitudes, af::array snrDb, dim_t elementIndex) {
    if (linearCellIndices.isempty()) return DetectionList(source);
    // Select one contiguous element plane, then gather only K values on device.
    af::array iqC32 = af::lookup(af::flat(source.getElementC32(elementIndex)), linearCellIndices, 0);
    return fromCells(source, std::move(linearCellIndices), std::move(amplitudes),
                     std::move(snrDb), std::move(iqC32));
}
void DetectionList::setDetections(af::array ranges, af::array dopplers, af::array amplitudes,
                                  af::array snrDb, af::array iqC32) {
    const auto count = static_cast<std::size_t>(ranges.elements());
    rangeIndices_ = std::move(ranges); dopplerIndices_ = std::move(dopplers);
    amplitudes_ = std::move(amplitudes); snrDb_ = std::move(snrDb);
    complexPairsC32_ = std::move(iqC32); detectionCount_ = count;
    clearAngles();
}
void DetectionList::setDopplerOrder(DopplerOrder order) {
    if (order == dopplerOrder_) return;
    if (!getIsEmpty()) {
        // Array operands retain u32 arithmetic. Selection avoids valid-output overflow.
        const auto half = static_cast<unsigned>(dopplerBinCount_ / 2);
        const auto other = static_cast<unsigned>(dopplerBinCount_) - half;
        const af::array halfBins = af::constant(half, dopplerIndices_.dims(), u32);
        const af::array otherBins = af::constant(other, dopplerIndices_.dims(), u32);
        af::array remapped;
        if (order == DopplerOrder::Centered) {
            remapped = af::select(dopplerIndices_ >= otherBins,
                                 dopplerIndices_ - otherBins, dopplerIndices_ + halfBins);
        } else {
            remapped = af::select(dopplerIndices_ >= halfBins,
                                 dopplerIndices_ - halfBins, dopplerIndices_ + otherBins);
        }
        dopplerIndices_ = std::move(remapped);
    }
    dopplerOrder_ = order;
}
void DetectionList::setAmplitudes(af::array amplitudes) { amplitudes_ = std::move(amplitudes); }
void DetectionList::setSnrDb(af::array snrDb) { snrDb_ = std::move(snrDb); }
void DetectionList::setComplexPairsC32(af::array complexPairsC32) { complexPairsC32_ = std::move(complexPairsC32); }
void DetectionList::setAzimuthRadians(af::array azimuthRadians) { azimuthRadians_ = std::move(azimuthRadians); }
void DetectionList::setElevationRadians(af::array elevationRadians) { elevationRadians_ = std::move(elevationRadians); }
void DetectionList::setAngles(af::array azimuthRadians, af::array elevationRadians) {
    azimuthRadians_ = std::move(azimuthRadians); elevationRadians_ = std::move(elevationRadians);
}
void DetectionList::clearAngles() noexcept { azimuthRadians_.reset(); elevationRadians_.reset(); }
DetectionList DetectionList::getDetection(std::size_t detectionIndex) const {
    const auto one = detail::sequence(static_cast<std::int64_t>(detectionIndex), 1);
    auto result = *this;
    result.detectionCount_ = 1;
    result.rangeIndices_ = rangeIndices_(one); result.dopplerIndices_ = dopplerIndices_(one);
    result.amplitudes_ = amplitudes_(one); result.snrDb_ = snrDb_(one);
    result.complexPairsC32_ = complexPairsC32_(one);
    if (azimuthRadians_) result.azimuthRadians_ = af::array((*azimuthRadians_)(one));
    if (elevationRadians_) result.elevationRadians_ = af::array((*elevationRadians_)(one));
    return result;
}
DetectionList DetectionList::select(const af::array& detectionIndices) const {
    auto result = *this;
    result.detectionCount_ = static_cast<std::size_t>(detectionIndices.elements());
    if (result.getIsEmpty()) {
        result.rangeIndices_ = af::array{}; result.dopplerIndices_ = af::array{}; result.amplitudes_ = af::array{};
        result.snrDb_ = af::array{}; result.complexPairsC32_ = af::array{};
        if (azimuthRadians_) result.azimuthRadians_ = af::array{};
        if (elevationRadians_) result.elevationRadians_ = af::array{};
        return result;
    }
    result.rangeIndices_ = af::lookup(rangeIndices_, detectionIndices, 0);
    result.dopplerIndices_ = af::lookup(dopplerIndices_, detectionIndices, 0);
    result.amplitudes_ = af::lookup(amplitudes_, detectionIndices, 0);
    result.snrDb_ = af::lookup(snrDb_, detectionIndices, 0);
    result.complexPairsC32_ = af::lookup(complexPairsC32_, detectionIndices, 0);
    if (azimuthRadians_) result.azimuthRadians_ = af::lookup(*azimuthRadians_, detectionIndices, 0);
    if (elevationRadians_) result.elevationRadians_ = af::lookup(*elevationRadians_, detectionIndices, 0);
    return result;
}
DetectionList DetectionList::clone() const {
    auto result = *this;
    if (getIsEmpty()) return result;
    result.rangeIndices_ = rangeIndices_.copy(); result.dopplerIndices_ = dopplerIndices_.copy();
    result.amplitudes_ = amplitudes_.copy(); result.snrDb_ = snrDb_.copy();
    result.complexPairsC32_ = complexPairsC32_.copy();
    if (azimuthRadians_) result.azimuthRadians_ = azimuthRadians_->copy();
    if (elevationRadians_) result.elevationRadians_ = elevationRadians_->copy();
    return result;
}
af::array DetectionList::getRangesMeters() const {
    if (getIsEmpty()) return {};
    return rangeIndices_.as(f32) * static_cast<float>(rangeBinSpacingMeters_) +
           static_cast<float>(firstRangeMeters_);
}
af::array DetectionList::getDopplerHz() const {
    if (getIsEmpty()) return {};
    // Keep indices integral through signed-bin decoding, including values > 2^24.
    const af::array bins = dopplerIndices_.as(s64);
    const auto fftSize = static_cast<long long>(dopplerBinCount_);
    const af::array length = af::constant(fftSize, bins.dims(), s64);
    af::array signedBins;
    if (dopplerOrder_ == DopplerOrder::Centered) {
        signedBins = bins - af::constant(fftSize / 2, bins.dims(), s64);
    } else {
        const af::array lastPositive = af::constant((fftSize - 1) / 2, bins.dims(), s64);
        signedBins = af::select(bins <= lastPositive, bins, bins - length);
    }
    return signedBins.as(f32) * static_cast<float>(getDopplerBinSpacingHz());
}
af::array DetectionList::getRadialVelocitiesMps() const {
    if (getIsEmpty()) return {};
    return getDopplerHz() * static_cast<float>(metadata_.getRadialVelocityMps(1.0));
}
af::array DetectionList::getPositionsMeters() const {
    if (getIsEmpty()) return {};
    const af::array ranges = getRangesMeters();
    const af::array horizontal = ranges * af::cos(*elevationRadians_);
    const af::array xyz = af::join(1, horizontal * af::cos(*azimuthRadians_),
                                 horizontal * af::sin(*azimuthRadians_), ranges * af::sin(*elevationRadians_));
    return af::reorder(xyz, 1, 0, 2, 3);
}
std::vector<Detection> DetectionList::recordsToHost(std::size_t batchSize) const {
    std::vector<Detection> records;
    if (getIsEmpty()) return records;
    records.reserve(detectionCount_);
    const auto capacity = std::min(batchSize, detectionCount_);
    std::vector<unsigned> ranges(capacity), dopplers(capacity);
    std::vector<float> amplitudes(capacity), snr(capacity);
    std::vector<af::cfloat> iqC32(capacity);
    std::vector<float> azimuth(getHasAzimuth() ? capacity : 0);
    std::vector<float> elevation(getHasElevation() ? capacity : 0);
    for (std::size_t first = 0; first < detectionCount_;) {
        const auto count = std::min(capacity, detectionCount_ - first);
        const auto block = detail::sequence(static_cast<std::int64_t>(first),
                                            static_cast<std::int64_t>(count));
        // Explicit materialization of proxies into af::array before host export.
        af::array(rangeIndices_(block)).host(ranges.data());
        af::array(dopplerIndices_(block)).host(dopplers.data());
        af::array(amplitudes_(block)).host(amplitudes.data());
        af::array(snrDb_(block)).host(snr.data());
        af::array(complexPairsC32_(block)).host(iqC32.data());
        if (azimuthRadians_) af::array((*azimuthRadians_)(block)).host(azimuth.data());
        if (elevationRadians_) af::array((*elevationRadians_)(block)).host(elevation.data());
        for (std::size_t i = 0; i < count; ++i) {
            records.emplace_back(ranges[i], dopplers[i], amplitudes[i], snr[i],
                std::complex<float>(iqC32[i].real, iqC32[i].imag),
                azimuthRadians_ ? std::optional<float>(azimuth[i]) : std::nullopt,
                elevationRadians_ ? std::optional<float>(elevation[i]) : std::nullopt);
        }
        first += count;
    }
    return records;
}
void DetectionList::evaluate() const {
    if (getIsEmpty()) return;
    rangeIndices_.eval(); dopplerIndices_.eval(); amplitudes_.eval(); snrDb_.eval(); complexPairsC32_.eval();
    if (azimuthRadians_) azimuthRadians_->eval();
    if (elevationRadians_) elevationRadians_->eval();
}
void DetectionList::synchronize() const { evaluate(); af::sync(); }
} // namespace radar
