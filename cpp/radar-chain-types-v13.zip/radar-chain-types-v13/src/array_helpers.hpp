#pragma once
#include <cstddef>
#include <radar/detail/ArrayFire.hpp>
#include <cstdint>
#include <vector>

namespace radar::detail {
// Precondition-only helpers. No bounds, dtype, context, overflow or value checks.
/** @brief Make an unchecked inclusive ArrayFire sequence from first/count; count must be positive. */
inline af::seq sequence(std::int64_t first, std::int64_t count) {
    return af::seq(static_cast<double>(first), static_cast<double>(first + count - 1));
}
/** @brief Compute f32 magnitude squared from c32 input on the active backend. */
inline af::array computePower(const af::array& data) {
    return af::real(data * af::conjg(data));
}
/** @brief Explicitly evaluate and fence the active device. */
inline void synchronize(const af::array& data) {
    data.eval();
    af::sync();
}
/** @brief Explicit blocking download of c32 input into host float I/Q pairs. */
inline std::vector<af::cfloat> toHost(const af::array& data) {
    std::vector<af::cfloat> result(static_cast<std::size_t>(data.elements()));
    if (!result.empty()) data.host(result.data());
    return result;
}
} // namespace radar::detail
