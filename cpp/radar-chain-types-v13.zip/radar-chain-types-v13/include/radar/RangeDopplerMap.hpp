#pragma once
#include <radar/detail/ArrayFire.hpp>
#include <cstdint>
#include <cstddef>
#include <vector>
#include <radar/CPI_Metadata.hpp>
#include <radar/types.hpp>

#include <radar/RangePulseBuffer.hpp>

namespace radar {

// Complex Doppler spectra: [Doppler, range, element, 1], not just power.
// All indexed helpers are UNCHECKED: valid indices/slices and an active owning
// ArrayFire backend/device are caller preconditions. The wrapper performs no runtime validation.
/**
 * @brief c32 complex single-precision IQ stored as [Doppler,range,element,1].
 * @details c32 means two float components (I,Q), eight bytes per value. This
 * class never auto-casts f32/c64 input, validates input, or implicitly downloads IQ.
 * @pre All adopted arrays are c32 and satisfy this layout on the active device.
 * Indexed helpers require valid indices/counts. Copies retain ArrayFire handles;
 * use clone() only when an independent allocation is explicitly required.
 */
class RangeDopplerMap final {
public:
    /** @brief Adopt c32 [Doppler,range,element] IQ with direct processed calibration.
     * @param iqC32 Already-computed c32 spectra; FFT size is inferred from dim0.
     * @param metadata Acquisition/waveform description, including PRF and bandwidth.
     * @param firstRangeMeters Calibrated range of output range bin zero.
     * @param rangeBinSpacingMeters Processed range spacing; may differ from ADC spacing.
     * @param integratedPulseCount Actual integrated pulses, excluding FFT padding.
     * @param order Existing storage order; the constructor does not shift data.
     * @pre FFT size >= integratedPulseCount > 0; correct c32 layout/device; no checks. */
    RangeDopplerMap(af::array iqC32, CPI_Metadata metadata,
                   double firstRangeMeters, double rangeBinSpacingMeters,
                   dim_t integratedPulseCount, DopplerOrder order = DopplerOrder::Unshifted);
    // Adopts [D,R,E,1] FFT output. Allows zero padding, not pulse truncation.
    /** @brief Construct or adopt c32 IQ using the documented layout; no implicit dtype conversion or validation. */
    RangeDopplerMap(const RangePulseBuffer& source, af::array dopplerIqC32,
                   DopplerOrder order = DopplerOrder::Unshifted);

    /** @brief Get the c32 complex IQ array by const reference; no copy or download. */
    [[nodiscard]] const af::array& getDataC32() const noexcept { return iqC32_; }
    /** @brief Get CPI metadata by const reference. */
    [[nodiscard]] const CPI_Metadata& getMetadata() const noexcept { return metadata_; }
    /** @brief Get the number of Doppler FFT bins, including padding. */
    [[nodiscard]] dim_t getDopplerBinCount() const noexcept { return dopplerBinCount_; }
    /** @brief Get the number of processed range bins. */
    [[nodiscard]] dim_t getRangeBinCount() const noexcept { return rangeBinCount_; }
    // Hardware element count (dim2), not getDataC32().elements() total IQ values.
    /** @brief Get hardware element count, not total ArrayFire value count. */
    [[nodiscard]] dim_t getElementCount() const noexcept { return elementCount_; }
    /** @brief Get the documented four-dimensional storage shape; final dimension is one. */
    [[nodiscard]] af::dim4 getDimensions() const { return af::dim4(dopplerBinCount_, rangeBinCount_, elementCount_); }
    /** @brief Get logical c32 payload bytes, excluding ArrayFire allocator/workspace overhead. */
    [[nodiscard]] std::size_t getBytes() const noexcept {
        return static_cast<std::size_t>(dopplerBinCount_) * static_cast<std::size_t>(rangeBinCount_) *
               static_cast<std::size_t>(elementCount_) * sizeof(af::cfloat);
    }
    // Semantic argument order stays range, Doppler, element despite [D,R,E].
    /** @brief Compute an unchecked logical column-major index; not a pointer offset into a strided view. */
    [[nodiscard]] std::size_t getLinearIndex(dim_t rangeBin, dim_t dopplerBin, dim_t elementIndex) const noexcept {
        return static_cast<std::size_t>(dopplerBin) + static_cast<std::size_t>(dopplerBinCount_) *
               (static_cast<std::size_t>(rangeBin) + static_cast<std::size_t>(rangeBinCount_) *
                static_cast<std::size_t>(elementIndex));
    }
    /** @brief Get calibrated output bin-zero range in meters. */
    [[nodiscard]] double getFirstRangeMeters() const noexcept { return firstRangeMeters_; }
    /** @brief Get processed range-bin spacing in meters. */
    [[nodiscard]] double getRangeBinSpacingMeters() const noexcept { return rangeBinSpacingMeters_; }
    /** @brief Get range in meters for a valid range bin. */
    [[nodiscard]] double getRangeMeters(dim_t rangeBin) const noexcept { return firstRangeMeters_ + static_cast<double>(rangeBin) * rangeBinSpacingMeters_; }
    /** @brief Get actual integrated pulse count; excludes FFT padding. */
    [[nodiscard]] dim_t getIntegratedPulseCount() const noexcept { return integratedPulseCount_; }
    /** @brief Get the storage order of Doppler bins. */
    [[nodiscard]] DopplerOrder getDopplerOrder() const noexcept { return dopplerOrder_; }
    /** @brief Get PRF/Nfft frequency grid spacing, not waveform resolution. */
    [[nodiscard]] double getDopplerBinSpacingHz() const noexcept {
        return metadata_.getPrfHz() / static_cast<double>(dopplerBinCount_);
    }
    /** @brief Get actual integrated pulses/PRF duration, excluding padding. */
    [[nodiscard]] double getCoherentIntervalSeconds() const noexcept {
        return static_cast<double>(integratedPulseCount_) / metadata_.getPrfHz();
    }
    /** @brief Convert a valid array bin to signed FFT-bin index; even Nyquist is negative. */
    [[nodiscard]] std::int64_t getSignedDopplerBin(dim_t bin) const noexcept {
        if (dopplerOrder_ == DopplerOrder::Centered) return bin - dopplerBinCount_ / 2;
        return bin <= (dopplerBinCount_ - 1) / 2 ? bin : bin - dopplerBinCount_;
    }
    /** @brief Get Doppler frequency in Hz for a valid Doppler bin. */
    [[nodiscard]] double getDopplerHz(dim_t dopplerBin) const noexcept { return static_cast<double>(getSignedDopplerBin(dopplerBin)) * getDopplerBinSpacingHz(); }
    /** @brief Get monostatic radial velocity in m/s, positive receding. */
    [[nodiscard]] double getRadialVelocityMps(dim_t dopplerBin) const noexcept {
        return metadata_.getRadialVelocityMps(getDopplerHz(dopplerBin));
    }
    /** @brief Get the c32 two-dimensional plane for one valid element; storage may be shared. */
    [[nodiscard]] af::array getElementC32(dim_t elementIndex) const;
    /** @brief Get a c32 Doppler spectrum at a valid range and element. */
    [[nodiscard]] af::array getDopplerSpectrumC32(dim_t rangeBin, dim_t elementIndex) const;
    /** @brief Get a c32 range profile at a valid Doppler bin and element. */
    [[nodiscard]] af::array getRangeProfileC32(dim_t dopplerBin, dim_t elementIndex) const;
    /** @brief Get c32 values across all elements at one valid range-Doppler cell. */
    [[nodiscard]] af::array getElementVectorC32(dim_t rangeBin, dim_t dopplerBin) const;
    /** @brief Compute f32 noncoherent power sum over the element dimension. */
    [[nodiscard]] af::array computePowerSumElements() const;
    /** @brief Return a c32 range crop with updated range count and origin. */
    [[nodiscard]] RangeDopplerMap sliceRanges(dim_t firstRangeBin, dim_t rangeBinCount) const;
    /** @brief Return a map with c32 data shifted to the requested Doppler order. */
    [[nodiscard]] RangeDopplerMap withDopplerOrder(DopplerOrder order) const;
    /** @brief Reorder c32 [Doppler,range,element] to [range,Doppler,element]. */
    [[nodiscard]] af::array reorderToRangeFirstC32() const;
    /** @brief Compute f32 squared complex magnitude on the current backend; c32 IQ is preserved. */
    [[nodiscard]] af::array computePower() const;

    // Replacement is unchecked. Shape/layout and
    // backend/device must stay unchanged; constructors support intentional changes.
    /** @brief Adopt c32 replacement IQ; same shape and device are unchecked preconditions. */
    void setDataC32(af::array iqC32);
    /** @brief Replace numeric CPI metadata without validation; acquisition/grid consistency is the caller's responsibility. */
    void setMetadata(CPI_Metadata metadata);
    /** @brief Set calibrated range of bin zero; metadata only. */
    void setFirstRangeMeters(double value) noexcept { firstRangeMeters_ = value; }
    /** @brief Set processed range-bin spacing; metadata only. */
    void setRangeBinSpacingMeters(double value) noexcept { rangeBinSpacingMeters_ = value; }
    /** @brief Set actual integrated pulse count; does not resize/transform data. */
    void setIntegratedPulseCount(dim_t value) noexcept { integratedPulseCount_ = value; }
    // Explicitly shifts DATA and changes ordering metadata together, odd/even safe.
    /** @brief Shift c32 data and ordering metadata together; handles odd/even FFT lengths. */
    void setDopplerOrder(DopplerOrder order);
    /** @brief Explicitly deep-copy c32 payload; ordinary wrapper copies retain ArrayFire storage. */
    [[nodiscard]] RangeDopplerMap clone() const; // Explicit deep copy, no revalidation.
    /** @brief EXPLICIT blocking download of c32 IQ into float I/Q host pairs. */
    [[nodiscard]] std::vector<af::cfloat> toHost() const;
    /** @brief Request ArrayFire evaluation without an explicit device fence. */
    void evaluate() const;
    /** @brief Evaluate and explicitly wait for the active owning device; no host download. */
    void synchronize() const;

private:
    af::array iqC32_;
    CPI_Metadata metadata_;
    double firstRangeMeters_;
    double rangeBinSpacingMeters_;
    dim_t integratedPulseCount_;
    DopplerOrder dopplerOrder_;
    // Cached at construction and updated by trusted slice helpers only.
    dim_t dopplerBinCount_;
    dim_t rangeBinCount_;
    dim_t elementCount_;
};
} // namespace radar
