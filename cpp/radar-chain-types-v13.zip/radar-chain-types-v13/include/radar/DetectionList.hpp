#pragma once
#include <radar/detail/ArrayFire.hpp>
#include <cstddef>
#include <cstdint>
#include <radar/CPI_Metadata.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/Detection.hpp>
#include <optional>
#include <vector>
namespace radar {
/**
 * @brief Device-resident detection list with five required columns and optional angles.
 * @details Columns are u32 range/Doppler indices, f32 linear amplitudes/SNR-dB,
 * and c32 complex I/Q pairs. Every column has shape [detectionCount,1,1,1].
 * Each complex pair is ONE representative I/Q value, NOT an element snapshot.
 * Optional f32 azimuth/elevation columns use radians; absence allocates no array.
 * Presence is per column/list; a present NaN marks an invalid individual result.
 * This is a logical record list with private structure-of-arrays storage, not an
 * array of C++ Detection objects. Host Detection values are explicit exports only.
 * CPI metadata and direct range/Doppler calibration occur once per list. No full RDM or element snapshots are held.
 * @pre Columns are aligned, correctly typed and on the active owning backend/device.
 * No validation, dtype conversion, scalar readback or synchronization is implicit.
 */
class DetectionList final {
public:
    /** @brief Construct an empty list with the source map's metadata/grids. */
    explicit DetectionList(const RangeDopplerMap& source);
    /** @brief Construct an empty list from direct source calibration, without an RDM.
     * @param metadata Acquisition/waveform data; PRF is not stored again elsewhere.
     * @param firstRangeMeters Source range-bin-zero position in meters.
     * @param rangeBinSpacingMeters Source processed range spacing in meters.
     * @param dopplerBinCount Source FFT length including padding, not detection count.
     * @param integratedPulseCount Actual pulses integrated, excluding padding.
     * @param order Storage order for the future Doppler-index column.
     * @pre Positive valid counts/spacing and correct active device; unchecked. */
    DetectionList(CPI_Metadata metadata, double firstRangeMeters, double rangeBinSpacingMeters,
                  dim_t dopplerBinCount, dim_t integratedPulseCount,
                  DopplerOrder order = DopplerOrder::Unshifted);
    /**
     * @brief Adopt five device columns without copying their numerical payloads.
     * @param source Source grid; its IQ is NOT retained.
     * @param rangeIndices u32 [K] range indices in the source grid.
     * @param dopplerIndices u32 [K] Doppler indices in source FFT order.
     * @param amplitudes f32 [K] linear detector magnitudes, not powers.
     * @param snrDb f32 [K] detector-provided SNR in decibels.
     * @param complexPairsC32 c32 [K] representative complex I/Q per detection.
     */
    DetectionList(const RangeDopplerMap& source, af::array rangeIndices, af::array dopplerIndices,
                  af::array amplitudes, af::array snrDb, af::array complexPairsC32);
    /** @brief Adopt columns with detached metadata/grids; same column contracts as above. */
    DetectionList(CPI_Metadata metadata, double firstRangeMeters, double rangeBinSpacingMeters,
                  dim_t dopplerBinCount, dim_t integratedPulseCount, DopplerOrder order,
                  af::array rangeIndices, af::array dopplerIndices, af::array amplitudes,
                  af::array snrDb, af::array complexPairsC32);
    /**
     * @brief Decode u32 linear cell indices and adopt already-gathered c32 I/Q.
     * @details cell = Doppler index + Doppler bin count * range index.
     * All numerical arguments are [K]; no RDM gather or host transfer occurs.
     */
    [[nodiscard]] static DetectionList fromCells(const RangeDopplerMap& source,
        af::array linearCellIndices, af::array amplitudes, af::array snrDb, af::array complexPairsC32);
    /**
     * @brief Decode cell indices and gather ONE selected element's c32 I/Q column.
     * @param elementIndex Representative element/beam, default zero.
     * @details Supplied amplitudes/SNR are not recalculated from that element;
     * a detector may have used a different combined signal. No E-by-K snapshot.
     */
    [[nodiscard]] static DetectionList fromMap(const RangeDopplerMap& source,
        af::array linearCellIndices, af::array amplitudes, af::array snrDb, dim_t elementIndex = 0);
    /** @brief Get number of detections, without querying device values. */
    [[nodiscard]] std::size_t getDetectionCount() const noexcept { return detectionCount_; }
    /** @brief Get whether the list is empty. */
    [[nodiscard]] bool getIsEmpty() const noexcept { return detectionCount_ == 0; }
    /** @brief Get CPI metadata stored once per list. */
    [[nodiscard]] const CPI_Metadata& getMetadata() const noexcept { return metadata_; }
    /** @brief Get calibrated range of source bin zero in meters. */
    [[nodiscard]] double getFirstRangeMeters() const noexcept { return firstRangeMeters_; }
    /** @brief Get source range-bin spacing in meters. */
    [[nodiscard]] double getRangeBinSpacingMeters() const noexcept { return rangeBinSpacingMeters_; }
    /** @brief Get source FFT length, including padding; not detection count. */
    [[nodiscard]] dim_t getDopplerBinCount() const noexcept { return dopplerBinCount_; }
    /** @brief Get actual integrated pulse count, excluding padding. */
    [[nodiscard]] dim_t getIntegratedPulseCount() const noexcept { return integratedPulseCount_; }
    /** @brief Get storage order used by the Doppler-index column. */
    [[nodiscard]] DopplerOrder getDopplerOrder() const noexcept { return dopplerOrder_; }
    /** @brief Get source PRF/Nfft frequency grid spacing in Hz. */
    [[nodiscard]] double getDopplerBinSpacingHz() const noexcept {
        return metadata_.getPrfHz() / static_cast<double>(dopplerBinCount_);
    }
    /** @brief Get actual integrated pulses/PRF duration in seconds. */
    [[nodiscard]] double getCoherentIntervalSeconds() const noexcept {
        return static_cast<double>(integratedPulseCount_) / metadata_.getPrfHz();
    }
    /** @brief Convert a supplied range BIN (not detection index) to meters; no device access. */
    [[nodiscard]] double getRangeMetersForBin(std::uint32_t bin) const noexcept {
        return firstRangeMeters_ + static_cast<double>(bin) * rangeBinSpacingMeters_;
    }
    /** @brief Convert a supplied Doppler BIN (not detection index) to Hz; no device access. */
    [[nodiscard]] double getDopplerHzForBin(std::uint32_t bin) const noexcept {
        const auto value = static_cast<std::int64_t>(bin);
        const auto length = static_cast<std::int64_t>(dopplerBinCount_);
        const auto signedBin = dopplerOrder_ == DopplerOrder::Centered
            ? value - length / 2 : (value <= (length - 1) / 2 ? value : value - length);
        return static_cast<double>(signedBin) * getDopplerBinSpacingHz();
    }
    /** @brief Get u32 [K] range indices. */
    [[nodiscard]] const af::array& getRangeIndices() const noexcept { return rangeIndices_; }
    /** @brief Get u32 [K] Doppler indices. */
    [[nodiscard]] const af::array& getDopplerIndices() const noexcept { return dopplerIndices_; }
    /** @brief Get f32 [K] linear amplitudes, not powers. */
    [[nodiscard]] const af::array& getAmplitudes() const noexcept { return amplitudes_; }
    /** @brief Get f32 [K] stored SNR in dB, without recomputation. */
    [[nodiscard]] const af::array& getSnrDb() const noexcept { return snrDb_; }
    /** @brief Get c32 [K] representative I/Q pairs, not per-element vectors. */
    [[nodiscard]] const af::array& getComplexPairsC32() const noexcept { return complexPairsC32_; }
    /** @brief Get whether azimuth has been supplied, even for an empty list. */
    [[nodiscard]] bool getHasAzimuth() const noexcept { return azimuthRadians_.has_value(); }
    /** @brief Get whether elevation has been supplied, even for an empty list. */
    [[nodiscard]] bool getHasElevation() const noexcept { return elevationRadians_.has_value(); }
    /** @brief Get whether both angle columns have been supplied. */
    [[nodiscard]] bool getHasAngles() const noexcept { return getHasAzimuth() && getHasElevation(); }
    /** @brief Get f32 [K] azimuth radians. @pre getHasAzimuth() is true. */
    [[nodiscard]] const af::array& getAzimuthRadians() const noexcept { return *azimuthRadians_; }
    /** @brief Get f32 [K] elevation radians. @pre getHasElevation() is true. */
    [[nodiscard]] const af::array& getElevationRadians() const noexcept { return *elevationRadians_; }
    /** @brief Get logical device payload bytes; excludes allocator overhead/shared storage. */
    [[nodiscard]] std::size_t getPayloadBytes() const noexcept {
        return detectionCount_ * (24u + 4u * static_cast<unsigned>(getHasAzimuth())
                                      + 4u * static_cast<unsigned>(getHasElevation()));
    }
    /** @brief Replace all five aligned columns as one list operation; clear old angles.
     * @pre All columns have the same count, correct dtype, order and device.
     * The count is read from host-side array metadata, never from device values. */
    void setDetections(af::array rangeIndices, af::array dopplerIndices,
                       af::array amplitudes, af::array snrDb, af::array complexPairsC32);
    /** @brief Replace numeric acquisition metadata without touching arrays. */
    void setMetadata(CPI_Metadata metadata) noexcept { metadata_ = metadata; }
    /** @brief Set source range origin; metadata only, no index changes. */
    void setFirstRangeMeters(double value) noexcept { firstRangeMeters_ = value; }
    /** @brief Set source range-bin spacing; metadata only. */
    void setRangeBinSpacingMeters(double value) noexcept { rangeBinSpacingMeters_ = value; }
    /** @brief Set actual integrated pulse count, excluding FFT padding. */
    void setIntegratedPulseCount(dim_t value) noexcept { integratedPulseCount_ = value; }
    /** @brief Remap Doppler indices on device and update ordering together.
     * @details Preserves physical frequencies, detection order and all other fields.
     * @pre FFT length fits u32; all Doppler indices are valid. No RDM is retained or shifted. */
    void setDopplerOrder(DopplerOrder order);
    /** @brief Replace linear amplitudes; same count/device and f32 required. */
    void setAmplitudes(af::array amplitudes);
    /** @brief Replace SNR-dB column; same count/device and f32 required. */
    void setSnrDb(af::array snrDb);
    /** @brief Replace c32 I/Q column; same count/device required. */
    void setComplexPairsC32(af::array complexPairsC32);
    /** @brief Attach f32 [K] azimuth radians; no host data read or dtype conversion. */
    void setAzimuthRadians(af::array azimuthRadians);
    /** @brief Attach f32 [K] elevation radians. */
    void setElevationRadians(af::array elevationRadians);
    /** @brief Attach both f32 [K] angle columns; radians, original detection order. */
    void setAngles(af::array azimuthRadians, af::array elevationRadians);
    /** @brief Release both optional angle handles without touching core columns. */
    void clearAngles() noexcept;
    /** @brief Return a one-entry DEVICE list; all indexing is unchecked. */
    [[nodiscard]] DetectionList getDetection(std::size_t detectionIndex) const;
    /** @brief Subset/reorder all present columns by u32 indices; duplicates allowed. */
    [[nodiscard]] DetectionList select(const af::array& detectionIndices) const;
    /** @brief Explicit deep copy of all present numerical columns. */
    [[nodiscard]] DetectionList clone() const;
    /** @brief Compute f32 range coordinates on device; metadata stays host-side. */
    [[nodiscard]] af::array getRangesMeters() const;
    /** @brief Compute f32 Doppler frequencies on device; signed integer bin decoding. */
    [[nodiscard]] af::array getDopplerHz() const;
    /** @brief Compute f32 monostatic radial velocities, positive receding. */
    [[nodiscard]] af::array getRadialVelocitiesMps() const;
    /** @brief Compute f32 [3,K] sensor-local XYZ; +x boresight, +y azimuth, +z up.
     *  @pre Both angle columns exist. Not a world-coordinate transformation. */
    [[nodiscard]] af::array getPositionsMeters() const;
    /** @brief EXPLICIT blocking export to complete host records using bounded staging.
     * @param batchSize Maximum records per temporary host staging block; must be positive.
     * @details Returned vector owns all records; there is no persistent host mirror.
     * Optional presence is list-wide. A present NaN denotes an invalid estimate. */
    [[nodiscard]] std::vector<Detection> recordsToHost(std::size_t batchSize = 4096) const;
    /** @brief Request evaluation of present columns; no explicit device fence. */
    void evaluate() const;
    /** @brief Evaluate and explicitly wait for the active device. */
    void synchronize() const;
private:
    CPI_Metadata metadata_;
    double firstRangeMeters_;
    double rangeBinSpacingMeters_;
    dim_t dopplerBinCount_;
    dim_t integratedPulseCount_;
    DopplerOrder dopplerOrder_;
    std::size_t detectionCount_ = 0;
    af::array rangeIndices_;
    af::array dopplerIndices_;
    af::array amplitudes_;
    af::array snrDb_;
    af::array complexPairsC32_;
    std::optional<af::array> azimuthRadians_;
    std::optional<af::array> elevationRadians_;
};
} // namespace radar
