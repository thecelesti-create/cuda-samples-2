#pragma once

#include <radar/detail/ArrayFire.hpp>
#include <radar/CPI_Metadata.hpp>
#include <cstddef>
#include <vector>
#include <span>

namespace radar {

// Raw complex single-precision IQ: [sample, pulse, element, 1].
// All indexed helpers are UNCHECKED: valid indices/slices and an active owning
// ArrayFire backend/device are caller preconditions. The wrapper performs no runtime validation.
/**
 * @brief c32 complex single-precision IQ stored as [sample,pulse,element,1].
 * @details c32 means two float components (I,Q), eight bytes per value. This
 * class never auto-casts f32/c64 input, validates input, or implicitly downloads IQ.
 * @pre All adopted arrays are c32 and satisfy this layout on the active device.
 * Indexed helpers require valid indices/counts. Copies retain ArrayFire handles;
 * use clone() only when an independent allocation is explicitly required.
 */
class SamplePulseBuffer final {
public:
    /** @brief Adopt an existing c32 IQ array; no implicit dtype conversion or validation.
     * @param iqC32 Device/host-backend c32 [sample,pulse,element,1] array.
     * @param metadata CPI acquisition metadata.
     * @pre The array is c32 on the active owning backend/device. */
    SamplePulseBuffer(af::array iqC32, CPI_Metadata metadata);
    /** @brief Allocate a zero-filled c32 IQ cube with named sample/pulse/element dimensions. */
    [[nodiscard]] static SamplePulseBuffer zeros(dim_t sampleCount, dim_t pulseCount, dim_t elementCount,
                                                 CPI_Metadata metadata);
    /** @brief Explicitly upload float I/Q pairs in column-major sample/pulse/element order.
     * @pre iqC32 contains sampleCount*pulseCount*elementCount float-complex values. */
    [[nodiscard]] static SamplePulseBuffer fromHost(std::span<const af::cfloat> iqC32,
                                                    dim_t sampleCount, dim_t pulseCount, dim_t elementCount,
                                                    CPI_Metadata metadata);

    /** @brief Get the c32 complex IQ array by const reference; no copy or download. */
    [[nodiscard]] const af::array& getDataC32() const noexcept { return iqC32_; }
    /** @brief Get CPI metadata by const reference. */
    [[nodiscard]] const CPI_Metadata& getMetadata() const noexcept { return metadata_; }
    /** @brief Get the number of fast-time samples. */
    [[nodiscard]] dim_t getSampleCount() const noexcept { return sampleCount_; }
    /** @brief Get the number of slow-time pulses. */
    [[nodiscard]] dim_t getPulseCount() const noexcept { return pulseCount_; }
    // Hardware element count (dim2), not getDataC32().elements() total IQ values.
    /** @brief Get hardware element count, not total ArrayFire value count. */
    [[nodiscard]] dim_t getElementCount() const noexcept { return elementCount_; }
    /** @brief Get the documented four-dimensional storage shape; final dimension is one. */
    [[nodiscard]] af::dim4 getDimensions() const { return af::dim4(sampleCount_, pulseCount_, elementCount_); }
    /** @brief Get logical c32 payload bytes, excluding ArrayFire allocator/workspace overhead. */
    [[nodiscard]] std::size_t getBytes() const noexcept {
        return static_cast<std::size_t>(sampleCount_) * static_cast<std::size_t>(pulseCount_) *
               static_cast<std::size_t>(elementCount_) * sizeof(af::cfloat);
    }
    // Logical column-major offset; not necessarily a physical offset in a view.
    /** @brief Compute an unchecked logical column-major index; not a pointer offset into a strided view. */
    [[nodiscard]] std::size_t getLinearIndex(dim_t sampleIndex, dim_t pulseIndex, dim_t elementIndex) const noexcept {
        return static_cast<std::size_t>(sampleIndex) + static_cast<std::size_t>(sampleCount_) *
               (static_cast<std::size_t>(pulseIndex) + static_cast<std::size_t>(pulseCount_) *
                static_cast<std::size_t>(elementIndex));
    }
    /** @brief Get the timestamp of a valid pulse index in application seconds. */
    [[nodiscard]] double getPulseTimeSeconds(dim_t pulseIndex) const noexcept {
        return metadata_.getFirstPulseTimeSeconds() + static_cast<double>(pulseIndex) *
               metadata_.getPulsePeriodSeconds();
    }
    /** @brief Get the round-trip delay of a valid raw sample in seconds. */
    [[nodiscard]] double getSampleDelaySeconds(dim_t sampleIndex) const noexcept {
        return metadata_.getFirstSampleDelaySeconds() + static_cast<double>(sampleIndex) *
               metadata_.getSamplePeriodSeconds();
    }
    /** @brief Get pulseCount * elementCount independent fast-time vectors. */
    [[nodiscard]] dim_t getMatchedFilterBatchCount() const noexcept { return pulseCount_ * elementCount_; }
    /** @brief Get one c32 fast-time/range vector at a valid pulse and element. */
    [[nodiscard]] af::array getPulseC32(dim_t pulseIndex, dim_t elementIndex) const;
    /** @brief Get the c32 two-dimensional plane for one valid element; storage may be shared. */
    [[nodiscard]] af::array getElementC32(dim_t elementIndex) const;
    /** @brief Get the c32 slow-time vector at a valid sample/range and element. */
    [[nodiscard]] af::array getSlowTimeC32(dim_t sampleIndex, dim_t elementIndex) const;
    /** @brief Return a c32 sample crop with updated sample count and sample-zero delay. */
    [[nodiscard]] SamplePulseBuffer sliceSamples(dim_t firstSample, dim_t sampleCount) const;
    /** @brief Return a c32 pulse crop with updated pulse count and pulse-zero timestamp. */
    [[nodiscard]] SamplePulseBuffer slicePulses(dim_t firstPulse, dim_t pulseCount) const;
    /** @brief Compute f32 squared complex magnitude on the current backend; c32 IQ is preserved. */
    [[nodiscard]] af::array computePower() const;

    // Replacement is unchecked. Shape/layout and
    // backend/device must stay unchanged; constructors support intentional changes.
    /** @brief Adopt c32 replacement IQ; same shape and device are unchecked preconditions. */
    void setDataC32(af::array iqC32);
    /** @brief Replace numeric CPI metadata without validation; acquisition/grid consistency is the caller's responsibility. */
    void setMetadata(CPI_Metadata metadata);
    /** @brief Explicitly deep-copy c32 payload; ordinary wrapper copies retain ArrayFire storage. */
    [[nodiscard]] SamplePulseBuffer clone() const; // Explicit deep copy, no revalidation.
    /** @brief EXPLICIT blocking download of c32 IQ into float I/Q host pairs. */
    [[nodiscard]] std::vector<af::cfloat> toHost() const;
    /** @brief Request ArrayFire evaluation without an explicit device fence. */
    void evaluate() const;
    /** @brief Evaluate and explicitly wait for the active owning device; no host download. */
    void synchronize() const;

private:
    af::array iqC32_;
    CPI_Metadata metadata_;
    // Cached at construction and updated by trusted slice helpers only.
    dim_t sampleCount_;
    dim_t pulseCount_;
    dim_t elementCount_;
};
} // namespace radar
