#pragma once
namespace radar {
/** @brief Vacuum propagation speed in meters per second. */
inline constexpr double speedOfLightMps = 299792458.0;
/** @brief Pi. */
inline constexpr double pi = 3.141592653589793238462643383279502884;
/** @brief Physical storage order of Doppler bins; even Nyquist maps negative. */
enum class DopplerOrder { Unshifted, Centered };
/** @brief Receiver convention; reported radial velocity is positive receding. */
enum class PositiveDoppler { Approaching, Receding };
} // namespace radar
