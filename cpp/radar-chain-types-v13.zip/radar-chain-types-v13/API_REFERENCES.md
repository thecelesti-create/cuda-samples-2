# API and mathematical references

This code targets the real ArrayFire 3.10 API. Reviewing documentation is not a
replacement for compiling/linking against an installed SDK; see VALIDATION.md.

- ArrayFire cfloat (two float I/Q components): https://arrayfire.org/docs/complex_8h_source.htm
- ArrayFire array construction, storage, copy and host export: https://arrayfire.org/docs/array_8h_source.htm
- ArrayFire leading-axis FFT: https://arrayfire.org/docs/group__signal__func__fft.htm
- ArrayFire reorder: https://arrayfire.org/docs/group__manip__func__reorder.htm
- ArrayFire indexing/lookup: https://arrayfire.org/docs/group__index__func__lookup.htm
- ArrayFire phase: https://arrayfire.org/docs/group__arith__func__arg.htm
- ArrayFire timing and asynchronous execution: https://arrayfire.org/docs/timing.htm
- Uniform-PRF Doppler and monostatic speed limits: https://www.mathworks.com/help/phased/ug/doppler-estimation.html
- Round-trip time/range: https://www.mathworks.com/help/phased/ref/range2time.html
- Ideal bandwidth/range-resolution relation: https://www.mathworks.com/help/phased/ref/range2bw.html
- Receive-aperture baseline phase relation: https://www.analog.com/en/resources/analog-dialogue/articles/phased-array-antenna-patterns-part1.html
- Direction cosines and forward-hemisphere azimuth/elevation: https://www.mathworks.com/help/phased/ref/uv2azel.html

For uniform PRF, the sampling interval is 1/PRF; c*t/2 gives c/(2*PRF)
range ambiguity distance. Slow time samples at PRF, hence a signed Doppler interval
[-PRF/2,PRF/2). Monostatic velocity magnitude boundary is lambda*PRF/4.
The nominal c/(2*B) range resolution is distinct from the output bin spacing.

## GoogleTest integration

- GoogleTest CMake quickstart and imported test targets:
  https://google.github.io/googletest/quickstart-cmake.html
- GoogleTest assertions (EXPECT_NEAR uses an absolute error bound):
  https://google.github.io/googletest/reference/assertions.html
- CMake per-case discovery and PRE_TEST discovery mode:
  https://cmake.org/cmake/help/latest/module/GoogleTest.html

The project uses an installed GoogleTest package rather than the quickstart's
network FetchContent example. GoogleTest is a PRIVATE dependency of test targets
only. Tests use native GoogleTest assertions and explicit numerical tolerances.

## v13 phase zero test

- ArrayFire elementwise inequality (b8 result): https://arrayfire.org/docs/group__arith__func__neq.htm
- ArrayFire elementwise logical OR: https://arrayfire.org/docs/group__arith__func__or.htm
- ArrayFire complex argument: https://arrayfire.org/docs/group__arith__func__arg.htm

These document the expression's operators; consulting them is not a real SDK
compile or backend execution.
