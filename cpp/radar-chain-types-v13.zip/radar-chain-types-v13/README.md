# Radar chain libraries — v13

C++20 / ArrayFire 3.10+, with a separate uniform-array interferometry library.
Based on v12, applying only cleanup proposals #1–#4. CMake version is 0.13.0.
Interferometry now has two concrete algorithms with constructor parameters and
fixed phase/coordinate conventions, not public array-geometry classes.
Default builds contain libraries only; opt-in tests use GoogleTest 1.12+.

```text
SamplePulseBuffer -> RangePulseBuffer -> RangeDopplerMap -> DetectionList
                                                              |
                                               interferometry |
                                                              v
                                                      DetectionList
                                                  (angles attached)
```

## v13 API cleanup

Use one entry point per construction purpose:

```cpp
#include <radar/SamplePulseBuffer.hpp>
#include <utility>

// Adopt an existing c32 array; the constructor retains/moves its handle.
radar::SamplePulseBuffer adopted(std::move(iqC32), metadata);
// Allocate or upload explicitly with the named factories.
auto zero = radar::SamplePulseBuffer::zeros(sampleCount, pulseCount, elementCount, metadata);
auto uploaded = radar::SamplePulseBuffer::fromHost(hostIqC32, sampleCount, pulseCount, elementCount, metadata);
// Same-shape replacement and explicit deep copy remain available.
uploaded.setDataC32(std::move(replacementIqC32));
auto detached = uploaded.clone();
```

Allocating/uploading constructor overloads and `withDataC32()` have been removed.
Stage-to-stage constructors, slices, `setDataC32()` and `clone()` remain.

Action names distinguish computation and data movement from ordinary getters:

| Action | Meaning |
|---|---|
| `ranges.reorderForDopplerC32()` | `[range,pulse,element]` to `[pulse,range,element]` |
| `map.reorderToRangeFirstC32()` | `[Doppler,range,element]` to `[range,Doppler,element]` |
| `cube.computePower()` | f32 squared magnitude, leaving c32 IQ intact |
| `map.computePowerSumElements()` | f32 noncoherent power sum across elements |

`getDataC32()` and the actual metadata/dimension getters retain their names.
No result caching, new validators, CUDA-specific code or changes to data layouts
were introduced. The phase helper uses a direct component zero test rather than
squaring a correlation solely to test for zero. See `MIGRATION.md` for breaking
name changes and `VALIDATION.md` for actual execution status.

## Device data, small CPU metadata

| Type | Numerical storage |
|---|---|
| SamplePulseBuffer | c32 `[sample,pulse,element,1]` |
| RangePulseBuffer | c32 `[range,pulse,element,1]` |
| RangeDopplerMap | c32 `[Doppler,range,element,1]` |
| DetectionList | Private u32 range/Doppler columns, f32 amplitude/SNR-dB columns, c32 I/Q column |
| Detection | One ordinary host value returned by explicit `recordsToHost()` |

DetectionList is again ArrayFire-backed: it is **not a host vector or a native
CUDA record buffer**. The logical record has five values, but its device layout
is structure-of-arrays using supported ArrayFire dtypes, not an array of C++
Detection objects. All five columns are `[K,1,1,1]`, share the same ordering, and
are adopted together. List operations `select()`, `getDetection()` and `clone()`
apply to all fields and optional angles together. No hidden host mirror is kept.

Indices retain u32 precision instead of being encoded as floats. Amplitude is
linear magnitude, SNR is detector-supplied dB, and the c32 pair is ONE
representative complex I/Q value per detection, not all element IQ.
`setDetections()` replaces all five columns and clears stale angles. Individual
field setters still require same-count/device input; no runtime validation is added.

Optional f32 azimuth/elevation columns are radians. Absence is list-wide for each
column and allocates no numerical array. A present NaN can represent an invalid
angle for one detection. Empty lists can retain optional-column presence. This
is distinct from arbitrary per-record `std::optional` flags in the old host v11.
No AzElDetectionList exists.

Selecting CUDA before the initial upload puts numerical data on CUDA; selecting
CPU/OpenCL uses that backend instead. Containers do not select/switch backends,
copy between devices, or introduce CUDA runtime dependencies. ArrayFire and its
backend runtimes must still be installed and configured. CPI metadata, array
handles and scalar dimensions remain on the host.

## No axis classes

Range calibration is directly stored as `firstRangeMeters_` and
`rangeBinSpacingMeters_`. The map also stores `integratedPulseCount_` and
`dopplerOrder_`; its existing `dopplerBinCount_` is the FFT length. DetectionList
copies those few scalars so it can outlive the source RDM without retaining it.
PRF is read from CPI_Metadata, not duplicated in a second grid object.

```cpp
#include <radar/RangePulseBuffer.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/types.hpp>
#include <utility>

radar::RangeDopplerMap doDoppler(const radar::RangePulseBuffer& input) {
    af::array outputC32 = af::fft(input.reorderForDopplerC32());
    return {input, std::move(outputC32), radar::DopplerOrder::Unshifted};
}
```

Construct a range buffer with explicit output calibration:

```cpp
radar::RangePulseBuffer ranges(samples, filteredIqC32,
                               /* firstRangeMeters */ 300.0,
                               /* rangeBinSpacingMeters */ 7.5);
```

`RangePulseBuffer(samples, filteredIqC32)` is a convenience ONLY for an output
whose filter delay is already corrected and which retains the original raw
sample timing/spacing. Cropping or resampling may require the explicit overload.
Constructors never perform matched filtering or infer an unknown filter delay.

```cpp
map.getFirstRangeMeters();
map.getRangeBinSpacingMeters();
map.getRangeMeters(rangeBin);
map.getDopplerHz(dopplerBin);
map.getDopplerBinCount();        // Includes zero padding.
map.getIntegratedPulseCount();  // Actual observations, not padding.
map.getDopplerBinSpacingHz();   // PRF/Nfft.
map.getCoherentIntervalSeconds(); // Integrated pulses/PRF.
map.getDopplerOrder();
```

Range crops update their origin. Pulse crops update their first-pulse timestamp.
Changing the map's Doppler order shifts IQ and metadata together, including odd
FFT lengths. Changing a detection list's Doppler order instead remaps its integer
indices on device, retaining detection ordering and physical frequencies. These
are explicit operations, not constructor side effects. To match a shifted RDM,
remap its associated detection list explicitly too.

Changing first range, spacing, pulse count or CPI metadata is a metadata-only
setter; the caller must ensure it describes the actual data. Changing PRF updates
derived Doppler spacing immediately because it is computed from current metadata.
Scalar `DetectionList::getRangeMetersForBin()` / `getDopplerHzForBin()` accept BIN
indices supplied by the caller, not detection positions or device values.
`getRangesMeters()` / `getDopplerHz()` compute whole f32 coordinate arrays on device.

## Detection and angle handoff

```cpp
#include <radar/DetectionList.hpp>
#include <radar/interferometry/Interferometry2D.hpp>

// cells = u32 [K] linear indices: Doppler + Nfft * range.
// amplitudes and snrDb = f32 [K]. The factory gathers one representative c32 I/Q.
auto detections = radar::DetectionList::fromMap(map, cells, amplitudes, snrDb, 0);

const double wavelength = phaseCenterMap.getMetadata().getWavelengthMeters();
const radar::interferometry::Interferometry2D estimator(
    4, 3, wavelength/2, wavelength/2); // Example half-wavelength grid; use hardware spacing.

auto located = estimator.estimate(phaseCenterMap, detections);
// To update the existing wrapper: detections = estimator.estimate(phaseCenterMap, detections);

const auto& azimuthDevice = located.getAzimuthRadians();
const auto& elevationDevice = located.getElevationRadians();
const auto records = located.recordsToHost(); // EXPLICIT final numerical download.
```

`fromCells()` accepts already-gathered representative c32 IQ and avoids that
gather. `estimate()` takes const-reference inputs, returns a shallow list copy,
and attaches new angle arrays; the five base columns are retained, not deep-copied.
To update an existing wrapper, assign the returned value:
`detections = estimator.estimate(phaseCenterMap, detections);`. This does not promise
reuse of an old angle allocation. No intermediate index upload or angle download
is present in these paths. Separate phase-center maps and externally gathered
c32 `[element,K]` IQ are also supported. See `interferometry/README.md` for geometry,
phase convention, 1D elevation prior, spatial ambiguity and contiguous-input rules.

`getDetection(i)` returns a one-entry DEVICE list, not a host `Detection&`.
No ordinary CPU getter silently downloads a scalar. `recordsToHost(batchSize)`
exports complete host values with bounded staging (default 4096). Its final
vector holds all returned records. There is no persistent CPU/device mirror.

## Simpler interferometry construction

```cpp
#include <radar/interferometry/Interferometry1D.hpp>
#include <radar/interferometry/Interferometry2D.hpp>

radar::interferometry::Interferometry1D linearEstimator(
    elementSpacingMeters, assumedElevationRadians); // default elevation: zero
radar::interferometry::Interferometry2D planarEstimator(
    azimuthElementCount, elevationElementCount,
    azimuthSpacingMeters, elevationSpacingMeters);
```

No geometry classes, spatial sign enums, steering-reference parameters, or
configuration bundles remain. Only layout/spacings, the 1D elevation prior, and
an optional batch size belong in algorithm constructors. Wavelength is taken from
CPI_Metadata; the 1D element count is inferred from the input. 2D extents must be
supplied because flattened elements alone do not encode the rectangular shape.

The fixed frame is +x boresight, +y positive azimuth, +z up. Calibrated spatial IQ
uses `exp(+j*2*pi*(y*u+z*v)/wavelength)`, where `u=cos(el)*sin(az)` and `v=sin(el)`.
Rectangular ordering is `elementIndex = yIndex + azimuthElementCount*zIndex`.
Outputs are radians in the forward hemisphere. 1D elevation is the configured
assumption, not an independently measured value. Inputs using different signs or
removed steering phases must be normalized upstream. Read `interferometry/README.md`
for exact input/calibration and spatial-ambiguity contracts.

## Memory and unchecked contracts

Required logical detection storage is `24*K` bytes. Each present angle column
adds `4*K` bytes (32*K with both). This excludes handles, allocator rounding,
shared views and temporary computations. Interferometry's principal c32 block
is `8*E*min(K,batchSize)` bytes; other buffers and asynchronous work also use memory.
No peak-allocation or measured speed guarantee is made.

The wrappers have no dtype, shape, finite-value, index, device or overflow scans.
Supply correct c32 IQ, aligned columns, valid dimensions and the same active
backend/device. Invalid input is a caller precondition violation. `setDataC32()`
requires an unchanged shape because cached dimensions are not re-inferred.
Batch sizes must be positive. Whole-grid linear indices/FFT lengths used by
sparse operations must fit u32, and products/counts must fit dim_t and size_t.

`clone()` is an explicit deep copy; ordinary array copies retain handles. Views
can keep parent allocations alive. `flat()` / `moddims()` of noncontiguous views
may materialize data; use contiguous owned RDMs on the low-memory gather path.
Evaluation, allocation and ArrayFire internals can synchronize (e.g. `where()`
needs a compacted count). Device residency is not a claim of zero host work or
zero implicit backend waits. Explicit `synchronize()` is for intentional fences.

## CPI helpers

CPI_Metadata remains numeric: sample rate, PRF, RF carrier, bandwidth, timing,
CPI ID and Doppler sign convention. The fourth constructor argument is waveform
bandwidth Hz; the optional fifth is CPI ID. Uniform-PRF monostatic helpers remain:

| Getter | Definition |
|---|---|
| getUnambiguousRangeMeters | c/(2*PRF) |
| getMinUnambiguousDopplerHz | -PRF/2 |
| getMaxUnambiguousDopplerHz | +PRF/2, exclusive |
| getUnambiguousDopplerSpanHz | PRF |
| getMaxUnambiguousSpeedMps | wavelength*PRF/4 |
| getNominalRangeResolutionMeters | c/(2*bandwidth), not sample spacing |
| getFirstSampleRangeMeters | c*rawSampleZeroDelay/2 |
| getSampleRangeSpacingMeters | c/(2*ADC sample rate) |

Processed range calibration remains with the stage data, not CPI_Metadata.

## Build

Use a clean directory after extracting `radar-chain-types-v13`.
CMake 3.20+, C++20, ArrayFire 3.10+; GoogleTest 1.12+ only when tests are enabled.
The existing ArrayFire guard accepts version 3.10 or later within 3.x.
No automatic dependency downloads or test framework in the exported libraries.

```sh
# Libraries only (default).
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release --parallel

# Libraries and GoogleTest suites, using CUDA through ArrayFire's unified backend.
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release --no-tests=error --output-on-failure

# Only the fake/reference chain tests.
ctest --test-dir build-tests -C Release -R "PipelineTests" -V --no-tests=error
```

Windows/Visual Studio: add `-A x64` when configuring and, if needed,
`-DCMAKE_PREFIX_PATH="$env:AF_PATH"`. Linux/WSL uses `-DCMAKE_PREFIX_PATH="$AF_PATH"`.
Supply GTest_DIR/CMAKE_PREFIX_PATH for a nonstandard GoogleTest install. Runtime
libraries must be visible to the loader. Use cpu/opencl instead of cuda as needed.
For a directly linked backend use `RADAR_ARRAYFIRE_BACKEND=CPU|CUDA|OPENCL`, leave
RADAR_TEST_BACKEND empty, and pass no backend argument to a runner.

Consumers link `radar::chain_types` or `radar::interferometry`; these are still
independent targets. `radar::metadata` (CPI_Metadata/host Detection) is available separately. With no
ArrayFire SDK, set `RADAR_BUILD_ARRAYFIRE_TYPES=OFF` to build that host library.
The geometry library is gone; scalar phase-model tests still work without ArrayFire
when GoogleTest is installed and tests are explicitly enabled.
Tests are opt-in even when a parent sets BUILD_TESTING=ON. No examples/executable
applications are part of a default library build. See `tests/README.md`.

All eight classes have individual .hpp/.cpp files, private fields and Doxygen
comments. Include concrete headers: the removed umbrellas/config/alias have not
returned. `radar_docs` is available when Doxygen is installed. Container recipes
are retained in Dockerfile/CONTAINER.md but are not certified as executed here.

See VALIDATION.md for actual build/test status. Source review is not an
ArrayFire CPU/CUDA integration or performance certification.
