#include <radar/interferometry/Interferometry1D.hpp>
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/types.hpp>
#include "device_helpers.hpp"
#include <cstddef>
#include <span>
#include <cmath>

namespace radar::interferometry {
Interferometry1D::Interferometry1D(double elementSpacingMeters, double assumedElevationRadians,
                                 std::size_t detectionBatchSize) noexcept
    : elementSpacingMeters_(elementSpacingMeters),
      assumedElevationRadians_(assumedElevationRadians), detectionBatchSize_(detectionBatchSize) {}

void Interferometry1D::computeAngles(const af::array& elementIqC32, double wavelengthMeters,
                                    af::array& azimuthRadians, af::array& elevationRadians) const {
    // Infer count from the actual gathered input; no duplicate count to keep in sync.
    const auto elementCount = static_cast<std::size_t>(elementIqC32.dims(0));
    const af::array lower = elementIqC32(detail::sequence(0, elementCount - 1), af::span);
    const af::array upper = elementIqC32(detail::sequence(1, elementCount - 1), af::span);
    const af::array correlation = af::sum(af::conjg(lower) * upper, 0);
    const float azimuthScale = static_cast<float>(wavelengthMeters /
        (2.0 * radar::pi * elementSpacingMeters_ * std::cos(assumedElevationRadians_)));
    // Fixed positive-exponent convention. A line cannot independently measure elevation.
    azimuthRadians = af::asin(detail::phase(correlation) * azimuthScale);
    elevationRadians = af::constant(static_cast<float>(assumedElevationRadians_),
                                    azimuthRadians.dims(), f32);
}

DetectionList Interferometry1D::estimate(const RangeDopplerMap& map, const DetectionList& detections) const {
    const double wavelengthMeters = detections.getMetadata().getWavelengthMeters();
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return detail::gather(map, detections, first, count); },
        [&](const af::array& iqC32, af::array& azimuth, af::array& elevation) {
            computeAngles(iqC32, wavelengthMeters, azimuth, elevation);
        });
}

DetectionList Interferometry1D::estimate(std::span<const RangeDopplerMap> maps, const DetectionList& detections) const {
    const double wavelengthMeters = detections.getMetadata().getWavelengthMeters();
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return detail::gather(maps, detections, first, count); },
        [&](const af::array& iqC32, af::array& azimuth, af::array& elevation) {
            computeAngles(iqC32, wavelengthMeters, azimuth, elevation);
        });
}

DetectionList Interferometry1D::estimate(const af::array& elementIqC32, const DetectionList& detections) const {
    const double wavelengthMeters = detections.getMetadata().getWavelengthMeters();
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return elementIqC32(af::span, detail::sequence(first, count)); },
        [&](const af::array& iqC32, af::array& azimuth, af::array& elevation) {
            computeAngles(iqC32, wavelengthMeters, azimuth, elevation);
        });
}
} // namespace radar::interferometry
