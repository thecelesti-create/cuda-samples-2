#include <radar/interferometry/Interferometry2D.hpp>
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/types.hpp>
#include "device_helpers.hpp"
#include <cstddef>
#include <span>

namespace radar::interferometry {
Interferometry2D::Interferometry2D(std::size_t azimuthElementCount, std::size_t elevationElementCount,
                                 double azimuthSpacingMeters, double elevationSpacingMeters,
                                 std::size_t detectionBatchSize) noexcept
    : azimuthElementCount_(azimuthElementCount), elevationElementCount_(elevationElementCount),
      azimuthSpacingMeters_(azimuthSpacingMeters), elevationSpacingMeters_(elevationSpacingMeters),
      detectionBatchSize_(detectionBatchSize) {}

void Interferometry2D::computeAngles(const af::array& elementIqC32, double wavelengthMeters,
                                    af::array& azimuthRadians, af::array& elevationRadians) const {
    const af::array grid = af::moddims(elementIqC32, static_cast<dim_t>(azimuthElementCount_),
                                     static_cast<dim_t>(elevationElementCount_), elementIqC32.dims(1));
    const af::array lowerY = grid(detail::sequence(0, azimuthElementCount_ - 1), af::span, af::span);
    const af::array upperY = grid(detail::sequence(1, azimuthElementCount_ - 1), af::span, af::span);
    const af::array lowerZ = grid(af::span, detail::sequence(0, elevationElementCount_ - 1), af::span);
    const af::array upperZ = grid(af::span, detail::sequence(1, elevationElementCount_ - 1), af::span);
    const af::array correlationY = af::sum(af::sum(af::conjg(lowerY) * upperY, 0), 1);
    const af::array correlationZ = af::sum(af::sum(af::conjg(lowerZ) * upperZ, 0), 1);
    const af::array u = detail::phase(correlationY) *
        static_cast<float>(wavelengthMeters / (2.0 * radar::pi * azimuthSpacingMeters_));
    const af::array v = detail::phase(correlationZ) *
        static_cast<float>(wavelengthMeters / (2.0 * radar::pi * elevationSpacingMeters_));
    // Forward (+x) hemisphere; preserve azimuth/elevation coupling. No phase unwrapping
    // or clipping: an invalid direction cosine remains an invalid numerical result.
    azimuthRadians = af::atan2(u, af::sqrt(1.0f - u*u - v*v));
    elevationRadians = af::asin(v);
}

DetectionList Interferometry2D::estimate(const RangeDopplerMap& map, const DetectionList& detections) const {
    const double wavelengthMeters = detections.getMetadata().getWavelengthMeters();
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return detail::gather(map, detections, first, count); },
        [&](const af::array& iqC32, af::array& azimuth, af::array& elevation) {
            computeAngles(iqC32, wavelengthMeters, azimuth, elevation);
        });
}

DetectionList Interferometry2D::estimate(std::span<const RangeDopplerMap> maps, const DetectionList& detections) const {
    const double wavelengthMeters = detections.getMetadata().getWavelengthMeters();
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return detail::gather(maps, detections, first, count); },
        [&](const af::array& iqC32, af::array& azimuth, af::array& elevation) {
            computeAngles(iqC32, wavelengthMeters, azimuth, elevation);
        });
}

DetectionList Interferometry2D::estimate(const af::array& elementIqC32, const DetectionList& detections) const {
    const double wavelengthMeters = detections.getMetadata().getWavelengthMeters();
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return elementIqC32(af::span, detail::sequence(first, count)); },
        [&](const af::array& iqC32, af::array& azimuth, af::array& elevation) {
            computeAngles(iqC32, wavelengthMeters, azimuth, elevation);
        });
}
} // namespace radar::interferometry
