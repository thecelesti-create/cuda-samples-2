#include <gtest/gtest.h>
#include <algorithm>
#include <cmath>
#include <radar/CPI_Metadata.hpp>
#include <radar/DetectionList.hpp>
#include <radar/interferometry/Interferometry2D.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/types.hpp>
#include <vector>


/** @brief Synthetic 4-by-3 array attaches known optional angles. */
TEST(InterferometryTests, SyntheticRectangularArray) {
    using namespace radar;
    using namespace radar::interferometry;
    constexpr dim_t dopplerCount = 8, rangeCount = 16;
    constexpr dim_t azimuthCount = 4, elevationCount = 3;
    constexpr unsigned rangeIndex = 5, dopplerIndex = 2;
    const CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6, 7);
    const double azimuth = 20.0 * pi / 180.0;
    const double elevation = 10.0 * pi / 180.0;
    const double u = std::cos(elevation) * std::sin(azimuth);
    const double v = std::sin(elevation);
    std::vector<af::cfloat> iqC32(
        dopplerCount * rangeCount * azimuthCount * elevationCount, {0.0f, 0.0f});
    for (dim_t z = 0; z < elevationCount; ++z) {
        for (dim_t y = 0; y < azimuthCount; ++y) {
            const double phase = pi * (static_cast<double>(y) * u + static_cast<double>(z) * v);
            const dim_t elementIndex = y + azimuthCount * z;
            iqC32[dopplerIndex + dopplerCount * (rangeIndex + rangeCount * elementIndex)] = {
                static_cast<float>(std::cos(phase)), static_cast<float>(std::sin(phase))};
        }
    }
    const af::array dataC32(af::dim4(dopplerCount, rangeCount, azimuthCount * elevationCount),
                           iqC32.data(), afHost);
    const RangeDopplerMap map(dataC32, metadata, 100.0, 10.0, dopplerCount);
    const auto detections = DetectionList::fromMap(map,
        af::constant(dopplerIndex + dopplerCount * rangeIndex, af::dim4(1), u32),
        af::constant(1.0f, af::dim4(1), f32), af::constant(20.0f, af::dim4(1), f32));
    const Interferometry2D estimator(azimuthCount, elevationCount,
        metadata.getWavelengthMeters() / 2.0, metadata.getWavelengthMeters() / 2.0);
    const DetectionList located = estimator.estimate(map, detections);
    ASSERT_TRUE(located.getHasAngles()) << "both angle columns attached";
    ASSERT_TRUE(!detections.getHasAzimuth() && !detections.getHasElevation()) << "input remains unchanged";
    ASSERT_TRUE(located.getAzimuthRadians().type() == f32 &&
          located.getElevationRadians().type() == f32) << "angle columns are f32";
    ASSERT_EQ(located.getComplexPairsC32().type(), c32) << "representative IQ remains c32";
    const auto records = located.recordsToHost();
    ASSERT_EQ(records.size(), 1) << "one input detection remains one output detection";
    const auto& record = records.front();
    ASSERT_TRUE(record.getAzimuthRadians().has_value() && record.getElevationRadians().has_value()) << "host optional angles are present";
    EXPECT_NEAR(*record.getAzimuthRadians(), azimuth, 2e-5 * std::max(1.0, std::abs(static_cast<double>(azimuth))));
    EXPECT_NEAR(*record.getElevationRadians(), elevation, 2e-5 * std::max(1.0, std::abs(static_cast<double>(elevation))));
    ASSERT_TRUE(record.getRangeIndex() == rangeIndex && record.getDopplerIndex() == dopplerIndex) << "original detection indices preserved";
    EXPECT_NEAR(record.getAmplitude(), 1.0, 1e-05);
    EXPECT_NEAR(record.getSnrDb(), 20.0, 0.0002);
    EXPECT_NEAR(record.getComplexPairC32().real(), 1.0, 1e-05);
    EXPECT_NEAR(record.getComplexPairC32().imag(), 0.0, 1e-05);
    EXPECT_NEAR(located.getMetadata().getBandwidthHz(), metadata.getBandwidthHz(), 1e-10 * std::max(1.0, std::abs(static_cast<double>(metadata.getBandwidthHz()))));
}
