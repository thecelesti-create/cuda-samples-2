#include <gtest/gtest.h>
#include "../src/device_helpers.hpp"
#include <radar/CPI_Metadata.hpp>
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/interferometry/Interferometry1D.hpp>
#include <radar/interferometry/Interferometry2D.hpp>
#include <radar/types.hpp>
#include <cmath>
#include <cstddef>
#include <initializer_list>
#include <span>
#include <type_traits>
#include <vector>

using namespace radar;
using namespace radar::interferometry;
static_assert(!std::is_aggregate_v<Interferometry1D>);
static_assert(!std::is_polymorphic_v<Interferometry2D>);
static_assert(std::is_trivially_copyable_v<Interferometry1D>);
static_assert(std::is_trivially_copyable_v<Interferometry2D>);

namespace {
/** @brief Upload a u32 index column for a fixture. */
af::array ids(std::initializer_list<unsigned> values) {
    return af::array(static_cast<dim_t>(values.size()), values.begin(), afHost);
}
/** @brief Synthesize c32 RDMs with the fixed positive spatial exponent and y-fast order. */
RangeDopplerMap makePlane(std::size_t azimuthCount, std::size_t elevationCount,
                         double azimuth, double elevation,
                         double azimuthSpacingWavelengths = 0.5,
                         double elevationSpacingWavelengths = 0.5,
                         double carrierHz = 10e9) {
    constexpr dim_t dopplerCount = 8, rangeCount = 6;
    const CPI_Metadata metadata(10e6, 2000, carrierHz, 5e6, 12);
    std::vector<af::cfloat> iqC32(static_cast<std::size_t>(dopplerCount * rangeCount) *
                                 azimuthCount * elevationCount);
    const double u = std::cos(elevation) * std::sin(azimuth);
    const double v = std::sin(elevation);
    for (std::size_t z = 0; z < elevationCount; ++z) {
        for (std::size_t y = 0; y < azimuthCount; ++y) {
            const double phase = 2.0 * pi * (static_cast<double>(y) * azimuthSpacingWavelengths * u +
                                            static_cast<double>(z) * elevationSpacingWavelengths * v);
            const double gain = 1.0 + 0.1 * static_cast<double>(y + z);
            for (dim_t range = 0; range < rangeCount; ++range) {
                for (dim_t doppler = 0; doppler < dopplerCount; ++doppler) {
                    const auto index = static_cast<std::size_t>(doppler + dopplerCount * range) +
                        static_cast<std::size_t>(dopplerCount * rangeCount) * (y + azimuthCount * z);
                    iqC32[index] = {static_cast<float>(gain * std::cos(phase + 0.63)),
                                   static_cast<float>(gain * std::sin(phase + 0.63))};
                }
            }
        }
    }
    return {af::array(af::dim4(dopplerCount, rangeCount,
                     static_cast<dim_t>(azimuthCount * elevationCount)), iqC32.data(), afHost),
            metadata, 100.0, 10.0, 4};
}
/** @brief Five detections in nontrivial order, including duplicate and nonzero cells. */
DetectionList detected(const RangeDopplerMap& map) {
    return DetectionList::fromMap(map, ids({10, 45, 10, 0, 35}),
        af::constant(1.0f, af::dim4(5), f32), af::constant(20.0f, af::dim4(5), f32));
}
/** @brief Test-only export verifying coordinates, preserved fields and angle dtypes. */
void checkAngles(const DetectionList& output, double azimuth, double elevation) {
    ASSERT_TRUE(output.getHasAngles());
    EXPECT_EQ(output.getAzimuthRadians().type(), f32);
    EXPECT_EQ(output.getElevationRadians().type(), f32);
    EXPECT_EQ(output.getComplexPairsC32().type(), c32);
    const auto records = output.recordsToHost();
    ASSERT_EQ(records.size(), 5U);
    for (const auto& record : records) {
        ASSERT_TRUE(record.getAzimuthRadians().has_value());
        ASSERT_TRUE(record.getElevationRadians().has_value());
        EXPECT_NEAR(*record.getAzimuthRadians(), azimuth, 3e-5);
        EXPECT_NEAR(*record.getElevationRadians(), elevation, 3e-5);
        EXPECT_FLOAT_EQ(record.getAmplitude(), 1.0f);
        EXPECT_FLOAT_EQ(record.getSnrDb(), 20.0f);
    }
    EXPECT_EQ(records[0].getRangeIndex(), 1U);
    EXPECT_EQ(records[0].getDopplerIndex(), 2U);
    EXPECT_EQ(records[2].getRangeIndex(), 1U);
    EXPECT_EQ(records[2].getDopplerIndex(), 2U);
    EXPECT_DOUBLE_EQ(output.getMetadata().getBandwidthHz(), 5e6);
}
} // namespace

/** @brief No external configuration class: constructor scalars are retained directly. */
TEST(InterferometryTests, ConstructorParameters) {
    const Interferometry1D line(0.01, 0.2, 128);
    EXPECT_DOUBLE_EQ(line.getElementSpacingMeters(), 0.01);
    EXPECT_DOUBLE_EQ(line.getAssumedElevationRadians(), 0.2);
    EXPECT_EQ(line.getDetectionBatchSize(), 128U);
    const Interferometry1D defaultLine(0.015);
    EXPECT_DOUBLE_EQ(defaultLine.getAssumedElevationRadians(), 0.0);
    EXPECT_EQ(defaultLine.getDetectionBatchSize(), 4096U);
    const Interferometry2D grid(4, 3, 0.01, 0.012, 256);
    EXPECT_EQ(grid.getAzimuthElementCount(), 4U);
    EXPECT_EQ(grid.getElevationElementCount(), 3U);
    EXPECT_DOUBLE_EQ(grid.getAzimuthSpacingMeters(), 0.01);
    EXPECT_DOUBLE_EQ(grid.getElevationSpacingMeters(), 0.012);
    EXPECT_EQ(grid.getDetectionBatchSize(), 256U);
}

/** @brief Positive and negative angles use ONE fixed convention, with a known elevation prior. */
TEST(InterferometryTests, LinearFixedConventionAndBatching) {
    for (double azimuth : {-0.35, 0.25}) {
        for (double elevation : {-0.2, 0.0, 0.12}) {
            const auto map = makePlane(5, 1, azimuth, elevation);
            const auto list = detected(map);
            for (std::size_t block : {1U, 2U, 8U}) {
                const Interferometry1D estimator(map.getMetadata().getWavelengthMeters() / 2.0,
                                                 elevation, block);
                ASSERT_NO_FATAL_FAILURE(checkAngles(estimator.estimate(map, list), azimuth, elevation));
                EXPECT_FALSE(list.getHasAngles());
            }
        }
    }
}

/** @brief Same estimator infers 1D aperture count from packed, separate and gathered IQ inputs. */
TEST(InterferometryTests, LinearInfersElementCountAndInputPaths) {
    const CPI_Metadata metadata(10e6, 2000, 10e9, 5e6);
    const Interferometry1D estimator(metadata.getWavelengthMeters() / 2.0);
    for (std::size_t count : {2U, 5U, 8U}) {
        const auto map = makePlane(count, 1, 0.3, 0.0);
        const auto list = detected(map);
        ASSERT_NO_FATAL_FAILURE(checkAngles(estimator.estimate(map, list), 0.3, 0.0));
        std::vector<RangeDopplerMap> maps;
        for (std::size_t element = 0; element < count; ++element) {
            maps.emplace_back(map.getElementC32(static_cast<dim_t>(element)), map.getMetadata(),
                map.getFirstRangeMeters(), map.getRangeBinSpacingMeters(), map.getIntegratedPulseCount());
        }
        ASSERT_NO_FATAL_FAILURE(checkAngles(estimator.estimate(std::span<const RangeDopplerMap>(maps), list),
                                           0.3, 0.0));
        const auto planes = af::moddims(map.getDataC32(), 48, static_cast<dim_t>(count));
        const af::array elementIqC32 = af::reorder(af::lookup(planes, ids({10,45,10,0,35}), 0), 1, 0, 2, 3);
        ASSERT_NO_FATAL_FAILURE(checkAngles(estimator.estimate(elementIqC32, list), 0.3, 0.0));
    }
}

/** @brief Unequal y/z spacing, non-square array, all input paths, and a separate detector map. */
TEST(InterferometryTests, RectangularInputPathsAndUnequalSpacing) {
    const double azimuth = 0.35, elevation = -0.17;
    const auto map = makePlane(4, 3, azimuth, elevation, 0.4, 0.3);
    const auto sumBeam = makePlane(1, 1, azimuth, elevation);
    const auto list = detected(sumBeam);
    const double wavelength = map.getMetadata().getWavelengthMeters();
    const Interferometry2D estimator(4, 3, 0.4 * wavelength, 0.3 * wavelength, 2);
    ASSERT_NO_FATAL_FAILURE(checkAngles(estimator.estimate(map, list), azimuth, elevation));
    std::vector<RangeDopplerMap> maps;
    for (dim_t element = 0; element < 12; ++element) {
        maps.emplace_back(map.getElementC32(element), map.getMetadata(), map.getFirstRangeMeters(),
            map.getRangeBinSpacingMeters(), map.getIntegratedPulseCount(), map.getDopplerOrder());
    }
    ASSERT_NO_FATAL_FAILURE(checkAngles(estimator.estimate(std::span<const RangeDopplerMap>(maps), list),
                                       azimuth, elevation));
    const auto planes = af::moddims(map.getDataC32(), 48, 12);
    const af::array elementIqC32 = af::reorder(af::lookup(planes, ids({10,45,10,0,35}), 0), 1, 0, 2, 3);
    ASSERT_NO_FATAL_FAILURE(checkAngles(estimator.estimate(elementIqC32, list), azimuth, elevation));
    auto previous = list;
    previous.setAngles(af::constant(0, af::dim4(5), f32), af::constant(0, af::dim4(5), f32));
    ASSERT_NO_FATAL_FAILURE(checkAngles(estimator.estimate(map, previous), azimuth, elevation));
}

/** @brief Fixed convention has no automatic sign correction; conjugation mirrors inferred directions. */
TEST(InterferometryTests, ConjugationMirrorsAnglesAndDopplerSignIsIndependent) {
    auto map = makePlane(4, 3, 0.25, 0.1);
    const double spacing = map.getMetadata().getWavelengthMeters() / 2.0;
    const Interferometry2D estimator(4, 3, spacing, spacing);
    auto list = detected(map);
    auto metadata = list.getMetadata();
    metadata.setPositiveDoppler(PositiveDoppler::Receding);
    list.setMetadata(metadata);
    ASSERT_NO_FATAL_FAILURE(checkAngles(estimator.estimate(map, list), 0.25, 0.1));
    map.setDataC32(af::conjg(map.getDataC32()));
    ASSERT_NO_FATAL_FAILURE(checkAngles(estimator.estimate(map, list), -0.25, -0.1));
}

/** @brief One physical array configuration obtains wavelength from each detection CPI. */
TEST(InterferometryTests, WavelengthFromCpiMetadata) {
    const Interferometry2D estimator(4, 3, 0.01, 0.012);
    for (double carrierHz : {8e9, 12e9}) {
        const CPI_Metadata metadata(10e6, 2000, carrierHz, 5e6);
        const double wavelength = metadata.getWavelengthMeters();
        const auto map = makePlane(4, 3, 0.3, 0.12, 0.01 / wavelength, 0.012 / wavelength, carrierHz);
        ASSERT_NO_FATAL_FAILURE(checkAngles(estimator.estimate(map, detected(map)), 0.3, 0.12));
    }
}

/** @brief Empty lists and undefined phases are values, not exception-based validation. */
TEST(InterferometryTests, EmptyAndUndefinedAngles) {
    auto map = makePlane(2, 2, 0.0, 0.0);
    const double spacing = map.getMetadata().getWavelengthMeters() / 2.0;
    const Interferometry2D estimator(2, 2, spacing, spacing);
    const auto empty = estimator.estimate(map, DetectionList(map));
    EXPECT_TRUE(empty.getIsEmpty());
    EXPECT_TRUE(empty.getHasAngles());
    const Interferometry1D line(spacing);
    const auto emptyLine = line.estimate(makePlane(2, 1, 0.0, 0.0), DetectionList(map));
    EXPECT_TRUE(emptyLine.getIsEmpty());
    EXPECT_TRUE(emptyLine.getHasAngles());
    map.setDataC32(af::constant(0.0f, map.getDimensions(), c32));
    for (const auto& record : estimator.estimate(map, detected(map)).recordsToHost()) {
        ASSERT_TRUE(record.getAzimuthRadians().has_value());
        ASSERT_TRUE(record.getElevationRadians().has_value());
        EXPECT_TRUE(std::isnan(*record.getAzimuthRadians()));
        EXPECT_TRUE(std::isnan(*record.getElevationRadians()));
    }
}

/** @brief Assigning an estimate retains the original columns and calibration. */
TEST(InterferometryTests, AssignEstimateDeviceResultsAndMetadata) {
    const auto map = makePlane(4, 3, 0.25, 0.1);
    auto list = detected(map);
    const double spacing = map.getMetadata().getWavelengthMeters() / 2.0;
    const Interferometry2D estimator(4, 3, spacing, spacing, 2);
    list = estimator.estimate(map, list);
    EXPECT_DOUBLE_EQ(list.getFirstRangeMeters(), map.getFirstRangeMeters());
    EXPECT_DOUBLE_EQ(list.getRangeBinSpacingMeters(), map.getRangeBinSpacingMeters());
    EXPECT_EQ(list.getIntegratedPulseCount(), map.getIntegratedPulseCount());
    EXPECT_EQ(list.getDopplerOrder(), map.getDopplerOrder());
    ASSERT_NO_FATAL_FAILURE(checkAngles(list, 0.25, 0.1));
}


/** @brief Component zero testing preserves tiny nonzero phases and maps signed zero to NaN. */
TEST(InterferometryTests, PhasePreservesTinyNonzeroCorrelations) {
    // Values are normal f32; squaring 1e-25 underflows even though its phase exists.
    const std::vector<af::cfloat> values{
        {0.0f, 0.0f}, {-0.0f, -0.0f}, {1e-25f, 0.0f}, {-1e-25f, 0.0f},
        {0.0f, 1e-25f}, {0.0f, -1e-25f}, {1e-25f, 1e-25f}, {-1e-25f, -1e-25f}
    };
    const af::array correlations(af::dim4(2, 4), values.data(), afHost);
    const af::array phases = radar::interferometry::detail::phase(correlations);
    ASSERT_EQ(phases.type(), f32);
    ASSERT_EQ(phases.dims(0), 8);
    ASSERT_EQ(phases.dims(1), 1);
    std::vector<float> actual(values.size());
    phases.host(actual.data()); // Test boundary only.
    EXPECT_TRUE(std::isnan(actual[0]));
    EXPECT_TRUE(std::isnan(actual[1]));
    for (std::size_t i = 2; i < values.size(); ++i) {
        SCOPED_TRACE(i);
        EXPECT_TRUE(std::isfinite(actual[i]));
        EXPECT_NEAR(actual[i], std::atan2(values[i].imag, values[i].real), 1e-6f);
    }
}

/** @brief Real 1D/2D estimates remain finite when the correlation's squared magnitude would underflow. */
TEST(InterferometryTests, TinySignalEstimatesRemainDefined) {
    // Products of these samples remain normal f32 (around 1e-26). This does not
    // promise recovery when the adjacent-element correlation itself underflows.
    for (double azimuth : {-0.25, 0.0, 0.25}) {
        auto lineMap = makePlane(5, 1, azimuth, 0.1);
        lineMap.setDataC32(lineMap.getDataC32() * 1e-13f);
        const auto lineDetections = detected(lineMap);
        const double spacing = lineMap.getMetadata().getWavelengthMeters() / 2.0;
        const Interferometry1D line(spacing, 0.1, 2);
        ASSERT_NO_FATAL_FAILURE(checkAngles(line.estimate(lineMap, lineDetections), azimuth, 0.1));
        auto gridMap = makePlane(4, 3, azimuth, -0.15);
        gridMap.setDataC32(gridMap.getDataC32() * 1e-13f);
        const Interferometry2D grid(4, 3, spacing, spacing, 2);
        ASSERT_NO_FATAL_FAILURE(checkAngles(grid.estimate(gridMap, detected(gridMap)), azimuth, -0.15));
    }
}

/** @brief The explicit assignment idiom replaces all six removed forwarding overloads. */
TEST(InterferometryTests, AssignEstimateAllInputForms) {
    const auto lineMap = makePlane(5, 1, 0.25, 0.0);
    const auto gridMap = makePlane(4, 3, 0.25, 0.1);
    const double spacing = lineMap.getMetadata().getWavelengthMeters() / 2.0;
    const Interferometry1D line(spacing);
    const Interferometry2D grid(4, 3, spacing, spacing);
    auto lineList = detected(lineMap);
    auto gridList = detected(gridMap);
    std::vector<RangeDopplerMap> lineMaps, gridMaps;
    for (dim_t e = 0; e < 5; ++e) {
        lineMaps.emplace_back(lineMap.getElementC32(e), lineMap.getMetadata(),
            lineMap.getFirstRangeMeters(), lineMap.getRangeBinSpacingMeters(), lineMap.getIntegratedPulseCount());
    }
    for (dim_t e = 0; e < 12; ++e) {
        gridMaps.emplace_back(gridMap.getElementC32(e), gridMap.getMetadata(),
            gridMap.getFirstRangeMeters(), gridMap.getRangeBinSpacingMeters(), gridMap.getIntegratedPulseCount());
    }
    const af::array selected = ids({10, 45, 10, 0, 35});
    const af::array lineIq = af::reorder(af::lookup(af::moddims(lineMap.getDataC32(), 48, 5), selected, 0), 1, 0, 2, 3);
    const af::array gridIq = af::reorder(af::lookup(af::moddims(gridMap.getDataC32(), 48, 12), selected, 0), 1, 0, 2, 3);
    lineList = line.estimate(lineMap, lineList);
    ASSERT_NO_FATAL_FAILURE(checkAngles(lineList, 0.25, 0.0));
    lineList = line.estimate(std::span<const RangeDopplerMap>(lineMaps), lineList);
    ASSERT_NO_FATAL_FAILURE(checkAngles(lineList, 0.25, 0.0));
    lineList = line.estimate(lineIq, lineList);
    ASSERT_NO_FATAL_FAILURE(checkAngles(lineList, 0.25, 0.0));
    gridList = grid.estimate(gridMap, gridList);
    ASSERT_NO_FATAL_FAILURE(checkAngles(gridList, 0.25, 0.1));
    gridList = grid.estimate(std::span<const RangeDopplerMap>(gridMaps), gridList);
    ASSERT_NO_FATAL_FAILURE(checkAngles(gridList, 0.25, 0.1));
    gridList = grid.estimate(gridIq, gridList);
    ASSERT_NO_FATAL_FAILURE(checkAngles(gridList, 0.25, 0.1));
}
