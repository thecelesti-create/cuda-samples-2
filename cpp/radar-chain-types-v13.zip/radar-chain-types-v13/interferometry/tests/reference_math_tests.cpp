#include <gtest/gtest.h>
#include <radar/types.hpp>
#include <array>
#include <cmath>
#include <complex>
#include <cstddef>
#include <limits>
#include <initializer_list>
#include <vector>

// Independent scalar reference only. This does NOT invoke ArrayFire or production estimators.
namespace {
using radar::pi;
constexpr double wavelength = 0.03;
/** @brief Synthesize the fixed positive-exponent, y-fast far-field phase model. */
std::vector<std::complex<double>> synthesize(std::size_t azimuthCount, std::size_t elevationCount,
    double azimuthSpacing, double elevationSpacing, double u, double v) {
    std::vector<std::complex<double>> iq(azimuthCount * elevationCount);
    for (std::size_t z = 0; z < elevationCount; ++z) {
        for (std::size_t y = 0; y < azimuthCount; ++y) {
            const double phase = 2.0 * pi / wavelength *
                (static_cast<double>(y) * azimuthSpacing * u + static_cast<double>(z) * elevationSpacing * v);
            iq[y + azimuthCount * z] = std::polar(1.0 + 0.05 * static_cast<double>(y + z), phase + 0.63);
        }
    }
    return iq;
}
/** @brief Return independent scalar principal phase, with undefined zero mapped to NaN. */
double phaseOf(std::complex<double> correlation) {
    return std::norm(correlation) > 0 ? std::arg(correlation) : std::numeric_limits<double>::quiet_NaN();
}
/** @brief Infer linear-array azimuth using an explicit elevation prior. */
double scalar1D(const std::vector<std::complex<double>>& iq, double spacing, double assumedElevation = 0.0) {
    std::complex<double> correlation{0, 0};
    for (std::size_t element = 0; element + 1 < iq.size(); ++element) {
        correlation += std::conj(iq[element]) * iq[element + 1];
    }
    return std::asin(wavelength / (2.0 * pi * spacing * std::cos(assumedElevation)) * phaseOf(correlation));
}
/** @brief Infer rectangular-array azimuth/elevation, choosing the forward hemisphere. */
std::array<double, 2> scalar2D(const std::vector<std::complex<double>>& iq,
    std::size_t azimuthCount, std::size_t elevationCount, double azimuthSpacing, double elevationSpacing) {
    std::complex<double> correlationY{0, 0}, correlationZ{0, 0};
    for (std::size_t z = 0; z < elevationCount; ++z) {
        for (std::size_t y = 0; y < azimuthCount; ++y) {
            const auto element = y + azimuthCount * z;
            if (y + 1 < azimuthCount) correlationY += std::conj(iq[element]) * iq[element + 1];
            if (z + 1 < elevationCount) correlationZ += std::conj(iq[element]) * iq[element + azimuthCount];
        }
    }
    const double u = wavelength / (2.0 * pi * azimuthSpacing) * phaseOf(correlationY);
    const double v = wavelength / (2.0 * pi * elevationSpacing) * phaseOf(correlationZ);
    return {std::atan2(u, std::sqrt(1.0 - u*u - v*v)), std::asin(v)};
}
} // namespace

/** @brief Positive and negative target angles under the single positive-exponent convention. */
TEST(InterferometryReference, LinearDirectionCosine) {
    for (std::size_t count : {2U, 5U, 8U}) {
        for (int azimuthDegrees = -70; azimuthDegrees <= 70; azimuthDegrees += 5) {
            for (double elevation : {-0.3, 0.0, 0.3}) {
                const double azimuth = azimuthDegrees * pi / 180.0;
                const auto iq = synthesize(count, 1, 0.4*wavelength, 0.0,
                                           std::cos(elevation)*std::sin(azimuth), 0.0);
                EXPECT_NEAR(scalar1D(iq, 0.4*wavelength, elevation), azimuth, 1e-11);
            }
        }
    }
}

/** @brief Non-square rectangular layout with unequal spacing retains cross-axis coupling. */
TEST(InterferometryReference, RectangularDirectionCosines) {
    for (int azimuthDegrees = -60; azimuthDegrees <= 60; azimuthDegrees += 10) {
        for (int elevationDegrees = -40; elevationDegrees <= 40; elevationDegrees += 10) {
            const double azimuth = azimuthDegrees * pi / 180.0;
            const double elevation = elevationDegrees * pi / 180.0;
            const auto iq = synthesize(5, 3, wavelength/2, 0.4*wavelength,
                                       std::cos(elevation)*std::sin(azimuth), std::sin(elevation));
            const auto result = scalar2D(iq, 5, 3, wavelength/2, 0.4*wavelength);
            EXPECT_NEAR(result[0], azimuth, 1e-11);
            EXPECT_NEAR(result[1], elevation, 1e-11);
        }
    }
}

/** @brief Conjugated input reverses the fixed-convention direction instead of being auto-detected. */
TEST(InterferometryReference, ConjugationMirrorsAngles) {
    const double azimuth = 0.3, elevation = 0.1;
    auto iq = synthesize(4, 3, wavelength/2, wavelength/2,
                          std::cos(elevation)*std::sin(azimuth), std::sin(elevation));
    for (auto& value : iq) value = std::conj(value);
    const auto result = scalar2D(iq, 4, 3, wavelength/2, wavelength/2);
    EXPECT_NEAR(result[0], -azimuth, 1e-11);
    EXPECT_NEAR(result[1], -elevation, 1e-11);
}

/** @brief Long effective subarray baselines work only inside their unwrapped field of view. */
TEST(InterferometryReference, LongSpacingHasNoAmbiguityResolution) {
    const double u = 0.1, v = -0.1;
    const auto iq = synthesize(2, 2, 2*wavelength, 1.5*wavelength, u, v);
    const auto result = scalar2D(iq, 2, 2, 2*wavelength, 1.5*wavelength);
    EXPECT_NEAR(result[0], std::atan2(u, std::sqrt(1-u*u-v*v)), 1e-11);
    EXPECT_NEAR(result[1], std::asin(v), 1e-11);
    const auto aliased = synthesize(4, 1, wavelength, 0.0, 0.75, 0.0);
    EXPECT_NEAR(scalar1D(aliased, wavelength), std::asin(-0.25), 1e-11);
}

/** @brief Zero correlation and out-of-disk direction cosines remain undefined, not clipped targets. */
TEST(InterferometryReference, UndefinedAngles) {
    EXPECT_TRUE(std::isnan(scalar1D(std::vector<std::complex<double>>(4), wavelength/2)));
    const auto iq = synthesize(3, 2, wavelength/2, wavelength/2, 0.9, 0.9);
    EXPECT_TRUE(std::isnan(scalar2D(iq, 3, 2, wavelength/2, wavelength/2)[0]));
}
