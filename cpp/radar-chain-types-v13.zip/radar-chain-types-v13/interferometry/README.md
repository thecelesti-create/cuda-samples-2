# Interferometry — v13

Two C++20 / ArrayFire 3.10 algorithms, with concrete constructor parameters and
one fixed phase/coordinate convention. The public interface is just
`Interferometry1D.hpp` and `Interferometry2D.hpp`. Link `radar::interferometry`.
There are no geometry classes, configuration bundles, phase-sign enum, or umbrella
headers. The radar types retain their v12 layouts and metadata; v13 simplifies cube entry points and action names.

## Usage

```cpp
#include <radar/interferometry/Interferometry1D.hpp>
#include <radar/interferometry/Interferometry2D.hpp>

// Supply real hardware phase-center spacings, in meters, once at construction.
const radar::interferometry::Interferometry1D linearEstimator(
    elementSpacingMeters, assumedElevationRadians);
const radar::interferometry::Interferometry2D planarEstimator(
    azimuthElementCount, elevationElementCount,
    azimuthSpacingMeters, elevationSpacingMeters);

radar::DetectionList located = planarEstimator.estimate(phaseCenterRdm, detections);
// To replace the existing wrapper: detections = planarEstimator.estimate(phaseCenterRdm, detections);
```

The 1D constructor defaults assumed elevation to zero (horizontal plane).
The optional last argument on either constructor is `detectionBatchSize`, default
4096. It controls selected-cell IQ scratch, not full-map dimensions.
Configuration is read-only after construction; reconstruct a small estimator to
change it. Constructors allocate no ArrayFire arrays.

### Where each value comes from

| Value | Source |
|---|---|
| Wavelength | `detections.getMetadata().getWavelengthMeters()` at each estimate |
| Selected range and Doppler bins | `DetectionList` device columns |
| RDM dimensions, range calibration and Doppler ordering | Existing radar types |
| 1D element count | Actual input element dimension, separate-map count, or IQ row count |
| 1D uniform spacing and elevation assumption | `Interferometry1D` constructor |
| 2D y/z element counts and uniform spacings | `Interferometry2D` constructor |
| Detection batch size | Algorithm constructor, default 4096 |

A flattened RDM element dimension cannot describe the 2D grid shape, hence the two
constructor counts. Spacing is a hardware property and is never guessed from
wavelength. The same estimator can process multiple carrier frequencies provided
the calibrated model and unambiguous field-of-view conditions remain valid.

## Fixed conventions

The sensor-local right-handed frame is **+x boresight, +y positive azimuth, +z up**.
Only the forward hemisphere is returned. All angles are radians.

```text
u = cos(elevation) * sin(azimuth)
v = sin(elevation)
x(y,z) = A(y,z) * exp(+j * (2*pi/wavelength) * (y*u + z*v))
```

A positive phase of `conj(lowerElement) * upperElement` means a positive direction
cosine along that axis. The exponent/sign is **fixed**. There is no use of the
CPI Doppler sign to choose a spatial sign. Unknown per-center phase errors must
already be calibrated out; positive amplitude variations and a common phase are
allowed. No removed steering-reference slope is added back inside the estimator.

Supply input conforming to this convention. For another receiver convention or
spatially derotated data, normalize/calibrate it upstream. Simply conjugating a
complete RDM can also affect how its Doppler content is interpreted; a sign fix
must not silently mismatch its detection bin metadata. Prefer normalization at
an appropriate earlier pipeline boundary, or on gathered spatial IQ with its
bin meanings kept intact.

### 1D aperture

Uniform phase centers lie along +y in increasing element order. The actual input
must contain at least two elements. The algorithm sums adjacent complex products:

```text
C = sum(conj(x[e]) * x[e+1])
azimuth = asin(arg(C) * wavelength / (2*pi*spacing*cos(assumedElevation)))
elevation = assumedElevation
```

**Elevation is an input assumption, not a measured angle.** A line cannot uniquely
recover azimuth and elevation independently. The output's elevation column is
filled with that assumption, as documented by the algorithm contract.

### 2D aperture

A complete uniform rectangular grid lies in the yz plane. Each extent is at
least two. Uniform spacing may differ between y and z. The element order is:

```text
elementIndex = azimuthIndex + azimuthElementCount * elevationIndex
```

The algorithm sums adjacent correlations separately across all y and z baselines:

```text
Cy = sum(conj(x[y,z]) * x[y+1,z])
Cz = sum(conj(x[y,z]) * x[y,z+1])
u = arg(Cy) * wavelength / (2*pi*azimuthSpacing)
v = arg(Cz) * wavelength / (2*pi*elevationSpacing)
azimuth = atan2(u, sqrt(1-u*u-v*v))
elevation = asin(v)
```

A five-element cross, missing elements, or an extra sum beam does not satisfy the
rectangular-grid contract. This is not an arbitrary-layout array estimator.

## Input storage and output

The three already-supported input forms are retained; they differ only in where
phase-center IQ is stored, not in array assumptions or mathematical conventions:

```cpp
estimate(const RangeDopplerMap& packedRdm, const DetectionList& detections);
estimate(std::span<const RangeDopplerMap> separateRdms, const DetectionList& detections);
estimate(const af::array& elementIqC32, const DetectionList& detections);
```

Packed input is **c32 `[Doppler,range,element]`**. Separate input is an ordered span
of **c32 `[Doppler,range,1]`** maps. Already-gathered input is **c32 `[element,K]`**.
Separate RDMs are not concatenated. The pre-gathered path is useful for reuse and
requires all element IQ, not the list's single representative I/Q pair per cell.

Both algorithms return `DetectionList`: its existing device columns and shared
calibration are retained, and new optional **f32** azimuth/elevation columns are
attached in the same detection order. Duplicates are preserved. To update an
existing wrapper use `detections = estimator.estimate(input, detections);` for
any of the three input forms. This does not deep-copy base columns or promise
reuse of an old angle allocation. Only an explicit `recordsToHost()` exports CPU
values. No CUDA-specific code is introduced.

## Elemental and subarray RDMs

Use spacing between **effective phase centers**. For subarray-beamformed RDMs this
is not necessarily radiator spacing. Maps must retain coherent angle-dependent
phase differences between those centers and have compatible calibration/patterns.
If processing has removed those differences, the estimator cannot recover angles
from them. Normalize any known removed spatial phase upstream.

This is narrowband far-field, single-dominant-arrival processing per detected cell.
The receive spatial factor is `2*pi/wavelength`, not the radar round-trip factor.
No phase unwrapping, reference-direction restoration, grating-lobe resolution,
front/back disambiguation, multiple-source separation, or calibration is performed.
The principal phase must satisfy `abs(dy*u/wavelength) < 0.5` and, for 2D,
`abs(dz*v/wavelength) < 0.5`. Half-wavelength spacing covers the visible interior;
longer effective subarray spacings restrict the usable field of view. Exact
half-wavelength endfire endpoints are ambiguous.

Zero summed correlation gives a device NaN. The zero test compares real and
imaginary components directly; it no longer squares a small nonzero correlation
and risks treating underflowed squared magnitude as zero. This does not recover a
correlation that has already underflowed during its computation.
Out-of-domain inverse trigonometry
is not clipped to fabricate a valid target. Presence of an angle column does not
mean every entry is valid; a NaN differs from an absent optional column. Do not
use `-ffast-math` when relying on these NaN semantics.

## Memory and caller contracts

The gather/batching code is unchanged from v12; only the phase zero test changed
inside the shared helper. Only detected cells
are gathered, in blocks. Principal c32 IQ scratch is `8*E*min(K,batchSize)` bytes;
output angles are `8*K` bytes total. Other arithmetic intermediates and ArrayFire
allocator/queue behavior add memory, so this is not a peak-memory guarantee.

No constructors or helpers scan/check values, shape, dtype, backend or indices.
Supply valid counts, positive spacings/batch sizes, c32 IQ, matching CPI/grid/bin
order, and the owning active device. The low-memory RDM path requires contiguous
maps; flattening a strided view may materialize a larger allocation.

There are no explicit host/scalar readbacks, `where()` or `sync()` calls in the
library. Block-boundary `eval()` calls manage expression lifetimes. ArrayFire
internals can still allocate, synchronize or retain memory; no speedup is claimed.

## Tests

Tests use native GoogleTest and are opt-in. `radar_interferometry_tests` exercises
the actual ArrayFire implementation: constructor settings, inferred 1D count,
both signs of angle under the fixed convention, prior elevation, unequal 2D
spacing, input forms, wavelength read from CPI metadata, independent Doppler sign,
batching, assigned output, duplicate bins, empty/zero input, and synthetic 20/10
degree azimuth/elevation. The scalar `radar_interferometry_reference_tests` checks
an independent mathematical model and **does not run the actual estimators**.
The v13 regression cases cover tiny nonzero c32 correlations (including pure real
and pure imaginary values), signed-zero NaNs, tiny-signal 1D/2D estimates, and
explicit return-value assignment for all three input forms.

```sh
ctest --test-dir build-tests -C Release -R '^radar_interferometry\.' --no-tests=error --output-on-failure
```

See the root VALIDATION.md for what was actually executed.

## Mathematical/API references

- Receive-baseline phase: https://www.analog.com/en/resources/analog-dialogue/articles/phased-array-antenna-patterns-part1.html
- Coordinate definitions: https://www.mathworks.com/help/phased/ref/uv2azel.html
- Complex phase operation: https://arrayfire.org/docs/group__arith__func__arg.htm

The sign itself is a chosen input convention, not a claim about every receiver.
