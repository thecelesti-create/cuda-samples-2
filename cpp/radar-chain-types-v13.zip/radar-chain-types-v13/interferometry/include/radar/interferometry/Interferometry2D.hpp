#pragma once
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <cstddef>
#include <span>

namespace radar::interferometry {
/**
 * @brief Complete uniform-rectangular-array interferometry; all complex input is c32.
 * @details The aperture lies in yz: +x boresight, +y positive azimuth, +z up.
 * Element order is yIndex + azimuthElementCount*zIndex. Calibrated IQ obeys
 * x(y,z) = A * exp(+j*2*pi*(y*cos(elevation)*sin(azimuth)+z*sin(elevation))/wavelength).
 * Positive adjacent phase means positive corresponding direction cosine. Results
 * are azimuth/elevation radians in the forward hemisphere. Wavelength comes from
 * the detection CPI metadata. There are no sign, steering-reference or geometry objects.
 * @pre A complete grid, at least two phase centers per axis, positive spacings,
 * one dominant calibrated far-field arrival per selected cell, and principal
 * adjacent phase strictly between -pi and pi on both axes. No ambiguity resolution.
 * RDMs and list share CPI, grids, ordering and active backend/device. A cross or
 * arbitrary sparse aperture is not supported. Inputs are unchecked caller contracts.
 */
class Interferometry2D final {
public:
    /** @brief Configure the rectangular layout once, without allocating device memory.
     * @param azimuthElementCount Number of phase centers along +y (fastest element index).
     * @param elevationElementCount Number of phase centers along +z.
     * @param azimuthSpacingMeters Adjacent effective-phase-center spacing along y, in meters.
     * @param elevationSpacingMeters Adjacent effective-phase-center spacing along z, in meters.
     * @param detectionBatchSize Maximum selected cells per temporary IQ block.
     * @pre Counts >= 2, spacings > 0, batch size > 0; input element count equals the product. */
    Interferometry2D(std::size_t azimuthElementCount, std::size_t elevationElementCount,
                    double azimuthSpacingMeters, double elevationSpacingMeters,
                    std::size_t detectionBatchSize = 4096) noexcept;
    /** @brief Get the phase-center count along +y. */
    [[nodiscard]] std::size_t getAzimuthElementCount() const noexcept { return azimuthElementCount_; }
    /** @brief Get the phase-center count along +z. */
    [[nodiscard]] std::size_t getElevationElementCount() const noexcept { return elevationElementCount_; }
    /** @brief Get uniform effective-phase-center spacing along y, in meters. */
    [[nodiscard]] double getAzimuthSpacingMeters() const noexcept { return azimuthSpacingMeters_; }
    /** @brief Get uniform effective-phase-center spacing along z, in meters. */
    [[nodiscard]] double getElevationSpacingMeters() const noexcept { return elevationSpacingMeters_; }
    /** @brief Get the maximum selected cells per temporary IQ block. */
    [[nodiscard]] std::size_t getDetectionBatchSize() const noexcept { return detectionBatchSize_; }
    /** @brief Estimate from a contiguous c32 [Doppler,range,element] cube in y-fast order.
     * @return Shallow list copy with f32 azimuth/elevation columns; base columns are retained. */
    [[nodiscard]] DetectionList estimate(const RangeDopplerMap& phaseCenteredRdm,
                                         const DetectionList& detections) const;
    /** @brief Estimate from c32 [Doppler,range,1] maps in y-fast grid order.
     * @pre Map count equals the configured product. Full RDMs are never concatenated. */
    [[nodiscard]] DetectionList estimate(std::span<const RangeDopplerMap> phaseCenteredRdms,
                                         const DetectionList& detections) const;
    /** @brief Reuse calibrated c32 [element,detection] IQ in y-fast grid order; no RDM gather.
     * @pre Row count equals the configured product; columns match detection order, including duplicates.
     * This is NOT getComplexPairsC32(), which stores one representative I/Q per detection. */
    [[nodiscard]] DetectionList estimate(const af::array& elementIqC32,
                                         const DetectionList& detections) const;
private:
    /** @brief Compute one block's f32 azimuth/elevation from adjacent c32 correlations. */
    void computeAngles(const af::array& elementIqC32, double wavelengthMeters,
                       af::array& azimuthRadians, af::array& elevationRadians) const;
    std::size_t azimuthElementCount_;
    std::size_t elevationElementCount_;
    double azimuthSpacingMeters_;
    double elevationSpacingMeters_;
    std::size_t detectionBatchSize_;
};
} // namespace radar::interferometry
