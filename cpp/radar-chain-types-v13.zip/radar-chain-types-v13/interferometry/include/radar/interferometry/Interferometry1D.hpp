#pragma once
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <cstddef>
#include <span>

namespace radar::interferometry {
/**
 * @brief Uniform-line interferometry with fixed spatial convention; input IQ is c32.
 * @details Elements run along +y; +x is boresight and +z is up. Calibrated IQ obeys
 * x(y) = A * exp(+j*2*pi*y*cos(elevation)*sin(azimuth)/wavelength).
 * Positive adjacent-element phase therefore means positive azimuth. Elevation is
 * a constructor-supplied assumption, NOT a second measurement. Results are radians
 * on the forward hemisphere. Wavelength comes from the detection CPI metadata;
 * element count comes from the input, not a second configuration object.
 * @pre At least two uniformly spaced phase centers, one dominant far-field arrival
 * per selected cell, and unwrapped adjacent phase strictly between -pi and pi.
 * All input arrays are on the same active ArrayFire backend/device. RDMs and list
 * share CPI, range/Doppler grid and ordering. No validation or host readback is added.
 */
class Interferometry1D final {
public:
    /** @brief Configure spacing and the 1D elevation prior once, without allocating device memory.
     * @param elementSpacingMeters Distance between adjacent effective phase centers, in meters.
     * @param assumedElevationRadians Known/assumed elevation; zero is the horizontal-plane assumption.
     * @param detectionBatchSize Maximum selected cells per temporary IQ block.
     * @pre Spacing is positive, abs(elevation) < pi/2, and batch size is positive.
     * Inputs must already use the fixed phase convention; there is no sign/reference switch. */
    explicit Interferometry1D(double elementSpacingMeters,
                             double assumedElevationRadians = 0.0,
                             std::size_t detectionBatchSize = 4096) noexcept;
    /** @brief Get spacing between effective phase centers in meters. */
    [[nodiscard]] double getElementSpacingMeters() const noexcept { return elementSpacingMeters_; }
    /** @brief Get the assumed, not independently measured, elevation in radians. */
    [[nodiscard]] double getAssumedElevationRadians() const noexcept { return assumedElevationRadians_; }
    /** @brief Get the maximum selected cells per temporary IQ block. */
    [[nodiscard]] std::size_t getDetectionBatchSize() const noexcept { return detectionBatchSize_; }
    /** @brief Estimate from a contiguous c32 [Doppler,range,element] cube, ordered along +y.
     * @return Shallow copy of the list with f32 azimuth and assumed-elevation columns attached. */
    [[nodiscard]] DetectionList estimate(const RangeDopplerMap& phaseCenteredRdm,
                                         const DetectionList& detections) const;
    /** @brief Estimate from contiguous c32 [Doppler,range,1] maps ordered along +y.
     * @pre At least two maps. Only selected cells are gathered; full maps are never joined. */
    [[nodiscard]] DetectionList estimate(std::span<const RangeDopplerMap> phaseCenteredRdms,
                                         const DetectionList& detections) const;
    /** @brief Reuse calibrated c32 [element,detection] IQ ordered along +y; skips RDM gathering.
     * @pre Columns match the list order, including duplicates; at least two element rows.
     * This is NOT getComplexPairsC32(), which holds only one representative I/Q per detection. */
    [[nodiscard]] DetectionList estimate(const af::array& elementIqC32,
                                         const DetectionList& detections) const;
private:
    /** @brief Compute one block's f32 angle columns from c32 element IQ; no scalar readback. */
    void computeAngles(const af::array& elementIqC32, double wavelengthMeters,
                       af::array& azimuthRadians, af::array& elevationRadians) const;
    double elementSpacingMeters_;
    double assumedElevationRadians_;
    std::size_t detectionBatchSize_;
};
} // namespace radar::interferometry
