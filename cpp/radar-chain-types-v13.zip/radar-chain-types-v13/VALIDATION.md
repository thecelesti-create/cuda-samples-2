# Validation report — v13

This revision applies only approved cleanup proposals #1–#4 to the supplied v12
archive. No logs from v12 are reported as execution of v13.

## Executed

- The real ArrayFire-independent `radar_metadata` library configured and built
  as C++20 Release with GCC 14.2 and Clang 17, with warnings treated as errors.
  These builds compile CPI_Metadata.cpp and Detection.cpp, not the modified
  ArrayFire-backed classes. See `validation/{gcc,clang}-{configure,build}.txt`.
- An independent host-float program checked eight regression fixtures under GCC,
  Clang, and GCC AddressSanitizer/UndefinedBehaviorSanitizer. Both signed-zero
  fixtures selected NaN. Six tiny nonzero real/imaginary/mixed fixtures retained
  finite phases with component comparison, while f32 squared magnitude became
  zero. No sanitizer error was reported. This is a numeric illustration, NOT an
  execution of the ArrayFire helper, estimators or GoogleTest suites. Source and
  output are in `validation/phase-fixture-*.txt`; no standalone application was
  added to the project build.
- The text-based source audit passed: eight classes with individual HPP/CPP
  definitions, 58 private fields, and Doxygen comments adjacent to 210 function
  declarations (including private compute functions). No production assertions,
  throw-based validators, CUDA-specific code or interferometry host/scalar/sync/
  where calls were introduced. This is not a C++ compiler or Doxygen run.
- All four inherited Docker scripts passed `bash -n`. They were not executed.
- Archive integrity and the complete SHA-256 manifest were checked after packaging.

Commands and actual exit statuses are in `validation/commands.json`.

## Verified change boundaries

`validation/change-scope.txt` and `validation/production-diff.txt` capture the
source-level comparison with the original v12 ZIP:

1. The phase helper replaces squared magnitude with real/imaginary component
   comparisons and elementwise logical OR. Exactly zero still selects NaN.
2. All six estimateInPlace() wrappers are deleted; the three value-returning
   input overloads on each estimator remain.
3. Two SamplePulseBuffer allocation/upload constructors and all three
   withDataC32() wrappers are deleted. zeros()/fromHost() use the retained
   array-adopting constructor. Stage-to-stage constructors remain.
4. Four approved operation names are updated across declarations, definitions,
   tests and current documentation.

Only 11 existing production files changed; nine remain byte-identical. No new
production source/header files were added. In particular, DetectionList,
CPI_Metadata, Detection and core array_helpers.hpp are unchanged.

The rejected proposals were NOT applied: all production include lines are
unchanged; no shared scalar Doppler helper was added; gather and batching bodies
are unchanged; CMake files are unchanged except project version 0.13.0. The
Doxyfile's displayed project version is also updated.

## GoogleTest coverage included, not executed

The source contains 31 native GoogleTest cases:

| Runner | Cases |
|---|---:|
| radar_metadata_tests | 3 |
| radar_arrayfire_tests | 11 |
| radar_interferometry_reference_tests | 5 |
| radar_interferometry_tests | 12 |

New regression coverage includes pure-real/pure-imaginary tiny correlations,
signed-zero NaNs, tiny-signal estimates through both algorithms, assignment of
estimate() results for all input forms, the retained constructor/factory routes,
and renamed power/reorder methods with unequal dimensions and known values.
Existing pipeline tests use the new action names. These counts are source
inventory, not real CTest discovery or execution.

## Dependency failures and limits

A real full configure failed because ArrayFire 3.10 development files are not
installed. A separate test-enabled, metadata-only configure failed because
GoogleTest 1.12+ is not installed. A GitHub dependency probe failed DNS resolution.
Exact output is retained in `validation/real-arrayfire-configure.txt`,
`validation/real-gtest-configure.txt` and `validation/dependency-download.txt`.

**The modified ArrayFire code and GoogleTest suites have not been compiled,
linked or executed against their real SDKs here.** No mock SDK, declaration-only
header aid, substitute backend or fake GoogleTest was used. The official
ArrayFire documentation was consulted for elementwise inequality, logical OR,
and arg(); documentation review is not SDK compilation.

CPU/CUDA/OpenCL integration, NVIDIA hardware execution, Windows/MSVC builds,
Doxygen generation, Docker image builds, latency and peak GPU memory remain
unverified. No measured speedup is claimed.

## Run against installed dependencies

```sh
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release --no-tests=error --output-on-failure
```

For the chain only, add `-R "PipelineTests" -V` to CTest. For the new regressions,
use `-R "PhasePreservesTiny|TinySignal|AssignEstimate|NamedCubeFactories|ExplicitCompute"`.
Use a fresh build directory and supply actual ArrayFire/GoogleTest installation
paths. Replace cuda with cpu/opencl for another installed unified backend.
