#include <gtest/gtest.h>
#include <radar/detail/ArrayFire.hpp>
#include <exception>
#include <iostream>
#include <stdexcept>
#include <string_view>

/**
 * @brief GoogleTest entry point shared by the two ArrayFire test executables.
 * @details Accepts one optional positional backend (cpu, cuda, opencl) after
 * GoogleTest removes its flags. Backend selection is test-only. Discovery lists
 * cases without initializing an ArrayFire device; it still needs the SDK's shared
 * libraries on the loader path. Requested backends never silently fall back.
 */
int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    if (GTEST_FLAG_GET(list_tests)) {
        return RUN_ALL_TESTS();
    }

    try {
#if RADAR_ARRAYFIRE_UNIFIED
        if (argc > 2) {
            throw std::invalid_argument("Usage: test_executable [cpu|cuda|opencl] [--gtest_* flags]");
        }
        const std::string_view backend = argc == 2 ? argv[1] : "cpu";
        if (backend == "cpu") {
            af::setBackend(AF_BACKEND_CPU);
        } else if (backend == "cuda") {
            af::setBackend(AF_BACKEND_CUDA);
        } else if (backend == "opencl") {
            af::setBackend(AF_BACKEND_OPENCL);
        } else {
            throw std::invalid_argument("Backend must be cpu, cuda or opencl");
        }
#else
        if (argc != 1) {
            throw std::invalid_argument("A directly linked backend takes no backend argument");
        }
#endif
        af::setDevice(0);
        const int result = RUN_ALL_TESTS();
        af::sync(); // Final test boundary only; never part of a library handoff.
        return result;
    } catch (const std::exception& error) {
        std::cerr << "ArrayFire test environment failed: " << error.what() << '\n';
        return 1;
    }
}
