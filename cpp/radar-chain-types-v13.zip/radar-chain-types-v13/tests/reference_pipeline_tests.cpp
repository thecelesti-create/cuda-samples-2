#include <cstddef>
#include <gtest/gtest.h>
#include <algorithm>
#include <cmath>
#include <radar/CPI_Metadata.hpp>
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/RangePulseBuffer.hpp>
#include <radar/SamplePulseBuffer.hpp>
#include <radar/types.hpp>
#include <utility>
#include <vector>

namespace {
using namespace radar;
/** @brief Reference linear matched filtering with delay-corrected range axis.
 * @pre waveform is a nonempty c32 column; sizes fit dim_t; configuration is valid. */
RangePulseBuffer matchedFilter(const SamplePulseBuffer& source, const af::array& waveform) {
    const dim_t taps = waveform.dims(0);
    const dim_t linearLength = source.getSampleCount() + taps - 1;
    dim_t fftLength = 1;
    while (fftLength < linearLength) {
        fftLength *= 2;
    }

    // Linear convolution with h[n] = conj(waveform[taps-1-n]).
    // af::fft is unnormalized forward; af::ifft includes inverse normalization.
    const af::array h = af::conjg(af::flip(waveform, 0));
    // Explicit tile is intentionally simple for this tiny test fixture. A production
    // implementation should broadcast/cache the filter spectrum instead of
    // retaining a full-sized repeated spectrum. Benchmark those costs separately.
    const af::array filterSpectrum = af::tile(af::fft(h, fftLength),
                                              1, source.getPulseCount(), source.getElementCount());
    const af::array full = af::ifft(af::fft(source.getDataC32(), fftLength) * filterSpectrum);
    // Full convolution peak has a taps-1 delay. Retain lags [0, samples-1].
    // Cropping is an actual data selection, not merely a metadata correction.
    const af::array cropped = full(af::seq(static_cast<double>(taps - 1),
                                         static_cast<double>(taps + source.getSampleCount() - 2)),
                                   af::span, af::span);
    // Cropped output has original raw timing and sample rate, with filter lag removed.
    return {source, cropped};
}

/** @brief Reference c32 Doppler FFT after pulse-first reorder. */
RangeDopplerMap dopplerProcess(const RangePulseBuffer& source) {
    // Exactly one full-cube reorder; the output stays Doppler-first afterward.
    af::array pulseFirst = source.reorderForDopplerC32();
    af::array spectrum = af::fft(pulseFirst);
    return {source, std::move(spectrum), DopplerOrder::Unshifted};
}


/** @brief Fixed-threshold element-zero detector; not CFAR. Numerical results stay on device. */
DetectionList thresholdDetector(const RangeDopplerMap& map, double threshold,
                            double assumedNoisePower) {
    const af::array elementIqC32 = map.getElementC32(0);
    const af::array power = af::real(elementIqC32 * af::conjg(elementIqC32));
    af::array selected = af::where(power > static_cast<float>(threshold));
    if (selected.isempty()) return DetectionList(map);
    af::array iqC32 = af::lookup(af::flat(elementIqC32), selected, 0);
    af::array amplitudes = af::abs(iqC32);
    af::array snrDb = 20.0f * af::log10(amplitudes) -
                     10.0f * static_cast<float>(std::log10(assumedNoisePower));
    return DetectionList::fromCells(map, std::move(selected), std::move(amplitudes),
                                     std::move(snrDb), std::move(iqC32));
}

} // namespace


/** @brief Reference matched filter and FFT recover a known echo. */
TEST(PipelineTests, MatchedFilterDopplerDetection) {
    using namespace radar;
    constexpr dim_t sampleCount = 64, pulseCount = 16, elementCount = 5;
    constexpr dim_t echoStart = 18, toneBin = 3;
    const std::vector<af::cfloat> chips{
        {1, 0}, {1, 0}, {1, 0}, {-1, 0}, {-1, 0}, {1, 0}, {-1, 0}};
    const af::array waveform(static_cast<dim_t>(chips.size()), chips.data(), afHost);
    const CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6, 11);

    // No random noise: exact expected peak/SNR and deterministic thresholding.
    std::vector<af::cfloat> hostIqC32(
        static_cast<std::size_t>(sampleCount * pulseCount * elementCount), {0.0f, 0.0f});
    for (dim_t elementIndex = 0; elementIndex < elementCount; ++elementIndex) {
        for (dim_t pulseIndex = 0; pulseIndex < pulseCount; ++pulseIndex) {
            const double phase = 2.0 * pi * static_cast<double>(toneBin * pulseIndex) /
                                 static_cast<double>(pulseCount) +
                                 0.2 * static_cast<double>(elementIndex);
            for (std::size_t chip = 0; chip < chips.size(); ++chip) {
                const dim_t sampleIndex = echoStart + static_cast<dim_t>(chip);
                const auto offset = static_cast<std::size_t>(sampleIndex +
                    sampleCount * (pulseIndex + pulseCount * elementIndex));
                hostIqC32[offset] = {
                    chips[chip].real * static_cast<float>(std::cos(phase)),
                    chips[chip].real * static_cast<float>(std::sin(phase))};
            }
        }
    }
    const auto samples = SamplePulseBuffer::fromHost(
        hostIqC32, sampleCount, pulseCount, elementCount, metadata);
    const auto ranges = matchedFilter(samples, waveform);
    const auto map = dopplerProcess(ranges);
    const double expectedAmplitude = static_cast<double>(chips.size()) * pulseCount;
    // This is an assumed noise model, not noise estimated from the noiseless data.
    const double assumedNoisePower = expectedAmplitude;
    const auto detections = thresholdDetector(map, 3000.0, assumedNoisePower);
    const auto records = detections.recordsToHost();
    ASSERT_EQ(records.size(), 1) << "one peak exceeds the fixed threshold";
    const auto& record = records.front();
    ASSERT_EQ(record.getRangeIndex(), static_cast<unsigned>(echoStart)) << "matched-filter delay removed";
    ASSERT_EQ(record.getDopplerIndex(), static_cast<unsigned>(toneBin)) << "expected positive Doppler bin";
    EXPECT_NEAR(record.getAmplitude(), expectedAmplitude, 3e-4 * std::max(1.0, std::abs(static_cast<double>(expectedAmplitude))));
    EXPECT_NEAR(record.getComplexPairC32().real(), expectedAmplitude, 3e-4 * std::max(1.0, std::abs(static_cast<double>(expectedAmplitude))));
    EXPECT_NEAR(record.getComplexPairC32().imag(), 0.0, 0.0003);
    EXPECT_NEAR(record.getSnrDb(), 10.0 * std::log10(expectedAmplitude), 3e-4 * std::max(1.0, std::abs(static_cast<double>(10.0 * std::log10(expectedAmplitude)))));
    ASSERT_TRUE(!detections.getHasAngles()) << "reference detector does not invent angles";
    EXPECT_NEAR(detections.getMetadata().getBandwidthHz(), metadata.getBandwidthHz(), 1e-10 * std::max(1.0, std::abs(static_cast<double>(metadata.getBandwidthHz()))));
    EXPECT_NEAR(ranges.getRangeMeters(echoStart), static_cast<double>(echoStart) * speedOfLightMps / (2.0 * metadata.getSampleRateHz()), 1e-10 * std::max(1.0, std::abs(static_cast<double>(static_cast<double>(echoStart) * speedOfLightMps / (2.0 * metadata.getSampleRateHz())))));
    EXPECT_NEAR(map.getDopplerHz(toneBin), metadata.getPrfHz() * toneBin / pulseCount, 1e-10 * std::max(1.0, std::abs(static_cast<double>(metadata.getPrfHz() * toneBin / pulseCount))));
    ASSERT_TRUE(ranges.getDataC32().type() == c32 && map.getDataC32().type() == c32) << "complex stages retain c32";

    const auto empty = thresholdDetector(map, 1e6, assumedNoisePower);
    ASSERT_TRUE(empty.getIsEmpty()) << "higher threshold produces an empty list";
    ASSERT_TRUE(empty.recordsToHost().empty()) << "empty list can be exported";
    ASSERT_TRUE(!empty.getHasAngles()) << "empty detector result has absent angles";
}
