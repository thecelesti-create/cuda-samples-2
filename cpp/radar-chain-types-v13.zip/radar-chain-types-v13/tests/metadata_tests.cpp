#include <utility>
#include <gtest/gtest.h>
#include <algorithm>
#include <cmath>
#include <radar/CPI_Metadata.hpp>
#include <radar/Detection.hpp>
#include <radar/types.hpp>
#include <cstdint>
#include <complex>
#include <limits>
#include <optional>
#include <type_traits>

static_assert(!std::is_aggregate_v<radar::Detection>);
static_assert(!std::is_polymorphic_v<radar::Detection>);
static_assert(std::is_trivially_copyable_v<radar::CPI_Metadata>);
static_assert(std::is_same_v<decltype(std::declval<radar::Detection>().getComplexPairC32()), std::complex<float>>);
static_assert(std::is_same_v<decltype(std::declval<radar::Detection>().getRangeIndex()), std::uint32_t>);


using namespace radar;

/** @brief Bandwidth and unambiguous range/Doppler helpers. */
TEST(MetadataTests, BandwidthAndAmbiguityHelpers) {
    CPI_Metadata m(10e6,2000.0,10e9,5e6,42,1e-6,10.0);
    EXPECT_NEAR(m.getSampleRateHz(), 10e6, 0.001);
    EXPECT_NEAR(m.getPrfHz(), 2000.0, 2e-07);
    EXPECT_NEAR(m.getCarrierFrequencyHz(), 10e9, 1);
    EXPECT_NEAR(m.getBandwidthHz(), 5e6, 0.0005);
    ASSERT_EQ(m.getCpiId(), 42) << "CPI id";
    EXPECT_NEAR(m.getFirstSampleDelaySeconds(), 1e-6, 1e-10);
    EXPECT_NEAR(m.getFirstPulseTimeSeconds(), 10.0, 1e-09);
    EXPECT_NEAR(m.getSamplePeriodSeconds(), 1e-7, 1e-10);
    EXPECT_NEAR(m.getPulsePeriodSeconds(), 0.0005, 1e-10);
    EXPECT_NEAR(m.getWavelengthMeters(), 0.0299792458, 1e-10);
    EXPECT_NEAR(m.getUnambiguousRangeMeters(), 74948.1145, 7.49481145e-06);
    EXPECT_NEAR(m.getUnambiguousDopplerSpanHz(), 2000.0, 2e-07);
    EXPECT_NEAR(m.getMinUnambiguousDopplerHz(), -1000.0, 1e-07);
    EXPECT_NEAR(m.getMaxUnambiguousDopplerHz(), 1000.0, 1e-07);
    EXPECT_NEAR(m.getMaxUnambiguousSpeedMps(), 14.9896229, 1.49896229e-09);
    EXPECT_NEAR(m.getNominalRangeResolutionMeters(), 29.9792458, 2.99792458e-09);
    EXPECT_NEAR(m.getRadialVelocityMps(1000.0), -14.9896229, 1.49896229e-09);
    m.setPositiveDoppler(PositiveDoppler::Receding);
    EXPECT_NEAR(m.getRadialVelocityMps(1000.0), 14.9896229, 1.49896229e-09);
    m.setPrfHz(4000.0);
    EXPECT_NEAR(m.getUnambiguousRangeMeters(), 37474.05725, 3.747405725e-06);
    EXPECT_NEAR(m.getMaxUnambiguousDopplerHz(), 2000.0, 2e-07);
    EXPECT_NEAR(m.getMaxUnambiguousSpeedMps(), 29.9792458, 2.99792458e-09);
    m.setBandwidthHz(10e6);
    EXPECT_NEAR(m.getNominalRangeResolutionMeters(), 14.9896229, 1.49896229e-09);
    m.setSampleRateHz(20e6);
    EXPECT_NEAR(m.getSamplePeriodSeconds(), 5e-8, 1e-10);
    m.setCarrierFrequencyHz(5e9);
    EXPECT_NEAR(m.getWavelengthMeters(), 0.0599584916, 1e-10);
    m.setCpiId(8); m.setFirstSampleDelaySeconds(0.25); m.setFirstPulseTimeSeconds(5.0);
    ASSERT_EQ(m.getCpiId(), 8) << "CPI setter";
    EXPECT_NEAR(m.getFirstSampleDelaySeconds(), 0.25, 1e-10);
    EXPECT_NEAR(m.getFirstPulseTimeSeconds(), 5.0, 5e-10);
}

/** @brief Five-field record and independent optional angles. */
TEST(MetadataTests, DetectionValuesAndOptionalAngles) {
    Detection d(5,2,4.0f,12.0f,{3.0f,4.0f});
    ASSERT_TRUE(d.getRangeIndex()==5 && d.getDopplerIndex()==2) << "indices";
    EXPECT_NEAR(d.getAmplitude(), 4.0, 4e-10);
    EXPECT_NEAR(d.getSnrDb(), 12.0, 1.2e-09);
    EXPECT_NEAR(d.getComplexPairC32().real(), 3.0, 3e-10);
    EXPECT_NEAR(d.getComplexPairC32().imag(), 4.0, 4e-10);
    ASSERT_TRUE(!d.getAzimuthRadians() && !d.getElevationRadians()) << "angles absent";
    d.setAzimuthRadians(0.2f);
    ASSERT_TRUE(d.getAzimuthRadians() && !d.getElevationRadians()) << "independent azimuth";
    EXPECT_NEAR(*d.getAzimuthRadians(), 0.2, 1e-06);
    d.setElevationRadians(0.1f);
    EXPECT_NEAR(*d.getElevationRadians(), 0.1, 1e-06);
    d.setRangeIndex(6); d.setDopplerIndex(3); d.setAmplitude(7); d.setSnrDb(-2);
    d.setComplexPairC32({1,-1});
    ASSERT_TRUE(d.getRangeIndex()==6 && d.getDopplerIndex()==3) << "record setters";
    EXPECT_NEAR(d.getAmplitude(), 7, 7e-10);
    EXPECT_NEAR(d.getSnrDb(), -2, 2e-10);
    EXPECT_NEAR(d.getComplexPairC32().imag(), -1, 1e-10);
    d.setAzimuthRadians(std::nullopt);
    ASSERT_TRUE(!d.getAzimuthRadians()) << "clear angle";
    d.setElevationRadians(std::numeric_limits<float>::quiet_NaN());
    ASSERT_TRUE(d.getElevationRadians() && std::isnan(*d.getElevationRadians())) << "present NaN distinct from absent";
}

/** @brief Raw monostatic sample positions; acquisition helpers, not processed calibration. */
TEST(MetadataTests, RawSampleRangeHelpers) {
    CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6, 1, 2e-6);
    EXPECT_NEAR(metadata.getFirstSampleRangeMeters(), 299.792458, 1e-9);
    EXPECT_NEAR(metadata.getSampleRangeSpacingMeters(), 14.9896229, 1e-9);
    metadata.setSampleRateHz(20e6);
    EXPECT_NEAR(metadata.getSampleRangeSpacingMeters(), 7.49481145, 1e-9);
    EXPECT_NEAR(metadata.getNominalRangeResolutionMeters(), 29.9792458, 1e-9);
}
