#include <gtest/gtest.h>
#include <algorithm>
#include <cmath>
#include <radar/CPI_Metadata.hpp>
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/RangePulseBuffer.hpp>
#include <radar/SamplePulseBuffer.hpp>
#include <radar/types.hpp>
#include <utility>
#include <vector>

// Test-only placeholders, not implementations exported by either library.
namespace {
/** @brief FAKE matched filter: multiply c32 IQ by two; no pulse compression. */
radar::RangePulseBuffer fakeMatchedFilter(const radar::SamplePulseBuffer& input) {
    af::array iqC32 = input.getDataC32() * 2.0f;
    return {input, std::move(iqC32)};
}
/** @brief FAKE Doppler: reorder to [pulse,range,element]; deliberately no FFT. */
radar::RangeDopplerMap fakeDoppler(const radar::RangePulseBuffer& input) {
    return {input, input.reorderForDopplerC32(), radar::DopplerOrder::Unshifted};
}
/** @brief FAKE detector: select cell zero in element zero and assume unit noise power. */
radar::DetectionList fakeDetector(const radar::RangeDopplerMap& input) {
    af::array cells = af::constant(0u, af::dim4(1), u32);
    af::array iqC32 = af::lookup(af::flat(input.getElementC32(0)), cells, 0);
    af::array amplitudes = af::abs(iqC32);
    af::array snrDb = 20.0f * af::log10(amplitudes); // 10*log10(amplitude^2 / 1).
    return radar::DetectionList::fromCells(input, std::move(cells),
        std::move(amplitudes), std::move(snrDb), std::move(iqC32));
}
} // namespace


/** @brief Three fake algorithms preserve types and detection values. */
TEST(PipelineTests, ThreeFakeAlgorithms) {
    constexpr dim_t sampleCount = 8, pulseCount = 4, elementCount = 3;
    const radar::CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6, 1);
    const std::vector<af::cfloat> hostIqC32(
        sampleCount * pulseCount * elementCount, {1.0f, 0.0f});
    const auto samples = radar::SamplePulseBuffer::fromHost(
        hostIqC32, sampleCount, pulseCount, elementCount, metadata);

    // One input upload, no numerical host readback between algorithms.
    const auto ranges = fakeMatchedFilter(samples);
    const auto map = fakeDoppler(ranges);
    const auto detections = fakeDetector(map);
    ASSERT_EQ(samples.getDataC32().type(), c32) << "sample IQ is c32";
    ASSERT_EQ(ranges.getDataC32().type(), c32) << "range IQ is c32";
    ASSERT_EQ(map.getDataC32().type(), c32) << "RDM IQ is c32";
    ASSERT_TRUE(ranges.getRangeBinCount() == sampleCount &&
          ranges.getPulseCount() == pulseCount &&
          ranges.getElementCount() == elementCount) << "range-stage dimensions";
    ASSERT_TRUE(map.getDopplerBinCount() == pulseCount &&
          map.getRangeBinCount() == sampleCount &&
          map.getElementCount() == elementCount) << "Doppler-first dimensions";
    EXPECT_NEAR(detections.getMetadata().getBandwidthHz(), metadata.getBandwidthHz(), 1e-10 * std::max(1.0, std::abs(static_cast<double>(metadata.getBandwidthHz()))));
    ASSERT_TRUE(!detections.getHasAzimuth() && !detections.getHasElevation()) << "no fabricated angles";
    ASSERT_EQ(detections.getComplexPairsC32().type(), c32) << "detection IQ is c32";

    // Assertions read the small final result, not intermediate cubes.
    const auto records = detections.recordsToHost();
    ASSERT_EQ(records.size(), 1) << "fake detector returns one record";
    const auto& record = records.front();
    ASSERT_TRUE(record.getRangeIndex() == 0 && record.getDopplerIndex() == 0) << "selected cell zero";
    EXPECT_NEAR(record.getAmplitude(), 2.0, 2e-05);
    EXPECT_NEAR(record.getSnrDb(), 20.0 * std::log10(2.0), 1e-5 * std::max(1.0, std::abs(static_cast<double>(20.0 * std::log10(2.0)))));
    EXPECT_NEAR(record.getComplexPairC32().real(), 2.0, 2e-05);
    EXPECT_NEAR(record.getComplexPairC32().imag(), 0.0, 1e-05);
    ASSERT_TRUE(!record.getAzimuthRadians() && !record.getElevationRadians()) << "host optional fields absent";
}
