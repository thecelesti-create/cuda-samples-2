#include <cstddef>
#include <gtest/gtest.h>
#include <algorithm>
#include <cmath>
#include <radar/CPI_Metadata.hpp>
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/RangePulseBuffer.hpp>
#include <radar/SamplePulseBuffer.hpp>
#include <radar/types.hpp>
#include <initializer_list>
#include <limits>
#include <string>
#include <vector>
#include <type_traits>
#include <span>
#include <utility>

/** @brief Upload a small u32 test column. */
af::array indices(std::initializer_list<unsigned> values) {
    return af::array(static_cast<dim_t>(values.size()), values.begin(), afHost);
}
/** @brief Upload a small f32 test column. */
af::array floats(std::initializer_list<float> values) {
    return af::array(static_cast<dim_t>(values.size()), values.begin(), afHost);
}
/** @brief Explicitly download a test array using its exact scalar storage type. */
template<class T> std::vector<T> host(const af::array& a) {
    std::vector<T> result(static_cast<std::size_t>(a.elements()));
    if (!result.empty()) a.host(result.data());
    return result;
}
/** @brief Construct a tiny [D=8,R=6,E=3] c32 map with distinct element/cell IQ. */
radar::RangeDopplerMap makeMap() {
    using namespace radar;
    std::vector<af::cfloat> iqC32(8*6*3);
    for(dim_t e=0;e<3;++e) for(dim_t r=0;r<6;++r) for(dim_t d=0;d<8;++d)
        iqC32[d+8*(r+6*e)]={static_cast<float>(100*e+10*r+d),static_cast<float>(e)*0.25f};
    CPI_Metadata m(10e6,2000,10e9,5e6,5);
    m.setPositiveDoppler(PositiveDoppler::Receding);
    return {af::array(af::dim4(8,6,3),iqC32.data(),afHost),m,100.0,10.0,4};
}
/** @brief Execute real ArrayFire checks; requires an installed SDK/backend. */

using namespace radar;

/** @brief C32 stage layouts, slices, FFT and bandwidth propagation. */
TEST(ArrayFireTypes, C32LayoutsSlicesAndFFT) {
    CPI_Metadata m(10e6,2000,10e9,5e6,2);
    std::vector<af::cfloat> iqC32(8*4*3,{1,0});
    const auto samples=SamplePulseBuffer::fromHost(iqC32,8,4,3,m);
    ASSERT_EQ(samples.getDataC32().type(), c32) << "raw c32";
    ASSERT_TRUE(samples.getSampleCount()==8 && samples.getPulseCount()==4 && samples.getElementCount()==3) << "named counts";
    ASSERT_EQ(samples.getDataC32().elements(), 96) << "total value count";
    const auto cropped=samples.sliceSamples(2,3).slicePulses(1,2);
    ASSERT_TRUE(cropped.getSampleCount()==3 && cropped.getPulseCount()==2) << "slice counts";
    EXPECT_NEAR(cropped.getSampleDelaySeconds(0), 2e-7, 1e-10);
    EXPECT_NEAR(cropped.getPulseTimeSeconds(0), 0.0005, 1e-10);
    RangePulseBuffer ranges(samples,samples.getDataC32()*2.0f,100.0,5.0);
    EXPECT_NEAR(ranges.getMetadata().getBandwidthHz(), 5e6, 0.0005);
    const auto ordered=ranges.reorderForDopplerC32();
    ASSERT_TRUE(ordered.dims(0)==4 && ordered.dims(1)==8 && ordered.dims(2)==3) << "pulse-first reorder";
    const RangeDopplerMap map(ranges,af::fft(ordered),DopplerOrder::Unshifted);
    ASSERT_TRUE(map.getDataC32().type()==c32 && map.getDopplerBinCount()==4) << "FFT c32 shape";
    const auto h=map.toHost();
    EXPECT_NEAR(h[0].real, 8, 8e-05);
    EXPECT_NEAR(h[1].real, 0, 1e-05);
    EXPECT_NEAR(map.getMetadata().getBandwidthHz(), 5e6, 0.0005);
    auto shifted=map.withDopplerOrder(DopplerOrder::Centered).withDopplerOrder(DopplerOrder::Unshifted);
    EXPECT_NEAR(shifted.toHost()[0].real, 8, 8e-05);
    auto copy=samples.clone(); copy.setDataC32(af::constant(0,copy.getDimensions(),c32));
    EXPECT_NEAR(samples.toHost()[0].real, 1, 1e-10);
    EXPECT_NEAR(copy.toHost()[0].real, 0, 1e-10);
}

/** @brief Five detection columns, c32 representative IQ, coordinates. */
TEST(ArrayFireTypes, DetectionColumnsAndCoordinates) {
    const auto map=makeMap();
    const auto list=DetectionList::fromMap(map,indices({10,45,10}),floats({7,8,9}),floats({12,13,14}),1);
    ASSERT_TRUE(list.getDetectionCount()==3 && list.getPayloadBytes()==72) << "five-field payload";
    ASSERT_TRUE(list.getRangeIndices().type()==u32 && list.getDopplerIndices().type()==u32) << "integer bins";
    ASSERT_TRUE(list.getAmplitudes().type()==f32 && list.getSnrDb().type()==f32) << "scalar f32";
    ASSERT_EQ(list.getComplexPairsC32().type(), c32) << "required c32 I/Q";
    ASSERT_TRUE(!list.getHasAzimuth() && !list.getHasElevation()) << "angles initially absent";
    const auto r=list.recordsToHost();
    ASSERT_TRUE(r[0].getRangeIndex()==1 && r[0].getDopplerIndex()==2) << "integer decode";
    EXPECT_NEAR(r[0].getAmplitude(), 7, 7e-10);
    EXPECT_NEAR(r[0].getSnrDb(), 12, 1.2e-09);
    EXPECT_NEAR(r[0].getComplexPairC32().real(), 112, 1.12e-08);
    EXPECT_NEAR(r[0].getComplexPairC32().imag(), 0.25, 1e-10);
    ASSERT_TRUE(r[1].getRangeIndex()==5 && r[1].getDopplerIndex()==5) << "second indices";
    EXPECT_NEAR(r[1].getComplexPairC32().real(), 155, 1.55e-08);
    EXPECT_NEAR(host<float>(list.getRangesMeters())[0], 110, 1.1e-08);
    EXPECT_NEAR(host<float>(list.getDopplerHz())[0], 500, 5e-08);
    EXPECT_NEAR(host<float>(list.getDopplerHz())[1], -750, 7.5e-08);
    EXPECT_NEAR(host<float>(list.getRadialVelocitiesMps())[0], map.getMetadata().getRadialVelocityMps(500), 1e-5 * std::max(1.0, std::abs(static_cast<double>(map.getMetadata().getRadialVelocityMps(500)))));
    EXPECT_NEAR(list.getMetadata().getBandwidthHz(), 5e6, 0.0005);
}

/** @brief Optional angle lifecycle, selection, clone and export. */
TEST(ArrayFireTypes, OptionalAnglesSelectionAndClone) {
    const auto map=makeMap();
    auto base=DetectionList::fromMap(map,indices({10,45,10}),floats({7,8,9}),floats({12,13,14}));
    auto angled=base;
    angled.setAzimuthRadians(floats({0.0f,0.2f,0.4f}));
    ASSERT_TRUE(angled.getHasAzimuth() && !angled.getHasAngles()) << "azimuth only";
    ASSERT_TRUE(!base.getHasAzimuth()) << "input unchanged";
    auto azOnly=angled.select(indices({2,0,2}));
    ASSERT_TRUE(azOnly.getHasAzimuth() && !azOnly.getHasElevation()) << "partial optional selection";
    EXPECT_NEAR(*azOnly.recordsToHost()[0].getAzimuthRadians(), 0.4, 1e-06);
    angled.setElevationRadians(floats({0.0f,0.1f,0.2f}));
    ASSERT_TRUE(angled.getHasAngles() && angled.getPayloadBytes()==96) << "both angles payload";
    const auto xyz=host<float>(angled.getPositionsMeters());
    EXPECT_NEAR(xyz[0], 110, 1.1e-08);
    EXPECT_NEAR(xyz[1], 0, 1e-10);
    EXPECT_NEAR(xyz[2], 0, 1e-10);
    const auto selected=angled.select(indices({1,0,1}));
    const auto h=selected.recordsToHost();
    ASSERT_TRUE(h[0].getRangeIndex()==5 && h[2].getRangeIndex()==5) << "duplicate selection";
    EXPECT_NEAR(*h[0].getAzimuthRadians(), 0.2, 1e-06);
    EXPECT_NEAR(*h[2].getElevationRadians(), 0.1, 1e-06);
    EXPECT_NEAR(h[0].getAmplitude(), 8, 8e-10);
    EXPECT_NEAR(h[0].getSnrDb(), 13, 1.3e-09);
    auto deep=selected.clone(); deep.clearAngles();
    ASSERT_TRUE(!deep.getHasAngles() && selected.getHasAngles()) << "independent optional handles";
    deep.setAmplitudes(floats({1,2,3}));deep.setSnrDb(floats({4,5,6}));
    EXPECT_NEAR(selected.recordsToHost()[0].getAmplitude(), 8, 8e-10);
    EXPECT_NEAR(deep.recordsToHost()[0].getAmplitude(), 1, 1e-10);
    const auto one=selected.getDetection(2).recordsToHost();
    ASSERT_TRUE(one.size()==1 && one[0].getRangeIndex()==5) << "single device list";
    auto empty=selected.select(af::array{});
    ASSERT_TRUE(empty.getIsEmpty() && empty.getHasAngles()) << "empty preserves optional presence";
    ASSERT_TRUE(empty.recordsToHost().empty() && empty.getPositionsMeters().isempty()) << "empty export/math";
    empty.clearAngles();
    ASSERT_TRUE(!empty.getHasAzimuth()) << "clear empty angles";
    DetectionList plain(map);
    ASSERT_TRUE(plain.getIsEmpty() && !plain.getHasAngles()) << "empty list";
}

/** @brief Empty fromCells and precise u32 bins above f32 integer range. */
TEST(ArrayFireTypes, EmptyListsAndExactIntegerBins) {
    const auto map=makeMap();
    const auto empty=DetectionList::fromCells(map,{},{},{},{});
    ASSERT_TRUE(empty.getIsEmpty()) << "empty decoded list";
    DetectionList large(map.getMetadata(),map.getFirstRangeMeters(),map.getRangeBinSpacingMeters(),
        33554440,4,DopplerOrder::Unshifted,
        indices({1}),indices({16777217}),floats({1}),floats({0}),
        af::constant(1.0f,af::dim4(1),c32));
    ASSERT_EQ(large.recordsToHost()[0].getDopplerIndex(), 16777217u) << "no float conversion of indices";
    large.setDopplerOrder(DopplerOrder::Centered);
    EXPECT_EQ(large.recordsToHost()[0].getDopplerIndex(),33554437u);
    large.setDopplerOrder(DopplerOrder::Unshifted);
    EXPECT_EQ(large.recordsToHost()[0].getDopplerIndex(),16777217u);
}

/** @brief Direct calibration survives cropped/resampled stages and detached detections. */
TEST(ArrayFireTypes, DirectCalibrationAndPaddedFFT) {
    const CPI_Metadata metadata(10e6,2000,10e9,5e6,42,2e-6,10.0);
    const auto samples=SamplePulseBuffer::zeros(8,4,3,metadata);
    const RangePulseBuffer aligned(samples,samples.getDataC32());
    EXPECT_NEAR(aligned.getFirstRangeMeters(),299.792458,1e-9);
    EXPECT_NEAR(aligned.getRangeBinSpacingMeters(),14.9896229,1e-9);
    RangePulseBuffer ranges(samples,samples.getDataC32(),300.0,7.5);
    const auto cropped=ranges.sliceRanges(2,4).slicePulses(1,2);
    EXPECT_DOUBLE_EQ(cropped.getFirstRangeMeters(),315.0);
    EXPECT_EQ(cropped.getPulseCount(),2);
    EXPECT_NEAR(cropped.getPulseTimeSeconds(0),10.0005,1e-10);
    // Two actual pulses, eight Doppler bins: keep these meanings separate.
    auto map=RangeDopplerMap(cropped,af::fft(cropped.reorderForDopplerC32(),8));
    EXPECT_EQ(map.getDopplerBinCount(),8);
    EXPECT_EQ(map.getIntegratedPulseCount(),2);
    EXPECT_DOUBLE_EQ(map.getDopplerBinSpacingHz(),250.0);
    EXPECT_DOUBLE_EQ(map.getCoherentIntervalSeconds(),0.001);
    const auto sliced=map.sliceRanges(1,2);
    EXPECT_DOUBLE_EQ(sliced.getFirstRangeMeters(),322.5);
    auto list=DetectionList::fromMap(sliced,indices({1,10}),floats({1,2}),floats({3,4}));
    EXPECT_DOUBLE_EQ(list.getFirstRangeMeters(),322.5);
    EXPECT_DOUBLE_EQ(list.getRangeMetersForBin(1),330.0);
    EXPECT_DOUBLE_EQ(list.getDopplerHzForBin(2),500.0);
    EXPECT_EQ(list.getIntegratedPulseCount(),2);
    const auto rangeValues=host<float>(list.getRangesMeters());
    EXPECT_FLOAT_EQ(rangeValues[0],322.5f); EXPECT_FLOAT_EQ(rangeValues[1],330.0f);
    auto updated=metadata; updated.setPrfHz(4000.0);
    map.setMetadata(updated);
    EXPECT_DOUBLE_EQ(map.getDopplerBinSpacingHz(),500.0);
    EXPECT_DOUBLE_EQ(map.getCoherentIntervalSeconds(),0.0005);
    EXPECT_DOUBLE_EQ(list.getDopplerBinSpacingHz(),250.0); // Metadata stored by value.
    list.setMetadata(updated);
    EXPECT_DOUBLE_EQ(list.getDopplerBinSpacingHz(),500.0);
    EXPECT_FLOAT_EQ(host<float>(list.getDopplerHz())[1],1000.0f);
}

/** @brief Odd/even FFT shifting and sparse index remapping preserve physical coordinates. */
TEST(ArrayFireTypes, OddEvenDopplerOrdering) {
    const CPI_Metadata metadata(10e6,2000,10e9,5e6);
    for(dim_t n=2;n<=17;++n) {
        SCOPED_TRACE(::testing::Message() << "FFT length=" << n);
        std::vector<af::cfloat> values(static_cast<std::size_t>(n));
        std::vector<unsigned> binIds(static_cast<std::size_t>(n));
        for(dim_t k=0;k<n;++k) {values[k]={static_cast<float>(k),0};binIds[k]=static_cast<unsigned>(k);}
        const RangeDopplerMap map(af::array(n,values.data(),afHost),metadata,100.0,2.0,2);
        auto list=DetectionList::fromMap(map,af::array(n,binIds.data(),afHost),
            af::constant(1.0f,n,f32),af::constant(0.0f,n,f32));
        list.setAngles(af::constant(0.2f,n,f32),af::constant(0.1f,n,f32));
        auto centered=map.withDopplerOrder(DopplerOrder::Centered);
        const auto centeredValues=centered.toHost();
        list.setDopplerOrder(DopplerOrder::Centered);
        auto records=list.recordsToHost(3);
        const auto frequencies=host<float>(list.getDopplerHz());
        for(dim_t k=0;k<n;++k) {
            const auto signedBin=k< (n+1)/2?k:k-n;
            const auto shifted=(k+n/2)%n;
            EXPECT_EQ(map.getSignedDopplerBin(k),signedBin);
            EXPECT_EQ(centered.getSignedDopplerBin(shifted),signedBin);
            EXPECT_FLOAT_EQ(centeredValues[shifted].real,static_cast<float>(k));
            EXPECT_EQ(records[k].getDopplerIndex(),static_cast<unsigned>(shifted));
            EXPECT_NEAR(frequencies[k],map.getDopplerHz(k),0.001);
            EXPECT_NEAR(list.getDopplerHzForBin(static_cast<unsigned>(shifted)),map.getDopplerHz(k),1e-9);
            EXPECT_FLOAT_EQ(*records[k].getAzimuthRadians(),0.2f);
        }
        centered.setDopplerOrder(DopplerOrder::Unshifted);
        list.setDopplerOrder(DopplerOrder::Unshifted);
        records=list.recordsToHost(1);
        const auto restored=centered.toHost();
        for(dim_t k=0;k<n;++k) {
            EXPECT_EQ(records[k].getDopplerIndex(),static_cast<unsigned>(k));
            EXPECT_FLOAT_EQ(restored[k].real,static_cast<float>(k));
        }
    }
}

/** @brief List-wide replacement clears stale angles; GPU selection moves whole logical records. */
TEST(ArrayFireTypes, WholeListReplacementAndBatchedExport) {
    const auto map=makeMap();
    auto list=DetectionList::fromMap(map,indices({10,45,10}),floats({7,8,9}),floats({12,13,14}));
    list.setAngles(floats({0.1f,0.2f,0.3f}),floats({0.4f,0.5f,0.6f}));
    const auto saved=list;
    for(std::size_t batch:{1u,2u,4096u}) {
        const auto hostRecords=list.recordsToHost(batch);
        ASSERT_EQ(hostRecords.size(),3);
        EXPECT_FLOAT_EQ(hostRecords[1].getAmplitude(),8.0f);
        EXPECT_FLOAT_EQ(*hostRecords[2].getElevationRadians(),0.6f);
    }
    list.setDetections(indices({1,2}),indices({3,4}),floats({5,6}),floats({7,8}),
                       af::constant(2.0f,2,c32));
    EXPECT_EQ(list.getDetectionCount(),2); EXPECT_FALSE(list.getHasAngles());
    EXPECT_EQ(saved.getDetectionCount(),3); EXPECT_TRUE(saved.getHasAngles());
    const auto selected=list.select(indices({1,0,1})).recordsToHost();
    ASSERT_EQ(selected.size(),3);
    EXPECT_EQ(selected[0].getRangeIndex(),2u);
    EXPECT_EQ(selected[0].getDopplerIndex(),4u);
    EXPECT_FLOAT_EQ(selected[0].getAmplitude(),6.0f);
    EXPECT_FLOAT_EQ(selected[0].getSnrDb(),8.0f);
    EXPECT_FLOAT_EQ(selected[0].getComplexPairC32().real(),2.0f);
}


/** @brief Named factories are the only allocation/upload routes; existing arrays are adopted directly. */
TEST(ArrayFireTypes, NamedCubeFactoriesAndReplacement) {
    static_assert(std::is_constructible_v<SamplePulseBuffer, af::array, CPI_Metadata>);
    static_assert(!std::is_constructible_v<SamplePulseBuffer, dim_t, dim_t, dim_t, CPI_Metadata>);
    static_assert(!std::is_constructible_v<SamplePulseBuffer, std::span<const af::cfloat>,
                                           dim_t, dim_t, dim_t, CPI_Metadata>);
    const CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6, 13);
    const auto zero = SamplePulseBuffer::zeros(3, 2, 2, metadata);
    EXPECT_EQ(zero.getDataC32().type(), c32);
    EXPECT_EQ(zero.getSampleCount(), 3);
    EXPECT_EQ(zero.getPulseCount(), 2);
    EXPECT_EQ(zero.getElementCount(), 2);
    for (const auto value : zero.toHost()) {
        EXPECT_FLOAT_EQ(value.real, 0.0f);
        EXPECT_FLOAT_EQ(value.imag, 0.0f);
    }
    std::vector<af::cfloat> values(12);
    for (std::size_t i = 0; i < values.size(); ++i)
        values[i] = {static_cast<float>(i + 1), -static_cast<float>(i)};
    auto uploaded = SamplePulseBuffer::fromHost(values, 3, 2, 2, metadata);
    af::array iqC32(af::dim4(3, 2, 2), values.data(), afHost);
    const SamplePulseBuffer adopted(std::move(iqC32), metadata);
    const auto uploadValues = uploaded.toHost();
    const auto adoptedValues = adopted.toHost();
    ASSERT_EQ(uploadValues.size(), values.size());
    ASSERT_EQ(adoptedValues.size(), values.size());
    for (std::size_t i = 0; i < values.size(); ++i) {
        EXPECT_FLOAT_EQ(uploadValues[i].real, values[i].real);
        EXPECT_FLOAT_EQ(uploadValues[i].imag, values[i].imag);
        EXPECT_FLOAT_EQ(adoptedValues[i].real, values[i].real);
        EXPECT_FLOAT_EQ(adoptedValues[i].imag, values[i].imag);
    }
    const auto original = uploaded;
    uploaded.setDataC32(zero.getDataC32());
    EXPECT_FLOAT_EQ(uploaded.toHost()[0].real, 0.0f);
    EXPECT_FLOAT_EQ(original.toHost()[0].real, 1.0f);
    EXPECT_EQ(uploaded.getMetadata().getCpiId(), metadata.getCpiId());
    auto deep = original.clone();
    deep.setDataC32(zero.getDataC32());
    EXPECT_FLOAT_EQ(original.toHost()[1].real, 2.0f);
    EXPECT_FLOAT_EQ(deep.toHost()[1].real, 0.0f);
}

/** @brief Action-named compute/reorder methods preserve their layouts, values and input IQ. */
TEST(ArrayFireTypes, ExplicitComputeAndReorderOperations) {
    const CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6);
    std::vector<af::cfloat> values(3 * 2 * 2);
    for (std::size_t i = 0; i < values.size(); ++i)
        values[i] = {static_cast<float>(i + 1), 0.5f};
    const auto samples = SamplePulseBuffer::fromHost(values, 3, 2, 2, metadata);
    const RangePulseBuffer ranges(samples, samples.getDataC32());
    const af::array reordered = ranges.reorderForDopplerC32();
    const RangeDopplerMap map(ranges, reordered); // Reorder only: a layout test, not an FFT.
    EXPECT_EQ(reordered.type(), c32);
    EXPECT_EQ(reordered.dims(0), 2);
    EXPECT_EQ(reordered.dims(1), 3);
    EXPECT_EQ(reordered.dims(2), 2);
    const auto rawPower = host<float>(samples.computePower());
    const auto rangePower = host<float>(ranges.computePower());
    const af::array mapPowerArray = map.computePower();
    const af::array sumPowerArray = map.computePowerSumElements();
    EXPECT_EQ(mapPowerArray.type(), f32);
    EXPECT_EQ(sumPowerArray.type(), f32);
    EXPECT_EQ(sumPowerArray.dims(0), 2);
    EXPECT_EQ(sumPowerArray.dims(1), 3);
    EXPECT_EQ(sumPowerArray.dims(2), 1);
    const auto mapPower = host<float>(mapPowerArray);
    const auto summed = host<float>(sumPowerArray);
    const af::array rangeFirst = map.reorderToRangeFirstC32();
    EXPECT_EQ(rangeFirst.type(), c32);
    EXPECT_EQ(rangeFirst.dims(0), 3);
    EXPECT_EQ(rangeFirst.dims(1), 2);
    EXPECT_EQ(rangeFirst.dims(2), 2);
    const auto restored = host<af::cfloat>(rangeFirst);
    const auto reorderedValues = map.toHost();
    for (dim_t range = 0; range < 3; ++range) {
        for (dim_t pulse = 0; pulse < 2; ++pulse) {
            float sum = 0.0f;
            for (dim_t element = 0; element < 2; ++element) {
                const auto sourceIndex = static_cast<std::size_t>(range + 3 * (pulse + 2 * element));
                const auto mapIndex = static_cast<std::size_t>(pulse + 2 * (range + 3 * element));
                const auto value = values[sourceIndex];
                const float expected = value.real * value.real + value.imag * value.imag;
                EXPECT_FLOAT_EQ(rawPower[sourceIndex], expected);
                EXPECT_FLOAT_EQ(rangePower[sourceIndex], expected);
                EXPECT_FLOAT_EQ(mapPower[mapIndex], expected);
                EXPECT_FLOAT_EQ(reorderedValues[mapIndex].real, value.real);
                EXPECT_FLOAT_EQ(reorderedValues[mapIndex].imag, value.imag);
                EXPECT_FLOAT_EQ(restored[sourceIndex].real, value.real);
                EXPECT_FLOAT_EQ(restored[sourceIndex].imag, value.imag);
                sum += expected;
            }
            EXPECT_FLOAT_EQ(summed[static_cast<std::size_t>(pulse + 2 * range)], sum);
        }
    }
    EXPECT_FLOAT_EQ(samples.toHost()[0].real, 1.0f);
    EXPECT_FLOAT_EQ(ranges.toHost()[0].imag, 0.5f);
}
