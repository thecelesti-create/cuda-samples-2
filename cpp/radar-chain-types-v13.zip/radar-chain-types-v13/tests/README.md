# GoogleTest suites — v13

Tests are OFF by default. Enable RADAR_BUILD_TESTS=ON and supply GoogleTest 1.12+
through an installed config package or existing parent-provided targets. No
custom assertion framework, examples or automatic downloads are included.

| Runner | Cases | CTest prefix |
|---|---:|---|
| radar_metadata_tests | 3 | radar_metadata. |
| radar_arrayfire_tests | 11 | radar_arrayfire. |
| radar_interferometry_reference_tests | 5 | radar_interferometry_reference. |
| radar_interferometry_tests | 12 | radar_interferometry. |

Case counts describe source inventory, not execution status. See ../VALIDATION.md.

The chain runs in radar_arrayfire_tests:

- PipelineTests.ThreeFakeAlgorithms in simple_pipeline_tests.cpp: gain, reorder,
  fabricated cell zero, expected amplitude 2, SNR 6.0206 dB, I/Q 2+0i.
- PipelineTests.MatchedFilterDopplerDetection in reference_pipeline_tests.cpp:
  deterministic Barker echo at range sample 18 / Doppler bin 3, amplitude 112.

The actual angle estimator's synthetic fixture remains
InterferometryTests.SyntheticRectangularArray. New tests cover direct scalar
calibration, range crops, actual pulse count versus FFT padding, PRF propagation,
odd/even data shifts and sparse index remapping, whole-list replacement,
batched final export and explicit assignment of device-angle results. Angle tests retain packed,
separate-map and already-gathered c32 input cases, fixed-sign input, empty lists
and NaNs. New cases cover direct constructor parameters, inferred linear element
count, unequal rectangular spacing, CPI wavelength, and independence of spatial
phase convention from the CPI Doppler-sign setting.
v13 adds named-factory/adoption coverage, renamed power/reorder layout checks,
component zero-test regressions, tiny-signal estimates and all three estimate
assignment paths for both algorithms. The private phase helper is included only
by an existing test translation unit; it is not added to the public API.
All checks run only in tests, including in Release mode.

```sh
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release --no-tests=error --output-on-failure
ctest --test-dir build-tests -C Release -R "PipelineTests" -V --no-tests=error
```

Use cpu/opencl instead of cuda for other installed backends. CMake's unified
configuration passes that argument to the ArrayFire test main; explicit backend
failure is not skipped or changed to a fallback. Direct-linked builds take no
backend argument. GTest discovery lists cases before backend initialization but
still requires shared libraries on the loader path.

```sh
./build-tests/tests/radar_arrayfire_tests cuda --gtest_filter="PipelineTests.*"
```

Visual Studio:

```powershell
.\build-tests\tests\Release\radar_arrayfire_tests.exe cuda --gtest_filter="PipelineTests.*"
```

Without ArrayFire, RADAR_BUILD_ARRAYFIRE_TYPES=OFF enables building the numeric
metadata library (there is no geometry library). With GTest installed and tests opted in, that
configuration also builds the metadata and independent phase-model suites.
Those are not substitutes for execution of the actual ArrayFire implementation.
