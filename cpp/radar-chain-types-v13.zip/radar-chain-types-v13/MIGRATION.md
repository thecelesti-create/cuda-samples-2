# Migration: v12 -> v13

This revision applies **only proposals #1, #2, #3 and #4** approved in the review.
Extract into a clean directory and rebuild consumers. No compatibility aliases
or forwarding wrappers for removed entry points are provided.

## 1. Phase zero test

The interferometry helper now uses:

```cpp
const af::array nonzero = (af::real(correlation) != 0.0f) ||
                          (af::imag(correlation) != 0.0f);
```

Only exactly zero real AND imaginary components select the NaN fallback. A small
nonzero correlation can have a valid phase even if its squared magnitude would
underflow in f32. No extra validation, host readback or per-detection CPU loop was
added. This does not prevent underflow while forming the correlation itself.

## 2. Assign estimate results explicitly

All six `estimateInPlace()` overloads are removed. Their implementation was
assignment of `estimate()`; write that assignment directly:

```cpp
// Before:
estimator.estimateInPlace(rdm, detections);
// After:
detections = estimator.estimate(rdm, detections);
```

The same replacement applies to separate-RDM spans and pre-gathered c32 IQ.
Returning a list preserves base device columns through ArrayFire handles and
attaches computed angle columns. It does not promise reuse of angle storage.
The three value-returning overloads on each estimator are unchanged.

## 3. Named allocation/upload factories; fewer replacement wrappers

| Old route | v13 route |
|---|---|
| `SamplePulseBuffer(S, P, E, metadata)` | `SamplePulseBuffer::zeros(S, P, E, metadata)` |
| `SamplePulseBuffer(hostIq, S, P, E, metadata)` | `SamplePulseBuffer::fromHost(hostIq, S, P, E, metadata)` |
| `buffer.withDataC32(iq)` | Copy the wrapper explicitly, then call `setDataC32(iq)` |

The two removed constructors are not retained as private overloads. Factories
create one ArrayFire result and pass it to the retained array-adopting constructor.
`SamplePulseBuffer(af::array, CPI_Metadata)` is still public. All processed-stage
constructors remain, including those that carry metadata from an earlier stage.
`withDataC32()` is removed from all three cube types. `setDataC32()` and `clone()`
are unchanged:

```cpp
auto changed = original;              // Retain handles and small metadata.
changed.setDataC32(std::move(iqC32));  // Same shape/type/context are preconditions.
auto detached = original.clone();    // Explicit deep copy when actually required.
```

`withDopplerOrder()` is intentionally unchanged; it was not one of the approved
removals. No cached-dimension or same-shape caller contract changes were made.

## 4. Action names for compute/reorder operations

| v12 | v13 |
|---|---|
| `RangePulseBuffer::getDopplerInputC32()` | `reorderForDopplerC32()` |
| `RangeDopplerMap::getRangeFirstDataC32()` | `reorderToRangeFirstC32()` |
| `getPower()` on all three cubes | `computePower()` |
| `RangeDopplerMap::getPowerSumElements()` | `computePowerSumElements()` |

The calculations and data layouts behind these methods are unchanged; no cached
results or persistent arrays were introduced. Ordinary getters/setters, such as
`getDataC32()` and `setMetadata()`, keep their explicit prefixes.

```cpp
#include <radar/RangeDopplerMap.hpp>
#include <radar/RangePulseBuffer.hpp>
#include <utility>

radar::RangeDopplerMap doDoppler(const radar::RangePulseBuffer& input) {
    af::array fftC32 = af::fft(input.reorderForDopplerC32());
    return {input, std::move(fftC32)};
}
```

## Deliberately unchanged (#5–#8 not applied)

No forward-declaration/header-dependency refactoring; no shared scalar Doppler
helper; no gather-view hoisting/caching; no change to CMake language/default-build
policies. The root CMake change is only the version bump to 0.13.0. Detection
storage, calibration, fixed conventions, input forms and batching remain intact.

Libraries remain the default. Tests remain opt-in GoogleTest executables under
the test tree. `radar_arrayfire_tests` still contains both `PipelineTests.*` cases.
Use `VALIDATION.md` to distinguish source inventory from tests actually executed.
