# ArrayFire 3.10 container build and tests — v13

The existing Dockerfile provides a `cpu` target (source-built ArrayFire 3.10.0) and
`cuda` target (official ArrayFire 3.10.0 binary SDK with the configured CUDA 12.8.1
base image). Both explicitly enable `RADAR_BUILD_TESTS=ON`. They are development
and test environments, not minimized deployment images.

**The Docker images have not been built/run in this revision's execution
environment.** See `VALIDATION.md`. Installation recipes and upstream dependency
versions are inherited; this revision applies the four approved API/numerical cleanups, not
the SDK installation strategy. The recipes remain unexecuted here.

## Build and run

From the extracted repository root:

```sh
docker build --platform linux/amd64 --target cpu -t radar-af:cpu .
docker run --rm radar-af:cpu

docker build --platform linux/amd64 --target cuda -t radar-af:cuda .
docker run --rm --gpus all radar-af:cuda
```

The GPU target requires a compatible host NVIDIA driver and container GPU access.
On Windows use Docker Desktop's Linux/WSL2 GPU setup. The Dockerfile does not grant
GPU access to a host without it. Internet access is needed to fetch base images,
packages and the SDK. For lower build-memory use pass `--build-arg BUILD_JOBS=1`.

Both image builds run CTest on the CPU backend because normal image builds do not
expose a GPU. CUDA tests are requested at runtime with `--gpus all`. A missing
requested backend is a failure, not a successful CPU fallback.

## Test organization

Both Docker targets now install `libgtest-dev`. All test executables use the real
GoogleTest library; no private assertion framework is retained. The image build
uses CTest to discover and run each case on CPU. The runtime script runs the same
GoogleTest executables with the requested backend. CPU/CUDA arguments are unchanged.


The default non-container library build has tests OFF. Containers opt in because
their purpose is to test the libraries. There are four runners, all in
`/opt/radar/build/tests/`:

```text
radar_metadata_tests                  Scalar value classes
radar_arrayfire_tests                 Core types + fake and reference pipelines
radar_interferometry_reference_tests  Independent scalar phase model
radar_interferometry_tests            Actual estimators + synthetic 4x3 case
```

There are no demo executables, regex-output verifier, or separate application
steps. The numerical expectations live in C++ test functions linked into those
runners. The runtime script calls all four and passes the selected backend to
the ArrayFire-backed tests.

To run only one runner on the GPU:

```sh
docker run --rm --gpus all --entrypoint /opt/radar/build/tests/radar_arrayfire_tests radar-af:cuda cuda
```

For tests that do not need a backend:

```sh
docker run --rm --entrypoint ctest radar-af:cpu --test-dir /opt/radar/build -L unit --no-tests=error --output-on-failure
```

## Logs

Build-time logs are at `/opt/radar/build/validation/`. Runtime logs default to
`/tmp/radar-test-logs/` and are lost with `--rm` unless mounted out.

```sh
mkdir -p test-logs
docker run --rm --gpus all -v "$PWD/test-logs:/results" -e RADAR_TEST_LOG_DIR=/results radar-af:cuda
```

PowerShell:

```powershell
New-Item -ItemType Directory -Force test-logs | Out-Null
$logs = (Resolve-Path test-logs).Path
docker run --rm --gpus all --mount "type=bind,source=$logs,target=/results" -e RADAR_TEST_LOG_DIR=/results radar-af:cuda
```

Do not mount over `/opt/radar`, which would hide the built files. Container runtime
scripts write only logs through the specified results mount. These correctness
tests are not GPU benchmarks or validations against measured radar scenes.

SDK reference locations are retained in `API_REFERENCES.md` and the installer
scripts. OS packages and image digests are not fully pinned; bit-for-bit container
reproducibility is not claimed.
