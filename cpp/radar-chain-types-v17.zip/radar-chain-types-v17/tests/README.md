# GoogleTest suites — v17

Tests are OFF by default. Enable RADAR_BUILD_TESTS=ON and supply GoogleTest 1.11+
through an installed config package or existing parent-provided targets. No
custom assertion framework, examples or automatic downloads are included.

## GoogleTest 1.11 baseline

The installed package requirement is `find_package(GTest 1.11 CONFIG REQUIRED)`.
The shared ArrayFire runner reads `::testing::GTEST_FLAG(list_tests)`, not the
newer `GTEST_FLAG_GET` macro. Discovery still returns before device initialization.
Existing parent-provided `GTest::gtest` / `GTest::gtest_main` targets are accepted;
the parent is responsible for supplying version 1.11 or newer. No FetchContent,
vendored framework, compatibility shim, or automatic upgrade is introduced.

Tests use `TEST`, basic `ASSERT_*` / `EXPECT_*`, `ASSERT_NO_FATAL_FAILURE`,
`SCOPED_TRACE`, `testing::Message`, and `Test::RecordProperty`. The disabled timing
tests and CLI filters are retained. CMake's `gtest_discover_tests` / `PRE_TEST`
are CMake features (the project requires CMake 3.20), not GoogleTest 1.12 features.
See `../VALIDATION.md` for the distinction between source review and executed tests.

| Runner | Cases | CTest prefix |
|---|---:|---|
| radar_metadata_tests | 3 | radar_metadata. |
| radar_arrayfire_tests | 15 (1 disabled) | radar_arrayfire. |
| radar_interferometry_reference_tests | 5 | radar_interferometry_reference. |
| radar_interferometry_tests | 16 (1 disabled) | radar_interferometry. |

Case counts describe source inventory, not execution status. See ../VALIDATION.md.

The chain runs in radar_arrayfire_tests:

- PipelineTests.ThreeFakeAlgorithms in simple_pipeline_tests.cpp: gain, reorder,
  fabricated cell zero, expected amplitude 2, SNR 6.0206 dB, I/Q 2+0i.
- PipelineTests.MatchedFilterDopplerDetection in reference_pipeline_tests.cpp:
  deterministic Barker echo at range sample 18 / Doppler bin 3, amplitude 112.

The synthetic azimuth fixture is `InterferometryTests.SyntheticLinearAzimuth`:
five half-wavelength phase centers, expected azimuth 20 degrees, elevation absent.
The actual estimator tests use the one phase-centered RDM API and cover inferred
phase-center count,
positive/negative/zero azimuth, batch boundaries, a separate sum-beam detector,
CPI wavelength, fixed spatial convention independent of Doppler sign, tiny/zero
correlation, duplicate/nonzero cells, metadata and representative IQ preservation.

One compile-time member-signature check requires exactly one estimate overload;
additional invocability checks reject raw ArrayFire IQ and a span of RDMs.
Elemental and coherent subarray fixtures use the same API. All detector fixtures
in the azimuth suite use a one-plane sum beam; a regression changes only the
representative detector I/Q and verifies that angles still come from the
phase-centered RDM.

Azimuth-only regressions verify stale elevation is cleared from outputs while
inputs retain their old angles; empty lists also have no elevation column. A varied
per-cell fixture compares the real linear reduction to a scalar independent sum.
The reference suite checks the horizontal model and explicitly demonstrates the
off-plane apparent-angle limitation. No planar estimator or rectangular test remains.

There are 39 source cases: 37 default correctness cases and two disabled timing
cases. Counts are source inventory, NOT execution results. The disabled core
`ArrayFirePerformance.*` case is unchanged. The azimuth-only case is
`InterferometryPerformance.DISABLED_DeviceResidentAzimuthEstimation` and runs only
with `--gtest_also_run_disabled_tests`. See ../PERFORMANCE.md for commands.

All checks run only in tests, including in Release mode.

```sh
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release --no-tests=error --output-on-failure
ctest --test-dir build-tests -C Release -R "PipelineTests" -V --no-tests=error
```

Use cpu/opencl instead of cuda for other installed backends. CMake's unified
configuration passes that argument to the ArrayFire test main; explicit backend
failure is not skipped or changed to a fallback. Direct-linked builds take no
backend argument. GTest discovery lists cases before backend initialization but
still requires shared libraries on the loader path.

```sh
./build-tests/tests/radar_arrayfire_tests cuda --gtest_filter="PipelineTests.*"
```

Visual Studio:

```powershell
.\build-tests\tests\Release\radar_arrayfire_tests.exe cuda --gtest_filter="PipelineTests.*"
```

Without ArrayFire, RADAR_BUILD_ARRAYFIRE_TYPES=OFF enables building the numeric
metadata library (there is no geometry library). With GTest installed and tests opted in, that
configuration also builds the metadata and independent phase-model suites.
Those are not substitutes for execution of the actual ArrayFire implementation.
