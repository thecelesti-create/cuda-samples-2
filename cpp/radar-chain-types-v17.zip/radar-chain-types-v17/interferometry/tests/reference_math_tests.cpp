#include <gtest/gtest.h>
#include <radar/types.hpp>
#include <cmath>
#include <complex>
#include <cstddef>
#include <limits>
#include <initializer_list>
#include <vector>

// Independent scalar oracle only: this does NOT run ArrayFire or the production estimator.
namespace {
using radar::pi;
constexpr double wavelength = 0.03;
/** @brief Generate a positive-exponent uniform-line model with positive unequal gains. */
std::vector<std::complex<double>> synthesize(std::size_t elementCount, double spacing,
                                            double directionCosine) {
    std::vector<std::complex<double>> iq(elementCount);
    for (std::size_t element = 0; element < elementCount; ++element) {
        const double phase = 2.0 * pi / wavelength * static_cast<double>(element) * spacing * directionCosine;
        iq[element] = std::polar(1.0 + 0.05 * static_cast<double>(element), phase + 0.63);
    }
    return iq;
}
/** @brief Independently estimate apparent azimuth; exactly zero correlation is undefined. */
double scalarAzimuth(const std::vector<std::complex<double>>& iq, double spacing) {
    std::complex<double> correlation{};
    for (std::size_t element = 0; element + 1 < iq.size(); ++element)
        correlation += std::conj(iq[element]) * iq[element + 1];
    if (correlation.real() == 0.0 && correlation.imag() == 0.0)
        return std::numeric_limits<double>::quiet_NaN();
    return std::asin(wavelength / (2.0 * pi * spacing) * std::arg(correlation));
}
} // namespace

/** @brief Horizontal positive/negative azimuth is recovered for several counts and spacings. */
TEST(InterferometryReference, HorizontalAzimuth) {
    for (std::size_t count : {2U, 5U, 8U}) {
        for (double spacing : {0.2*wavelength, 0.4*wavelength, 0.5*wavelength}) {
            for (int degrees = -70; degrees <= 70; degrees += 5) {
                const double azimuth = degrees * pi / 180.0;
                EXPECT_NEAR(scalarAzimuth(synthesize(count, spacing, std::sin(azimuth)), spacing),
                            azimuth, 1e-11);
            }
        }
    }
}

/** @brief Conjugation reverses the fixed-convention azimuth; it is not auto-detected. */
TEST(InterferometryReference, ConjugationMirrorsAzimuth) {
    auto iq = synthesize(5, wavelength/2, std::sin(0.3));
    for (auto& value : iq) value = std::conj(value);
    EXPECT_NEAR(scalarAzimuth(iq, wavelength/2), -0.3, 1e-11);
}

/** @brief A horizontal line cannot independently recover true azimuth off the assumed plane. */
TEST(InterferometryReference, OffPlaneDirectionIsApparentAzimuth) {
    for (double azimuth : {-0.5, 0.3}) {
        for (double elevation : {-0.4, 0.2}) {
            const double u = std::cos(elevation) * std::sin(azimuth);
            const double result = scalarAzimuth(synthesize(5, wavelength/2, u), wavelength/2);
            EXPECT_NEAR(result, std::asin(u), 1e-11);
            EXPECT_GT(std::abs(result - azimuth), 1e-3);
        }
    }
}

/** @brief Large effective subarray spacings have only a limited unambiguous field of view. */
TEST(InterferometryReference, LongSpacingHasNoAmbiguityResolution) {
    EXPECT_NEAR(scalarAzimuth(synthesize(5, 2*wavelength, 0.1), 2*wavelength), std::asin(0.1), 1e-11);
    EXPECT_NEAR(scalarAzimuth(synthesize(5, wavelength, 0.75), wavelength), std::asin(-0.25), 1e-11);
}

/** @brief Zero or nonphysical correlation remains undefined rather than clipped to a target. */
TEST(InterferometryReference, UndefinedAzimuth) {
    EXPECT_TRUE(std::isnan(scalarAzimuth(std::vector<std::complex<double>>(5), wavelength/2)));
    // u=1.2 is nonphysical but has an unwrapped phase at this small spacing.
    EXPECT_TRUE(std::isnan(scalarAzimuth(synthesize(5, 0.1*wavelength, 1.2), 0.1*wavelength)));
}
