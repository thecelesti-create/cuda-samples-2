#include <gtest/gtest.h>
#include "../src/device_helpers.hpp"
#include <radar/CPI_Metadata.hpp>
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/interferometry/Interferometry1D.hpp>
#include <radar/types.hpp>
#include <cmath>
#include <complex>
#include <cstddef>
#include <initializer_list>
#include <span>
#include <type_traits>
#include <vector>

using namespace radar;
using namespace radar::interferometry;
static_assert(!std::is_aggregate_v<Interferometry1D>);
static_assert(!std::is_polymorphic_v<Interferometry1D>);
static_assert(std::is_trivially_copyable_v<Interferometry1D>);
static_assert(!std::is_constructible_v<Interferometry1D, double, double, std::size_t>);
// Taking the unqualified member address must be unambiguous: exactly one estimate API.
static_assert(std::is_same_v<decltype(&Interferometry1D::estimate),
    DetectionList (Interferometry1D::*)(const RangeDopplerMap&, const DetectionList&) const>);
static_assert(!std::is_invocable_v<decltype(&Interferometry1D::estimate),
    const Interferometry1D&, const af::array&, const DetectionList&>);
static_assert(!std::is_invocable_v<decltype(&Interferometry1D::estimate),
    const Interferometry1D&, std::span<const RangeDopplerMap>, const DetectionList&>);

namespace {
/** @brief Upload a u32 test index column. */
af::array ids(std::initializer_list<unsigned> values) {
    return af::array(static_cast<dim_t>(values.size()), values.begin(), afHost);
}
/** @brief Synthesize a phase-centered RDM with positive exponent and unequal gains. */
RangeDopplerMap makeLine(std::size_t elementCount, double azimuth,
                        double spacingWavelengths = 0.5, double carrierHz = 10e9) {
    constexpr dim_t dopplerCount = 8, rangeCount = 6;
    const CPI_Metadata metadata(10e6, 2000, carrierHz, 5e6, 12);
    std::vector<af::cfloat> iq(static_cast<std::size_t>(dopplerCount * rangeCount) * elementCount);
    for (std::size_t element = 0; element < elementCount; ++element) {
        const double phase = 2.0 * pi * static_cast<double>(element) * spacingWavelengths *
                             std::sin(azimuth) + 0.63;
        const double gain = 1.0 + 0.1 * static_cast<double>(element);
        for (dim_t cell = 0; cell < dopplerCount * rangeCount; ++cell) {
            iq[static_cast<std::size_t>(cell) +
               static_cast<std::size_t>(dopplerCount * rangeCount) * element] = {
                   static_cast<float>(gain * std::cos(phase)),
                   static_cast<float>(gain * std::sin(phase))};
        }
    }
    return {af::array(af::dim4(dopplerCount, rangeCount, static_cast<dim_t>(elementCount)),
                     iq.data(), afHost), metadata, 100.0, 10.0, 4};
}
/** @brief Form a one-plane sum-beam test fixture; only this map feeds the detector. */
RangeDopplerMap makeSumBeam(const RangeDopplerMap& phaseCenteredRdm) {
    return {af::sum(phaseCenteredRdm.getData(), 2), phaseCenteredRdm.getMetadata(),
            phaseCenteredRdm.getFirstRangeMeters(), phaseCenteredRdm.getRangeBinSpacingMeters(),
            phaseCenteredRdm.getIntegratedPulseCount(), phaseCenteredRdm.getDopplerOrder()};
}
/** @brief Fabricate five detections from sum-beam data, including nonzero and duplicate cells. */
DetectionList detected(const RangeDopplerMap& sumBeamRdm) {
    return DetectionList::fromMap(sumBeamRdm, ids({10, 45, 10, 0, 35}),
        af::constant(1.0f, af::dim4(5), f32), af::constant(20.0f, af::dim4(5), f32));
}
/** @brief Verify azimuth and preserve every sum-beam record field and calibration scalar. */
void checkAzimuth(const DetectionList& output, const DetectionList& input, double azimuth) {
    ASSERT_TRUE(output.getHasAzimuth());
    EXPECT_FALSE(output.getHasElevation());
    EXPECT_FALSE(output.getHasAngles()); // This property means BOTH columns are present.
    EXPECT_EQ(output.getAzimuthRadians().type(), f32);
    EXPECT_EQ(output.getComplexPairs().type(), c32);
    const auto records = output.recordsToHost();
    const auto originals = input.recordsToHost();
    ASSERT_EQ(records.size(), 5U);
    ASSERT_EQ(records.size(), originals.size());
    for (std::size_t k = 0; k < records.size(); ++k) {
        const auto& record = records[k];
        ASSERT_TRUE(record.getAzimuthRadians().has_value());
        EXPECT_FALSE(record.getElevationRadians().has_value());
        EXPECT_NEAR(*record.getAzimuthRadians(), azimuth, 3e-5);
        EXPECT_EQ(record.getRangeIndex(), originals[k].getRangeIndex());
        EXPECT_EQ(record.getDopplerIndex(), originals[k].getDopplerIndex());
        EXPECT_FLOAT_EQ(record.getAmplitude(), originals[k].getAmplitude());
        EXPECT_FLOAT_EQ(record.getSnrDb(), originals[k].getSnrDb());
        EXPECT_EQ(record.getComplexPair(), originals[k].getComplexPair());
    }
    EXPECT_EQ(records[0].getRangeIndex(), 1U);
    EXPECT_EQ(records[0].getDopplerIndex(), 2U);
    EXPECT_EQ(records[2].getRangeIndex(), 1U);
    EXPECT_EQ(records[2].getDopplerIndex(), 2U);
    EXPECT_EQ(output.getMetadata().getCpiId(), input.getMetadata().getCpiId());
    EXPECT_DOUBLE_EQ(output.getMetadata().getBandwidthHz(), input.getMetadata().getBandwidthHz());
    EXPECT_DOUBLE_EQ(output.getFirstRangeMeters(), input.getFirstRangeMeters());
    EXPECT_DOUBLE_EQ(output.getRangeBinSpacingMeters(), input.getRangeBinSpacingMeters());
    EXPECT_EQ(output.getIntegratedPulseCount(), input.getIntegratedPulseCount());
    EXPECT_EQ(output.getDopplerBinCount(), input.getDopplerBinCount());
    EXPECT_EQ(output.getDopplerOrder(), input.getDopplerOrder());
}
} // namespace

/** @brief Only spacing and batch size are constructor configuration. */
TEST(InterferometryTests, ConstructorParameters) {
    const Interferometry1D line(0.01, 128);
    EXPECT_DOUBLE_EQ(line.getElementSpacingMeters(), 0.01);
    EXPECT_EQ(line.getDetectionBatchSize(), 128U);
    const Interferometry1D defaults(0.015);
    EXPECT_DOUBLE_EQ(defaults.getElementSpacingMeters(), 0.015);
    EXPECT_EQ(defaults.getDetectionBatchSize(), 4096U);
}

/** @brief Fixed convention covers negative/zero/positive azimuth and batch boundaries. */
TEST(InterferometryTests, LinearFixedConventionAndBatching) {
    for (double azimuth : {-0.35, 0.0, 0.25}) {
        const auto map = makeLine(5, azimuth);
        const auto list = detected(makeSumBeam(map));
        for (std::size_t block : {1U, 2U, 5U, 8U}) {
            const Interferometry1D estimator(map.getMetadata().getWavelengthMeters() / 2.0, block);
            ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, azimuth));
            EXPECT_FALSE(list.getHasAzimuth());
            EXPECT_FALSE(list.getHasElevation());
        }
    }
}

/** @brief Infer the phase-center count from the RDM, never from a one-plane detector map. */
TEST(InterferometryTests, LinearInfersPhaseCenterCount) {
    for (std::size_t count : {2U, 5U, 8U}) {
        const auto map = makeLine(count, 0.3);
        const auto sumBeam = makeSumBeam(map);
        ASSERT_EQ(sumBeam.getElementCount(), 1);
        const auto list = detected(sumBeam);
        for (std::size_t block : {1U, 2U, 8U}) {
            const Interferometry1D estimator(map.getMetadata().getWavelengthMeters() / 2.0, block);
            ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, 0.3));
        }
    }
}

/** @brief Sum-beam I/Q is retained in detections but never used as phase-center IQ. */
TEST(InterferometryTests, SumBeamDetectionsWithPhaseCenteredRdm) {
    const auto map = makeLine(5, -0.2, 0.4);
    const auto sumBeam = makeSumBeam(map);
    ASSERT_EQ(sumBeam.getElementCount(), 1);
    auto list = detected(sumBeam);
    const Interferometry1D estimator(0.4 * map.getMetadata().getWavelengthMeters(), 2);
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, -0.2));
    // Alter only the representative detector I/Q. Spatial phase must still come from the RDM.
    list.setComplexPairs(af::constant(0.0f, af::dim4(5), c32));
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, -0.2));
}

/** @brief Elemental and coherent subarray phase centers use exactly the same public function. */
TEST(InterferometryTests, ElementalAndSubarrayUseSameApi) {
    const auto elementalRdm = makeLine(5, 0.25, 0.5);
    const auto elementalDetections = detected(makeSumBeam(elementalRdm));
    const Interferometry1D elementalEstimator(
        0.5 * elementalRdm.getMetadata().getWavelengthMeters(), 2);
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(
        elementalEstimator.estimate(elementalRdm, elementalDetections), elementalDetections, 0.25));

    // A model of three coherent subarray centers, not a beamformer implementation.
    // The larger spacing is valid for this small angle's unambiguous phase interval.
    const auto subarrayRdm = makeLine(3, -0.1, 1.5);
    const auto subarrayDetections = detected(makeSumBeam(subarrayRdm));
    const Interferometry1D subarrayEstimator(
        1.5 * subarrayRdm.getMetadata().getWavelengthMeters(), 2);
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(
        subarrayEstimator.estimate(subarrayRdm, subarrayDetections), subarrayDetections, -0.1));
}

/** @brief The spatial phase sign is fixed and independent of CPI Doppler sign. */
TEST(InterferometryTests, SpatialSignIndependentOfDopplerSign) {
    auto map = makeLine(5, 0.25);
    auto metadata = map.getMetadata();
    metadata.setPositiveDoppler(PositiveDoppler::Receding);
    map.setMetadata(metadata);
    const auto list = detected(makeSumBeam(map));
    const Interferometry1D estimator(metadata.getWavelengthMeters() / 2.0);
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, 0.25));
    // Conjugation is only a test stimulus, not an automatic receiver-convention fix.
    map.setData(af::conjg(map.getData()));
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, -0.25));
}

/** @brief Physical spacing is constant while wavelength is read anew from each detection CPI. */
TEST(InterferometryTests, WavelengthFromCpiMetadata) {
    const Interferometry1D estimator(0.01);
    for (double carrierHz : {8e9, 12e9}) {
        const CPI_Metadata metadata(10e6, 2000, carrierHz, 5e6);
        const auto map = makeLine(5, 0.3, 0.01 / metadata.getWavelengthMeters(), carrierHz);
        const auto list = detected(makeSumBeam(map));
        ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, 0.3));
    }
}

/** @brief Empty lists mark azimuth present without gathering cells or retaining stale elevation. */
TEST(InterferometryTests, EmptyAzimuthOutput) {
    const auto map = makeLine(2, 0.0);
    DetectionList input(makeSumBeam(map));
    input.setAngles({}, {});
    const Interferometry1D estimator(map.getMetadata().getWavelengthMeters() / 2.0);
    const auto output = estimator.estimate(map, input);
    EXPECT_TRUE(output.getIsEmpty());
    EXPECT_TRUE(output.getHasAzimuth());
    EXPECT_FALSE(output.getHasElevation());
    EXPECT_FALSE(output.getHasAngles());
    EXPECT_TRUE(output.recordsToHost().empty());
    EXPECT_TRUE(input.getHasAngles());
}

/** @brief Undefined zero correlation remains NaN, not manufactured boresight or elevation. */
TEST(InterferometryTests, UndefinedAzimuth) {
    auto map = makeLine(5, 0.0);
    map.setData(af::constant(0.0f, map.getDimensions(), c32));
    const Interferometry1D estimator(map.getMetadata().getWavelengthMeters() / 2.0, 2);
    for (const auto& record : estimator.estimate(map, detected(makeSumBeam(map))).recordsToHost()) {
        ASSERT_TRUE(record.getAzimuthRadians().has_value());
        EXPECT_TRUE(std::isnan(*record.getAzimuthRadians()));
        EXPECT_FALSE(record.getElevationRadians().has_value());
    }
}

/** @brief Only the output replaces old angles; input columns and calibration are unchanged. */
TEST(InterferometryTests, ClearsStaleElevationAndPreservesInput) {
    const auto map = makeLine(5, 0.25);
    auto list = detected(makeSumBeam(map));
    list.setAngles(af::constant(-0.7f, af::dim4(5), f32), af::constant(0.4f, af::dim4(5), f32));
    for (std::size_t batch : {2U, 8U}) {
        const Interferometry1D estimator(map.getMetadata().getWavelengthMeters() / 2.0, batch);
        ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, 0.25));
    }
    EXPECT_TRUE(list.getHasAngles());
    for (const auto& record : list.recordsToHost()) {
        ASSERT_TRUE(record.getAzimuthRadians().has_value());
        ASSERT_TRUE(record.getElevationRadians().has_value());
        EXPECT_FLOAT_EQ(*record.getAzimuthRadians(), -0.7f);
        EXPECT_FLOAT_EQ(*record.getElevationRadians(), 0.4f);
    }
}

/** @brief Assigning a returned list keeps sum-beam records, calibration and detection order. */
TEST(InterferometryTests, AssignEstimateDeviceResultsAndMetadata) {
    const auto map = makeLine(5, 0.25);
    const auto original = detected(makeSumBeam(map));
    auto list = original;
    const Interferometry1D estimator(map.getMetadata().getWavelengthMeters() / 2.0, 2);
    list = estimator.estimate(map, list);
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(list, original, 0.25));
    list = estimator.estimate(map, list);
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(list, original, 0.25));
}

/** @brief Component zero testing preserves tiny phases and maps signed zero to NaN. */
TEST(InterferometryTests, PhasePreservesTinyNonzeroCorrelations) {
    const std::vector<af::cfloat> values{
        {0.0f, 0.0f}, {-0.0f, -0.0f}, {1e-25f, 0.0f}, {-1e-25f, 0.0f},
        {0.0f, 1e-25f}, {0.0f, -1e-25f}, {1e-25f, 1e-25f}, {-1e-25f, -1e-25f}};
    const af::array correlations(af::dim4(2, 4), values.data(), afHost);
    const af::array phases = radar::interferometry::detail::phase(correlations);
    ASSERT_EQ(phases.type(), f32);
    ASSERT_EQ(phases.dims(0), 8);
    ASSERT_EQ(phases.dims(1), 1);
    std::vector<float> actual(values.size());
    phases.host(actual.data()); // Explicit test boundary.
    EXPECT_TRUE(std::isnan(actual[0]));
    EXPECT_TRUE(std::isnan(actual[1]));
    for (std::size_t i = 2; i < values.size(); ++i) {
        SCOPED_TRACE(i);
        EXPECT_TRUE(std::isfinite(actual[i]));
        EXPECT_NEAR(actual[i], std::atan2(values[i].imag, values[i].real), 1e-6f);
    }
}

/** @brief Small correlations stay usable even when squaring their magnitude would underflow. */
TEST(InterferometryTests, TinySignalEstimatesRemainDefined) {
    for (double azimuth : {-0.25, 0.0, 0.25}) {
        auto map = makeLine(5, azimuth);
        map.setData(map.getData() * 1e-13f);
        const auto list = detected(makeSumBeam(map));
        const Interferometry1D estimator(map.getMetadata().getWavelengthMeters() / 2.0, 2);
        ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, azimuth));
    }
}

/** @brief Internal gather and reduction match a scalar per-cell oracle across batch sizes. */
TEST(InterferometryTests, LinearReductionMatchesScalarPerDetection) {
    constexpr std::size_t elementCount = 5;
    constexpr dim_t dopplerCount = 4, rangeCount = 3, cellCount = 12;
    const CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6);
    std::vector<af::cfloat> iq(static_cast<std::size_t>(cellCount) * elementCount);
    for (std::size_t element = 0; element < elementCount; ++element) {
        for (std::size_t cell = 0; cell < static_cast<std::size_t>(cellCount); ++cell) {
            const double azimuth = -0.3 + 0.04 * static_cast<double>(cell);
            const double phase = 2.0 * pi * 0.4 * static_cast<double>(element) * std::sin(azimuth) + 0.61;
            const double gain = 1.0 + 0.07 * static_cast<double>((element + cell) % 7);
            iq[cell + static_cast<std::size_t>(cellCount) * element] = {
                static_cast<float>(gain * std::cos(phase) + 0.003 * static_cast<double>((element + cell) % 3)),
                static_cast<float>(gain * std::sin(phase) - 0.002 * static_cast<double>((2 * element + cell) % 5))};
        }
    }
    const RangeDopplerMap map(af::array(af::dim4(dopplerCount, rangeCount, elementCount), iq.data(), afHost),
                              metadata, 100.0, 10.0, 4);
    const std::vector<unsigned> cells{11, 0, 7, 11, 4, 2, 9};
    const af::array selected(static_cast<dim_t>(cells.size()), cells.data(), afHost);
    const auto detections = DetectionList::fromMap(makeSumBeam(map), selected,
        af::constant(1.0f, selected.dims(), f32), af::constant(20.0f, selected.dims(), f32));
    std::vector<double> expected;
    for (const auto cell : cells) {
        const auto value = [&](std::size_t element) {
            const auto& q = iq[cell + static_cast<std::size_t>(cellCount) * element];
            return std::complex<double>(q.real, q.imag);
        };
        std::complex<double> correlation{};
        for (std::size_t element = 0; element + 1 < elementCount; ++element)
            correlation += std::conj(value(element)) * value(element + 1);
        expected.push_back(std::asin(std::arg(correlation) / (2.0 * pi * 0.4)));
    }
    for (std::size_t batch : {1U, 3U, 16U}) {
        const Interferometry1D estimator(0.4 * metadata.getWavelengthMeters(), batch);
        const auto records = estimator.estimate(map, detections).recordsToHost();
        ASSERT_EQ(records.size(), cells.size());
        for (std::size_t k = 0; k < cells.size(); ++k) {
            ASSERT_TRUE(records[k].getAzimuthRadians().has_value());
            EXPECT_FALSE(records[k].getElevationRadians().has_value());
            EXPECT_NEAR(*records[k].getAzimuthRadians(), expected[k], 3e-5);
            EXPECT_EQ(records[k].getRangeIndex(), cells[k] / dopplerCount);
            EXPECT_EQ(records[k].getDopplerIndex(), cells[k] % dopplerCount);
        }
    }
}
