#include <gtest/gtest.h>
#include <cmath>
#include <radar/CPI_Metadata.hpp>
#include <radar/DetectionList.hpp>
#include <radar/interferometry/Interferometry1D.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/types.hpp>
#include <vector>

/** @brief Five horizontal half-wavelength phase centers recover 20 degrees of azimuth only. */
TEST(InterferometryTests, SyntheticLinearAzimuth) {
    using namespace radar;
    using namespace radar::interferometry;
    constexpr dim_t dopplerCount = 8, rangeCount = 16, elementCount = 5;
    constexpr unsigned rangeIndex = 5, dopplerIndex = 2;
    const CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6, 7);
    const double azimuth = 20.0 * pi / 180.0;
    std::vector<af::cfloat> iq(dopplerCount * rangeCount * elementCount, {0.0f, 0.0f});
    for (dim_t element = 0; element < elementCount; ++element) {
        const double phase = pi * static_cast<double>(element) * std::sin(azimuth);
        iq[dopplerIndex + dopplerCount * (rangeIndex + rangeCount * element)] = {
            static_cast<float>(std::cos(phase)), static_cast<float>(std::sin(phase))};
    }
    const af::array data(af::dim4(dopplerCount, rangeCount, elementCount), iq.data(), afHost);
    const RangeDopplerMap phaseCenteredRdm(data, metadata, 100.0, 10.0, dopplerCount);
    const RangeDopplerMap sumBeamRdm(af::sum(phaseCenteredRdm.getData(), 2),
                                    metadata, 100.0, 10.0, dopplerCount);
    ASSERT_EQ(sumBeamRdm.getElementCount(), 1);
    const auto detections = DetectionList::fromMap(sumBeamRdm,
        af::constant(dopplerIndex + dopplerCount * rangeIndex, af::dim4(1), u32),
        af::constant(1.0f, af::dim4(1), f32), af::constant(20.0f, af::dim4(1), f32));
    const Interferometry1D estimator(metadata.getWavelengthMeters() / 2.0);
    const DetectionList located = estimator.estimate(phaseCenteredRdm, detections);
    ASSERT_TRUE(located.getHasAzimuth());
    EXPECT_FALSE(located.getHasElevation());
    EXPECT_FALSE(located.getHasAngles());
    EXPECT_FALSE(detections.getHasAzimuth());
    EXPECT_FALSE(detections.getHasElevation());
    EXPECT_EQ(located.getAzimuthRadians().type(), f32);
    EXPECT_EQ(located.getComplexPairs().type(), c32);
    const auto records = located.recordsToHost();
    ASSERT_EQ(records.size(), 1U);
    const auto& record = records.front();
    ASSERT_TRUE(record.getAzimuthRadians().has_value());
    EXPECT_FALSE(record.getElevationRadians().has_value());
    EXPECT_NEAR(*record.getAzimuthRadians(), azimuth, 2e-5);
    EXPECT_EQ(record.getRangeIndex(), rangeIndex);
    EXPECT_EQ(record.getDopplerIndex(), dopplerIndex);
    EXPECT_FLOAT_EQ(record.getAmplitude(), 1.0f);
    EXPECT_FLOAT_EQ(record.getSnrDb(), 20.0f);
    // Representative I/Q remains the detector's sum-beam value, not an element value.
    const auto detectorRecords = detections.recordsToHost();
    ASSERT_EQ(detectorRecords.size(), 1U);
    EXPECT_EQ(record.getComplexPair(), detectorRecords.front().getComplexPair());
    EXPECT_DOUBLE_EQ(located.getMetadata().getBandwidthHz(), metadata.getBandwidthHz());
}
