#include <gtest/gtest.h>
#include <arrayfire.h>
#include <radar/CPI_Metadata.hpp>
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/interferometry/Interferometry1D.hpp>
#include <chrono>
#include <iostream>
#include <string>

namespace {
/** @brief Test-only warm timing of completed ArrayFire calls; not a GPU kernel-only timer. */
template<class Operation>
double meanMilliseconds(Operation&& operation) {
    constexpr int warmups=3, repetitions=20;
    for(int i=0;i<warmups;++i) { operation(); af::sync(); }
    const auto start=std::chrono::steady_clock::now();
    for(int i=0;i<repetitions;++i) { operation(); af::sync(); }
    const auto stop=std::chrono::steady_clock::now();
    return std::chrono::duration<double,std::milli>(stop-start).count()/repetitions;
}
}

/** @brief Opt-in end-to-end azimuth timing including the internal selected-cell gather. */
TEST(InterferometryPerformance, DISABLED_DeviceResidentAzimuthEstimation) {
    constexpr dim_t dopplers=128,ranges=2048,elements=12,detectionCount=8192;
    const radar::CPI_Metadata metadata(10e6,2000.0,10e9,5e6);
    const radar::RangeDopplerMap phaseCenteredRdm(
        af::constant(1.0f,af::dim4(dopplers,ranges,elements),c32),metadata,0.0,15.0,dopplers);
    const radar::RangeDopplerMap sumBeamRdm(
        af::sum(phaseCenteredRdm.getData(),2),metadata,0.0,15.0,dopplers);
    const af::array cells=af::range(af::dim4(detectionCount),0,u32);
    const auto detections=radar::DetectionList::fromMap(sumBeamRdm,cells,
        af::constant(12.0f,cells.dims(),f32),af::constant(20.0f,cells.dims(),f32));
    phaseCenteredRdm.evaluate(); detections.evaluate(); af::sync();
    const double spacing=metadata.getWavelengthMeters()/2.0;
    const radar::interferometry::Interferometry1D estimator(spacing);
    auto output=detections;
    const double elapsed=meanMilliseconds([&] {
        output=estimator.estimate(phaseCenteredRdm,detections);
        output.evaluate();
    });
    EXPECT_EQ(output.getDetectionCount(),static_cast<std::size_t>(detectionCount));
    EXPECT_TRUE(output.getHasAzimuth());
    EXPECT_FALSE(output.getHasElevation());
    EXPECT_NEAR(output.getAzimuthRadians().scalar<float>(),0.0f,1e-6f);
    RecordProperty("phase_centered_rdm_ms",std::to_string(elapsed));
    std::cout << "8192 sum-beam detections, 12 phase centers, batch 4096, mean ms/call "
              << "including internal gather and fence: " << elapsed << '\n';
}
