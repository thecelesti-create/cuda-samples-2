# Validation report — v17

This report describes checks actually executed on the v17 source. Old v16 logs
were removed and the recorded commands were run again; no old results are relabeled.
The v16 independent host-oracle source is retained and rerun because the core
classes and phase mathematics have not changed.

## Executed here

| Check | Result |
|---|---|
| Metadata-only C++20 Release configure/build with GCC 14.2 | Passed |
| Metadata-only C++20 Release configure/build with Clang 17 | Passed |
| Independent host value/scalar-oracle program, GCC `-O2 -Werror` | 806 checks passed |
| Same independent program, Clang `-O2 -Werror` | 806 checks passed |
| Same program, GCC AddressSanitizer + UndefinedBehaviorSanitizer | 806 checks passed |
| Public class/file/Doxygen text audit | Passed: 7 classes, 52 private fields, 197 function declarations |
| Scope/API source comparison against v16 | Passed; details below |
| Docker shell syntax (`bash -n`) | Four scripts passed |

The independent program compiles the real CPI_Metadata and host Detection
implementations and a separate scalar `std::complex<float>` azimuth oracle.
It is NOT GoogleTest and does NOT call Interferometry1D, ArrayFire gathering,
GPU kernels or device optional-angle operations. Its 806 successful checks do
not validate the modified public signature or the rewritten ArrayFire tests.
It remains an archival validation source (`validation/host-checks-source.txt`),
not a project test framework, dependency or executable target.

Logs are in `validation/{gcc,clang}-{configure,build,host-compile,host-run}.txt`,
`sanitizers-{compile,run}.txt`, `source-audit.txt`, `scope-and-test-audit.txt`,
and `shell-*.txt`. `commands.json` records build/dependency command exit statuses.
Sanitizer runs used leak detection and halt-on-error; no error was reported.

## Scope/API audit (source-level only)

All 14 core radar production files are byte-for-byte unchanged from v16. The root
CMake change is only 0.16.0 -> 0.17.0; all other CMake files and the shared
GoogleTest 1.11-compatible runner are unchanged. The independent GoogleTest phase
reference source is also unchanged.

There is one public `estimate` declaration and one implementation, taking
`const RangeDopplerMap& phaseCenteredRdm` plus `const DetectionList&`. The
collection-of-maps and pre-gathered array overloads and their unused separate-plane
helpers are removed. Source comparisons, ignoring whitespace and the map parameter
rename, show that computeAzimuth, the retained RDM estimate, index generation,
internal gather, phase zero handling and batched output logic are unchanged.

No public scratch type, added data-class fields, runtime validation, CUDA-specific
buffer, host numerical readback or explicit synchronization was introduced.
The audit is static text analysis, not C++ compilation or a Doxygen run.

## Dependency attempts and remaining limits

A full real CMake configuration fails because no ArrayFire 3.10 config package is
installed. A metadata-only tests-enabled configure fails because GoogleTest 1.11
is not installed. Exact diagnostics are in `real-arrayfire-configure.txt` and
`real-gtest-configure.txt`. A curl probe for the official GoogleTest 1.11 header
fails at DNS resolution (`network-probe.txt`). No stand-in SDK, fake backend or
substitute assertion framework was used to claim compilation or test success.

**The modified ArrayFire implementation and the actual GoogleTest suites have NOT
been compiled, linked or executed here against their real dependencies.** This
includes the new compile-time signature/invocability regressions: they are source
supplied for the real SDK build, not checks executed by the metadata-only build.
No CPU/CUDA/OpenCL integration result, Docker build, Windows/MSVC run, GPU timing
or peak-memory measurement is claimed. Source-level equivalence is not runtime
certification. This API cleanup makes no measured speedup claim.

## Supplied GoogleTest coverage (not executed here)

There are 39 source cases: 37 ordinary cases and two disabled timing cases.

| Runner | Cases | Disabled |
|---|---:|---:|
| radar_metadata_tests | 3 | 0 |
| radar_arrayfire_tests | 15 | 1 |
| radar_interferometry_reference_tests | 5 | 0 |
| radar_interferometry_tests | 16 | 1 |

The azimuth tests use one phase-centered RDM and sum-beam detections. A unique
member-function-address type check enforces one estimate API; invocability checks
reject raw ArrayFire IQ and a span of RDMs. Regressions cover inferred phase-center
count, elemental versus coherent subarray centers using the same API, invariance
to representative detector-IQ changes, matching grid/calibration, reordered and
duplicate detected cells, batch sizes including a partial tail, tiny/zero
correlations, CPI wavelength, fixed phase sign, input preservation, empty lists
and stale-elevation clearing. A per-cell scalar baseline remains independent of
the ArrayFire result. The synthetic five-element test expects 20 degrees azimuth
and no elevation; that is an expected fixture value, not captured execution.

The disabled azimuth timing case now measures only the public phase-centered RDM
API, including the internal gather. No pre-gathered benchmark or public adapter
is kept. Core chain tests remain in radar_arrayfire_tests, unchanged.

## Run with installed dependencies

```sh
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release --no-tests=error --output-on-failure
# Only actual ArrayFire azimuth tests:
ctest --test-dir build-tests -C Release -R '^radar_interferometry\.' --no-tests=error --output-on-failure
```

Use your installed dependency prefixes / GTest_DIR as necessary; change cuda to
cpu for CPU execution. Extract and build in a fresh directory. SHA256SUMS covers
all packaged files except itself; run `sha256sum -c SHA256SUMS` from the root.
