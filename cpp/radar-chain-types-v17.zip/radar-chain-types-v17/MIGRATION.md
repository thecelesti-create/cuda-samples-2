# Migration: v16 -> v17

CMake version is 0.17.0. This is a focused public API cleanup, not a change to the
radar types, phase convention, mathematical estimator, or batch-memory policy.

## One phase-centered RDM input

`Interferometry1D` now has exactly one `estimate` function:

```cpp
[[nodiscard]] DetectionList estimate(
    const RangeDopplerMap& phaseCenteredRdm,
    const DetectionList& detections) const;
```

The constructor is unchanged:

```cpp
Interferometry1D estimator(elementSpacingMeters, /* detectionBatchSize */ 4096);
auto result = estimator.estimate(phaseCenteredRdm, detections);
```

The prior single-RDM call remains source-compatible. No wrappers retain the two
removed overloads accepting `std::span<const RangeDopplerMap>` or `const af::array&`.
Their unused separate-plane preparation/gather helpers have also been removed.

## Your processing ownership

The detector uses only a sum-beam RDM. Interferometry receives one separate
phase-centered RDM with the original elemental or coherent subarray IQ in its
third dimension. Detection bin indices select the same cells in that cube:

```text
sumBeamRdm:       [Doppler,range,1] -> detector -> DetectionList
phaseCenteredRdm:[Doppler,range,E] --------------------+   |
                                                    estimate
                                                       |
                                             DetectionList + azimuth
```

Use the actual distance between effective phase centers as constructor spacing.
Elemental versus subarray input is not a different storage API. The inputs must
share CPI, range/Doppler grid/order and active backend/device. The phase-centered
cube has at least two coherent phase centers, uniformly ordered along +y. A single
combined beam is not a substitute. No runtime checks have been added.

All selected `[element,batchDetection]` IQ gathering stays internal. The public
API does not ask the detector or caller to gather, maintain or pass that scratch.
For existing multi-map callers, build the standard phase-centered cube upstream;
this library no longer joins or accepts a collection of separate map objects.

## Output, storage and compatibility retained

The five base detection arrays stay on their selected ArrayFire backend; the
returned wrapper retains their handles and adds a device azimuth column. Input
records are unchanged. Old output elevation is cleared and no elevation is
estimated. `recordsToHost()` remains the explicit final numerical download.
No full RDM is deliberately cloned or retained by the returned list; underlying
ArrayFire handles, queues and allocator lifetimes still determine release timing.

Core radar headers/sources, C++20, ArrayFire 3.10, GoogleTest 1.11 compatibility,
private members, Doxygen comments, tests-off-by-default and library targets are
unchanged. No geometry/axis classes, public scratch type, compatibility shim or
CUDA-specific allocation has been introduced.

## Tests and performance

Existing azimuth tests now call only the phase-centered RDM overload. Sum-beam
fixtures supply detections. Regressions cover both elemental and coherent subarray
planes, correct plane-count inference, duplicate/nonzero cells and preserved
representative sum-beam IQ. The disabled timing case measures the only API,
including internal gathering, and records `phase_centered_rdm_ms`.

```sh
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release -R '^radar_interferometry\.' --no-tests=error --output-on-failure
```

Use a fresh build directory and supply installed dependency paths as needed.
The tests and timings supplied here are not evidence of runtime execution; see
`VALIDATION.md` for the actual results and remaining limits.
