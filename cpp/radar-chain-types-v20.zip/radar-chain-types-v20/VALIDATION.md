# Validation — v20 (0.20.0)

Baseline: `radar-chain-types-v19.zip` (0.19.0). Version 20 is a breaking data-layout
release: `RangeDopplerMap` is physically **[range,Doppler,element]**. Algorithm
implementations, not the data classes, own any temporary axis permutations.

## Checks actually executed here

| Check | Result |
|---|---|
| C++20 metadata-only Release configure/build, GCC 14.2 | Passed |
| Same metadata-only build, Clang 17 | Passed |
| Real `CPI_Metadata` / `Detection` copy-move smoke program, GCC | Passed |
| Same host smoke program, Clang | Passed |
| Same host smoke program, GCC ASan + UBSan | Passed; no sanitizer diagnostics |
| Independent range-first layout/index oracle, GCC | Passed |
| Same layout/index oracle, Clang | Passed |
| Same layout/index oracle, GCC ASan + UBSan | Passed; no sanitizer diagnostics |
| Static public-API / Doxygen / source-contract audit | Passed |
| Docker helper shell syntax | All four scripts passed `bash -n` |
| Declaration-only production syntax aid, GCC / Clang | Passed; **not** a real ArrayFire SDK compile |
| Declaration-only test syntax aid, GCC / Clang | Passed; **not** a real GoogleTest/ArrayFire compile |

The host special-member program compiles the actual ArrayFire-independent
`CPI_Metadata` and `Detection` source. It confirms that the explicit defaults from
v19 still provide working copy/move construction and assignment. The source is
`validation/host-special-members.cpp.txt` and is not a project test target.

The independent range-first oracle is `validation/range-first-layout-oracle.cpp.txt`.
It does **not** use ArrayFire. It checks the mathematical/indexing contracts that
changed in v20:

- column-major `[R,D,E]` index `r + R*(d + D*e)`;
- flattened cell ID `r + R*d` and its inverse;
- `[R,P,E] -> [P,R,E] -> [R,D,E]` axis round trip for a transform-preserving model;
- odd and even Doppler-order remapping without changing range/element identity;
- the updated phase-center gather convention with a synthetic five-center 20-degree target.

All of those checks passed with GCC, Clang, and the GCC address/undefined-behavior
sanitizers. They validate the layout arithmetic independently; they are not a
substitute for running ArrayFire kernels.

## v19 -> v20 production scope

There are 17 production HPP/CPP/helper files. **Nine changed**:

```text
include/radar/DetectionList.hpp
include/radar/RangePulseBuffer.hpp
include/radar/RangeDopplerMap.hpp
src/DetectionList.cpp
src/RangePulseBuffer.cpp
src/RangeDopplerMap.cpp
interferometry/include/radar/interferometry/Interferometry1D.hpp
interferometry/src/Interferometry1D.cpp
interferometry/src/device_helpers.hpp
```

The other eight production files are byte-for-byte identical to v19, including
`CPI_Metadata`, `Detection`, `SamplePulseBuffer`, `types.hpp`, and the common array
helpers. `validation/scope-audit.txt` records the comparison.

The static audit found seven library classes, 52 private fields, and 230 public
function declarations with adjacent Doxygen documentation. All seven classes still
explicitly default their five special members. No removed axis/geometry types,
numbered dimension members, production `throw`/`assert` validators, CUDA-specific
allocations, or explicit interferometry host/scalar readbacks were found.

### Canonical layout changes verified in source

- `RangeDopplerMap` documents `[range,Doppler,element,1]`.
- Its constructor caches range from dim0 and Doppler from dim1.
- Range slicing operates on dim0.
- Doppler-order shifting operates on dim1.
- `getDopplerSpectrum(range,element)` selects dim1; `getRangeProfile(doppler,element)` selects dim0.
- `DetectionList::fromCells()` decodes `cell = range + rangeCount*doppler`.
- `DetectionList::fromMap()` gathers from a flattened range-first element plane.
- `Interferometry1D` reshapes the phase-centered `[R,D,E]` cube to `[R*D,E]` and rebuilds cell IDs with the same range-first formula.
- `RangePulseBuffer::reorderForDoppler()` and `RangeDopplerMap::reorderToRangeFirst()` are absent from production; algorithms own those axis permutations.

The reference Doppler test algorithm now explicitly performs both reorders:
`[R,P,E] -> [P,R,E] -> FFT -> [R,D,E]`. This is deliberate full-cube data
movement and v20 does not claim it is free or faster than the previous public
Doppler-first storage.

## Supplied GoogleTest coverage (not executed here)

Source inventory:

| Runner | Cases | Disabled timing cases |
|---|---:|---:|
| `radar_metadata_tests` | 7 | 0 |
| `radar_arrayfire_tests` | 22 | 1 |
| `radar_interferometry_tests` | 22 | 1 |
| **Total** | **51** | **2** |

The v20-specific cases cover the range-first RDM dimensions and linear index,
range/Doppler slices, even/odd Doppler ordering on dim1, the new detection-cell
encoding, the reference Doppler algorithm's algorithm-owned reorders, and
phase-centered interferometry with the updated `[R,D,E]` gather convention.
Existing copy/move, metadata, sparse-selection, pipeline, and azimuth tests remain.

## Real dependency attempts and limitations

A full CMake configure was attempted and failed because no ArrayFire 3.10 config
package is installed in this environment. A metadata-only tests-enabled configure
was also attempted and failed because no GoogleTest 1.11 config package is
installed. Exact diagnostics and exit statuses are in:

```text
validation/real-arrayfire-configure.txt
validation/real-gtest-configure.txt
validation/dependency-status.txt
validation/commands.json
```

To catch ordinary C++ declaration/call inconsistencies despite those missing
packages, the ArrayFire-facing production files and all eight test translation
units were parsed with GCC and Clang against small **declaration-only aids kept
outside the repository**. Those checks use `-std=c++20 -Wall -Wextra -Wpedantic
-Werror -fsyntax-only`; they do not link or execute anything and cannot verify
real ArrayFire/GTest overloads, proxy behavior, ABI, backend behavior, memory use,
or numerical results.

**The ArrayFire-backed classes, Interferometry1D, and actual GoogleTest suites have
NOT been compiled, linked, or executed against their real dependencies here.** No
CPU/CUDA/OpenCL integration result, Windows/MSVC result, Docker image execution,
GPU timing, or peak-device-memory result is claimed.

## Run with the installed SDKs

From a fresh extraction:

```sh
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release \
  -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release --no-tests=error --output-on-failure
```

On Windows/Visual Studio add `-A x64` during configure and supply the actual
ArrayFire / GoogleTest package paths when they are not already discoverable.
Run `radar_arrayfire_tests` and `radar_interferometry_tests` directly when you want
all selected cases to share one warmed process.

## Archive

`SHA256SUMS` lists every packaged file except itself. Build directories and all
temporary declaration-only SDK aids are excluded from the release archive.
