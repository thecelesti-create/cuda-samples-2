/**
 * @file test_arrayfire.cpp
 * @brief Radar-only pipeline tests, optional timing, and test-program device setup.
 * @details GoogleTest supplies main(). No interferometry headers or linkage.
 */
#include <gtest/gtest.h>
#include <arrayfire.h>
#include <radar/CPI_Metadata.hpp>
#include <radar/Detection.hpp>
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/RangePulseBuffer.hpp>
#include <radar/SamplePulseBuffer.hpp>
#include <radar/types.hpp>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <complex>
#include <cstddef>
#include <cstdlib>
#include <exception>
#include <initializer_list>
#include <iostream>
#include <limits>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

namespace {
/**
 * @brief Test-program setup used by GoogleTest's supplied main.
 * @details No ArrayFire call runs during global registration. The single local
 * environment has no ordering dependencies on other translation units.
 */
class ArrayFireTestEnvironment final : public ::testing::Environment {
public:
    /** @brief Select the requested backend/device before executing any tests. */
    void SetUp() override {
        initialized_ = false;
        try {
            const char* requestedBackend = std::getenv("RADAR_TEST_BACKEND");
#if RADAR_ARRAYFIRE_UNIFIED
            const std::string_view backend = requestedBackend && *requestedBackend
                ? requestedBackend : RADAR_TEST_DEFAULT_BACKEND;
            if (backend == "cpu") {
                af::setBackend(AF_BACKEND_CPU);
            } else if (backend == "cuda") {
                af::setBackend(AF_BACKEND_CUDA);
            } else if (backend == "opencl") {
                af::setBackend(AF_BACKEND_OPENCL);
            } else {
                FAIL() << "RADAR_TEST_BACKEND must be cpu, cuda or opencl; got: " << backend;
            }
            std::cout << "ArrayFire test backend: " << backend << '\n';
#else
            if (requestedBackend && *requestedBackend) {
                FAIL() << "A directly linked backend cannot be overridden; unset RADAR_TEST_BACKEND";
            }
#endif
            af::setDevice(0);
            initialized_ = true;
        } catch (const std::exception& error) {
            FAIL() << "ArrayFire test setup failed: " << error.what();
        }
    }

    /** @brief Report pending device errors at the final test-program boundary. */
    void TearDown() override {
        if (initialized_) {
            EXPECT_NO_THROW(af::sync());
        }
    }

private:
    bool initialized_ = false;
};

// GoogleTest owns the environment. Its constructor performs no device work.
[[maybe_unused]] ::testing::Environment* const arrayFireEnvironment =
    ::testing::AddGlobalTestEnvironment(new ArrayFireTestEnvironment);
} // namespace


// ============================================================================
// Three fake algorithms
// ============================================================================

// Test-only placeholders, not implementations exported by either library.
namespace {
/** @brief FAKE matched filter: multiply c32 IQ by two; no pulse compression. */
radar::RangePulseBuffer fakeMatchedFilter(const radar::SamplePulseBuffer& input) {
    af::array iq = input.getData() * 2.0f;
    return {input, std::move(iq)};
}
/** @brief FAKE Doppler: treat the pulse axis as fake Doppler bins; deliberately no FFT. */
radar::RangeDopplerMap fakeDoppler(const radar::RangePulseBuffer& input) {
    // Both types are canonically [range, second-axis, element], so this fake stage
    // needs no layout change. A real Doppler algorithm owns its FFT reorders.
    return {input, input.getData(), radar::DopplerOrder::Unshifted};
}
/** @brief FAKE detector: select cell zero in element zero and assume unit noise power. */
radar::DetectionList fakeDetector(const radar::RangeDopplerMap& input) {
    af::array cells = af::constant(0u, af::dim4(1), u32);
    af::array iq = af::lookup(af::flat(input.getElement(0)), cells, 0);
    af::array amplitudes = af::abs(iq);
    af::array snrDb = 20.0f * af::log10(amplitudes); // 10*log10(amplitude^2 / 1).
    return radar::DetectionList::fromCells(input, std::move(cells),
        std::move(amplitudes), std::move(snrDb), std::move(iq));
}
} // namespace


/** @brief Three fake algorithms preserve types and detection values. */
TEST(PipelineTests, ThreeFakeAlgorithms) {
    constexpr dim_t sampleCount = 8, pulseCount = 4, elementCount = 3;
    const radar::CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6, 1);
    const std::vector<af::cfloat> hostIq(
        sampleCount * pulseCount * elementCount, {1.0f, 0.0f});
    const auto samples = radar::SamplePulseBuffer::fromHost(
        hostIq, sampleCount, pulseCount, elementCount, metadata);

    // One input upload, no numerical host readback between algorithms.
    const auto ranges = fakeMatchedFilter(samples);
    const auto map = fakeDoppler(ranges);
    const auto detections = fakeDetector(map);
    ASSERT_EQ(samples.getData().type(), c32) << "sample IQ is c32";
    ASSERT_EQ(ranges.getData().type(), c32) << "range IQ is c32";
    ASSERT_EQ(map.getData().type(), c32) << "RDM IQ is c32";
    ASSERT_TRUE(ranges.getRangeBinCount() == sampleCount &&
          ranges.getPulseCount() == pulseCount &&
          ranges.getElementCount() == elementCount) << "range-stage dimensions";
    ASSERT_TRUE(map.getDopplerBinCount() == pulseCount &&
          map.getRangeBinCount() == sampleCount &&
          map.getElementCount() == elementCount) << "range-first RDM dimensions";
    EXPECT_NEAR(detections.getMetadata().getBandwidthHz(), metadata.getBandwidthHz(), 1e-10 * std::max(1.0, std::abs(static_cast<double>(metadata.getBandwidthHz()))));
    ASSERT_TRUE(!detections.getHasAzimuth() && !detections.getHasElevation()) << "no fabricated angles";
    ASSERT_EQ(detections.getComplexPairs().type(), c32) << "detection IQ is c32";

    // Assertions read the small final result, not intermediate cubes.
    const auto records = detections.recordsToHost();
    ASSERT_EQ(records.size(), 1) << "fake detector returns one record";
    const auto& record = records.front();
    ASSERT_TRUE(record.getRangeIndex() == 0 && record.getDopplerIndex() == 0) << "selected cell zero";
    EXPECT_NEAR(record.getAmplitude(), 2.0, 2e-05);
    EXPECT_NEAR(record.getSnrDb(), 20.0 * std::log10(2.0), 1e-5 * std::max(1.0, std::abs(static_cast<double>(20.0 * std::log10(2.0)))));
    EXPECT_NEAR(record.getComplexPair().real(), 2.0, 2e-05);
    EXPECT_NEAR(record.getComplexPair().imag(), 0.0, 1e-05);
    ASSERT_TRUE(!record.getAzimuthRadians() && !record.getElevationRadians()) << "host optional fields absent";
}

// ============================================================================
// Reference matched-filter / Doppler / detection chain
// ============================================================================

namespace {
using namespace radar;
/** @brief Reference linear matched filtering with delay-corrected range axis.
 * @pre waveform is a nonempty c32 column; sizes fit dim_t; configuration is valid. */
RangePulseBuffer matchedFilter(const SamplePulseBuffer& source, const af::array& waveform) {
    const dim_t taps = waveform.dims(0);
    const dim_t linearLength = source.getSampleCount() + taps - 1;
    dim_t fftLength = 1;
    while (fftLength < linearLength) {
        fftLength *= 2;
    }

    // Linear convolution with h[n] = conj(waveform[taps-1-n]).
    // af::fft is unnormalized forward; af::ifft includes inverse normalization.
    const af::array h = af::conjg(af::flip(waveform, 0));
    // Explicit tile is intentionally simple for this tiny test fixture. A production
    // implementation should broadcast/cache the filter spectrum instead of
    // retaining a full-sized repeated spectrum. Benchmark those costs separately.
    const af::array filterSpectrum = af::tile(af::fft(h, fftLength),
                                              1, source.getPulseCount(), source.getElementCount());
    const af::array full = af::ifft(af::fft(source.getData(), fftLength) * filterSpectrum);
    // Full convolution peak has a taps-1 delay. Retain lags [0, samples-1].
    // Cropping is an actual data selection, not merely a metadata correction.
    const af::array cropped = full(af::seq(static_cast<double>(taps - 1),
                                         static_cast<double>(taps + source.getSampleCount() - 2)),
                                   af::span, af::span);
    // Cropped output has original raw timing and sample rate, with filter lag removed.
    return {source, cropped};
}

/** @brief Reference c32 Doppler FFT; the algorithm owns both layout changes. */
RangeDopplerMap dopplerProcess(const RangePulseBuffer& source) {
    // ArrayFire's 1D FFT operates on dim0. Move pulse to dim0 for the transform,
    // then restore the public RangeDopplerMap contract: [range,Doppler,element].
    af::array pulseFirst = af::reorder(source.getData(), 1, 0, 2, 3);
    af::array dopplerFirst = af::fft(pulseFirst);
    af::array rangeFirst = af::reorder(dopplerFirst, 1, 0, 2, 3);
    return {source, std::move(rangeFirst), DopplerOrder::Unshifted};
}


/** @brief Fixed-threshold element-zero detector; not CFAR. Numerical results stay on device. */
DetectionList thresholdDetector(const RangeDopplerMap& map, double threshold,
                            double assumedNoisePower) {
    const af::array elementIq = map.getElement(0);
    const af::array power = af::real(elementIq * af::conjg(elementIq));
    af::array selected = af::where(power > static_cast<float>(threshold));
    if (selected.isempty()) return DetectionList(map);
    af::array iq = af::lookup(af::flat(elementIq), selected, 0);
    af::array amplitudes = af::abs(iq);
    af::array snrDb = 20.0f * af::log10(amplitudes) -
                     10.0f * static_cast<float>(std::log10(assumedNoisePower));
    return DetectionList::fromCells(map, std::move(selected), std::move(amplitudes),
                                     std::move(snrDb), std::move(iq));
}

} // namespace


/** @brief Reference matched filter and FFT recover a known echo. */
TEST(PipelineTests, MatchedFilterDopplerDetection) {
    using namespace radar;
    constexpr dim_t sampleCount = 64, pulseCount = 16, elementCount = 5;
    constexpr dim_t echoStart = 18, toneBin = 3;
    const std::vector<af::cfloat> chips{
        {1, 0}, {1, 0}, {1, 0}, {-1, 0}, {-1, 0}, {1, 0}, {-1, 0}};
    const af::array waveform(static_cast<dim_t>(chips.size()), chips.data(), afHost);
    const CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6, 11);

    // No random noise: exact expected peak/SNR and deterministic thresholding.
    std::vector<af::cfloat> hostIq(
        static_cast<std::size_t>(sampleCount * pulseCount * elementCount), {0.0f, 0.0f});
    for (dim_t elementIndex = 0; elementIndex < elementCount; ++elementIndex) {
        for (dim_t pulseIndex = 0; pulseIndex < pulseCount; ++pulseIndex) {
            const double phase = 2.0 * pi * static_cast<double>(toneBin * pulseIndex) /
                                 static_cast<double>(pulseCount) +
                                 0.2 * static_cast<double>(elementIndex);
            for (std::size_t chip = 0; chip < chips.size(); ++chip) {
                const dim_t sampleIndex = echoStart + static_cast<dim_t>(chip);
                const auto offset = static_cast<std::size_t>(sampleIndex +
                    sampleCount * (pulseIndex + pulseCount * elementIndex));
                hostIq[offset] = {
                    chips[chip].real * static_cast<float>(std::cos(phase)),
                    chips[chip].real * static_cast<float>(std::sin(phase))};
            }
        }
    }
    const auto samples = SamplePulseBuffer::fromHost(
        hostIq, sampleCount, pulseCount, elementCount, metadata);
    const auto ranges = matchedFilter(samples, waveform);
    const auto map = dopplerProcess(ranges);
    const double expectedAmplitude = static_cast<double>(chips.size()) * pulseCount;
    // This is an assumed noise model, not noise estimated from the noiseless data.
    const double assumedNoisePower = expectedAmplitude;
    const auto detections = thresholdDetector(map, 3000.0, assumedNoisePower);
    const auto records = detections.recordsToHost();
    ASSERT_EQ(records.size(), 1) << "one peak exceeds the fixed threshold";
    const auto& record = records.front();
    ASSERT_EQ(record.getRangeIndex(), static_cast<unsigned>(echoStart)) << "matched-filter delay removed";
    ASSERT_EQ(record.getDopplerIndex(), static_cast<unsigned>(toneBin)) << "expected positive Doppler bin";
    EXPECT_NEAR(record.getAmplitude(), expectedAmplitude, 3e-4 * std::max(1.0, std::abs(static_cast<double>(expectedAmplitude))));
    EXPECT_NEAR(record.getComplexPair().real(), expectedAmplitude, 3e-4 * std::max(1.0, std::abs(static_cast<double>(expectedAmplitude))));
    EXPECT_NEAR(record.getComplexPair().imag(), 0.0, 0.0003);
    EXPECT_NEAR(record.getSnrDb(), 10.0 * std::log10(expectedAmplitude), 3e-4 * std::max(1.0, std::abs(static_cast<double>(10.0 * std::log10(expectedAmplitude)))));
    ASSERT_TRUE(!detections.getHasAngles()) << "reference detector does not invent angles";
    EXPECT_NEAR(detections.getMetadata().getBandwidthHz(), metadata.getBandwidthHz(), 1e-10 * std::max(1.0, std::abs(static_cast<double>(metadata.getBandwidthHz()))));
    EXPECT_NEAR(ranges.getRangeMeters(echoStart), static_cast<double>(echoStart) * speedOfLightMps / (2.0 * metadata.getSampleRateHz()), 1e-10 * std::max(1.0, std::abs(static_cast<double>(static_cast<double>(echoStart) * speedOfLightMps / (2.0 * metadata.getSampleRateHz())))));
    EXPECT_NEAR(map.getDopplerHz(toneBin), metadata.getPrfHz() * toneBin / pulseCount, 1e-10 * std::max(1.0, std::abs(static_cast<double>(metadata.getPrfHz() * toneBin / pulseCount))));
    ASSERT_TRUE(ranges.getData().type() == c32 && map.getData().type() == c32) << "complex stages retain c32";

    const auto empty = thresholdDetector(map, 1e6, assumedNoisePower);
    ASSERT_TRUE(empty.getIsEmpty()) << "higher threshold produces an empty list";
    ASSERT_TRUE(empty.recordsToHost().empty()) << "empty list can be exported";
    ASSERT_TRUE(!empty.getHasAngles()) << "empty detector result has absent angles";
}

// ============================================================================
// Opt-in core performance test
// ============================================================================

namespace {
/** @brief Test-only mean call time after warmup; includes a device fence per call. */
template<class Operation>
double meanMilliseconds(Operation&& operation) {
    constexpr int warmups=3, repetitions=20;
    for (int i=0;i<warmups;++i) { operation(); af::sync(); }
    const auto start=std::chrono::steady_clock::now();
    for (int i=0;i<repetitions;++i) { operation(); af::sync(); }
    const auto stop=std::chrono::steady_clock::now();
    return std::chrono::duration<double,std::milli>(stop-start).count()/repetitions;
}
}

/** @brief Opt-in device-resident timings; no speed assertion or production benchmark dependency. */
TEST(ArrayFirePerformance, DISABLED_PowerAndDopplerReorder) {
    const radar::CPI_Metadata metadata(10e6,2000.0,10e9,5e6);
    const radar::RangePulseBuffer ranges(
        af::constant(1.0f,af::dim4(10000,800,5),c32),metadata,0.0,15.0);
    ranges.synchronize(); // Allocation/materialization is outside the timed region.
    af::array output;
    const double reference=meanMilliseconds([&] {
        output=af::real(ranges.getData()*af::conjg(ranges.getData()));
        output.eval();
    });
    output=af::array{};
    const double power=meanMilliseconds([&] { output=ranges.computePower(); output.eval(); });
    EXPECT_EQ(output.type(),f32);
    EXPECT_FLOAT_EQ(output.scalar<float>(),1.0f); // Test-only readback, AFTER timing.
    output=af::array{};
    const double reorder=meanMilliseconds([&] { output=af::reorder(ranges.getData(),1,0,2,3); output.eval(); });
    EXPECT_EQ(output.type(),c32);
    EXPECT_EQ(output.dims(0),800);
    EXPECT_EQ(output.dims(1),10000);
    RecordProperty("reference_power_ms",std::to_string(reference));
    RecordProperty("power_ms",std::to_string(power));
    RecordProperty("reorder_ms",std::to_string(reorder));
    std::cout << "Device-resident [10000,800,5], mean ms/call including fence: "
              << "reference power=" << reference << ", power=" << power
              << ", reorder=" << reorder << '\n';
}
