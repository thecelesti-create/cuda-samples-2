# Migration: v19 -> v20

Version 20 changes the canonical `RangeDopplerMap` storage contract so that the
class name matches the physical ArrayFire dimension order.

```text
SamplePulseBuffer : [sample, pulse, element]
RangePulseBuffer  : [range,  pulse, element]
RangeDopplerMap   : [range,  Doppler, element]
```

This is a breaking layout/indexing release. CMake version is `0.20.0`.

## RangeDopplerMap is range-first

In v19 the RDM was `[Doppler,range,element]`. In v20 it is
`[range,Doppler,element]`:

```cpp
// v20 standalone construction
radar::RangeDopplerMap map(
    iq, metadata, firstRangeMeters, rangeBinSpacingMeters,
    integratedPulseCount, radar::DopplerOrder::Unshifted);

// Required iq layout: [range,Doppler,element,1]
```

`getRangeBinCount()` now comes from dim0 and `getDopplerBinCount()` from dim1.
`getDimensions()` therefore returns `[R,D,E,1]`.

Raw ArrayFire access changes accordingly:

```cpp
// v20
map.getData()(rangeIndex, dopplerIndex, elementIndex);
```

The semantic helper argument order was already `(range,doppler,element)`, so
`getElementVector(range,doppler)` keeps its public argument order.

## Algorithms own axis reordering

The data types no longer expose axis-permutation helpers:

```text
removed: RangePulseBuffer::reorderForDoppler()
removed: RangeDopplerMap::reorderToRangeFirst()
```

An ArrayFire 1D Doppler FFT can explicitly manage its implementation layout:

```cpp
af::array pulseFirst = af::reorder(rangePulse.getData(), 1, 0, 2, 3);
af::array dopplerFirst = af::fft(pulseFirst);
af::array rangeFirst = af::reorder(dopplerFirst, 1, 0, 2, 3);
return radar::RangeDopplerMap(rangePulse, std::move(rangeFirst));
```

Constructors do not silently reorder. The array supplied to `RangeDopplerMap`
must already satisfy `[range,Doppler,element]`.

`setDopplerOrder()` / `withDopplerOrder()` remain because they change frequency-bin
ordering inside the Doppler axis rather than permuting semantic axes. Their shift
now operates on dim1.

## Flattened cell encoding changes

Because ArrayFire is column-major and range is now dim0, a flattened cell inside
one element plane is:

```text
cell = rangeIndex + rangeBinCount * dopplerIndex
```

v19 used:

```text
cell = dopplerIndex + dopplerBinCount * rangeIndex
```

`DetectionList::fromCells()` and `fromMap()` now decode/consume the v20 range-first
encoding. Detection records still store separate range and Doppler indices; only
linear cell IDs change.

## Slices and ordering

`RangeDopplerMap::sliceRanges()` now slices dim0. Doppler centering/uncentering
shifts dim1. `getDopplerSpectrum()` returns the raw `[1,D,1,1]` view for a selected
range/element; `getRangeProfile()` returns `[R,1,1,1]`.

## Interferometry

The public interferometry API is unchanged:

```cpp
DetectionList estimate(const RangeDopplerMap& phaseCenteredRdm,
                       const DetectionList& detections) const;
```

The required phase-centered cube is now `[range,Doppler,element]`. Internally it
reshapes the contiguous cube to `[range*Doppler,element]` and rebuilds selected
cell IDs using the v20 formula above before gathering IQ. The detector can continue
to use a one-plane sum-beam RDM with the same `[range,Doppler,1]` layout.

## Unchanged contracts

C++20, ArrayFire 3.10+, GoogleTest 1.11+, explicit defaulted special members,
private fields, unchecked hot-path contracts, c32 cube data, ArrayFire-backed
`DetectionList`, and azimuth-only `Interferometry1D` are retained.

Use a fresh build directory when moving from v19. Any producer, detector, file
format, or external algorithm that constructs or flattens an RDM must be updated
to the new range-first layout and cell encoding.
