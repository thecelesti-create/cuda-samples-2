#include <utility>
#include <vector>
#include <radar/CPI_Metadata.hpp>
#include <radar/RangePulseBuffer.hpp>
#include <radar/types.hpp>
#include <radar/RangeDopplerMap.hpp>
#include "array_helpers.hpp"

namespace radar {
RangeDopplerMap::RangeDopplerMap(af::array iq, CPI_Metadata metadata,
                                 double firstRangeMeters, double rangeBinSpacingMeters,
                                 dim_t integratedPulseCount, DopplerOrder order)
    : iq_(std::move(iq)), metadata_(metadata), firstRangeMeters_(firstRangeMeters),
      rangeBinSpacingMeters_(rangeBinSpacingMeters), integratedPulseCount_(integratedPulseCount),
      dopplerOrder_(order) {
    const auto shape = iq_.dims();
    rangeBinCount_ = shape[0]; dopplerBinCount_ = shape[1]; elementCount_ = shape[2];
}
RangeDopplerMap::RangeDopplerMap(const RangePulseBuffer& source, af::array iq, DopplerOrder order)
    : RangeDopplerMap(std::move(iq), source.getMetadata(), source.getFirstRangeMeters(),
                      source.getRangeBinSpacingMeters(), source.getPulseCount(), order) {}
af::array RangeDopplerMap::getElement(dim_t elementIndex) const {
    return iq_(af::span, af::span, detail::sequence(elementIndex, 1));
}
af::array RangeDopplerMap::getDopplerSpectrum(dim_t rangeBin, dim_t elementIndex) const {
    return iq_(detail::sequence(rangeBin, 1), af::span, detail::sequence(elementIndex, 1));
}
af::array RangeDopplerMap::getRangeProfile(dim_t dopplerBin, dim_t elementIndex) const {
    return iq_(af::span, detail::sequence(dopplerBin, 1), detail::sequence(elementIndex, 1));
}
af::array RangeDopplerMap::getElementVector(dim_t rangeBin, dim_t dopplerBin) const {
    return af::flat(iq_(detail::sequence(rangeBin, 1), detail::sequence(dopplerBin, 1), af::span));
}
af::array RangeDopplerMap::computePower() const { return detail::computePower(iq_); }
af::array RangeDopplerMap::computePowerSumElements() const { return af::sum(computePower(), 2); }
RangeDopplerMap RangeDopplerMap::sliceRanges(dim_t firstRangeBin, dim_t rangeBinCount) const {
    auto result = *this;
    result.iq_ = iq_(detail::sequence(firstRangeBin, rangeBinCount), af::span, af::span);
    result.firstRangeMeters_ = getRangeMeters(firstRangeBin);
    result.rangeBinCount_ = rangeBinCount;
    return result;
}
void RangeDopplerMap::setDopplerOrder(DopplerOrder order) {
    if (order == dopplerOrder_) return;
    const int half = static_cast<int>(getDopplerBinCount() / 2); // Must fit int.
    af::array shifted = af::shift(iq_, 0, order == DopplerOrder::Centered ? half : -half, 0, 0);
    iq_ = std::move(shifted);
    dopplerOrder_ = order;
}
RangeDopplerMap RangeDopplerMap::withDopplerOrder(DopplerOrder order) const {
    auto result = *this;
    result.setDopplerOrder(order);
    return result;
}
void RangeDopplerMap::setData(af::array iq) {
    iq_ = std::move(iq);
}
void RangeDopplerMap::setMetadata(CPI_Metadata metadata) {
    metadata_ = std::move(metadata);
}
RangeDopplerMap RangeDopplerMap::clone() const {
    auto result = *this;
    result.iq_ = iq_.copy();
    return result;
}
std::vector<af::cfloat> RangeDopplerMap::toHost() const { return detail::toHost(iq_); }
void RangeDopplerMap::evaluate() const { iq_.eval(); }
void RangeDopplerMap::synchronize() const { detail::synchronize(iq_); }
} // namespace radar
