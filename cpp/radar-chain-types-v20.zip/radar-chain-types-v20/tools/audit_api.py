#!/usr/bin/env python3
"""Static source-organization/Doxygen audit; not a C++ or ArrayFire compiler."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
headers=sorted((root/'include').rglob('*.hpp'))+sorted((root/'interferometry/include').rglob('*.hpp'))
classes=[]; fields=[]; methods=0; errors=[]
for p in headers:
    text=p.read_text()
    code=re.sub(r'/\*.*?\*/|//[^\n]*','',text,flags=re.S)
    if re.search(r'\bstruct\s+\w+\s*\{',code): errors.append(f'struct in {p}')
    found=re.findall(r'^class (\w+) final\s*\{',code,re.M)
    if len(found)>1: errors.append(f'multiple classes in {p}')
    for name in found:
        classes.append(name)
        if p.stem!=name: errors.append(f'wrong header filename for {name}')
        source=root/('interferometry/src' if 'interferometry/include' in p.as_posix() else 'src')/(name+'.cpp')
        if not source.exists() or f'{name}::{name}(' not in source.read_text(): errors.append(f'missing real CPP constructor for {name}')
    access='private'
    for line in code.splitlines():
        if line.strip() in ('public:','private:','protected:'): access=line.strip()[:-1]
        if re.match(r'\s*[\w:<>, ]+\s+\w+_\s*(?:=[^;]+)?;\s*$',line):
            field=line.strip();fields.append(field)
            if access!='private': errors.append(f'nonprivate field: {p}: {field}')
    # Include explicitly defaulted special members in the Doxygen audit.
    # Trivial getters and special members stay inline in their class headers.
    lines=text.splitlines()
    if found:
        for i,line in enumerate(lines):
            if re.match(r'^    (?:\[\[nodiscard\]\]|void |explicit |~?'+found[0]+r'\(|'+found[0]+r'& operator=)',line) and '(' in line:
                methods+=1
                j=i-1
                while j>=0 and not lines[j].strip(): j-=1
                if j<0 or not lines[j].strip().endswith('*/'): errors.append(f'no adjacent Doxygen doc: {p.name}:{i+1}')
        name = found[0]
        expected = [f'~{name}() = default;', f'{name}(const {name}&) = default;',
                    f'{name}& operator=(const {name}&) = default;',
                    f'{name}({name}&&) = default;', f'{name}& operator=({name}&&) = default;']
        for declaration in expected:
            if text.count(declaration) != 1:
                errors.append(f'missing/duplicated in-class default: {p}: {declaration}')
        if code.count('= default;') != 5:
            errors.append(f'expected exactly five defaulted special members: {p}')
        classline=next(i for i,l in enumerate(lines) if l.startswith('class '+found[0]))
        if not lines[classline-1].strip().endswith('*/'):errors.append(f'class lacks Doxygen: {p}')
for p in [*headers,*sorted((root/'src').rglob('*.cpp')),*sorted((root/'interferometry/src').rglob('*.cpp'))]:
    code=re.sub(r'/\*.*?\*/|//[^\n]*','',p.read_text(),flags=re.S)
    for name in ['Interferometry2D','UniformLinearArray','UniformRectangularArray','PhaseSign','RangeAxis','DopplerAxis','BinIndex','DetectionCell','DetectionContext','AngleEstimate','AzElDetection','AzElDetectionList']:
        if re.search(r'\b'+name+r'\b',code):errors.append(f'removed type {name} in {p}')
    if re.search(r'\bdim\d+_',code):errors.append(f'numbered dimension in {p}')
    if re.search(r'\bthrow\b|\bassert\s*\(',code):errors.append(f'production runtime validator in {p}')
for p in (root/'interferometry/src').glob('*'):
    code=re.sub(r'/\*.*?\*/|//[^\n]*','',p.read_text(),flags=re.S)
    if re.search(r'\b(?:host|scalar|sync|where)\s*[(<]',code):errors.append(f'host readback/fence in {p}')
for name in ('radar.hpp','metadata.hpp','config.hpp','RangeAxis.hpp','DopplerAxis.hpp','DetectionTransfer.hpp','arrayfire.hpp','ArrayFire.hpp'):
    if (root/'include/radar'/name).exists(): errors.append(f'removed header still exists: {name}')
for p in [*headers,*sorted((root/'src').rglob('*.cpp')),*sorted((root/'interferometry/src').rglob('*'))]:
    if re.search(r'cudaMalloc|cudaMemcpy|cudaStream|cuda_runtime',p.read_text()):
        errors.append(f'CUDA-specific storage/interop: {p}')

# v20 canonical RDM layout and data/algorithm boundary.
rdm_header=(root/'include/radar/RangeDopplerMap.hpp').read_text()
rdm_source=(root/'src/RangeDopplerMap.cpp').read_text()
detection_source=(root/'src/DetectionList.cpp').read_text()
interferometry_helper=(root/'interferometry/src/device_helpers.hpp').read_text()
if '[range,Doppler,element,1]' not in rdm_header:
    errors.append('RangeDopplerMap public contract is not range-first')
if 'rangeBinCount_ = shape[0]; dopplerBinCount_ = shape[1];' not in rdm_source:
    errors.append('RangeDopplerMap constructor does not cache range/doppler from dim0/dim1')
for removed in ('reorderForDoppler', 'reorderToRangeFirst'):
    for candidate in [*headers,*sorted((root/'src').rglob('*.cpp')),*sorted((root/'interferometry/src').rglob('*'))]:
        if candidate.is_file() and removed in candidate.read_text():
            errors.append(f'algorithm-specific axis helper still in production: {candidate}: {removed}')
if 'source.getRangeBinCount()' not in detection_source:
    errors.append('DetectionList linear-cell decode does not use range stride')
if 'getRangeIndices()(bins) + detections.getDopplerIndices()(bins) * stride' not in interferometry_helper:
    errors.append('interferometry gather does not use range-first cell encoding')

for p in root.rglob('*'):
    if p.is_file() and p.suffix in ('.hpp', '.cpp', '.h'):
        code=re.sub(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"', '', p.read_text(), flags=re.S)
        for token in re.findall(r'\b[A-Za-z_]\w*\b', code):
            if 'c32' in token.lower() and token != 'c32':
                errors.append(f'complex dtype in identifier: {p}: {token}')
    if p.is_file() and p.name.lower()=='arrayfire.hpp':
        errors.append(f'removed ArrayFire wrapper still present: {p}')
print(f'{len(classes)} classes with matching individual HPP/CPP constructor definitions')
print('\n'.join('  '+c for c in classes))
print(f'{len(fields)} fields, all private' if not errors else f'{len(fields)} field declarations examined')
print(f'{methods} function declarations checked for adjacent Doxygen documentation')
print('No removed types, numbered dimension members or production throw/assert validators')
print('No explicit host/scalar/sync/where calls in interferometry sources')
if errors:
    print('\n'.join(errors));raise SystemExit(1)
print('All seven library classes explicitly default all five special members in class')
print('v20 range-first RDM layout and cell-index contracts found')
print('PASS (static text audit only, not an SDK compile or Doxygen execution)')
