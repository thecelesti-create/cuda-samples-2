#include <radar/interferometry/Interferometry.hpp>
#include "test_support.hpp"
#include <array>
#include <vector>
#include <string>
#include <complex>
using namespace radar;
using namespace radar::interferometry;
constexpr dim_t dopplerBinCount=7, rangeBinCount=5;
constexpr double frequency=10e9;
constexpr double wavelength=speedOfLightMps/frequency;
const std::array<unsigned,3> cells{2u+7u*1u,5u+7u*3u,1u+7u*4u};
const std::array<double,3> azimuths{-0.4,0.0,0.5};
const std::array<double,3> elevations{0.1,0.0,-0.2};

template<class T> af::array upload(const std::vector<T>& values) {
    return values.empty()?af::array{}:af::array(static_cast<dim_t>(values.size()),values.data(),afHost);
}
RangeDopplerMap makeScene(std::size_t ny,std::size_t nz,double dy,double dz,PhaseSign sign,
                          double u0=0,double v0=0,double knownElevation=0) {
    std::vector<af::cfloat> data(static_cast<std::size_t>(dopplerBinCount*rangeBinCount)*ny*nz,af::cfloat(0,0));
    for(std::size_t k=0;k<cells.size();++k) {
        const double el=nz==1?knownElevation:elevations[k];
        const double u=std::cos(el)*std::sin(azimuths[k]),v=std::sin(el);
        for(std::size_t z=0;z<nz;++z) for(std::size_t y=0;y<ny;++y) {
            const double phase=static_cast<int>(sign)*2*pi/wavelength*
                (static_cast<double>(y)*dy*(u-u0)+static_cast<double>(z)*dz*(v-v0))+0.83;
            const auto value=std::polar(1.0+0.1*static_cast<double>(y+z),phase);
            data[cells[k]+static_cast<std::size_t>(dopplerBinCount*rangeBinCount)*(y+ny*z)]=
                af::cfloat(static_cast<float>(value.real()),static_cast<float>(value.imag()));
        }
    }
    return {af::array(af::dim4(dopplerBinCount,rangeBinCount,static_cast<dim_t>(ny*nz)),data.data(),afHost),
            CPI_Metadata(10e6,2000,frequency),RangeAxis(100,5),DopplerAxis(dopplerBinCount,dopplerBinCount,2000)};
}
DetectionList makeDetections(const RangeDopplerMap& map,bool snapshots=false) {
    const auto indices=upload<unsigned>({cells[2],cells[0],cells[1],cells[2]});
    const auto powers=af::constant(20.0f,af::dim4(4),f32),noise=af::constant(1.0f,af::dim4(4),f32);
    return snapshots?DetectionList::fromMap(map,indices,powers,noise):DetectionList::fromCells(map,indices,powers,noise);
}
void checkAngles(const AzElDetectionList& output,bool planar,double fixedElevation=0) {
    const auto records=output.recordsToHost();
    const std::array<std::size_t,4> order{2,0,1,2};
    test::check(records.size()==order.size(),"preserved detection count");
    for(std::size_t i=0;i<records.size();++i) {
        auto k=order[i];
        test::near(records[i].getAngles().getAzimuthRadians(),azimuths[k],3e-5);
        test::near(records[i].getAngles().getElevationRadians(),planar?elevations[k]:fixedElevation,3e-5);
        test::check(records[i].getDetection().getCell().getRangeBin()==cells[k]/7,"range order");
        test::check(records[i].getDetection().getCell().getDopplerBin()==cells[k]%7,"Doppler order");
        test::near(records[i].getDetection().getCell().getPower(),20);
    }
}
std::vector<RangeDopplerMap> split(const RangeDopplerMap& packed) {
    std::vector<RangeDopplerMap> maps;maps.reserve(static_cast<std::size_t>(packed.getElementCount()));
    for(dim_t e=0;e<packed.getElementCount();++e)
        maps.emplace_back(packed.getElement(e),packed.getMetadata(),packed.getRangeAxis(),packed.getDopplerAxis());
    return maps;
}
int main(int argc,char** argv) {
    try {
#if RADAR_ARRAYFIRE_UNIFIED
        const std::string backend=argc>1?argv[1]:"cpu";
        if(backend=="cpu")af::setBackend(AF_BACKEND_CPU);
        else if(backend=="cuda")af::setBackend(AF_BACKEND_CUDA);
        else if(backend=="opencl")af::setBackend(AF_BACKEND_OPENCL);
        else throw std::invalid_argument("backend must be cpu/cuda/opencl");
#else
        (void)argc;(void)argv;
#endif
        af::setDevice(0);
        test::run("1D packed/separate/snapshot paths and batches",[] {
            for(auto sign:{PhaseSign::Positive,PhaseSign::Negative}) {
                constexpr double assumedElevation=0.17;
                auto map=makeScene(5,1,wavelength/2,0,sign,0,0,assumedElevation);
                auto detections=makeDetections(map);
                test::check(!detections.getHasElementSnapshots(),"sparse detector has no IQ payload");
                test::check(detections.getSnapshotBytes()==0,"no IQ allocation");
                for(std::size_t batch:{std::size_t{1},std::size_t{2},std::size_t{4096}}) {
                    const Interferometry1D estimator(UniformLinearArray(5,wavelength/2,assumedElevation,sign),batch);
                    checkAngles(estimator.estimate(map,detections),false,assumedElevation);
                    const auto maps=split(map);
                    checkAngles(estimator.estimate(std::span<const RangeDopplerMap>(maps),detections),false,assumedElevation);
                    const auto withSnapshots=makeDetections(map,true);
                    checkAngles(estimator.estimate(withSnapshots),false,assumedElevation);
                }
            }
        });
        test::run("2D nonsquare grid packed/separate/snapshot paths",[] {
            for(auto sign:{PhaseSign::Positive,PhaseSign::Negative}) {
                auto map=makeScene(4,3,wavelength/2,0.4*wavelength,sign);
                auto detections=makeDetections(map);
                for(std::size_t batch:{std::size_t{1},std::size_t{3},std::size_t{4096}}) {
                    const Interferometry2D estimator(UniformRectangularArray(4,3,wavelength/2,0.4*wavelength,sign),batch);
                    checkAngles(estimator.estimate(map,detections),true);
                    const auto maps=split(map);
                    checkAngles(estimator.estimate(std::span<const RangeDopplerMap>(maps),detections),true);
                    checkAngles(estimator.estimate(makeDetections(map,true)),true);
                }
            }
        });
        test::run("different detection-map element count is allowed",[] {
            auto map=makeScene(4,3,wavelength/2,wavelength/2,PhaseSign::Positive);
            const RangeDopplerMap beam(af::sum(map.getData(),2),map.getMetadata(),map.getRangeAxis(),map.getDopplerAxis());
            auto detections=makeDetections(beam);
            const Interferometry2D estimator(UniformRectangularArray(4,3,wavelength/2,wavelength/2));
            const auto output=estimator.estimate(map,detections);
            checkAngles(output,true);
            test::check(output.getElementCount()==1,"original detection context retained");
        });
        test::run("empty input and absent snapshots remain empty",[] {
            auto map=makeScene(2,2,wavelength/2,wavelength/2,PhaseSign::Positive);
            const DetectionList empty(map.getDetectionContext());
            const Interferometry1D line(UniformLinearArray(2,wavelength/2));
            const Interferometry2D grid(UniformRectangularArray(2,2,wavelength/2,wavelength/2));
            test::check(line.estimate(map,empty).getIsEmpty(),"empty ULA");
            test::check(grid.estimate(map,empty).getIsEmpty(),"empty URA");
            auto detections=makeDetections(map);
            test::check(!detections.clone().getHasElementSnapshots(),"clone without IQ");
            test::check(!detections.select(upload<unsigned>({2u,0u})).getHasElementSnapshots(),"select without IQ");
            test::check(!detections.getDetection(0).getHasElementSnapshots(),"single without IQ");
        });
        test::run("null correlations produce NaN, not false boresight",[] {
            auto map=makeScene(3,2,wavelength/2,wavelength/2,PhaseSign::Positive);
            auto emptyCell=DetectionList::fromCells(map,upload<unsigned>({0u}),upload<float>({0}),upload<float>({1}));
            const Interferometry2D grid(UniformRectangularArray(3,2,wavelength/2,wavelength/2));
            const auto records=grid.estimate(map,emptyCell).recordsToHost();
            test::check(std::isnan(records[0].getAngles().getAzimuthRadians()),"undefined phase");
        });
        std::cout<<"All "<<test::checks<<" ArrayFire interferometry checks passed.\n";
        return 0;
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
