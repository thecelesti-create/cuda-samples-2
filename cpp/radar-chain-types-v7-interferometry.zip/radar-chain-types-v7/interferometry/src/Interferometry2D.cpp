#include <radar/interferometry/Interferometry2D.hpp>
#include "device_helpers.hpp"
#include <cmath>

namespace radar::interferometry {
namespace {
void compute(const af::array& snapshots, const UniformRectangularArray& geometry,
             double wavelength, af::array& azimuth, af::array& elevation) {
    const auto azimuthCount = geometry.getAzimuthElementCount();
    const auto elevationCount = geometry.getElevationElementCount();
    const af::array grid = af::moddims(snapshots, static_cast<dim_t>(azimuthCount),
                                     static_cast<dim_t>(elevationCount), snapshots.dims(1));
    const af::array lowerY = grid(detail::sequence(0, azimuthCount - 1), af::span, af::span);
    const af::array upperY = grid(detail::sequence(1, azimuthCount - 1), af::span, af::span);
    const af::array lowerZ = grid(af::span, detail::sequence(0, elevationCount - 1), af::span);
    const af::array upperZ = grid(af::span, detail::sequence(1, elevationCount - 1), af::span);
    const af::array correlationY = af::sum(af::sum(af::conjg(lowerY) * upperY, 0), 1);
    const af::array correlationZ = af::sum(af::sum(af::conjg(lowerZ) * upperZ, 0), 1);
    const double signedWavelength = static_cast<int>(geometry.getPhaseSign()) * wavelength;
    const af::array u = detail::phase(correlationY) *
        static_cast<float>(signedWavelength / (2.0 * radar::pi * geometry.getAzimuthSpacingMeters())) +
        static_cast<float>(geometry.getReferenceDirectionCosineY());
    const af::array v = detail::phase(correlationZ) *
        static_cast<float>(signedWavelength / (2.0 * radar::pi * geometry.getElevationSpacingMeters())) +
        static_cast<float>(geometry.getReferenceDirectionCosineZ());
    // Front hemisphere only. Out-of-disk noisy estimates naturally produce NaN;
    // no clipping to an apparently valid horizon target or phase unwrapping.
    azimuth = af::atan2(u, af::sqrt(1.0f - u*u - v*v));
    elevation = af::asin(v);
}
} // namespace
AzElDetectionList Interferometry2D::estimate(const RangeDopplerMap& map,
                                               const DetectionList& detections) const {
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return detail::gather(map, detections, first, count); },
        [&](const af::array& iq, af::array& az, af::array& el) {
            compute(iq, geometry_, map.getMetadata().getWavelengthMeters(), az, el);
        });
}
AzElDetectionList Interferometry2D::estimate(std::span<const RangeDopplerMap> maps,
                                               const DetectionList& detections) const {
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return detail::gather(maps, detections, first, count); },
        [&](const af::array& iq, af::array& az, af::array& el) {
            compute(iq, geometry_, maps.front().getMetadata().getWavelengthMeters(), az, el);
        });
}
AzElDetectionList Interferometry2D::estimate(const DetectionList& detections) const {
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) {
            return detections.getElementSnapshots()(af::span, detail::sequence(first, count));
        },
        [&](const af::array& iq, af::array& az, af::array& el) {
            compute(iq, geometry_, detections.getContext().getMetadata().getWavelengthMeters(), az, el);
        });
}
} // namespace radar::interferometry
