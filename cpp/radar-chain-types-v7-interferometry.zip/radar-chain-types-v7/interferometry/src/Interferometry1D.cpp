#include <radar/interferometry/Interferometry1D.hpp>
#include "device_helpers.hpp"
#include <cmath>

namespace radar::interferometry {
namespace {
void compute(const af::array& snapshots, const UniformLinearArray& geometry,
             double wavelength, af::array& azimuth, af::array& elevation) {
    const auto elementCount = geometry.getElementCount();
    const auto lower = snapshots(detail::sequence(0, elementCount - 1), af::span);
    const auto upper = snapshots(detail::sequence(1, elementCount - 1), af::span);
    const af::array correlation = af::sum(af::conjg(lower) * upper, 0);
    const float scale = static_cast<float>(static_cast<int>(geometry.getPhaseSign()) *
                                           wavelength / (2.0 * radar::pi * geometry.getSpacingMeters()));
    const af::array u = detail::phase(correlation) * scale +
                        static_cast<float>(geometry.getReferenceDirectionCosineY());
    // 1D aperture cannot independently estimate elevation. Explicit prior only.
    azimuth = af::asin(u / static_cast<float>(std::cos(geometry.getAssumedElevationRadians())));
    elevation = af::constant(static_cast<float>(geometry.getAssumedElevationRadians()), azimuth.dims(), f32);
}
} // namespace
AzElDetectionList Interferometry1D::estimate(const RangeDopplerMap& map,
                                               const DetectionList& detections) const {
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return detail::gather(map, detections, first, count); },
        [&](const af::array& iq, af::array& az, af::array& el) {
            compute(iq, geometry_, map.getMetadata().getWavelengthMeters(), az, el);
        });
}
AzElDetectionList Interferometry1D::estimate(std::span<const RangeDopplerMap> maps,
                                               const DetectionList& detections) const {
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return detail::gather(maps, detections, first, count); },
        [&](const af::array& iq, af::array& az, af::array& el) {
            compute(iq, geometry_, maps.front().getMetadata().getWavelengthMeters(), az, el);
        });
}
AzElDetectionList Interferometry1D::estimate(const DetectionList& detections) const {
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) {
            return detections.getElementSnapshots()(af::span, detail::sequence(first, count));
        },
        [&](const af::array& iq, af::array& az, af::array& el) {
            compute(iq, geometry_, detections.getContext().getMetadata().getWavelengthMeters(), az, el);
        });
}
} // namespace radar::interferometry
