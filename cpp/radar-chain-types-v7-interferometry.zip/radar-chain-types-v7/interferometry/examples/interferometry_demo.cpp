#include <radar/radar.hpp>
#include <radar/interferometry/Interferometry.hpp>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

int main(int argc, char** argv) {
    try {
#if RADAR_ARRAYFIRE_UNIFIED
        const std::string backend = argc > 1 ? argv[1] : "cuda";
        if (backend == "cuda") af::setBackend(AF_BACKEND_CUDA);
        else if (backend == "cpu") af::setBackend(AF_BACKEND_CPU);
        else throw std::invalid_argument("backend must be cpu or cuda");
#else
        (void)argc; (void)argv;
#endif
        using namespace radar;
        using namespace radar::interferometry;
        CPI_Metadata metadata(10e6, 2000.0, 10e9);
        const double wavelength = metadata.getWavelengthMeters();
        constexpr dim_t azimuthElementCount = 4, elevationElementCount = 3;
        constexpr dim_t dopplerBinCount = 8, rangeBinCount = 16;
        constexpr dim_t rangeBin = 5, dopplerBin = 2;
        constexpr double trueAzimuth = 20.0 * pi / 180.0;
        constexpr double trueElevation = 10.0 * pi / 180.0;
        const double u = std::cos(trueElevation) * std::sin(trueAzimuth);
        const double v = std::sin(trueElevation);
        const dim_t elementCount = azimuthElementCount * elevationElementCount;
        std::vector<af::cfloat> hostIq(static_cast<std::size_t>(dopplerBinCount * rangeBinCount * elementCount),
                                      af::cfloat(0.0f, 0.0f));
        for (dim_t z = 0; z < elevationElementCount; ++z)
            for (dim_t y = 0; y < azimuthElementCount; ++y) {
                // Half-wavelength spacing => adjacent phase = pi * direction cosine.
                const double phase = pi * (static_cast<double>(y)*u + static_cast<double>(z)*v);
                const dim_t element = y + azimuthElementCount * z;
                hostIq[static_cast<std::size_t>(dopplerBin + dopplerBinCount*(rangeBin + rangeBinCount*element))] =
                    af::cfloat(static_cast<float>(std::cos(phase)), static_cast<float>(std::sin(phase)));
            }
        RangeDopplerMap rdm(af::array(af::dim4(dopplerBinCount, rangeBinCount, elementCount), hostIq.data(), afHost),
                            metadata, RangeAxis(0.0, 15.0), DopplerAxis(dopplerBinCount, dopplerBinCount, 2000.0));
        // Stand-in detection index on device. No element IQ stored in this list.
        const auto detections = DetectionList::fromCells(rdm,
            af::constant(static_cast<unsigned>(dopplerBin + dopplerBinCount*rangeBin), af::dim4(1), u32),
            af::constant(static_cast<float>(elementCount), af::dim4(1), f32),
            af::constant(1.0f, af::dim4(1), f32));
        const Interferometry2D estimator(UniformRectangularArray(
            azimuthElementCount, elevationElementCount, wavelength/2.0, wavelength/2.0));
        const AzElDetectionList located = estimator.estimate(rdm, detections);
        // Final boundary only: the estimation above uses ArrayFire arrays.
        const auto output = located.recordsToHost();
        std::cout << "azimuth=" << output[0].getAngles().getAzimuthRadians() * 180.0/pi
                  << " deg, elevation=" << output[0].getAngles().getElevationRadians() * 180.0/pi << " deg\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
