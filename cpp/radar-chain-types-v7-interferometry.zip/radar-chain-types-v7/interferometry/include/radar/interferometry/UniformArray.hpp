#pragma once
#include <radar/types.hpp>
#include <cstddef>

namespace radar::interferometry {
// Independent of the Doppler sign convention. Positive uses
// x(y,z) = A * exp(+j*2*pi/lambda * (y*(u-u0) + z*(v-v0))).
enum class PhaseSign { Positive = 1, Negative = -1 };

// ULA on +y. One baseline axis measures u = cos(el)*sin(az), not both angles.
// Assumed elevation is input knowledge, NOT an elevation estimate.
// All arguments/setters are unchecked configuration contracts.
class UniformLinearArray final {
public:
    UniformLinearArray(std::size_t elementCount, double spacingMeters,
                       double assumedElevationRadians = 0.0,
                       PhaseSign phaseSign = PhaseSign::Positive,
                       double referenceDirectionCosineY = 0.0) noexcept
        : elementCount_(elementCount), spacingMeters_(spacingMeters),
          assumedElevationRadians_(assumedElevationRadians), phaseSign_(phaseSign),
          referenceDirectionCosineY_(referenceDirectionCosineY) {}
    [[nodiscard]] std::size_t getElementCount() const noexcept { return elementCount_; }
    [[nodiscard]] double getSpacingMeters() const noexcept { return spacingMeters_; }
    [[nodiscard]] double getAssumedElevationRadians() const noexcept { return assumedElevationRadians_; }
    [[nodiscard]] PhaseSign getPhaseSign() const noexcept { return phaseSign_; }
    [[nodiscard]] double getReferenceDirectionCosineY() const noexcept { return referenceDirectionCosineY_; }
    void setElementCount(std::size_t value) noexcept { elementCount_ = value; }
    void setSpacingMeters(double value) noexcept { spacingMeters_ = value; }
    void setAssumedElevationRadians(double value) noexcept { assumedElevationRadians_ = value; }
    void setPhaseSign(PhaseSign value) noexcept { phaseSign_ = value; }
    void setReferenceDirectionCosineY(double value) noexcept { referenceDirectionCosineY_ = value; }
private:
    std::size_t elementCount_;
    double spacingMeters_;
    double assumedElevationRadians_;
    PhaseSign phaseSign_;
    double referenceDirectionCosineY_;
};

// Rectangular grid in the yz plane. +x is boresight, +y positive azimuth, +z up.
// Element order: yIndex + azimuthElementCount * zIndex. Both counts >= 2.
// Spacing describes effective phase centers, including subarray phase centers.
class UniformRectangularArray final {
public:
    UniformRectangularArray(std::size_t azimuthElementCount, std::size_t elevationElementCount,
                            double azimuthSpacingMeters, double elevationSpacingMeters,
                            PhaseSign phaseSign = PhaseSign::Positive,
                            double referenceDirectionCosineY = 0.0,
                            double referenceDirectionCosineZ = 0.0) noexcept
        : azimuthElementCount_(azimuthElementCount), elevationElementCount_(elevationElementCount),
          azimuthSpacingMeters_(azimuthSpacingMeters), elevationSpacingMeters_(elevationSpacingMeters),
          phaseSign_(phaseSign), referenceDirectionCosineY_(referenceDirectionCosineY),
          referenceDirectionCosineZ_(referenceDirectionCosineZ) {}
    [[nodiscard]] std::size_t getAzimuthElementCount() const noexcept { return azimuthElementCount_; }
    [[nodiscard]] std::size_t getElevationElementCount() const noexcept { return elevationElementCount_; }
    [[nodiscard]] std::size_t getElementCount() const noexcept { return azimuthElementCount_ * elevationElementCount_; }
    [[nodiscard]] double getAzimuthSpacingMeters() const noexcept { return azimuthSpacingMeters_; }
    [[nodiscard]] double getElevationSpacingMeters() const noexcept { return elevationSpacingMeters_; }
    [[nodiscard]] PhaseSign getPhaseSign() const noexcept { return phaseSign_; }
    [[nodiscard]] double getReferenceDirectionCosineY() const noexcept { return referenceDirectionCosineY_; }
    [[nodiscard]] double getReferenceDirectionCosineZ() const noexcept { return referenceDirectionCosineZ_; }
    void setAzimuthElementCount(std::size_t value) noexcept { azimuthElementCount_ = value; }
    void setElevationElementCount(std::size_t value) noexcept { elevationElementCount_ = value; }
    void setAzimuthSpacingMeters(double value) noexcept { azimuthSpacingMeters_ = value; }
    void setElevationSpacingMeters(double value) noexcept { elevationSpacingMeters_ = value; }
    void setPhaseSign(PhaseSign value) noexcept { phaseSign_ = value; }
    void setReferenceDirectionCosineY(double value) noexcept { referenceDirectionCosineY_ = value; }
    void setReferenceDirectionCosineZ(double value) noexcept { referenceDirectionCosineZ_ = value; }
private:
    std::size_t azimuthElementCount_;
    std::size_t elevationElementCount_;
    double azimuthSpacingMeters_;
    double elevationSpacingMeters_;
    PhaseSign phaseSign_;
    double referenceDirectionCosineY_;
    double referenceDirectionCosineZ_;
};
} // namespace radar::interferometry
