#pragma once
#include <radar/AzElDetectionList.hpp>
#include <radar/interferometry/UniformArray.hpp>
#include <span>

namespace radar::interferometry {
class Interferometry2D final {
public:
    explicit Interferometry2D(UniformRectangularArray geometry,
                                 std::size_t detectionBatchSize = 4096) noexcept
        : geometry_(geometry), detectionBatchSize_(detectionBatchSize) {}
    [[nodiscard]] const UniformRectangularArray& getGeometry() const noexcept { return geometry_; }
    void setGeometry(UniformRectangularArray geometry) noexcept { geometry_ = geometry; }
    [[nodiscard]] std::size_t getDetectionBatchSize() const noexcept { return detectionBatchSize_; }
    void setDetectionBatchSize(std::size_t value) noexcept { detectionBatchSize_ = value; }

    // Packed [Doppler,range,element] phase-center cube. Only detected cells gathered.
    [[nodiscard]] AzElDetectionList estimate(const RangeDopplerMap& phaseCenteredRdm,
                                             const DetectionList& detections) const;
    // One [Doppler,range,1] map per ordered phase center; no whole-map join/copy.
    [[nodiscard]] AzElDetectionList estimate(std::span<const RangeDopplerMap> phaseCenteredRdms,
                                             const DetectionList& detections) const;
    // Fastest path when detection snapshots already contain the correct phase centers.
    [[nodiscard]] AzElDetectionList estimate(const DetectionList& detections) const;
private:
    UniformRectangularArray geometry_;
    std::size_t detectionBatchSize_;
};
} // namespace radar::interferometry
