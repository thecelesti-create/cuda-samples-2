# Uniform-array phase interferometry

Separate C++20 library: **`radar::interferometry`**. Requires `radar::chain_types`
and ArrayFire 3.10+. Class members are private; configuration getters/setters are
inline and unchecked. No per-detection CPU loops, host readbacks, covariance
matrices, eigensolvers, or spatial angle-grid scans are used in the estimators.

## API

```cpp
#include <radar/interferometry/Interferometry.hpp>
using namespace radar::interferometry;

const double wavelength = rdm.getMetadata().getWavelengthMeters();
const Interferometry1D line(
    UniformLinearArray(5, wavelength/2.0, /*known elevation*/ 0.0));
radar::AzElDetectionList result1D = line.estimate(rdm, detections);

const Interferometry2D grid(
    UniformRectangularArray(4, 3, wavelength/2.0, wavelength/2.0));
radar::AzElDetectionList result2D = grid.estimate(planarRdm, detections);
```

Both classes have three overloads, all returning `AzElDetectionList`:

```cpp
estimate(const RangeDopplerMap& packedPhaseCenters, const DetectionList& detections);
estimate(std::span<const RangeDopplerMap> individualPhaseCenters, const DetectionList& detections);
estimate(const DetectionList& alreadyGatheredPhaseCenterSnapshots);
```

The first path takes one c32 [Doppler,range,element] cube. The second accepts
one c32 [Doppler,range,1] RDM per phase center. It gathers each center into a
SMALL snapshot block, never joins the full RDMs. A `std::vector<RangeDopplerMap>`
converts to the span without copying any map. The last path avoids gathering
entirely when existing [element,K] snapshots are already correct and calibrated.

The RDM+list overloads use the supplied RDM(s), NOT IQ that happens to be in the
DetectionList. The output preserves original detection order, duplicates, bin
indices, power/noise values, context and optional original snapshots. It does
not replace that context with phase-center geometry or deliberately retain the
whole RDM. Caller-supplied original IQ views may still retain a parent allocation;
that ArrayFire alias lifetime is separate from this library's explicit storage.

## Coordinate system and signal model

Sensor-local right-handed frame: **+x boresight, +y positive azimuth, +z up**.
Angles are radians. Define `u = cos(elevation)*sin(azimuth)`, `v = sin(elevation)`.

For phase center `(y,z)` the expected narrowband, far-field, single-arrival IQ is:

```text
x(y,z) = A(y,z) * exp(j * sign * (2*pi/lambda) * [y*(u-u0) + z*(v-v0)])
```

After calibration, A may vary in positive amplitude; any unknown center-specific
phase invalidates the phase slope. A common complex phase cancels. `PhaseSign`
is Positive (+1) by default; select Negative (-1) for the conjugate receiver
convention. This is INDEPENDENT of the radar Doppler sign setting.

`u0` and `v0` default to zero. Set reference direction cosines ONLY if the input
was spatially derotated by those known steering phases. They restore the known
removed phase slope. They are not automatic boresight offsets and cannot resolve
unknown integer phase wraps. Re-reference both array axes consistently.

The receive-baseline spatial factor is **2*pi/lambda**, not the monostatic
range/Doppler round-trip 4*pi/lambda factor. Transmit phase is assumed common;
virtual-array/TDM-MIMO scheduling and moving-platform phase correction are outside
this implementation.

## 1D method

Phase centers lie along +y, with equal spacing `d`. The code takes the phase of
summed adjacent complex products (circular averaging, not an average of angles):

```text
C = sum(conj(x[n]) * x[n+1])
u = u0 + sign * lambda/(2*pi*d) * arg(C)
azimuth = asin(u / cos(assumedElevation))
elevation = assumedElevation
```

At least two phase centers, positive spacing, and `abs(assumedElevation) < pi/2`
are required. **A ULA does not estimate both azimuth and elevation independently.**
Elevation is an explicit prior (default zero). With no valid elevation prior,
interpret the measured quantity as a direction cosine, not an independent 3D fix.
This method returns the forward/broadside branch of the azimuth.

## 2D method

A COMPLETE uniform rectangular grid in the yz plane, with both extents >= 2:

```text
elementIndex = azimuthIndex + azimuthElementCount * elevationIndex
```

`azimuthSpacingMeters` and `elevationSpacingMeters` may differ. Adjacent products
are accumulated separately along each axis, across ALL rows/columns:

```text
Cy = sum(conj(x[y,z]) * x[y+1,z])
Cz = sum(conj(x[y,z]) * x[y,z+1])
u = u0 + sign * lambda/(2*pi*dy) * arg(Cy)
v = v0 + sign * lambda/(2*pi*dz) * arg(Cz)
azimuth = atan2(u, sqrt(1 - u*u - v*v))
elevation = asin(v)
```

This retains the azimuth/elevation coupling; `asin(u)` alone is not generally the
azimuth when elevation is nonzero. The method chooses +x; planar baselines do not
resolve the front/back ambiguity. There is no behind-array hemisphere selector.

A five-element cross, incomplete grid, or arbitrary layout is NOT a rectangular
grid. Do not feed a fifth sum beam as if it were an additional physical phase
center. Four quadrant centers can be a 2x2 input; their ordering and real positions
must satisfy the stated model.

## Elemental versus subarray-beamformed inputs

The algorithms are identical for elemental or subarray RDMs. Set the geometry
spacing to the **distance between effective phase centers**, not the spacing of
radiators within a subarray. Centers must be uniformly spaced and coherent, with
compatible subarray patterns/steering/calibration over the angle region used.
A phase-center model is not automatically valid for arbitrary, differently
weighted or differently steered subarray beams.

The relative arrival phase between distinct centers must still be present.
If every RDM has been rephased to the same common center in a way that removes the
angle-dependent inter-center phase, these methods have no angle information left.
They do not undo arbitrary calibration or infer physical geometry from metadata.

Principal `arg()` phases are wrapped. For this implementation the residual must
ALWAYS satisfy `abs(d*(u-u0)/lambda) < 1/2` (and the corresponding z condition),
including when a nonzero steering reference is supplied. With zero reference,
spacing no greater than half a wavelength covers the visible interior without
spatial aliasing; exact half-wavelength endfire endpoints remain ambiguous.
Larger subarray spacings restrict the unwrapped residual field of view. Adding
a known reference back does not recover a lost integer wrap. No ambiguity
resolver, MUSIC, ESPRIT, multi-source separation, or phase unwrapping is included.
Multiple unresolved targets in one range-Doppler cell can bias these estimates.

Zero summed correlation is mapped to NaN on device. `asin`/`sqrt` naturally yield
NaN for out-of-domain/noisy direction cosines; there is no clipping to a fake
valid target. At least the azimuth may be NaN while the elevation is still defined.
No confidence/quality mask or uncertainty estimate is generated. The caller
handles invalid estimates at its chosen downstream boundary. Do not enable
`-ffast-math` and expect NaN-based behavior to remain reliable.

## Memory and execution

Only K selected cells are processed, with nominal work O(elementCount*K).
The detector can use `DetectionList::fromCells()` to retain no IQ at all. Angle
estimation then gathers from separate phase-center RDMs once. Existing snapshots
can instead be reused via the one-argument estimate overload.

`getDetectionBatchSize()` defaults to 4096; `setDetectionBatchSize(B)` requires
B > 0. The dominant snapshot block has `8 * elementCount * min(K,B)` bytes.
For 12 centers at B=4096 this block alone is 393,216 bytes. Pair products,
gather/reorder buffers, column indices and math intermediates also require memory.
Two output angle arrays require 8*K bytes, beyond the retained input arrays.
The single-block path adopts computed output columns directly, avoiding a second
full set of angle buffers. No persistent scratch cache or duplicate RDM is owned
by an estimator.

For the no-full-cube-copy path, input RDMs must be contiguous in their documented
layouts. `moddims`/`flat` on a strided slice may cause ArrayFire to materialize a
full copy. Use packed owned stage results or pre-gathered snapshots for low-memory
processing of otherwise strided input. This is a caller contract, not a runtime
contiguity scan.

`eval()` is used at block boundaries to limit deferred expression lifetimes;
there is no explicit `sync()`, `host()`, `scalar()`, or data-dependent `where()`
in the interferometry library. Backend internals, asynchronous queues and the
ArrayFire memory pool can retain workspace, so the block-size formula is NOT a
hard guarantee on peak device allocation. The functions are not CUDA kernels
launched with zero CPU work: the host issues ArrayFire operations and loops over
blocks (and separate input maps). Benchmark the packed and separate-map paths
on your workload; no unmeasured speedup is claimed.

## Unchecked caller contracts

All arrays use the same active backend/device. RDMs and detections correspond to
the same CPI, wavelength, range grid, FFT length AND Doppler ordering. Input maps
have the stated element counts/order. `DetectionList` may come from a single
sum-beam map and have a different element count; that is supported. Bin columns
are u32 [K], values are in bounds, powers/noise are aligned, sizes fit dim_t/u32,
and snapshots (when used) are c32 [E,K]. Geometry has finite positive spacings,
valid sign/reference values, and consistent counts. There is no automatic
`fftshift`, interpolation, remapping, hardware calibration, or metadata matching.

## Tests

`tests/reference_math_tests.cpp` runs an INDEPENDENT scalar std::complex oracle,
using production geometry classes. It checks the signal model and conventions,
NOT ArrayFire kernel behavior. `tests/arrayfire_tests.cpp` exercises the actual
estimators on packed, separate-map and snapshot paths, multiple batch sizes,
negative sign, rectangular grids, nonzero/duplicate cells, missing snapshots,
original context preservation and empty/undefined results. Run that executable
with `cpu` and `cuda` on a real SDK installation.

`examples/interferometry_demo.cpp` is a small synthetic 4x3 half-wavelength
array. Its expected answer is azimuth 20 degrees, elevation 10 degrees. See the
root validation report for exactly which tests were executed in this environment.

## References

- Analog Devices: phased-array inter-element phase/path relation and far-field model:
  https://www.analog.com/en/resources/analog-dialogue/articles/phased-array-antenna-patterns-part1.html
- MathWorks: direction-cosine to azimuth/elevation conversion and +x hemisphere:
  https://www.mathworks.com/help/phased/ref/uv2azel.html
- ArrayFire arg (complex phase in radians):
  https://arrayfire.org/docs/group__arith__func__arg.htm
- ArrayFire lookup (indexing preconditions / mirrored out-of-range behavior):
  https://arrayfire.org/docs/group__index__func__lookup.htm
