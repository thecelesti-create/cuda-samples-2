#pragma once

#include <radar/types.hpp>
#include <cmath>
#include <cstddef>
#include <limits>
#include <string>
#include <utility>
#include <vector>

namespace radar {

// Uniform-PRF, monostatic coherent processing interval. Times use an application
// epoch. Positive rates and valid metadata are caller preconditions.
// Nonvirtual value class: private storage, inline unchecked getters, unchecked setters.
class CPI_Metadata final {
public:
    CPI_Metadata(double sampleRateHz, double prfHz, double carrierFrequencyHz,
                 std::uint64_t cpiId = 0, double firstSampleDelaySeconds = 0.0,
                 double firstPulseTimeSeconds = 0.0,
                 PositiveDoppler positiveDoppler = PositiveDoppler::Approaching,
                 std::string waveformId = {}, std::vector<std::string> elementNames = {})
        : sampleRateHz_(sampleRateHz), prfHz_(prfHz),
          carrierFrequencyHz_(carrierFrequencyHz), cpiId_(cpiId),
          firstSampleDelaySeconds_(firstSampleDelaySeconds),
          firstPulseTimeSeconds_(firstPulseTimeSeconds), positiveDoppler_(positiveDoppler),
          waveformId_(std::move(waveformId)), elementNames_(std::move(elementNames)) {
        samplePeriodSeconds_ = 1.0 / sampleRateHz_;
        pulsePeriodSeconds_ = 1.0 / prfHz_;
        wavelengthMeters_ = speedOfLightMps / carrierFrequencyHz_;
        velocityPerHz_ = (positiveDoppler_ == PositiveDoppler::Receding ? 0.5 : -0.5)
                         * wavelengthMeters_;
    }

    [[nodiscard]] double getSampleRateHz() const noexcept { return sampleRateHz_; }
    [[nodiscard]] double getPrfHz() const noexcept { return prfHz_; }
    [[nodiscard]] double getCarrierFrequencyHz() const noexcept { return carrierFrequencyHz_; }
    [[nodiscard]] std::uint64_t getCpiId() const noexcept { return cpiId_; }
    [[nodiscard]] double getFirstSampleDelaySeconds() const noexcept { return firstSampleDelaySeconds_; }
    [[nodiscard]] double getFirstPulseTimeSeconds() const noexcept { return firstPulseTimeSeconds_; }
    [[nodiscard]] PositiveDoppler getPositiveDoppler() const noexcept { return positiveDoppler_; }
    [[nodiscard]] const std::string& getWaveformId() const noexcept { return waveformId_; }
    [[nodiscard]] const std::vector<std::string>& getElementNames() const noexcept { return elementNames_; }
    [[nodiscard]] double getSamplePeriodSeconds() const noexcept { return samplePeriodSeconds_; }
    [[nodiscard]] double getPulsePeriodSeconds() const noexcept { return pulsePeriodSeconds_; }
    [[nodiscard]] double getWavelengthMeters() const noexcept { return wavelengthMeters_; }
    // Positive output means receding; finite input is a caller precondition.
    [[nodiscard]] double getRadialVelocityMps(double dopplerHz) const noexcept {
        return velocityPerHz_ * dopplerHz;
    }

    void setSampleRateHz(double value) {
        const double period = 1.0 / value;
        sampleRateHz_ = value;
        samplePeriodSeconds_ = period;
    }
    void setPrfHz(double value) {
        const double period = 1.0 / value;
        prfHz_ = value;
        pulsePeriodSeconds_ = period;
    }
    void setCarrierFrequencyHz(double value) {
        const double wavelength = speedOfLightMps / value;
        carrierFrequencyHz_ = value;
        wavelengthMeters_ = wavelength;
        velocityPerHz_ = (positiveDoppler_ == PositiveDoppler::Receding ? 0.5 : -0.5) * wavelength;
    }
    void setCpiId(std::uint64_t value) noexcept { cpiId_ = value; }
    void setFirstSampleDelaySeconds(double value) {
        firstSampleDelaySeconds_ = value;
    }
    void setFirstPulseTimeSeconds(double value) {
        firstPulseTimeSeconds_ = value;
    }
    void setPositiveDoppler(PositiveDoppler value) {
        positiveDoppler_ = value;
        velocityPerHz_ = (value == PositiveDoppler::Receding ? 0.5 : -0.5) * wavelengthMeters_;
    }
    void setWaveformId(std::string value) { waveformId_ = std::move(value); }
    // A metadata object has no cube shape; label-count compatibility is maintained
    // by the caller before handing metadata to a buffer.
    void setElementNames(std::vector<std::string> value) { elementNames_ = std::move(value); }

private:
    double sampleRateHz_;
    double prfHz_;
    double carrierFrequencyHz_;
    std::uint64_t cpiId_;
    double firstSampleDelaySeconds_;
    double firstPulseTimeSeconds_;
    PositiveDoppler positiveDoppler_;
    std::string waveformId_;
    std::vector<std::string> elementNames_;
    double samplePeriodSeconds_;
    double pulsePeriodSeconds_;
    double wavelengthMeters_;
    double velocityPerHz_;
};
} // namespace radar
