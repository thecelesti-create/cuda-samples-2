#pragma once

#include <radar/SamplePulseBuffer.hpp>

namespace radar {

// Range-compressed complex IQ: [range, pulse, element, 1].
// All indexed helpers are UNCHECKED: valid indices/slices and an active owning
// ArrayFire backend/device are caller preconditions. The wrapper performs no runtime validation.
class RangePulseBuffer final {
public:
    RangePulseBuffer(af::array iq, CPI_Metadata metadata, RangeAxis rangeAxis);
    // Adopts an already-computed result. Pulse/element counts must match source;
    // the matched filter may change the range count. No filtering in this class.
    RangePulseBuffer(const SamplePulseBuffer& source, af::array filteredIq, RangeAxis rangeAxis);

    [[nodiscard]] const af::array& getData() const noexcept { return iq_; }
    [[nodiscard]] const CPI_Metadata& getMetadata() const noexcept { return metadata_; }
    [[nodiscard]] dim_t getRangeBinCount() const noexcept { return rangeBinCount_; }
    [[nodiscard]] dim_t getPulseCount() const noexcept { return pulseCount_; }
    // Hardware element count (dim2), not getData().elements() total IQ values.
    [[nodiscard]] dim_t getElementCount() const noexcept { return elementCount_; }
    [[nodiscard]] af::dim4 getDimensions() const { return af::dim4(rangeBinCount_, pulseCount_, elementCount_); }
    [[nodiscard]] std::size_t getBytes() const noexcept {
        return static_cast<std::size_t>(rangeBinCount_) * static_cast<std::size_t>(pulseCount_) *
               static_cast<std::size_t>(elementCount_) * sizeof(af::cfloat);
    }
    // Logical column-major offset; not necessarily a physical offset in a view.
    [[nodiscard]] std::size_t getLinearIndex(dim_t rangeBin, dim_t pulseIndex, dim_t elementIndex) const noexcept {
        return static_cast<std::size_t>(rangeBin) + static_cast<std::size_t>(rangeBinCount_) *
               (static_cast<std::size_t>(pulseIndex) + static_cast<std::size_t>(pulseCount_) *
                static_cast<std::size_t>(elementIndex));
    }
    [[nodiscard]] double getPulseTimeSeconds(dim_t pulseIndex) const noexcept {
        return metadata_.getFirstPulseTimeSeconds() + static_cast<double>(pulseIndex) *
               metadata_.getPulsePeriodSeconds();
    }
    [[nodiscard]] const RangeAxis& getRangeAxis() const noexcept { return rangeAxis_; }
    [[nodiscard]] double getRangeMeters(dim_t rangeBin) const noexcept { return rangeAxis_.getMeters(rangeBin); }
    [[nodiscard]] dim_t getDopplerBatchCount() const noexcept { return rangeBinCount_ * elementCount_; }
    [[nodiscard]] af::array getPulse(dim_t pulseIndex, dim_t elementIndex) const;
    [[nodiscard]] af::array getElement(dim_t elementIndex) const;
    [[nodiscard]] af::array getSlowTime(dim_t rangeBin, dim_t elementIndex) const;
    [[nodiscard]] RangePulseBuffer sliceRanges(dim_t firstRangeBin, dim_t rangeBinCount) const;
    [[nodiscard]] RangePulseBuffer slicePulses(dim_t firstPulse, dim_t pulseCount) const;
    // Explicit reorder [R,P,E] -> [P,R,E] for ArrayFire's leading-axis FFT.
    [[nodiscard]] af::array getDopplerInput() const;
    [[nodiscard]] af::array getPower() const;

    // Replacement is unchecked. Shape/layout and
    // backend/device must stay unchanged; constructors support intentional changes.
    void setData(af::array iq);
    void setMetadata(CPI_Metadata metadata);
    void setRangeAxis(RangeAxis rangeAxis);
    [[nodiscard]] RangePulseBuffer withData(af::array iq) const;
    [[nodiscard]] RangePulseBuffer clone() const; // Explicit deep copy, no revalidation.
    [[nodiscard]] std::vector<af::cfloat> toHost() const;
    void evaluate() const;
    void synchronize() const;

private:
    af::array iq_;
    CPI_Metadata metadata_;
    RangeAxis rangeAxis_;
    // Cached at construction and updated by trusted slice helpers only.
    dim_t rangeBinCount_;
    dim_t pulseCount_;
    dim_t elementCount_;
};
} // namespace radar
