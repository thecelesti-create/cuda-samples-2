#pragma once

#include <radar/detail/ArrayFire.hpp>
#include <radar/metadata.hpp>
#include <span>

namespace radar {

// Raw complex single-precision IQ: [sample, pulse, element, 1].
// All indexed helpers are UNCHECKED: valid indices/slices and an active owning
// ArrayFire backend/device are caller preconditions. The wrapper performs no runtime validation.
class SamplePulseBuffer final {
public:
    SamplePulseBuffer(af::array iq, CPI_Metadata metadata);
    // Explicit zero allocation or host upload; sizes must match the supplied data.
    SamplePulseBuffer(dim_t sampleCount, dim_t pulseCount, dim_t elementCount, CPI_Metadata metadata);
    SamplePulseBuffer(std::span<const af::cfloat> iq, dim_t sampleCount, dim_t pulseCount,
                      dim_t elementCount, CPI_Metadata metadata);
    [[nodiscard]] static SamplePulseBuffer zeros(dim_t sampleCount, dim_t pulseCount, dim_t elementCount,
                                                 CPI_Metadata metadata);
    [[nodiscard]] static SamplePulseBuffer fromHost(std::span<const af::cfloat> iq,
                                                    dim_t sampleCount, dim_t pulseCount, dim_t elementCount,
                                                    CPI_Metadata metadata);

    [[nodiscard]] const af::array& getData() const noexcept { return iq_; }
    [[nodiscard]] const CPI_Metadata& getMetadata() const noexcept { return metadata_; }
    [[nodiscard]] dim_t getSampleCount() const noexcept { return sampleCount_; }
    [[nodiscard]] dim_t getPulseCount() const noexcept { return pulseCount_; }
    // Hardware element count (dim2), not getData().elements() total IQ values.
    [[nodiscard]] dim_t getElementCount() const noexcept { return elementCount_; }
    [[nodiscard]] af::dim4 getDimensions() const { return af::dim4(sampleCount_, pulseCount_, elementCount_); }
    [[nodiscard]] std::size_t getBytes() const noexcept {
        return static_cast<std::size_t>(sampleCount_) * static_cast<std::size_t>(pulseCount_) *
               static_cast<std::size_t>(elementCount_) * sizeof(af::cfloat);
    }
    // Logical column-major offset; not necessarily a physical offset in a view.
    [[nodiscard]] std::size_t getLinearIndex(dim_t sampleIndex, dim_t pulseIndex, dim_t elementIndex) const noexcept {
        return static_cast<std::size_t>(sampleIndex) + static_cast<std::size_t>(sampleCount_) *
               (static_cast<std::size_t>(pulseIndex) + static_cast<std::size_t>(pulseCount_) *
                static_cast<std::size_t>(elementIndex));
    }
    [[nodiscard]] double getPulseTimeSeconds(dim_t pulseIndex) const noexcept {
        return metadata_.getFirstPulseTimeSeconds() + static_cast<double>(pulseIndex) *
               metadata_.getPulsePeriodSeconds();
    }
    [[nodiscard]] double getSampleDelaySeconds(dim_t sampleIndex) const noexcept {
        return metadata_.getFirstSampleDelaySeconds() + static_cast<double>(sampleIndex) *
               metadata_.getSamplePeriodSeconds();
    }
    [[nodiscard]] dim_t getMatchedFilterBatchCount() const noexcept { return pulseCount_ * elementCount_; }
    [[nodiscard]] af::array getPulse(dim_t pulseIndex, dim_t elementIndex) const;
    [[nodiscard]] af::array getElement(dim_t elementIndex) const;
    [[nodiscard]] af::array getSlowTime(dim_t sampleIndex, dim_t elementIndex) const;
    [[nodiscard]] SamplePulseBuffer sliceSamples(dim_t firstSample, dim_t sampleCount) const;
    [[nodiscard]] SamplePulseBuffer slicePulses(dim_t firstPulse, dim_t pulseCount) const;
    [[nodiscard]] af::array getPower() const;

    // Replacement is unchecked. Shape/layout and
    // backend/device must stay unchanged; constructors support intentional changes.
    void setData(af::array iq);
    void setMetadata(CPI_Metadata metadata);
    [[nodiscard]] SamplePulseBuffer withData(af::array iq) const;
    [[nodiscard]] SamplePulseBuffer clone() const; // Explicit deep copy, no revalidation.
    [[nodiscard]] std::vector<af::cfloat> toHost() const;
    void evaluate() const;
    void synchronize() const;

private:
    af::array iq_;
    CPI_Metadata metadata_;
    // Cached at construction and updated by trusted slice helpers only.
    dim_t sampleCount_;
    dim_t pulseCount_;
    dim_t elementCount_;
};
} // namespace radar
