#pragma once

#include <radar/RangePulseBuffer.hpp>

namespace radar {

// Complex Doppler spectra: [Doppler, range, element, 1], not just power.
// All indexed helpers are UNCHECKED: valid indices/slices and an active owning
// ArrayFire backend/device are caller preconditions. The wrapper performs no runtime validation.
class RangeDopplerMap final {
public:
    RangeDopplerMap(af::array iq, CPI_Metadata metadata, RangeAxis rangeAxis,
                   DopplerAxis dopplerAxis);
    // Adopts [D,R,E,1] FFT output. Allows zero padding, not pulse truncation.
    RangeDopplerMap(const RangePulseBuffer& source, af::array dopplerIq,
                   DopplerOrder order = DopplerOrder::Unshifted);

    [[nodiscard]] const af::array& getData() const noexcept { return iq_; }
    [[nodiscard]] const CPI_Metadata& getMetadata() const noexcept { return metadata_; }
    [[nodiscard]] dim_t getDopplerBinCount() const noexcept { return dopplerBinCount_; }
    [[nodiscard]] dim_t getRangeBinCount() const noexcept { return rangeBinCount_; }
    // Hardware element count (dim2), not getData().elements() total IQ values.
    [[nodiscard]] dim_t getElementCount() const noexcept { return elementCount_; }
    [[nodiscard]] af::dim4 getDimensions() const { return af::dim4(dopplerBinCount_, rangeBinCount_, elementCount_); }
    [[nodiscard]] std::size_t getBytes() const noexcept {
        return static_cast<std::size_t>(dopplerBinCount_) * static_cast<std::size_t>(rangeBinCount_) *
               static_cast<std::size_t>(elementCount_) * sizeof(af::cfloat);
    }
    // Semantic argument order stays range, Doppler, element despite [D,R,E].
    [[nodiscard]] std::size_t getLinearIndex(dim_t rangeBin, dim_t dopplerBin, dim_t elementIndex) const noexcept {
        return static_cast<std::size_t>(dopplerBin) + static_cast<std::size_t>(dopplerBinCount_) *
               (static_cast<std::size_t>(rangeBin) + static_cast<std::size_t>(rangeBinCount_) *
                static_cast<std::size_t>(elementIndex));
    }
    [[nodiscard]] const RangeAxis& getRangeAxis() const noexcept { return rangeAxis_; }
    [[nodiscard]] double getRangeMeters(dim_t rangeBin) const noexcept { return rangeAxis_.getMeters(rangeBin); }
    [[nodiscard]] const DopplerAxis& getDopplerAxis() const noexcept { return dopplerAxis_; }
    [[nodiscard]] double getDopplerHz(dim_t dopplerBin) const noexcept { return dopplerAxis_.getHertz(dopplerBin); }
    [[nodiscard]] double getRadialVelocityMps(dim_t dopplerBin) const noexcept {
        return metadata_.getRadialVelocityMps(getDopplerHz(dopplerBin));
    }
    [[nodiscard]] DetectionContext getDetectionContext() const;
    [[nodiscard]] af::array getElement(dim_t elementIndex) const;
    [[nodiscard]] af::array getDopplerSpectrum(dim_t rangeBin, dim_t elementIndex) const;
    [[nodiscard]] af::array getRangeProfile(dim_t dopplerBin, dim_t elementIndex) const;
    [[nodiscard]] af::array getElementVector(dim_t rangeBin, dim_t dopplerBin) const;
    [[nodiscard]] af::array getPowerSumElements() const;
    [[nodiscard]] RangeDopplerMap sliceRanges(dim_t firstRangeBin, dim_t rangeBinCount) const;
    [[nodiscard]] RangeDopplerMap withDopplerOrder(DopplerOrder order) const;
    [[nodiscard]] af::array getRangeFirstData() const;
    [[nodiscard]] af::array getPower() const;

    // Replacement is unchecked. Shape/layout and
    // backend/device must stay unchanged; constructors support intentional changes.
    void setData(af::array iq);
    void setMetadata(CPI_Metadata metadata);
    void setRangeAxis(RangeAxis rangeAxis);
    // Explicitly shifts DATA and changes ordering metadata together, odd/even safe.
    void setDopplerOrder(DopplerOrder order);
    [[nodiscard]] RangeDopplerMap withData(af::array iq) const;
    [[nodiscard]] RangeDopplerMap clone() const; // Explicit deep copy, no revalidation.
    [[nodiscard]] std::vector<af::cfloat> toHost() const;
    void evaluate() const;
    void synchronize() const;

private:
    af::array iq_;
    CPI_Metadata metadata_;
    RangeAxis rangeAxis_;
    DopplerAxis dopplerAxis_;
    // Cached at construction and updated by trusted slice helpers only.
    dim_t dopplerBinCount_;
    dim_t rangeBinCount_;
    dim_t elementCount_;
};
} // namespace radar
