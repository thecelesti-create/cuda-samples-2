#include <radar/radar.hpp>
#include "test_support.hpp"
#include <string>
#include <utility>
#include <type_traits>

static_assert(noexcept(std::declval<const radar::SamplePulseBuffer&>().getSampleCount()));
static_assert(noexcept(std::declval<const radar::SamplePulseBuffer&>().getLinearIndex(0, 0, 0)));
static_assert(noexcept(std::declval<const radar::DetectionList&>().getDetectionCount()));
static_assert(noexcept(std::declval<const radar::AzElDetectionList&>().getDetectionCount()));

// Compile-time coverage for all renamed stage APIs (requires an ArrayFire SDK).
static_assert(noexcept(std::declval<const radar::SamplePulseBuffer&>().getElementCount()));
static_assert(noexcept(std::declval<const radar::RangePulseBuffer&>().getElementCount()));
static_assert(noexcept(std::declval<const radar::RangeDopplerMap&>().getElementCount()));
static_assert(noexcept(std::declval<const radar::DetectionList&>().getElementCount()));
static_assert(std::is_same_v<decltype(std::declval<const radar::SamplePulseBuffer&>().getElement(0)), af::array>);
static_assert(std::is_same_v<decltype(std::declval<const radar::RangePulseBuffer&>().getElement(0)), af::array>);
static_assert(std::is_same_v<decltype(std::declval<const radar::RangeDopplerMap&>().getElementVector(0, 0)), af::array>);
static_assert(std::is_same_v<decltype(std::declval<const radar::RangeDopplerMap&>().getPowerSumElements()), af::array>);
static_assert(std::is_same_v<decltype(std::declval<const radar::DetectionList&>().getElementSnapshots()), const af::array&>);
static_assert(std::is_same_v<decltype(std::declval<const radar::AzElDetectionList&>().getElementSnapshots()), const af::array&>);

// Explicit property names are the only public accessor API.
static_assert(noexcept(std::declval<const radar::SamplePulseBuffer&>().getPulseCount()));
static_assert(noexcept(std::declval<const radar::RangePulseBuffer&>().getRangeBinCount()));
static_assert(noexcept(std::declval<const radar::RangePulseBuffer&>().getPulseCount()));
static_assert(noexcept(std::declval<const radar::RangeDopplerMap&>().getDopplerBinCount()));
static_assert(noexcept(std::declval<const radar::RangeDopplerMap&>().getRangeBinCount()));
static_assert(std::is_same_v<decltype(std::declval<const radar::SamplePulseBuffer&>().getData()),
                             const af::array&>);
static_assert(std::is_same_v<decltype(std::declval<const radar::DetectionList&>().getDetection(0)),
                             radar::DetectionList>);
static_assert(std::is_same_v<decltype(std::declval<const radar::AzElDetectionList&>().getDetection(0)),
                             radar::AzElDetectionList>);

using namespace radar;

CPI_Metadata makeMetadata() { return {10e6, 2000, 10e9, 0, 1e-6, 10}; }
std::vector<af::cfloat> numbered(dim_t leadingAxisExtent, dim_t middleAxisExtent, dim_t trailingAxisExtent) {
    std::vector<af::cfloat> values(static_cast<std::size_t>(leadingAxisExtent * middleAxisExtent * trailingAxisExtent));
    for (dim_t elementIndex = 0; elementIndex < trailingAxisExtent; ++elementIndex)
        for (dim_t j = 0; j < middleAxisExtent; ++j)
            for (dim_t i = 0; i < leadingAxisExtent; ++i) {
                const float value = static_cast<float>(i + 10 * j + 100 * elementIndex);
                values[static_cast<std::size_t>(i + leadingAxisExtent * (j + middleAxisExtent * elementIndex))] = {value, -value};
            }
    return values;
}
void complexNear(const af::cfloat& a, const af::cfloat& b, double tolerance = 1e-5) {
    test::near(a.real, b.real, tolerance);
    test::near(a.imag, b.imag, tolerance);
}
std::vector<af::cfloat> host(const af::array& data) {
    std::vector<af::cfloat> values(static_cast<std::size_t>(data.elements()));
    if (!values.empty()) data.host(values.data());
    return values;
}
void chooseBackend(const std::string& name) {
    // Run with no argument for a directly linked CPU/CUDA/OpenCL backend.
    if (name == "cpu") af::setBackend(AF_BACKEND_CPU);
    else if (name == "cuda") af::setBackend(AF_BACKEND_CUDA);
    else if (name == "opencl") af::setBackend(AF_BACKEND_OPENCL);
    else throw std::invalid_argument("backend must be cpu, cuda, or opencl");
}

template<class T>
af::array upload(std::initializer_list<T> values) {
    if (values.size() == 0) return af::array{};
    return af::array(static_cast<dim_t>(values.size()), values.begin(), afHost);
}
template<class T>
std::vector<T> download(const af::array& values) {
    std::vector<T> result(static_cast<std::size_t>(values.elements()));
    if (!result.empty()) values.host(result.data());
    return result;
}

int main(int argc, char** argv) {
    try {
#if RADAR_ARRAYFIRE_UNIFIED
        if (argc > 1) chooseBackend(argv[1]);
#else
        (void)argv;
        if (argc > 1) throw std::invalid_argument("direct-backend tests take no backend argument");
#endif
        af::info();
        test::run("explicit dimension getters preserve semantic axes", [] {
            const auto raw = SamplePulseBuffer::zeros(11, 7, 3, makeMetadata());
            const auto sampleSlice = raw.sliceSamples(2, 5);
            test::check(sampleSlice.getSampleCount() == 5, "sample slice changes sample count");
            test::check(sampleSlice.getPulseCount() == 7, "sample slice preserves pulse count");
            test::check(sampleSlice.getElementCount() == 3, "sample slice preserves elements");
            const auto pulseSlice = raw.slicePulses(1, 3);
            test::check(pulseSlice.getSampleCount() == 11 && pulseSlice.getPulseCount() == 3,
                        "pulse slice changes only pulse count");
            const RangePulseBuffer ranges(raw, af::constant(0, af::dim4(9, 7, 3), c32), {100, 5});
            const auto rangeSlice = ranges.sliceRanges(2, 4);
            test::check(rangeSlice.getRangeBinCount() == 4, "range slice updates range bins");
            test::check(rangeSlice.getPulseCount() == 7 && rangeSlice.getElementCount() == 3,
                        "range slice preserves pulses and elements");
            const RangeDopplerMap map(ranges, af::constant(0, af::dim4(8, 9, 3), c32));
            test::check(map.getDopplerBinCount() == 8, "padded Doppler count is FFT output length");
            test::check(map.getRangeBinCount() == 9 && map.getElementCount() == 3,
                        "Doppler-first layout retains range and element meaning");
            test::check(map.getDopplerAxis().getPulsesUsed() == 7, "pulse count is not padded FFT count");
            const auto croppedMap = map.sliceRanges(2, 4);
            test::check(croppedMap.getRangeBinCount() == 4 && croppedMap.getDopplerBinCount() == 8,
                        "map crop updates range count, not Doppler count");
            test::check(croppedMap.getLinearIndex(1, 2, 1) == 2 + 8 * (1 + 4),
                        "logical offset uses the named Doppler/range/element counts");
        });
        test::run("raw upload, column-major indexing, singleton axes", [] {
            const auto input = numbered(8, 4, 2);
            const auto raw = SamplePulseBuffer::fromHost(input, 8, 4, 2, makeMetadata());
            test::check(raw.getSampleCount() == 8 && raw.getPulseCount() == 4 && raw.getElementCount() == 2, "raw dimensions");
            test::check(raw.getBytes() == input.size() * 8, "c32 bytes");
            test::check(raw.getElementCount() == 2 && raw.getData().elements() == 64,
                        "hardware element count differs from total IQ values");
            const af::array firstElement = raw.getElement(0);
            test::check(firstElement.dims(0) == 8 && firstElement.dims(1) == 4 && firstElement.dims(2) == 1,
                        "element slice preserves sample/pulse axes");
            const auto downloaded = raw.toHost();
            for (std::size_t i = 0; i < input.size(); ++i) complexNear(downloaded[i], input[i]);
            test::check(raw.getLinearIndex(3, 2, 1) == 3 + 8 * (2 + 4), "raw offset");
            complexNear(host(raw.getPulse(2, 1))[3], {123, -123});
            const auto singleton = SamplePulseBuffer::zeros(8, 1, 1, makeMetadata());
            test::check(singleton.getPulseCount() == 1 && singleton.getElementCount() == 1, "singleton axes accepted");
        });
        test::run("copy-on-write, explicit clone, and replacement", [] {
            const auto raw = SamplePulseBuffer::zeros(8, 4, 2, makeMetadata());
            af::array modified = raw.getData();
            modified(0, 0, 0) = af::cfloat(9, 2);
            complexNear(raw.toHost().at(0), {0, 0});
            const auto replacement = raw.withData(std::move(modified));
            complexNear(replacement.toHost().at(0), {9, 2});
            complexNear(replacement.clone().toHost().at(0), {9, 2});
        });
        test::run("slices update sample timing and CPI start", [] {
            const auto raw = SamplePulseBuffer::fromHost(numbered(8, 4, 2), 8, 4, 2, makeMetadata());
            const auto samples = raw.sliceSamples(2, 3);
            test::near(samples.getMetadata().getFirstSampleDelaySeconds(), 1.2e-6);
            complexNear(samples.toHost().at(0), {2, -2});
            const auto pulses = raw.slicePulses(1, 2);
            test::near(pulses.getMetadata().getFirstPulseTimeSeconds(), 10.0005);
            complexNear(pulses.toHost().at(0), {10, -10});
        });
        test::run("matched-filter result adoption permits range-length changes", [] {
            const auto raw = SamplePulseBuffer::zeros(8, 4, 2, makeMetadata());
            const RangePulseBuffer ranges(raw, af::constant(0, af::dim4(6, 4, 2), c32), {100, 5});
            test::check(ranges.getRangeBinCount() == 6, "MF may change range length");
            test::near(ranges.sliceRanges(2, 3).getRangeMeters(0), 110);
        });
        test::run("explicit reorder retains every element without conjugating", [] {
            const auto values = numbered(8, 4, 2);
            const RangePulseBuffer ranges(af::array(af::dim4(8, 4, 2), values.data()), makeMetadata(), {100, 5});
            const auto input = ranges.getDopplerInput();
            test::check(input.dims(0) == 4 && input.dims(1) == 8, "pulse-first layout");
            const auto reordered = host(input);
            for (dim_t elementIndex = 0; elementIndex < 2; ++elementIndex)
                for (dim_t r = 0; r < 8; ++r)
                    for (dim_t p = 0; p < 4; ++p)
                        complexNear(reordered[static_cast<std::size_t>(p + 4 * (r + 8 * elementIndex))],
                                    values[static_cast<std::size_t>(r + 8 * (p + 4 * elementIndex))]);
        });
        test::run("batched FFT actually transforms pulses and supports padding", [] {
            const RangePulseBuffer ranges(af::constant(1, af::dim4(8, 4, 2), c32), makeMetadata(), {100, 5});
            const RangeDopplerMap map(ranges, af::fft(ranges.getDopplerInput()));
            test::check(map.getDopplerBinCount() == 4 && map.getRangeBinCount() == 8, "map layout");
            const auto spectrum = host(map.getDopplerSpectrum(0, 0));
            complexNear(spectrum[0], {4, 0});
            for (std::size_t i = 1; i < spectrum.size(); ++i) complexNear(spectrum[i], {0, 0});
            const RangeDopplerMap padded(ranges, af::fft(ranges.getDopplerInput(), 8));
            test::check(padded.getDopplerAxis().getPulsesUsed() == 4, "preserve original pulse count");
            test::near(padded.getDopplerAxis().getBinSpacingHz(), 250);
        });
        test::run("odd/even fftshift modifies both samples and metadata", [] {
            for (const dim_t n : {dim_t{4}, dim_t{5}}) {
                const auto values = numbered(n, 2, 2);
                const RangeDopplerMap original(af::array(af::dim4(n, 2, 2), values.data()), makeMetadata(),
                                              {100, 5}, {n, n, 2000});
                const auto centered = original.withDopplerOrder(DopplerOrder::Centered);
                const auto shifted = centered.toHost();
                for (dim_t i = 0; i < n; ++i) {
                    const dim_t oldIndex = (i + n - n / 2) % n;
                    complexNear(shifted[static_cast<std::size_t>(i)], values[static_cast<std::size_t>(oldIndex)]);
                    test::near(centered.getDopplerHz(i), original.getDopplerHz(oldIndex));
                }
                const auto restored = centered.withDopplerOrder(DopplerOrder::Unshifted).toHost();
                for (std::size_t i = 0; i < values.size(); ++i) complexNear(restored[i], values[i]);
            }
        });
        test::run("device detections gather IQ and preserve element phase", [] {
            const auto values = numbered(4, 8, 2);
            const RangeDopplerMap map(af::array(af::dim4(4, 8, 2), values.data()), makeMetadata(),
                                      {100, 5}, {4, 4, 2000});
            const auto list = DetectionList::fromMap(map, upload<unsigned>({13, 22}),
                upload<float>({100, 50}), upload<float>({1, 2}));
            test::check(list.getDetectionCount() == 2 && list.getElementCount() == 2, "list sizes");
            test::check(list.getRangeBins().type() == u32 && list.getPowers().type() == f32, "typed columns");
            test::check(list.getElementSnapshots().dims(0) == 2 &&
                        list.getElementSnapshots().dims(1) == 2, "snapshot layout");
            const auto snapshots = list.snapshotsToHost();
            complexNear(snapshots[0], {31, -31}); complexNear(snapshots[1], {131, -131});
            complexNear(snapshots[2], {52, -52}); complexNear(snapshots[3], {152, -152});
            const auto records = list.recordsToHost();
            test::near(records[0].getRangeMeters(), 115);
            test::near(records[1].getDopplerHz(), -1000);
            test::check(download<unsigned>(list.getRangeBins()) == std::vector<unsigned>({3, 5}), "integer range decode");
            test::check(download<unsigned>(list.getDopplerBins()) == std::vector<unsigned>({1, 2}), "integer Doppler decode");
            test::near(download<float>(list.getRangesMeters())[0], 115, 1e-5);
            test::near(download<float>(list.getDopplerHz())[1], -1000, 1e-5);
            test::near(download<float>(list.getRadialVelocitiesMps())[1], records[1].getRadialVelocityMps(), 1e-5);
            test::near(download<float>(list.getSnrDb())[0], 20, 1e-5);
            const auto selected = list.select(upload<unsigned>({1, 0, 1}));
            test::check(selected.getDetectionCount() == 3, "selection permits duplicate indices");
            test::check(download<unsigned>(selected.getRangeBins()) == std::vector<unsigned>({5, 3, 5}), "selection alignment");
            complexNear(selected.snapshotsToHost()[0], {52, -52});
            complexNear(list.clone().snapshotsToHost()[3], {152, -152});
            const auto one = list.getDetection(1);
            test::check(one.getDetectionCount() == 1 && one.getRangeBins().type() == u32, "single record stays on device");
            test::check(af::getBackendId(one.getRangeBins()) == af::getBackendId(map.getData()), "same backend");
            test::check(af::getDeviceId(one.getElementSnapshots()) == af::getDeviceId(map.getData()), "same device");
            const auto slicedList = DetectionList::fromMap(map.sliceRanges(2, 4), upload<unsigned>({5}),
                upload<float>({100}), upload<float>({1}));
            complexNear(slicedList.snapshotsToHost()[1], {131, -131});
            test::near(slicedList.recordsToHost()[0].getRangeMeters(), 115);
            // A detached constructor can use already gathered results without retaining map.
            const DetectionList adopted(map.getDetectionContext(), list.getRangeBins(), list.getDopplerBins(),
                list.getPowers(), list.getNoisePowers(), list.getElementSnapshots());
            test::near(adopted.recordsToHost()[0].getRangeMeters(), 115);
        });
        test::run("empty detections, angles, and singleton element gather", [] {
            const RangeDopplerMap map(af::constant(0, af::dim4(4, 8, 1), c32), makeMetadata(),
                                      {100, 5}, {4, 4, 2000});
            const auto empty = DetectionList::fromMap(map, {}, {}, {});
            test::check(empty.getIsEmpty() && empty.getSnapshotBytes() == 0, "empty storage");
            test::check(empty.clone().getIsEmpty() && empty.select(af::array{}).getIsEmpty(), "empty operations");
            test::check(empty.getDopplerHz().isempty() && empty.recordsToHost().empty(), "empty derived outputs");
            empty.synchronize();
            const AzElDetectionList emptyAngles(empty, {}, {});
            test::check(emptyAngles.getPositionsMeters().isempty() && emptyAngles.recordsToHost().empty(), "empty angles");
            auto list = DetectionList::fromMap(map, upload<unsigned>({0, 4}),
                upload<float>({1, 1}), upload<float>({1, 1}));
            test::check(list.getElementSnapshots().dims(0) == 1 && list.getElementSnapshots().dims(1) == 2,
                        "singleton element dimension is not detection dimension");
            const AzElDetectionList located(std::move(list), upload<float>({0, static_cast<float>(pi/2)}),
                                           upload<float>({0, 0}));
            const auto xyz = download<float>(located.getPositionsMeters());
            test::check(located.getPositionsMeters().dims(0) == 3 && located.getPositionsMeters().dims(1) == 2,
                        "xyz shape is [3,detection]");
            test::near(xyz[0], 100, 1e-5); test::near(xyz[4], 105, 1e-5);
            test::near(located.recordsToHost()[0].getPositionMeters()[0], 100, 1e-5);
            test::near(download<float>(located.select(upload<unsigned>({1})).getPositionMeters(0))[1], 105, 1e-5);
            test::check(located.clone().getDetectionCount() == 2, "angle clone");
            // Float endpoints are exported as-is, with float precision.
            const AzElDetectionList endpoints(located.getDetections(), upload<float>({static_cast<float>(pi), -static_cast<float>(pi)}),
                upload<float>({static_cast<float>(pi/2), -static_cast<float>(pi/2)}));
            test::near(endpoints.recordsToHost()[0].getAngles().getAzimuthRadians(), pi, 1e-6);
            test::near(endpoints.recordsToHost()[1].getAngles().getElevationRadians(), -pi/2, 1e-6);
        });
        test::run("device column storage and power setter", [] {
            const RangeDopplerMap map(af::constant(1, af::dim4(4, 8, 2), c32), makeMetadata(),
                                      {100, 5}, {4, 4, 2000});
            auto list = DetectionList::fromMap(map, upload<unsigned>({0}), upload<float>({1}), upload<float>({1}));
            test::near(list.recordsToHost()[0].getCell().getPower(), 1); // Not partially committed.
            list.setPowers(upload<float>({0}), upload<float>({2}));
            test::check(std::isinf(download<float>(list.getSnrDb())[0]) && download<float>(list.getSnrDb())[0] < 0,
                        "zero power is valid negative-infinite cell/noise dB");
            // No out-of-range value tests: scanning GPU indices is deliberately not a constructor task.
        });
        test::run("device coordinate columns respect centered odd/even Doppler order", [] {
            for (const dim_t count : {dim_t{4}, dim_t{5}}) {
                const RangeDopplerMap unshifted(af::constant(1, af::dim4(count, 2, 1), c32),
                    makeMetadata(), {100, 5}, {count, count, 2000});
                for (const auto order : {DopplerOrder::Unshifted, DopplerOrder::Centered}) {
                    const auto map = unshifted.withDopplerOrder(order);
                    const af::array cells = af::range(af::dim4(count), 0, u32);
                    const auto list = DetectionList::fromMap(map, cells, af::constant(1.0f, count, f32),
                        af::constant(1.0f, count, f32));
                    const auto hz = download<float>(list.getDopplerHz());
                    for (dim_t i = 0; i < count; ++i)
                        test::near(hz[static_cast<std::size_t>(i)], map.getDopplerHz(i), 1e-5);
                }
            }
        });
        test::run("large detection indices never round through f32", [] {
            // Only two detections: large context does not allocate a large cube.
            const DetectionContext context(makeMetadata(), {0, 1}, {4, 4, 2000}, 20000000, 1);
            const DetectionList list(context, upload<unsigned>({16777217u, 16777219u}), upload<unsigned>({1, 2}),
                upload<float>({1, 1}), upload<float>({1, 1}), af::constant(0, af::dim4(1, 2), c32));
            const auto records = list.recordsToHost();
            test::check(records[0].getCell().getRangeBin() == 16777217, "u32 bin survives above f32 integer precision");
            test::check(records[1].getCell().getRangeBin() == 16777219, "second u32 bin survives");
        });
        test::run("same-shape setters update buffers", [] {
            auto raw = SamplePulseBuffer::zeros(8, 4, 2, makeMetadata());
            raw.setData(af::constant(2, raw.getDimensions(), c32));
            complexNear(raw.toHost()[0], {2, 0});
            test::check(raw.getSampleCount() == 8 && raw.getBytes() == 8 * 4 * 2 * 8, "cached shape preserved");
            complexNear(raw.toHost()[0], {2, 0});
            auto m = makeMetadata(); m.setElementNames({"a"});
            test::check(raw.getMetadata().getElementNames().empty(), "failed metadata replacement preserves labels");
            m.setElementNames({"a", "b"}); raw.setMetadata(m);
            test::check(raw.getMetadata().getElementNames().size() == 2, "matching labels accepted");
            RangePulseBuffer ranges(raw, raw.getData(), {100, 5});
            ranges.setRangeAxis({200, 10}); test::near(ranges.getRangeMeters(3), 230);
            RangeDopplerMap map(ranges, af::fft(ranges.getDopplerInput()));
            auto invalid = map.getMetadata(); invalid.setPrfHz(1000);
            test::near(map.getMetadata().getPrfHz(), 2000);
            map.setDopplerOrder(DopplerOrder::Centered);
            test::check(map.getDopplerAxis().getOrder() == DopplerOrder::Centered, "setter updates order");
            test::check(map.getDopplerAxis().getOrder() == DopplerOrder::Centered, "invalid order not committed");
            auto detections = DetectionList::fromMap(map, upload<unsigned>({0}), upload<float>({1}), upload<float>({1}));
            detections.setElementSnapshots(af::constant(7, af::dim4(2, 1), c32));
            complexNear(detections.snapshotsToHost()[0], {7, 0});
            AzElDetectionList angles(std::move(detections), upload<float>({0}), upload<float>({0}));
            angles.setAngles(upload<float>({static_cast<float>(pi/6)}), upload<float>({static_cast<float>(pi/18)}));
            test::near(angles.recordsToHost()[0].getAngles().getAzimuthRadians(), pi / 6, 1e-5);
            test::check(angles.getDetectionCount() == 1, "failed angle replacement preserves list");
        });
        af::sync();
        std::cout << "All " << test::checks << " ArrayFire checks passed.\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "FAIL: " << error.what() << '\n';
        return 1;
    }
}
