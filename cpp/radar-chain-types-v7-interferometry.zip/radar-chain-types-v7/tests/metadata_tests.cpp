#include <radar/metadata.hpp>
#include "test_support.hpp"
#include <type_traits>

using namespace radar;

CPI_Metadata makeMetadata() { return {10e6, 2000.0, 10e9, 42}; }

// Encapsulated, nonvirtual value classes; numeric records remain trivially copyable.
static_assert(!std::is_default_constructible_v<CPI_Metadata>);
static_assert(!std::is_default_constructible_v<RangeAxis>);
static_assert(!std::is_default_constructible_v<DopplerAxis>);
static_assert(!std::is_aggregate_v<CPI_Metadata> && !std::is_polymorphic_v<CPI_Metadata>);
static_assert(!std::is_aggregate_v<RangeAxis> && std::is_trivially_copyable_v<RangeAxis>);
static_assert(!std::is_aggregate_v<DopplerAxis> && std::is_trivially_copyable_v<DopplerAxis>);
static_assert(!std::is_aggregate_v<DetectionCell> && std::is_trivially_copyable_v<DetectionCell>);
static_assert(!std::is_aggregate_v<Detection> && std::is_trivially_copyable_v<Detection>);
static_assert(!std::is_aggregate_v<DetectionContext> && !std::is_polymorphic_v<DetectionContext>);
static_assert(!std::is_aggregate_v<AngleEstimate> && std::is_trivially_copyable_v<AngleEstimate>);
static_assert(!std::is_aggregate_v<AzElDetection> && std::is_trivially_copyable_v<AzElDetection>);
static_assert(noexcept(std::declval<const CPI_Metadata&>().getRadialVelocityMps(0)));
static_assert(noexcept(std::declval<const CPI_Metadata&>().getElementNames()));
static_assert(noexcept(std::declval<const DetectionContext&>().getElementCount()));
static_assert(std::is_same_v<decltype(std::declval<const CPI_Metadata&>().getElementNames()),
                             const std::vector<std::string>&>);
static_assert(noexcept(std::declval<const RangeAxis&>().getMeters(0)));
static_assert(noexcept(std::declval<const DopplerAxis&>().getHertz(0)));
static_assert(noexcept(std::declval<const Detection&>().getSnrDb()));
static_assert(noexcept(std::declval<const AzElDetection&>().getPositionMeters()));

int main() {
    try {
        test::run("explicit get/set names and semantic metadata counts", [] {
            auto m = makeMetadata();
            m.setCpiId(99);
            test::check(m.getCpiId() == 99, "get/set CPI ID pair");
            m.setElementNames({"left", "center", "right"});
            test::check(m.getElementNames().size() == 3, "get/set element-name pair");
            const DetectionContext context(m, {100, 5}, {16, 7, 2000}, 9, 3);
            test::check(context.getRangeBinCount() == 9, "range bin count");
            test::check(context.getElementCount() == 3, "hardware element count");
            test::check(context.getDopplerAxis().getFftSize() == 16, "padded Doppler FFT size");
            test::check(context.getDopplerAxis().getPulsesUsed() == 7, "physical pulse count");
            const auto record = context.makeDetection({2, 3, 10, 2});
            test::check(record.getCell().getRangeBin() == 2, "getters retain cell indices");
            test::near(record.getRangeMeters(), 110);
        });
        test::run("CPI constructor initialization and access", [] {
            const auto m = makeMetadata();
            test::check(m.getCpiId() == 42, "CPI ID");
            test::near(m.getSampleRateHz(), 10e6);
            test::near(m.getPrfHz(), 2000);
            test::near(m.getCarrierFrequencyHz(), 10e9);
            test::near(m.getSamplePeriodSeconds(), 1e-7);
            test::near(m.getPulsePeriodSeconds(), 0.0005);
            test::near(m.getWavelengthMeters(), speedOfLightMps / 10e9);
        });
        test::run("CPI setters update caches", [] {
            auto m = makeMetadata();
            m.setSampleRateHz(20e6); test::near(m.getSamplePeriodSeconds(), 5e-8);
            m.setPrfHz(1000); test::near(m.getPulsePeriodSeconds(), 0.001);
            m.setCarrierFrequencyHz(5e9); test::near(m.getWavelengthMeters(), speedOfLightMps / 5e9);
            test::near(m.getRadialVelocityMps(1000), -29.9792458);
            m.setPositiveDoppler(PositiveDoppler::Receding);
            test::near(m.getRadialVelocityMps(1000), 29.9792458);
            m.setCpiId(17); test::check(m.getCpiId() == 17, "CPI setter");
            m.setFirstSampleDelaySeconds(2e-6); test::near(m.getFirstSampleDelaySeconds(), 2e-6);
            m.setFirstPulseTimeSeconds(12); test::near(m.getFirstPulseTimeSeconds(), 12);
            m.setWaveformId("chirp"); test::check(m.getWaveformId() == "chirp", "waveform setter");
            m.setElementNames({"left", "right"}); test::check(m.getElementNames().size() == 2, "labels");
            test::near(m.getSampleRateHz(), 20e6); test::near(m.getSamplePeriodSeconds(), 5e-8);
            test::near(m.getPrfHz(), 1000);
            test::near(m.getWavelengthMeters(), speedOfLightMps / 5e9);
            test::near(m.getFirstSampleDelaySeconds(), 2e-6);
            test::near(m.getFirstPulseTimeSeconds(), 12);
            test::near(m.getRadialVelocityMps(1000), 29.9792458);
        });
        test::run("element naming and detached context propagation", [] {
            auto m = makeMetadata();
            test::check(m.getElementNames().empty(), "element labels are optional");
            m.setElementNames({"element0", "element1", "element2", "element3", "element4"});
            test::check(m.getElementNames().size() == 5, "five element labels");
            test::check(m.getElementNames()[4] == "element4", "element label order preserved");
            const DetectionContext context(m, {100, 5}, {8, 8, 2000}, 64, 5);
            test::check(context.getElementCount() == 5, "hardware element count");
            test::check(context.getMetadata().getElementNames() == m.getElementNames(), "context retains element names");
            m.setElementNames({});
            const DetectionContext unlabeled(m, {100, 5}, {8, 8, 2000}, 64, 5);
            test::check(unlabeled.getElementCount() == 5, "hardware count does not depend on labels");
        });
        test::run("range timing and axis setters", [] {
            auto axis = RangeAxis::fromRoundTripTiming(1e-6, 10e6);
            test::near(axis.getFirstBinMeters(), 149.896229);
            test::near(axis.getBinSpacingMeters(), 14.9896229);
            test::near(axis.getMeters(4), axis.getFirstBinMeters() + 4 * axis.getBinSpacingMeters());
            test::near(axis.sliced(4).getMeters(0), axis.getMeters(4));
            test::near(RangeAxis{-10, 2}.getMeters(5), 0);
            axis.setFirstBinMeters(100); axis.setBinSpacingMeters(5);
            test::near(axis.getMeters(3), 115);
            test::near(axis.getMeters(3), 115);
        });
        test::run("even/odd/singleton Doppler ordering", [] {
            for (const BinIndex n : {BinIndex{4}, BinIndex{5}, BinIndex{1}}) {
                const DopplerAxis u{n, n, 2000, DopplerOrder::Unshifted};
                const DopplerAxis c{n, n, 2000, DopplerOrder::Centered};
                for (BinIndex i = 0; i < n; ++i) {
                    const auto expected = i <= (n - 1) / 2 ? i : i - n;
                    test::near(u.getHertz(i), static_cast<double>(expected) * 2000.0 / static_cast<double>(n));
                    test::near(c.getHertz(i), static_cast<double>(i - n / 2) * 2000.0 / static_cast<double>(n));
                }
            }
        });
        test::run("zero padding and Doppler setter values", [] {
            auto axis = DopplerAxis{16, 8, 2000};
            test::near(axis.getBinSpacingHz(), 125);
            test::near(axis.getCoherentIntervalSeconds(), 0.004);
            test::check(axis.getFftSize() == 16, "FFT size retains value");
            test::check(axis.getPulsesUsed() == 8, "pulse count retains value");
            axis.setFftSize(32); test::near(axis.getBinSpacingHz(), 62.5);
            axis.setPulsesUsed(16); test::near(axis.getCoherentIntervalSeconds(), 0.008);
            axis.setPrfHz(4000); test::near(axis.getBinSpacingHz(), 125);
            test::near(axis.getCoherentIntervalSeconds(), 0.004);
            axis.setOrder(DopplerOrder::Centered); test::near(axis.getHertz(16), 0);
            test::check(axis.getOrder() == DopplerOrder::Centered, "failed order setter must preserve axis");
        });
        test::run("DetectionCell values and setters", [] {
            DetectionCell cell(2, 3, 10, 2);
            test::check(cell.getRangeBin() == 2 && cell.getDopplerBin() == 3, "cell bins");
            cell.setRangeBin(5); cell.setDopplerBin(1); cell.setPower(100); cell.setNoisePower(4);
            test::check(cell.getRangeBin() == 5 && cell.getDopplerBin() == 1, "cell setters");
            test::near(cell.getPower(), 100); test::near(cell.getNoisePower(), 4);
            test::check(cell.getRangeBin() == 5 && cell.getDopplerBin() == 1, "failed setters preserve bins");
            test::near(cell.getPower(), 100); test::near(cell.getNoisePower(), 4);
        });
        test::run("detection coordinate conversion", [] {
            const DetectionContext context{makeMetadata(), {100, 5}, {4, 4, 2000}, 10, 5};
            const auto d = context.makeDetection({3, 1, 100, 1});
            test::near(d.getRangeMeters(), 115); test::near(d.getDopplerHz(), 500);
            test::near(d.getRadialVelocityMps(), -7.49481145); test::near(d.getSnrDb(), 20);
            const auto zero = context.makeDetection({0, 0, 0, 1});
            test::check(std::isinf(zero.getSnrDb()) && zero.getSnrDb() < 0, "zero power gives -inf");
            const DetectionContext negative{makeMetadata(), {-1, 5}, {4, 4, 2000}, 10, 5};
            auto labeled = makeMetadata(); labeled.setElementNames({"a", "b"});
            const DetectionContext ok(labeled, {0, 5}, {4, 4, 2000}, 10, 2);
            test::check(ok.getElementCount() == 2, "matching labels accepted");
        });
        test::run("angles, Cartesian coordinates, and setter values", [] {
            const Detection d(DetectionCell{}, 100, 0, 0);
            auto p = AzElDetection(d, AngleEstimate::fromDegrees(0, 0)).getPositionMeters();
            test::near(p[0], 100); test::near(p[1], 0); test::near(p[2], 0);
            p = AzElDetection(d, AngleEstimate::fromDegrees(90, 0)).getPositionMeters();
            test::near(p[0], 0); test::near(p[1], 100); test::near(p[2], 0);
            p = AzElDetection(d, AngleEstimate::fromDegrees(0, 90)).getPositionMeters();
            test::near(p[0], 0); test::near(p[1], 0); test::near(p[2], 100);
            AngleEstimate angles;
            angles.setAzimuthRadians(0.5); angles.setElevationRadians(0.25);
            test::near(angles.getAzimuthRadians(), 0.5); test::near(angles.getElevationRadians(), 0.25);
        });
        std::cout << "All " << test::checks << " metadata checks passed.\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "FAIL: " << error.what() << '\n';
        return 1;
    }
}
