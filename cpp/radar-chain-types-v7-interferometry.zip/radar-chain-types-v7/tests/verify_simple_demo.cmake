# Execute the actual linked executable, not a mock or a declaration-only build.
cmake_minimum_required(VERSION 3.20)
if(NOT DEFINED PROGRAM OR NOT EXISTS "${PROGRAM}")
    message(FATAL_ERROR "Pass -DPROGRAM=/absolute/path/to/radar_simple_demo")
endif()
set(arguments)
if(DEFINED BACKEND AND NOT BACKEND STREQUAL "")
    list(APPEND arguments "${BACKEND}")
endif()
execute_process(
    COMMAND "${PROGRAM}" ${arguments}
    RESULT_VARIABLE result OUTPUT_VARIABLE output ERROR_VARIABLE errors
    TIMEOUT 120)
message("${output}")
if(NOT errors STREQUAL "")
    message("${errors}")
endif()
# Check the process status explicitly. A success-looking line must never hide a crash.
if(NOT "${result}" STREQUAL "0")
    message(FATAL_ERROR "radar_simple_demo failed (result: ${result})")
endif()
string(REPLACE "\r\n" "\n" output "${output}")
string(REPLACE "\n" ";" lines "${output}")
list(FIND lines "Fake chain produced 1 detection(s)." count_line)
list(FIND lines "range bin=0, Doppler bin=0, power=12" cell_line)
if(count_line EQUAL -1 OR cell_line EQUAL -1)
    message(FATAL_ERROR "Unexpected demo result: expected exactly the one-cell demo output with power 12")
endif()
message(STATUS "Demo output and exit status verified.")
