# Radar chain types + interferometry — v0.7

C++20, ArrayFire **3.10+**, private class members, `get`/`set` accessors, semantic
dimension names, and element terminology. No Eigen or FFTW dependency in our code.

## Libraries and source layout

```text
include/radar/            # The five types, CPI_Metadata, lightweight value classes
src/                     # Matching implementation files
interferometry/          # SEPARATE LIBRARY: radar::interferometry
    include/radar/interferometry/
        UniformArray.hpp
        Interferometry1D.hpp
        Interferometry2D.hpp
        Interferometry.hpp
    src/                 # GPU-oriented adjacent-baseline estimators
    examples/            # Synthetic 2D phase-center demonstration
    tests/               # Independent scalar math + real ArrayFire tests
examples/simple_demo.cpp # Three FAKE algorithms: sample -> range -> RDM -> detections
examples/pipeline.cpp    # Small reference processing chain, not optimized production DSP
tests/                   # Core metadata + ArrayFire tests
Dockerfile, docker/      # CPU and CUDA build/run targets retained
```

`radar::chain_types` and `radar::interferometry` are separate static targets.
The latter publicly links the former. No duplicated radar type definitions.

## Storage contract

| Type | Storage |
|---|---|
| SamplePulseBuffer | c32 [sample,pulse,element,1] |
| RangePulseBuffer | c32 [range,pulse,element,1] |
| RangeDopplerMap | c32 [Doppler,range,element,1] |
| DetectionList | u32 [K] range/Doppler bins, f32 [K] power/noise, optional c32 [element,K] IQ |
| AzElDetectionList | Original DetectionList + f32 [K] azimuth/elevation radians |

The fourth cube dimension is 1. Dimensions and metadata are host scalars; all
bulk numerical columns use ArrayFire. Hardware element count is `getElementCount()`;
ArrayFire's `array.elements()` means total stored values. For subarray RDMs,
the element dimension enumerates effective phase centers, not each radiator.

## Fast-path contract: NO wrapper validation

The old bounds/dtype/shape/backend/finite-value/overflow/label/PRF validation
routines and throw paths are removed from constructors, setters, getters, and
CPU-export value classes. There is no validation flag, hidden debug assert,
`isfinite` scan, or host scalar reduction in the production wrappers.

Valid shapes, same-device residency, representable sizes/indices, matching axes,
positive metadata rates and aligned columns are now **caller responsibilities**.
A wrong index may produce a wrong result instead of an exception: ArrayFire lookup
can mirror/wrap out-of-range indices. Invalid C++ indexing/overflow can be undefined.
`setData()` is still a SAME-SHAPE replacement contract; it does not check or update
the cached dimensions. Use a constructor for an intentionally changed grid.

Only algorithm/control-flow branches remain, e.g. empty results, Doppler order,
and optional snapshot handling. Interferometry maps zero coherence to NaN on the
device and lets out-of-domain angle math yield NaN. Those are numerical semantics,
not host validation scans. ArrayFire itself still validates its own API calls.
Compile-time C++/SDK guards, installer checksums, and test assertions remain;
none impose per-detection overhead on the runtime path.

A wrapper does not intentionally retain its predecessor, but caller-supplied
views or lazy expressions may still keep an underlying parent allocation alive.
ArrayFire handle copying does not guarantee immediate release of a source buffer.

No constructor fences the GPU or downloads numerical data. `evaluate()` requests
execution; `synchronize()` is an explicit fence. `toHost()`, `recordsToHost()`,
and `snapshotsToHost()` are explicit transfers. `clone()` explicitly deep-copies;
ordinary wrapper copies retain ArrayFire handles and copy small host metadata.
Do not mutate an aliased ArrayFire handle's shape/device behind the wrapper.

## Low-memory detection choice

```cpp
// No snapshot gather or retained IQ. Cells/power/noise are already on device.
auto detections = radar::DetectionList::fromCells(map, cells, powers, noisePowers);

// Existing path: also gather and retain [element,K] coherent IQ.
auto withIq = radar::DetectionList::fromMap(map, cells, powers, noisePowers);
```

`cells` are u32 indices into [Doppler,range]: `doppler + DopplerCount*range`.
The linear plane must fit the u32 representation. `fromCells()` uses integer
arithmetic for decoding; it does not round indices through f32. Separate bin
columns can also be adopted directly without snapshots.

`getHasElementSnapshots()` is a cached flag. Empty optional snapshots propagate
through select/clone/single-detection extraction. An IQ getter requires snapshots
to exist. `setElementSnapshots({})` releases that list's reference to optional IQ.
An angle result preserves the ORIGINAL DetectionList context and optional IQ,
not a second copy of the phase-center cube. Detection-map and angle-map element
counts may differ; range/Doppler cell grids and CPI identity must still match.

## Interferometry

See [interferometry/README.md](interferometry/README.md) for the geometry, signal
model, sign convention, aliasing limits, three input paths, and memory contracts.
The code implements real phase estimation, unlike the three-algorithm fake demo.

```cpp
#include <radar/interferometry/Interferometry.hpp>
using namespace radar::interferometry;

const double wavelength = phaseCenteredRdm.getMetadata().getWavelengthMeters();
const Interferometry2D estimator(
    UniformRectangularArray(4, 3, wavelength/2.0, wavelength/2.0));
radar::AzElDetectionList output = estimator.estimate(phaseCenteredRdm, detections);
```

Create estimator configuration once and reuse it. Inputs are const references;
outputs are returned by value. The default detection batch size is 4096.

## Build and run

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DRADAR_TEST_BACKEND=cpu
cmake --build build --parallel
ctest --test-dir build --output-on-failure
./build/radar_simple_demo cpu
./build/radar_interferometry_demo cpu
```

For the user's Windows CUDA installation:

```powershell
cmake -S . -B build -A x64 -DCMAKE_PREFIX_PATH="$env:AF_PATH" -DRADAR_TEST_BACKEND=cuda
cmake --build build --config Release --parallel
ctest --test-dir build -C Release --output-on-failure
.\build\Release\radar_interferometry_demo.exe cuda
```

The new demo's expected output is azimuth 20 degrees, elevation 10 degrees;
this is expected arithmetic, NOT captured GPU output in this archive.

From a parent CMake project:

```cmake
add_subdirectory(path/to/radar-chain-types-v7)
target_link_libraries(your_target PRIVATE radar::interferometry)
```

Disable the second library with `-DRADAR_BUILD_INTERFEROMETRY=OFF`. The directly
linked backends remain `CPU`, `CUDA`, `OPENCL`; the default is `UNIFIED`.
With a direct backend, use no executable backend argument and leave
`RADAR_TEST_BACKEND` empty. No implicit CPU fallback is requested for CUDA tests.

Metadata/reference-only tests without ArrayFire:

```sh
cmake -S . -B build-metadata -DRADAR_BUILD_ARRAYFIRE_TYPES=OFF
cmake --build build-metadata --parallel
ctest --test-dir build-metadata --output-on-failure
```

Docker instructions are in [CONTAINER.md](CONTAINER.md). Tests/checksums are
build/test operations, not repeated per-stage runtime validation.
See [VALIDATION.md](VALIDATION.md) for executed tests and the real-SDK limitation.
