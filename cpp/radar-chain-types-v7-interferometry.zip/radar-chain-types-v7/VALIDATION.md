# Validation report — v0.7

## Executed on this revision

The metadata and independent phase-model tests were compiled and run as C++20:

| Test | GCC 14.2 | Clang 17 | GCC ASan + UBSan |
|---|---:|---:|---:|
| Metadata/value classes | 99 passed | 99 passed | 99 passed |
| Independent interferometry math | 600 passed | 600 passed | 600 passed |

Release compiles used `-O2 -Wall -Wextra -Wpedantic -Werror`. The sanitizer
configuration used `-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer`,
leak detection, and halt-on-error. No sanitizer errors were reported.
The CMake Release metadata/reference-only build and both registered CTests passed.

The metadata count is smaller than v0.6 because tests expecting runtime rejection
were removed together with the requested runtime validators. Invalid inputs are
now precondition violations; getters/setters are not tested for throwing.

The independent reference tests generate far-field phases and recover angles
using a separate scalar `std::complex<double>` implementation. They cover signs,
1D known elevation, 2D cross-axis coupling, rectangular layouts, unequal spacings,
positive nonuniform gains, common phase, known subarray phase re-referencing,
long-baseline ambiguity, zero correlation and invalid direction cosines.
They exercise production geometry value classes but **NOT ArrayFire estimator
kernels**, single-precision device behavior, memory allocation, or GPU speed.

Actual logs: `validation/compiler-tests.txt`, `validation/sanitizers.txt`, and
`validation/metadata-{configure,build,ctest}.txt`. All logs describe this revision;
old validation logs are not carried forward.

## Source audit and limited syntax checks

Clang AST inspection found **17 repository-defined classes and 83 fields, all
private**. The production source has no old validation routines, runtime throw
paths, assertions, structs, or numbered dimension members. The interferometry
sources contain no explicit `host()`, `scalar()`, `sync()`, or `where()` calls.

All five core implementations, the new two implementations, all three examples,
and both ArrayFire test sources passed GCC and Clang C++20 `-fsyntax-only -Werror`
using an **isolated declaration-only ArrayFire aid**. It only checks the project's
own declarations and C++ consistency; it does not verify actual ArrayFire
headers, proxy semantics, overloads, ABI, linking, or execution. The aid was not
executed and is not in the delivered repository or any normal build path.

Logs: `validation/source-audit.txt`, `validation/syntax-only.txt`.
Four Docker shell scripts also passed `bash -n`; this is syntax checking, not
execution of the installers or Dockerfile (`validation/shell-syntax.txt`).

## Real SDK attempt and remaining limitation

An actual full configure was attempted for ArrayFire 3.10. It failed because
`ArrayFireConfig.cmake` / an installed SDK is unavailable. The environment also
has no Docker executable/socket or exposed NVIDIA device. The exact configure
failure and environment probe are in `validation/real-sdk-attempt.txt`.

**No real ArrayFire compile/link, CPU/CUDA/OpenCL execution, Docker image build,
Windows/MSVC run, or GPU latency/peak-memory measurement was completed here.**
The library targets ArrayFire 3.10 via its real CMake/API contract, not a substitute
backend. Declaration-only acceptance and the independent mathematical oracle
must not be reported as an actual ArrayFire integration pass.

## Included for your installed SDK, not executed here

The core integration suite covers valid stage transitions, ordering, slices,
FFT/gather, device-resident records, explicit host exports, setters and copies.
New interferometry tests exercise packed maps, separate phase-center RDMs and
pre-gathered snapshots, both phase signs, 1D known elevation, non-square 2D grids,
several batch sizes, reordered/duplicate detections, context preservation when the
detector uses a sum beam, optional IQ, empty results, and zero-coherence NaNs.

The new synthetic 4x3 half-wavelength demo is expected to return azimuth 20 degrees
and elevation 10 degrees. The original fake three-stage main is expected to return
one detection at (0,0) with power 12. These are expected mathematical outputs,
not captured execution logs.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DRADAR_TEST_BACKEND=cpu
cmake --build build --parallel
ctest --test-dir build --output-on-failure
./build/radar_interferometry_demo cpu
```

Use CUDA and your ArrayFire installation path as described in README.md.
The retained container recipes run CPU tests during image construction, then the
requested CPU/CUDA tests at runtime. They remain unexecuted in this environment.
