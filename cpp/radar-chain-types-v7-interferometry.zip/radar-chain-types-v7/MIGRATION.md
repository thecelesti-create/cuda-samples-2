# Migration from v0.6 to v0.7

## Runtime validation removed

Constructors/setters now adopt their inputs without shape, dtype, finite-value,
label, PRF, backend/device or overflow validation. The old validation helper header
is removed, not disabled by a macro. Invalid-input rejection tests were removed;
correctness tests remain. `setData` still assumes an identical shape. Do not
misinterpret the lack of a throw as permission to change metadata/grid contracts.
ArrayFire itself retains its own API behavior/checks. Compile-time C++20 and
ArrayFire 3.10 guards remain. No `-ffast-math` flag was introduced.

## Optional detection IQ

Existing `DetectionList::fromMap` continues to gather IQ. New `fromCells` takes
the same arguments but only creates bin/power/noise columns. Direct adoption
constructors now default the snapshots argument to an empty array.
`getHasElementSnapshots()` identifies available IQ without querying the backend.
`setElementSnapshots({})` releases optional IQ; select/clone/getDetection preserve
its absence. IQ getters require it to exist.

CPU `AngleEstimate` no longer rejects nonfinite values. NaN can now represent an
undefined phase estimate. CPU exports preserve f32 angular endpoints as-is,
rather than doing special endpoint clamping.

## Separate interferometry target

The new top-level `interferometry/` folder builds `radar::interferometry` and uses
the existing radar types as its API. Link that target to get both libraries.
Disable with `RADAR_BUILD_INTERFEROMETRY=OFF` to build only the core.
Read its README before setting phase sign, phase-center spacings, elevation prior,
removed steering references, and 2D element order. The implementation assumes
uniform line/rectangular geometry, calibrated far-field IQ and an unambiguous
principal phase branch; it is not a generic arbitrary-array estimator.

## Preserved conventions

C++20, ArrayFire 3.10+, all five HPP/CPP pairs, PascalCase class/file names,
CPI_Metadata spelling, private data members, semantic dimension names, element
terminology, explicit get/set accessors, const-reference algorithm inputs and
value-returned outputs. The three-fake-algorithm demo remains in examples/.
Docker build/test scaffolding is retained and now includes the second library.
