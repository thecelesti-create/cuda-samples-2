#include <radar/RangePulseBuffer.hpp>
#include "array_helpers.hpp"

namespace radar {
RangePulseBuffer::RangePulseBuffer(af::array iq, CPI_Metadata metadata, RangeAxis rangeAxis)
    : iq_(std::move(iq)), metadata_(std::move(metadata)), rangeAxis_(rangeAxis),
      rangeBinCount_(iq_.dims(0)), pulseCount_(iq_.dims(1)), elementCount_(iq_.dims(2)) {
}
RangePulseBuffer::RangePulseBuffer(const SamplePulseBuffer& source, af::array iq, RangeAxis rangeAxis)
    : RangePulseBuffer(std::move(iq), source.getMetadata(), rangeAxis) {
}
af::array RangePulseBuffer::getPulse(dim_t pulseIndex, dim_t elementIndex) const {
    return iq_(af::span, detail::sequence(pulseIndex, 1), detail::sequence(elementIndex, 1));
}
af::array RangePulseBuffer::getElement(dim_t elementIndex) const {
    return iq_(af::span, af::span, detail::sequence(elementIndex, 1));
}
af::array RangePulseBuffer::getSlowTime(dim_t rangeBin, dim_t elementIndex) const {
    return iq_(detail::sequence(rangeBin, 1), af::span, detail::sequence(elementIndex, 1));
}
RangePulseBuffer RangePulseBuffer::sliceRanges(dim_t firstRangeBin, dim_t rangeBinCount) const {
    auto result = *this;
    result.iq_ = iq_(detail::sequence(firstRangeBin, rangeBinCount), af::span, af::span);
    result.rangeAxis_ = rangeAxis_.sliced(firstRangeBin);
    result.rangeBinCount_ = rangeBinCount;
    return result;
}
RangePulseBuffer RangePulseBuffer::slicePulses(dim_t firstPulse, dim_t pulseCount) const {
    auto result = *this;
    result.iq_ = iq_(af::span, detail::sequence(firstPulse, pulseCount), af::span);
    result.metadata_.setFirstPulseTimeSeconds(getPulseTimeSeconds(firstPulse));
    result.pulseCount_ = pulseCount;
    return result;
}
af::array RangePulseBuffer::getDopplerInput() const { return af::reorder(iq_, 1, 0, 2, 3); }
af::array RangePulseBuffer::getPower() const { return detail::computePower(iq_); }
void RangePulseBuffer::setData(af::array iq) {
    iq_ = std::move(iq);
}
void RangePulseBuffer::setMetadata(CPI_Metadata metadata) {
    metadata_ = std::move(metadata);
}
void RangePulseBuffer::setRangeAxis(RangeAxis rangeAxis) {
    rangeAxis_ = rangeAxis;
}
RangePulseBuffer RangePulseBuffer::withData(af::array iq) const {
    auto result = *this;
    result.setData(std::move(iq));
    return result;
}
RangePulseBuffer RangePulseBuffer::clone() const {
    auto result = *this;
    result.iq_ = iq_.copy();
    return result;
}
std::vector<af::cfloat> RangePulseBuffer::toHost() const { return detail::toHost(iq_); }
void RangePulseBuffer::evaluate() const { iq_.eval(); }
void RangePulseBuffer::synchronize() const { detail::synchronize(iq_); }
} // namespace radar
