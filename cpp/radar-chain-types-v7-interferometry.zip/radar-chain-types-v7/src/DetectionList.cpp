#include <radar/DetectionList.hpp>
#include "array_helpers.hpp"

namespace radar {
DetectionList::DetectionList(DetectionContext context) : context_(std::move(context)) {
    static_assert(sizeof(unsigned) == 4, "ArrayFire u32 host storage requires 32-bit unsigned");
}

DetectionList::DetectionList(DetectionContext context, af::array rangeBins,
                             af::array dopplerBins, af::array powers, af::array noisePowers,
                             af::array elementSnapshots)
    : context_(std::move(context)),
      detectionCount_(static_cast<std::size_t>(rangeBins.elements())),
      rangeBins_(std::move(rangeBins)), dopplerBins_(std::move(dopplerBins)),
      powers_(std::move(powers)), noisePowers_(std::move(noisePowers)),
      snapshots_(std::move(elementSnapshots)), hasElementSnapshots_(!snapshots_.isempty()) {
}
DetectionList::DetectionList(const RangeDopplerMap& source, af::array rangeBins,
                             af::array dopplerBins, af::array powers, af::array noisePowers,
                             af::array elementSnapshots)
    : DetectionList(source.getDetectionContext(), std::move(rangeBins), std::move(dopplerBins),
                    std::move(powers), std::move(noisePowers), std::move(elementSnapshots)) {
}
DetectionList::DetectionList(const RangeDopplerMap& source, af::array linearCellIndices,
                             af::array powers, af::array noisePowers)
    : context_(source.getDetectionContext()),
      detectionCount_(static_cast<std::size_t>(linearCellIndices.elements())),
      powers_(std::move(powers)), noisePowers_(std::move(noisePowers)) {
    if (getIsEmpty()) return;

    // Both operands are u32: integer quotient/remainder, no float index rounding.
    const auto dopplerBinCount = static_cast<unsigned>(source.getDopplerBinCount());
    const af::array divisors = af::constant(dopplerBinCount, linearCellIndices.dims(), u32);
    rangeBins_ = linearCellIndices / divisors;
    dopplerBins_ = linearCellIndices - rangeBins_ * divisors;

    // View [D,R,E] as [D*R,E], gather K rows -> [K,E], reorder -> [E,K].
    // Indices address one range-Doppler plane, not the entire E-plane cube.
    const dim_t cellCount = source.getDopplerBinCount() * source.getRangeBinCount();
    const af::array cellByElement = af::moddims(source.getData(), cellCount, getElementCount());
    snapshots_ = af::reorder(af::lookup(cellByElement, linearCellIndices, 0), 1, 0, 2, 3);
    hasElementSnapshots_ = true;
}
DetectionList::DetectionList(DetectionContext context, std::size_t detectionCount,
                             af::array rangeBins, af::array dopplerBins, af::array powers,
                             af::array noisePowers, af::array snapshots)
    : context_(std::move(context)), detectionCount_(detectionCount),
      rangeBins_(std::move(rangeBins)), dopplerBins_(std::move(dopplerBins)),
      powers_(std::move(powers)), noisePowers_(std::move(noisePowers)), snapshots_(std::move(snapshots)), hasElementSnapshots_(!snapshots_.isempty()) {}

DetectionList DetectionList::fromMap(const RangeDopplerMap& source, af::array linearCellIndices,
                                     af::array powers, af::array noisePowers) {
    return {source, std::move(linearCellIndices), std::move(powers), std::move(noisePowers)};
}
DetectionList DetectionList::fromCells(const RangeDopplerMap& source, af::array linearCellIndices,
                                       af::array powers, af::array noisePowers) {
    if (linearCellIndices.isempty()) return DetectionList(source.getDetectionContext());
    const auto dopplerBinCount = static_cast<unsigned>(source.getDopplerBinCount());
    const auto divisors = af::constant(dopplerBinCount, linearCellIndices.dims(), u32);
    af::array rangeBins = linearCellIndices / divisors;
    af::array dopplerBins = linearCellIndices - rangeBins * divisors;
    return {source, std::move(rangeBins), std::move(dopplerBins),
            std::move(powers), std::move(noisePowers), {}};
}
af::array DetectionList::getElementSnapshot(std::size_t detectionIndex) const {
    return snapshots_(af::span, detail::sequence(static_cast<BinIndex>(detectionIndex), 1));
}
DetectionList DetectionList::getDetection(std::size_t detectionIndex) const {
    const auto one = detail::sequence(static_cast<BinIndex>(detectionIndex), 1);
    return {context_, 1, rangeBins_(one), dopplerBins_(one), powers_(one), noisePowers_(one),
            hasElementSnapshots_ ? af::array(snapshots_(af::span, one)) : af::array{}};
}
af::array DetectionList::getRangesMeters() const {
    if (getIsEmpty()) return af::array{};
    const auto& axis = context_.getRangeAxis();
    return rangeBins_.as(f32) * static_cast<float>(axis.getBinSpacingMeters()) +
           static_cast<float>(axis.getFirstBinMeters());
}
af::array DetectionList::getDopplerHz() const {
    if (getIsEmpty()) return af::array{};
    const auto& axis = context_.getDopplerAxis();
    // Shift as signed integers before converting to f32, avoiding unsigned wrap.
    const af::array bins = dopplerBins_.as(s64);
    af::array signedBins;
    if (axis.getOrder() == DopplerOrder::Centered) {
        signedBins = bins - static_cast<long long>(axis.getFftSize() / 2);
    } else {
        signedBins = af::select(bins <= static_cast<long long>((axis.getFftSize() - 1) / 2),
                                bins, bins - static_cast<long long>(axis.getFftSize()));
    }
    return signedBins.as(f32) * static_cast<float>(axis.getBinSpacingHz());
}
af::array DetectionList::getRadialVelocitiesMps() const {
    if (getIsEmpty()) return af::array{};
    return getDopplerHz() * static_cast<float>(context_.getMetadata().getRadialVelocityMps(1.0));
}
af::array DetectionList::getSnrDb() const {
    if (getIsEmpty()) return af::array{};
    return 10.0f * (af::log10(powers_) - af::log10(noisePowers_));
}
void DetectionList::setPowers(af::array powers, af::array noisePowers) {
    powers_ = std::move(powers);
    noisePowers_ = std::move(noisePowers);
}
void DetectionList::setElementSnapshots(af::array snapshots) {
    snapshots_ = std::move(snapshots);
    hasElementSnapshots_ = !snapshots_.isempty();
}
DetectionList DetectionList::select(const af::array& detectionIndices) const {
    const auto count = static_cast<std::size_t>(detectionIndices.elements());
    if (count == 0) return {context_, 0, {}, {}, {}, {}, {}};
    return {context_, count, af::lookup(rangeBins_, detectionIndices, 0),
            af::lookup(dopplerBins_, detectionIndices, 0), af::lookup(powers_, detectionIndices, 0),
            af::lookup(noisePowers_, detectionIndices, 0),
            hasElementSnapshots_ ? af::lookup(snapshots_, detectionIndices, 1) : af::array{}};
}
DetectionList DetectionList::clone() const {
    if (getIsEmpty()) return *this;
    return {context_, detectionCount_, rangeBins_.copy(), dopplerBins_.copy(), powers_.copy(),
            noisePowers_.copy(), hasElementSnapshots_ ? snapshots_.copy() : af::array{}};
}
std::vector<Detection> DetectionList::recordsToHost() const {
    if (getIsEmpty()) return {};
    std::vector<unsigned> rangeBins(detectionCount_), dopplerBins(detectionCount_);
    std::vector<float> powers(detectionCount_), noisePowers(detectionCount_);
    rangeBins_.host(rangeBins.data());
    dopplerBins_.host(dopplerBins.data());
    powers_.host(powers.data());
    noisePowers_.host(noisePowers.data());
    std::vector<Detection> records;
    records.reserve(detectionCount_);
    for (std::size_t i = 0; i < detectionCount_; ++i)
        records.emplace_back(context_, DetectionCell(rangeBins[i], dopplerBins[i], powers[i], noisePowers[i]));
    return records;
}
std::vector<af::cfloat> DetectionList::snapshotsToHost() const {
    return hasElementSnapshots_ ? detail::toHost(snapshots_) : std::vector<af::cfloat>{};
}
void DetectionList::evaluate() const {
    if (getIsEmpty()) return;
    rangeBins_.eval(); dopplerBins_.eval(); powers_.eval(); noisePowers_.eval();
    if (hasElementSnapshots_) snapshots_.eval();
}
void DetectionList::synchronize() const {
    evaluate();
    af::sync(); // Always fence, including an empty result after queued work.
}
} // namespace radar
