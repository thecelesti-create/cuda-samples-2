#include <radar/AzElDetectionList.hpp>
#include "array_helpers.hpp"

namespace radar {
AzElDetectionList::AzElDetectionList(DetectionList detections, af::array azimuthRadians,
                                     af::array elevationRadians)
    : detections_(std::move(detections)), azimuthRadians_(std::move(azimuthRadians)),
      elevationRadians_(std::move(elevationRadians)) {
}
AzElDetectionList AzElDetectionList::getDetection(std::size_t detectionIndex) const {
    const auto one = detail::sequence(static_cast<BinIndex>(detectionIndex), 1);
    return {detections_.getDetection(detectionIndex), azimuthRadians_(one), elevationRadians_(one)};
}
af::array AzElDetectionList::getPositionsMeters() const {
    if (getIsEmpty()) return af::array{};
    const af::array ranges = detections_.getRangesMeters();
    const af::array horizontal = ranges * af::cos(elevationRadians_);
    const af::array xyz = af::join(1, horizontal * af::cos(azimuthRadians_),
                                 horizontal * af::sin(azimuthRadians_), ranges * af::sin(elevationRadians_));
    return af::reorder(xyz, 1, 0, 2, 3);
}
af::array AzElDetectionList::getPositionMeters(std::size_t detectionIndex) const {
    return getDetection(detectionIndex).getPositionsMeters();
}
void AzElDetectionList::setAngles(af::array azimuthRadians, af::array elevationRadians) {
    azimuthRadians_ = std::move(azimuthRadians);
    elevationRadians_ = std::move(elevationRadians);
}
AzElDetectionList AzElDetectionList::select(const af::array& detectionIndices) const {
    auto selected = detections_.select(detectionIndices);
    if (selected.getIsEmpty()) return {std::move(selected), {}, {}};
    return {std::move(selected), af::lookup(azimuthRadians_, detectionIndices, 0),
            af::lookup(elevationRadians_, detectionIndices, 0)};
}
AzElDetectionList AzElDetectionList::clone() const {
    if (getIsEmpty()) return *this;
    return {detections_.clone(), azimuthRadians_.copy(), elevationRadians_.copy()};
}
std::vector<AzElDetection> AzElDetectionList::recordsToHost() const {
    if (getIsEmpty()) return {};
    const auto detections = detections_.recordsToHost();
    std::vector<float> azimuth(getDetectionCount()), elevation(getDetectionCount());
    azimuthRadians_.host(azimuth.data());
    elevationRadians_.host(elevation.data());
    std::vector<AzElDetection> records;
    records.reserve(getDetectionCount());
    for (std::size_t i = 0; i < getDetectionCount(); ++i)
        records.emplace_back(detections[i], AngleEstimate(azimuth[i], elevation[i]));
    return records;
}
void AzElDetectionList::evaluate() const {
    detections_.evaluate();
    if (!getIsEmpty()) { azimuthRadians_.eval(); elevationRadians_.eval(); }
}
void AzElDetectionList::synchronize() const { evaluate(); af::sync(); }
} // namespace radar
