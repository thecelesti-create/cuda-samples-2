#pragma once
#include <radar/detail/ArrayFire.hpp>
#include <radar/metadata.hpp>
#include <utility>

namespace radar::detail {
// Precondition-only helpers. No bounds, dtype, context, overflow or value checks.
inline af::seq sequence(BinIndex first, BinIndex count) {
    return af::seq(static_cast<double>(first), static_cast<double>(first + count - 1));
}
inline af::array computePower(const af::array& data) {
    return af::real(data * af::conjg(data));
}
inline void synchronize(const af::array& data) {
    data.eval();
    af::sync();
}
inline std::vector<af::cfloat> toHost(const af::array& data) {
    std::vector<af::cfloat> result(static_cast<std::size_t>(data.elements()));
    if (!result.empty()) data.host(result.data());
    return result;
}
} // namespace radar::detail
