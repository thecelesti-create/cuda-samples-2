#include <radar/SamplePulseBuffer.hpp>
#include "array_helpers.hpp"

namespace radar {
SamplePulseBuffer::SamplePulseBuffer(af::array iq, CPI_Metadata metadata)
    : iq_(std::move(iq)), metadata_(std::move(metadata)),
      sampleCount_(iq_.dims(0)), pulseCount_(iq_.dims(1)), elementCount_(iq_.dims(2)) {
}
SamplePulseBuffer::SamplePulseBuffer(dim_t sampleCount, dim_t pulseCount, dim_t elementCount, CPI_Metadata metadata)
    : metadata_(std::move(metadata)), sampleCount_(sampleCount), pulseCount_(pulseCount), elementCount_(elementCount) {
    iq_ = af::constant(0, af::dim4(sampleCount, pulseCount, elementCount), c32);
}
SamplePulseBuffer::SamplePulseBuffer(std::span<const af::cfloat> iq,
                                     dim_t sampleCount, dim_t pulseCount, dim_t elementCount, CPI_Metadata metadata)
    : metadata_(std::move(metadata)), sampleCount_(sampleCount), pulseCount_(pulseCount), elementCount_(elementCount) {
    iq_ = af::array(af::dim4(sampleCount, pulseCount, elementCount), iq.data(), afHost);
}
SamplePulseBuffer SamplePulseBuffer::zeros(dim_t sampleCount, dim_t pulseCount, dim_t elementCount, CPI_Metadata metadata) {
    return {sampleCount, pulseCount, elementCount, std::move(metadata)};
}
SamplePulseBuffer SamplePulseBuffer::fromHost(std::span<const af::cfloat> iq,
                                             dim_t sampleCount, dim_t pulseCount, dim_t elementCount, CPI_Metadata metadata) {
    return {iq, sampleCount, pulseCount, elementCount, std::move(metadata)};
}
af::array SamplePulseBuffer::getPulse(dim_t pulseIndex, dim_t elementIndex) const {
    return iq_(af::span, detail::sequence(pulseIndex, 1), detail::sequence(elementIndex, 1));
}
af::array SamplePulseBuffer::getElement(dim_t elementIndex) const {
    return iq_(af::span, af::span, detail::sequence(elementIndex, 1));
}
af::array SamplePulseBuffer::getSlowTime(dim_t sampleIndex, dim_t elementIndex) const {
    return iq_(detail::sequence(sampleIndex, 1), af::span, detail::sequence(elementIndex, 1));
}
SamplePulseBuffer SamplePulseBuffer::sliceSamples(dim_t firstSample, dim_t sampleCount) const {
    auto result = *this;
    result.iq_ = iq_(detail::sequence(firstSample, sampleCount), af::span, af::span);
    result.metadata_.setFirstSampleDelaySeconds(getSampleDelaySeconds(firstSample));
    result.sampleCount_ = sampleCount;
    return result;
}
SamplePulseBuffer SamplePulseBuffer::slicePulses(dim_t firstPulse, dim_t pulseCount) const {
    auto result = *this;
    result.iq_ = iq_(af::span, detail::sequence(firstPulse, pulseCount), af::span);
    result.metadata_.setFirstPulseTimeSeconds(getPulseTimeSeconds(firstPulse));
    result.pulseCount_ = pulseCount;
    return result;
}
af::array SamplePulseBuffer::getPower() const { return detail::computePower(iq_); }
void SamplePulseBuffer::setData(af::array iq) {
    iq_ = std::move(iq);
}
void SamplePulseBuffer::setMetadata(CPI_Metadata metadata) {
    metadata_ = std::move(metadata);
}
SamplePulseBuffer SamplePulseBuffer::withData(af::array iq) const {
    auto result = *this;
    result.setData(std::move(iq));
    return result;
}
SamplePulseBuffer SamplePulseBuffer::clone() const {
    auto result = *this;
    result.iq_ = iq_.copy();
    return result;
}
std::vector<af::cfloat> SamplePulseBuffer::toHost() const { return detail::toHost(iq_); }
void SamplePulseBuffer::evaluate() const { iq_.eval(); }
void SamplePulseBuffer::synchronize() const { detail::synchronize(iq_); }
} // namespace radar
