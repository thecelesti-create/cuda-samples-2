# ArrayFire 3.10 / C++20 container build and tests

## Status — read first

**The Dockerfiles and scripts have been created, but no Docker image was built or
run in the generation environment. The ArrayFire sample has NOT been executed.**

The environment has no Docker executable/daemon socket, no NVIDIA device, and no
installed ArrayFire SDK. Downloading the SDK failed because the command environment
could not resolve GitHub; the separate download tool also failed. See
`VALIDATION.md` and `validation/real-sdk-attempt.txt` for the current environment and SDK check. The tests below are
configured tests, not reported successful ArrayFire executions.

## What is included

The v0.7 project is included: unchecked radar type wrappers, optional detection
IQ, and the separate interferometry library. The container setup provides:

- A `Dockerfile` with separate `cpu` and `cuda` targets.
- Scripts installing a real ArrayFire 3.10.0 SDK, compiling the complete C++20
  project, and executing the actual linked executables.
- A CTest smoke test for `examples/simple_demo.cpp`, checking process status and
  the specific expected result. The main itself also rejects incorrect final data.
- A runtime test runner that explicitly selects CPU or CUDA; it never silently
  substitutes CPU for a requested CUDA run.

There is no mock ArrayFire header, stub library, or emulated backend in this setup.
There are no registry pushes or automatic uploads of your repository.

## CPU: build and run

Run these from the extracted repository directory containing `Dockerfile`.
They work as separate commands in PowerShell, Bash, or a normal terminal:

```sh
docker build --platform linux/amd64 --target cpu -t radar-af:cpu .
docker run --rm radar-af:cpu
```

The CPU target uses Ubuntu 24.04 and builds the **official full ArrayFire 3.10.0
source bundle**, with the published SHA-256 checked before extraction. It enables
CPU and unified backends, using FFTW/OpenBLAS/LAPACK, and disables CUDA, OpenCL,
oneAPI, upstream tests/examples, and the optional graphics library build.

The project itself is built in C++20 Release mode. Docker build invokes CTest on
the real CPU backend and stops if configure, compile, integration tests, or the
sample fails. The completed image's entrypoint repeats the requested runtime tests.

ArrayFire's SDK keeps its own upstream compiler/language configuration; C++20 is
required for this repository and its consumers, not imposed on unrelated upstream
third-party source builds.

## NVIDIA GPU: build and run

On Windows, use Docker Desktop's **WSL2 backend**, Linux containers, an updated WSL
kernel, and an NVIDIA Windows driver supporting WSL GPU access. On native Linux,
configure the NVIDIA driver and NVIDIA Container Toolkit on the host. Neither the
host GPU driver nor the container runtime belongs inside the application image.

```sh
docker build --platform linux/amd64 --target cuda -t radar-af:cuda .
docker run --rm --gpus all radar-af:cuda
```

The CUDA target uses `nvidia/cuda:12.8.1-devel-ubuntu24.04` and the official Linux
ArrayFire 3.10.0 installer that ArrayFire lists as built with CUDA 12.8. This avoids
recompiling the whole CUDA backend merely to compile your application. The NVIDIA
base-image tag, installer, linked libraries, and hardware execution have **not**
been exercised here.

The installer accepts its included license noninteractively. It is downloaded
from ArrayFire's versioned HTTPS link. Unlike the CPU source bundle, an independent
published digest for that installer was not available here; it is not claimed to
be hash-pinned. An optional `ARRAYFIRE_INSTALLER_SHA256` build argument lets you
supply an independently verified digest. Recording a computed digest alone is not
an integrity check against a trusted expected value.

**The CUDA image also runs CPU tests during image construction. GPU tests run only
at container runtime with `--gpus all`.** Ordinary Docker builds do not receive your
GPU just because their base image contains CUDA. A successful CPU build is not a
successful CUDA runtime test.

To run only the sample rather than the full suite:

```sh
docker run --rm --gpus all --entrypoint /opt/radar/build/radar_simple_demo radar-af:cuda cuda
```

An optional driver visibility check is:

```sh
docker run --rm --gpus all --entrypoint nvidia-smi radar-af:cuda
```

You can also explicitly run the CUDA image's CPU backend:

```sh
docker run --rm radar-af:cuda cpu
```

The application is linked to the unified backend. Its test/demo executables call
`af::setBackend` for the requested backend and report errors if it is unavailable.
There is no automatic CPU fallback in the runner.

## What the sample must produce

The three original fake algorithm bodies are unchanged:

```text
SamplePulseBuffer [8 samples, 4 pulses, 3 elements]
    fakeMatchedFilter: multiply IQ by 2
RangePulseBuffer
    fakeDoppler: reorder only (not an FFT)
RangeDopplerMap
    fakeDetector: select cell zero
DetectionList
```

Input IQ is `1 + 0i`. Three elements each contribute `|2 + 0i|^2 = 4`, so the
expected result is:

```text
Fake chain produced 1 detection(s).
range bin=0, Doppler bin=0, power=12
```

**That block is expected output, not a captured successful execution.**

The main now throws on a wrong count, bin, or power. The smoke-test wrapper also
requires a zero exit status and both exact output lines; a printed success line
cannot hide a nonzero process exit. The validation is at final output, not in the
performance-critical helpers. CPU export still happens only at final printing.

## Test contents and logs

At image construction, CTest registers:

```text
radar_metadata                  Metadata/value-class tests (no ArrayFire)
radar_interferometry_reference   Independent scalar phase-model tests (no ArrayFire)
radar_arrayfire                  Actual ArrayFire data-type integration suite
radar_interferometry             Actual ArrayFire 1D/2D estimator tests
radar_simple_demo                Sample executable plus result/exit-status checks
```

At runtime, `docker/run-tests.sh [cpu|cuda]` executes both scalar suites, both real
ArrayFire integration suites on that backend, the sample verifier, and the synthetic
interferometry demo. The integration
suite exercises slices, axis changes, FFT transitions, detection gather, angle
columns, setters, clones, and explicit host export. These are not GPU performance
benchmarks and they do not establish real-scene accuracy or production radar performance.

Build-time logs are inside the image at `/opt/radar/build/validation/`. Runtime logs
are written to `/tmp/radar-test-logs` by default. They disappear with `--rm` unless
you mount an output directory. To retain runtime logs in PowerShell:

```powershell
New-Item -ItemType Directory -Force test-logs | Out-Null
$logs = (Resolve-Path test-logs).Path
docker run --rm --gpus all --mount "type=bind,source=$logs,target=/results" -e RADAR_TEST_LOG_DIR=/results radar-af:cuda
```

For Bash:

```sh
mkdir -p test-logs
docker run --rm --gpus all -v "$PWD/test-logs:/results" -e RADAR_TEST_LOG_DIR=/results radar-af:cuda
```

Only logs are written through this mount. Do not mount over `/opt/radar`, which
would hide the compiled executables already stored in the image.

## Configuration and troubleshooting

Build parallelism defaults to two jobs. You may change it with
`--build-arg BUILD_JOBS=4`, or lower it to one if memory is constrained. The source
and binary SDK targets may use different CPU math-library builds, so do not infer
performance parity from correctness tests.

This is a development/test image with a compiler and SDK, not a minimized deployment
image. The build requires internet access for Docker images, OS packages, and the
upstream SDK/dependencies. Versioned tags are used, but OS package versions and base
image digests are not fully locked; this is not a claim of bit-for-bit reproducibility.

A GPU run that reports a missing/unsupported backend is a failed test, not a pass.
Check host GPU access, driver/runtime compatibility, and the actual `af::info()`
output. The library's small fake main does not contain a real matched filter or
Doppler FFT; the integration suite includes an actual FFT check.

## Primary references

- ArrayFire 3.10.0 release and published full-source asset checksum:
  https://github.com/arrayfire/arrayfire/releases/expanded_assets/v3.10.0
- Official Linux 3.10.0 installer and its listed CUDA version:
  https://arrayfire.com/download/
- ArrayFire installer documentation:
  https://arrayfire.org/docs/installing.htm
- Upstream 3.10.0 build switches:
  https://github.com/arrayfire/arrayfire/blob/v3.10.0/CMakeLists.txt
- CPU backend dependency guidance (the wiki includes older platform examples):
  https://github.com/arrayfire/arrayfire/wiki/Build-Instructions-for-Linux
- Docker Desktop GPU requirements on Windows:
  https://docs.docker.com/desktop/features/gpu/
- NVIDIA Container Toolkit installation on Linux:
  https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html

## v0.7 additions

The default build now compiles `radar::interferometry`. The runtime script runs
its scalar-reference tests, actual ArrayFire estimator tests, and the synthetic
2D demo. Build-time tests target CPU; CUDA execution is only at `docker run
--gpus all`. These containers are still unexecuted in the generation environment.
The root VALIDATION.md is the current test record; old logs are not carried forward.
