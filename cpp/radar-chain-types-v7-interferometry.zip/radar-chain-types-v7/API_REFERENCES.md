# API and model references consulted for v0.7

ArrayFire API documentation (not a local installed SDK):
- https://arrayfire.org/docs/classaf_1_1array.htm
- https://arrayfire.org/docs/group__index__func__lookup.htm
- https://arrayfire.org/docs/group__arith__func__arg.htm
- https://arrayfire.org/docs/group__arith__func__atan.htm
- https://arrayfire.org/docs/group__data__func__select.htm

Phase model / coordinates:
- https://www.analog.com/en/resources/analog-dialogue/articles/phased-array-antenna-patterns-part1.html
- https://www.mathworks.com/help/phased/ref/uv2azel.html

The CMake dependency remains ArrayFire 3.10+. Online interface review is not a
compile against that SDK. No header or runtime substitute is shipped.
