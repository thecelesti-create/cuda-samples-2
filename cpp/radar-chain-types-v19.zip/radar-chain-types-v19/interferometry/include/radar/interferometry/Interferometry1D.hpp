#pragma once
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <cstddef>

namespace radar::interferometry {
/**
 * @brief Azimuth-only interferometry for a uniform horizontal line; input IQ is c32.
 * @details Elements run along +y; +x is boresight and +z is up. Calibrated IQ obeys
 * x(y) = A * exp(+j*2*pi*y*sin(azimuth)/wavelength). Positive adjacent-element
 * phase means positive azimuth, in radians on the forward hemisphere. The model
 * assumes arrivals in the horizontal plane. A line cannot distinguish true
 * azimuth from elevation off that plane: the result is then the apparent angle
 * asin(cos(elevation)*sin(azimuth)), not an independent two-angle estimate.
 * Wavelength comes from detection CPI metadata; element count comes from the
 * phase-centered RDM. Its element planes may represent elemental or coherent
 * subarray phase centers. Detection records normally originate from a sum beam;
 * their representative I/Q is not used for angle estimation. Selected phase-center
 * IQ is gathered internally in bounded batches, never supplied by the detector.
 * @pre At least two uniformly spaced phase centers, one dominant far-field arrival
 * per selected cell, and unwrapped adjacent phase strictly between -pi and pi.
 * All arrays use the same active ArrayFire backend/device. The RDM and detections
 * share CPI, range/Doppler grid and ordering. No runtime validation or host readback.
 */
class Interferometry1D final {
public:
    /** @brief Destroy the value using the default memberwise behavior. */
    ~Interferometry1D() = default;
    /** @brief Copy all stored values using the default memberwise behavior. */
    Interferometry1D(const Interferometry1D&) = default;
    /** @brief Copy-assign all stored values. */
    Interferometry1D& operator=(const Interferometry1D&) = default;
    /** @brief Move all members using their default value semantics. */
    Interferometry1D(Interferometry1D&&) = default;
    /** @brief Move-assign all members using their default value semantics. */
    Interferometry1D& operator=(Interferometry1D&&) = default;

    /** @brief Configure physical spacing and scratch-block size; allocates no device memory.
     * @param elementSpacingMeters Distance between adjacent effective phase centers, in meters.
     * @param detectionBatchSize Maximum selected cells per temporary IQ block; default 4096.
     * @pre Spacing and batch size are positive. Use the fixed horizontal-plane,
     * positive-phase convention; there is no elevation prior or sign/reference switch. */
    explicit Interferometry1D(double elementSpacingMeters,
                             std::size_t detectionBatchSize = 4096) noexcept;
    /** @brief Get spacing between effective phase centers in meters. */
    [[nodiscard]] double getElementSpacingMeters() const noexcept { return elementSpacingMeters_; }
    /** @brief Get the maximum selected cells per temporary IQ block. */
    [[nodiscard]] std::size_t getDetectionBatchSize() const noexcept { return detectionBatchSize_; }
    /** @brief Estimate azimuth from one phase-centered RDM and sum-beam detections.
     * @param phaseCenteredRdm Contiguous c32 [Doppler,range,element] cube. Each
     * element plane is one elemental or coherent subarray phase center, ordered
     * along +y. This is not a single combined sum-beam map.
     * @param detections Selected cells from the sum beam on the same CPI and
     * range/Doppler grid/order. No elemental IQ is required in the detection list.
     * @return Shallow list copy with a new f32 azimuth column and no elevation column.
     * Any old angles are replaced only on the result; input detections are unchanged.
     * @pre At least two phase-center planes. The effective center spacing matches
     * the constructor. The low-memory gather path requires contiguous RDM storage. */
    [[nodiscard]] DetectionList estimate(const RangeDopplerMap& phaseCenteredRdm,
                                         const DetectionList& detections) const;
private:
    /** @brief Compute one block's f32 azimuth column from c32 element IQ without host readback. */
    [[nodiscard]] af::array computeAzimuth(const af::array& elementIq, float azimuthScale) const;
    double elementSpacingMeters_;
    std::size_t detectionBatchSize_;
};
} // namespace radar::interferometry
