/**
 * @file test_interferometry.cpp
 * @brief All 1D interferometry tests: ArrayFire results, scalar reference, and timing.
 * @details GoogleTest supplies main(); this target belongs only to interferometry.
 */
#include <gtest/gtest.h>
#include <arrayfire.h>
#include <radar/CPI_Metadata.hpp>
#include <radar/Detection.hpp>
#include <radar/DetectionList.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/types.hpp>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <complex>
#include <cstddef>
#include <cstdlib>
#include <exception>
#include <initializer_list>
#include <iostream>
#include <limits>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>
#include <radar/interferometry/Interferometry1D.hpp>
#include "../src/device_helpers.hpp"

namespace {
/**
 * @brief Test-program setup used by GoogleTest's supplied main.
 * @details No ArrayFire call runs during global registration. The single local
 * environment has no ordering dependencies on other translation units.
 */
class ArrayFireTestEnvironment final : public ::testing::Environment {
public:
    /** @brief Select the requested backend/device before executing any tests. */
    void SetUp() override {
        initialized_ = false;
        try {
            const char* requestedBackend = std::getenv("RADAR_TEST_BACKEND");
#if RADAR_ARRAYFIRE_UNIFIED
            const std::string_view backend = requestedBackend && *requestedBackend
                ? requestedBackend : RADAR_TEST_DEFAULT_BACKEND;
            if (backend == "cpu") {
                af::setBackend(AF_BACKEND_CPU);
            } else if (backend == "cuda") {
                af::setBackend(AF_BACKEND_CUDA);
            } else if (backend == "opencl") {
                af::setBackend(AF_BACKEND_OPENCL);
            } else {
                FAIL() << "RADAR_TEST_BACKEND must be cpu, cuda or opencl; got: " << backend;
            }
            std::cout << "ArrayFire test backend: " << backend << '\n';
#else
            if (requestedBackend && *requestedBackend) {
                FAIL() << "A directly linked backend cannot be overridden; unset RADAR_TEST_BACKEND";
            }
#endif
            af::setDevice(0);
            initialized_ = true;
        } catch (const std::exception& error) {
            FAIL() << "ArrayFire test setup failed: " << error.what();
        }
    }

    /** @brief Report pending device errors at the final test-program boundary. */
    void TearDown() override {
        if (initialized_) {
            EXPECT_NO_THROW(af::sync());
        }
    }

private:
    bool initialized_ = false;
};

// GoogleTest owns the environment. Its constructor performs no device work.
[[maybe_unused]] ::testing::Environment* const arrayFireEnvironment =
    ::testing::AddGlobalTestEnvironment(new ArrayFireTestEnvironment);
} // namespace


namespace {
/** @brief Test-only mean call time after warmup; includes a device fence per call. */
template<class Operation>
double meanMilliseconds(Operation&& operation) {
    constexpr int warmups=3, repetitions=20;
    for (int i=0;i<warmups;++i) { operation(); af::sync(); }
    const auto start=std::chrono::steady_clock::now();
    for (int i=0;i<repetitions;++i) { operation(); af::sync(); }
    const auto stop=std::chrono::steady_clock::now();
    return std::chrono::duration<double,std::milli>(stop-start).count()/repetitions;
}
}


// ============================================================================
// Azimuth interferometry tests
// ============================================================================

using namespace radar;
using namespace radar::interferometry;
static_assert(!std::is_aggregate_v<Interferometry1D>);
static_assert(!std::is_polymorphic_v<Interferometry1D>);
static_assert(std::is_trivially_copyable_v<Interferometry1D>);
static_assert(!std::is_constructible_v<Interferometry1D, double, double, std::size_t>);
// Taking the unqualified member address must be unambiguous: exactly one estimate API.
static_assert(std::is_same_v<decltype(&Interferometry1D::estimate),
    DetectionList (Interferometry1D::*)(const RangeDopplerMap&, const DetectionList&) const>);
static_assert(!std::is_invocable_v<decltype(&Interferometry1D::estimate),
    const Interferometry1D&, const af::array&, const DetectionList&>);
static_assert(!std::is_invocable_v<decltype(&Interferometry1D::estimate),
    const Interferometry1D&, std::span<const RangeDopplerMap>, const DetectionList&>);

namespace {
/** @brief Upload a u32 test index column. */
af::array ids(std::initializer_list<unsigned> values) {
    return af::array(static_cast<dim_t>(values.size()), values.begin(), afHost);
}
/** @brief Synthesize a phase-centered RDM with positive exponent and unequal gains. */
RangeDopplerMap makeLine(std::size_t elementCount, double azimuth,
                        double spacingWavelengths = 0.5, double carrierHz = 10e9) {
    constexpr dim_t dopplerCount = 8, rangeCount = 6;
    const CPI_Metadata metadata(10e6, 2000, carrierHz, 5e6, 12);
    std::vector<af::cfloat> iq(static_cast<std::size_t>(dopplerCount * rangeCount) * elementCount);
    for (std::size_t element = 0; element < elementCount; ++element) {
        const double phase = 2.0 * pi * static_cast<double>(element) * spacingWavelengths *
                             std::sin(azimuth) + 0.63;
        const double gain = 1.0 + 0.1 * static_cast<double>(element);
        for (dim_t cell = 0; cell < dopplerCount * rangeCount; ++cell) {
            iq[static_cast<std::size_t>(cell) +
               static_cast<std::size_t>(dopplerCount * rangeCount) * element] = {
                   static_cast<float>(gain * std::cos(phase)),
                   static_cast<float>(gain * std::sin(phase))};
        }
    }
    return {af::array(af::dim4(dopplerCount, rangeCount, static_cast<dim_t>(elementCount)),
                     iq.data(), afHost), metadata, 100.0, 10.0, 4};
}
/** @brief Form a one-plane sum-beam test fixture; only this map feeds the detector. */
RangeDopplerMap makeSumBeam(const RangeDopplerMap& phaseCenteredRdm) {
    return {af::sum(phaseCenteredRdm.getData(), 2), phaseCenteredRdm.getMetadata(),
            phaseCenteredRdm.getFirstRangeMeters(), phaseCenteredRdm.getRangeBinSpacingMeters(),
            phaseCenteredRdm.getIntegratedPulseCount(), phaseCenteredRdm.getDopplerOrder()};
}
/** @brief Fabricate five detections from sum-beam data, including nonzero and duplicate cells. */
DetectionList detected(const RangeDopplerMap& sumBeamRdm) {
    return DetectionList::fromMap(sumBeamRdm, ids({10, 45, 10, 0, 35}),
        af::constant(1.0f, af::dim4(5), f32), af::constant(20.0f, af::dim4(5), f32));
}
/** @brief Verify azimuth and preserve every sum-beam record field and calibration scalar. */
void checkAzimuth(const DetectionList& output, const DetectionList& input, double azimuth) {
    ASSERT_TRUE(output.getHasAzimuth());
    EXPECT_FALSE(output.getHasElevation());
    EXPECT_FALSE(output.getHasAngles()); // This property means BOTH columns are present.
    EXPECT_EQ(output.getAzimuthRadians().type(), f32);
    EXPECT_EQ(output.getComplexPairs().type(), c32);
    const auto records = output.recordsToHost();
    const auto originals = input.recordsToHost();
    ASSERT_EQ(records.size(), 5U);
    ASSERT_EQ(records.size(), originals.size());
    for (std::size_t k = 0; k < records.size(); ++k) {
        const auto& record = records[k];
        ASSERT_TRUE(record.getAzimuthRadians().has_value());
        EXPECT_FALSE(record.getElevationRadians().has_value());
        EXPECT_NEAR(*record.getAzimuthRadians(), azimuth, 3e-5);
        EXPECT_EQ(record.getRangeIndex(), originals[k].getRangeIndex());
        EXPECT_EQ(record.getDopplerIndex(), originals[k].getDopplerIndex());
        EXPECT_FLOAT_EQ(record.getAmplitude(), originals[k].getAmplitude());
        EXPECT_FLOAT_EQ(record.getSnrDb(), originals[k].getSnrDb());
        EXPECT_EQ(record.getComplexPair(), originals[k].getComplexPair());
    }
    EXPECT_EQ(records[0].getRangeIndex(), 1U);
    EXPECT_EQ(records[0].getDopplerIndex(), 2U);
    EXPECT_EQ(records[2].getRangeIndex(), 1U);
    EXPECT_EQ(records[2].getDopplerIndex(), 2U);
    EXPECT_EQ(output.getMetadata().getCpiId(), input.getMetadata().getCpiId());
    EXPECT_DOUBLE_EQ(output.getMetadata().getBandwidthHz(), input.getMetadata().getBandwidthHz());
    EXPECT_DOUBLE_EQ(output.getFirstRangeMeters(), input.getFirstRangeMeters());
    EXPECT_DOUBLE_EQ(output.getRangeBinSpacingMeters(), input.getRangeBinSpacingMeters());
    EXPECT_EQ(output.getIntegratedPulseCount(), input.getIntegratedPulseCount());
    EXPECT_EQ(output.getDopplerBinCount(), input.getDopplerBinCount());
    EXPECT_EQ(output.getDopplerOrder(), input.getDopplerOrder());
}
} // namespace

/** @brief Only spacing and batch size are constructor configuration. */
TEST(InterferometryTests, ConstructorParameters) {
    const Interferometry1D line(0.01, 128);
    EXPECT_DOUBLE_EQ(line.getElementSpacingMeters(), 0.01);
    EXPECT_EQ(line.getDetectionBatchSize(), 128U);
    const Interferometry1D defaults(0.015);
    EXPECT_DOUBLE_EQ(defaults.getElementSpacingMeters(), 0.015);
    EXPECT_EQ(defaults.getDetectionBatchSize(), 4096U);
}

/** @brief Fixed convention covers negative/zero/positive azimuth and batch boundaries. */
TEST(InterferometryTests, LinearFixedConventionAndBatching) {
    for (double azimuth : {-0.35, 0.0, 0.25}) {
        const auto map = makeLine(5, azimuth);
        const auto list = detected(makeSumBeam(map));
        for (std::size_t block : {1U, 2U, 5U, 8U}) {
            const Interferometry1D estimator(map.getMetadata().getWavelengthMeters() / 2.0, block);
            ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, azimuth));
            EXPECT_FALSE(list.getHasAzimuth());
            EXPECT_FALSE(list.getHasElevation());
        }
    }
}

/** @brief Infer the phase-center count from the RDM, never from a one-plane detector map. */
TEST(InterferometryTests, LinearInfersPhaseCenterCount) {
    for (std::size_t count : {2U, 5U, 8U}) {
        const auto map = makeLine(count, 0.3);
        const auto sumBeam = makeSumBeam(map);
        ASSERT_EQ(sumBeam.getElementCount(), 1);
        const auto list = detected(sumBeam);
        for (std::size_t block : {1U, 2U, 8U}) {
            const Interferometry1D estimator(map.getMetadata().getWavelengthMeters() / 2.0, block);
            ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, 0.3));
        }
    }
}

/** @brief Sum-beam I/Q is retained in detections but never used as phase-center IQ. */
TEST(InterferometryTests, SumBeamDetectionsWithPhaseCenteredRdm) {
    const auto map = makeLine(5, -0.2, 0.4);
    const auto sumBeam = makeSumBeam(map);
    ASSERT_EQ(sumBeam.getElementCount(), 1);
    auto list = detected(sumBeam);
    const Interferometry1D estimator(0.4 * map.getMetadata().getWavelengthMeters(), 2);
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, -0.2));
    // Alter only the representative detector I/Q. Spatial phase must still come from the RDM.
    list.setComplexPairs(af::constant(0.0f, af::dim4(5), c32));
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, -0.2));
}

/** @brief Elemental and coherent subarray phase centers use exactly the same public function. */
TEST(InterferometryTests, ElementalAndSubarrayUseSameApi) {
    const auto elementalRdm = makeLine(5, 0.25, 0.5);
    const auto elementalDetections = detected(makeSumBeam(elementalRdm));
    const Interferometry1D elementalEstimator(
        0.5 * elementalRdm.getMetadata().getWavelengthMeters(), 2);
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(
        elementalEstimator.estimate(elementalRdm, elementalDetections), elementalDetections, 0.25));

    // A model of three coherent subarray centers, not a beamformer implementation.
    // The larger spacing is valid for this small angle's unambiguous phase interval.
    const auto subarrayRdm = makeLine(3, -0.1, 1.5);
    const auto subarrayDetections = detected(makeSumBeam(subarrayRdm));
    const Interferometry1D subarrayEstimator(
        1.5 * subarrayRdm.getMetadata().getWavelengthMeters(), 2);
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(
        subarrayEstimator.estimate(subarrayRdm, subarrayDetections), subarrayDetections, -0.1));
}

/** @brief The spatial phase sign is fixed and independent of CPI Doppler sign. */
TEST(InterferometryTests, SpatialSignIndependentOfDopplerSign) {
    auto map = makeLine(5, 0.25);
    auto metadata = map.getMetadata();
    metadata.setPositiveDoppler(PositiveDoppler::Receding);
    map.setMetadata(metadata);
    const auto list = detected(makeSumBeam(map));
    const Interferometry1D estimator(metadata.getWavelengthMeters() / 2.0);
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, 0.25));
    // Conjugation is only a test stimulus, not an automatic receiver-convention fix.
    map.setData(af::conjg(map.getData()));
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, -0.25));
}

/** @brief Physical spacing is constant while wavelength is read anew from each detection CPI. */
TEST(InterferometryTests, WavelengthFromCpiMetadata) {
    const Interferometry1D estimator(0.01);
    for (double carrierHz : {8e9, 12e9}) {
        const CPI_Metadata metadata(10e6, 2000, carrierHz, 5e6);
        const auto map = makeLine(5, 0.3, 0.01 / metadata.getWavelengthMeters(), carrierHz);
        const auto list = detected(makeSumBeam(map));
        ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, 0.3));
    }
}

/** @brief Empty lists mark azimuth present without gathering cells or retaining stale elevation. */
TEST(InterferometryTests, EmptyAzimuthOutput) {
    const auto map = makeLine(2, 0.0);
    DetectionList input(makeSumBeam(map));
    input.setAngles({}, {});
    const Interferometry1D estimator(map.getMetadata().getWavelengthMeters() / 2.0);
    const auto output = estimator.estimate(map, input);
    EXPECT_TRUE(output.getIsEmpty());
    EXPECT_TRUE(output.getHasAzimuth());
    EXPECT_FALSE(output.getHasElevation());
    EXPECT_FALSE(output.getHasAngles());
    EXPECT_TRUE(output.recordsToHost().empty());
    EXPECT_TRUE(input.getHasAngles());
}

/** @brief Undefined zero correlation remains NaN, not manufactured boresight or elevation. */
TEST(InterferometryTests, UndefinedAzimuth) {
    auto map = makeLine(5, 0.0);
    map.setData(af::constant(0.0f, map.getDimensions(), c32));
    const Interferometry1D estimator(map.getMetadata().getWavelengthMeters() / 2.0, 2);
    for (const auto& record : estimator.estimate(map, detected(makeSumBeam(map))).recordsToHost()) {
        ASSERT_TRUE(record.getAzimuthRadians().has_value());
        EXPECT_TRUE(std::isnan(*record.getAzimuthRadians()));
        EXPECT_FALSE(record.getElevationRadians().has_value());
    }
}

/** @brief Only the output replaces old angles; input columns and calibration are unchanged. */
TEST(InterferometryTests, ClearsStaleElevationAndPreservesInput) {
    const auto map = makeLine(5, 0.25);
    auto list = detected(makeSumBeam(map));
    list.setAngles(af::constant(-0.7f, af::dim4(5), f32), af::constant(0.4f, af::dim4(5), f32));
    for (std::size_t batch : {2U, 8U}) {
        const Interferometry1D estimator(map.getMetadata().getWavelengthMeters() / 2.0, batch);
        ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, 0.25));
    }
    EXPECT_TRUE(list.getHasAngles());
    for (const auto& record : list.recordsToHost()) {
        ASSERT_TRUE(record.getAzimuthRadians().has_value());
        ASSERT_TRUE(record.getElevationRadians().has_value());
        EXPECT_FLOAT_EQ(*record.getAzimuthRadians(), -0.7f);
        EXPECT_FLOAT_EQ(*record.getElevationRadians(), 0.4f);
    }
}

/** @brief Assigning a returned list keeps sum-beam records, calibration and detection order. */
TEST(InterferometryTests, AssignEstimateDeviceResultsAndMetadata) {
    const auto map = makeLine(5, 0.25);
    const auto original = detected(makeSumBeam(map));
    auto list = original;
    const Interferometry1D estimator(map.getMetadata().getWavelengthMeters() / 2.0, 2);
    list = estimator.estimate(map, list);
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(list, original, 0.25));
    list = estimator.estimate(map, list);
    ASSERT_NO_FATAL_FAILURE(checkAzimuth(list, original, 0.25));
}

/** @brief Component zero testing preserves tiny phases and maps signed zero to NaN. */
TEST(InterferometryTests, PhasePreservesTinyNonzeroCorrelations) {
    const std::vector<af::cfloat> values{
        {0.0f, 0.0f}, {-0.0f, -0.0f}, {1e-25f, 0.0f}, {-1e-25f, 0.0f},
        {0.0f, 1e-25f}, {0.0f, -1e-25f}, {1e-25f, 1e-25f}, {-1e-25f, -1e-25f}};
    const af::array correlations(af::dim4(2, 4), values.data(), afHost);
    const af::array phases = radar::interferometry::detail::phase(correlations);
    ASSERT_EQ(phases.type(), f32);
    ASSERT_EQ(phases.dims(0), 8);
    ASSERT_EQ(phases.dims(1), 1);
    std::vector<float> actual(values.size());
    phases.host(actual.data()); // Explicit test boundary.
    EXPECT_TRUE(std::isnan(actual[0]));
    EXPECT_TRUE(std::isnan(actual[1]));
    for (std::size_t i = 2; i < values.size(); ++i) {
        SCOPED_TRACE(i);
        EXPECT_TRUE(std::isfinite(actual[i]));
        EXPECT_NEAR(actual[i], std::atan2(values[i].imag, values[i].real), 1e-6f);
    }
}

/** @brief Small correlations stay usable even when squaring their magnitude would underflow. */
TEST(InterferometryTests, TinySignalEstimatesRemainDefined) {
    for (double azimuth : {-0.25, 0.0, 0.25}) {
        auto map = makeLine(5, azimuth);
        map.setData(map.getData() * 1e-13f);
        const auto list = detected(makeSumBeam(map));
        const Interferometry1D estimator(map.getMetadata().getWavelengthMeters() / 2.0, 2);
        ASSERT_NO_FATAL_FAILURE(checkAzimuth(estimator.estimate(map, list), list, azimuth));
    }
}

/** @brief Internal gather and reduction match a scalar per-cell oracle across batch sizes. */
TEST(InterferometryTests, LinearReductionMatchesScalarPerDetection) {
    constexpr std::size_t elementCount = 5;
    constexpr dim_t dopplerCount = 4, rangeCount = 3, cellCount = 12;
    const CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6);
    std::vector<af::cfloat> iq(static_cast<std::size_t>(cellCount) * elementCount);
    for (std::size_t element = 0; element < elementCount; ++element) {
        for (std::size_t cell = 0; cell < static_cast<std::size_t>(cellCount); ++cell) {
            const double azimuth = -0.3 + 0.04 * static_cast<double>(cell);
            const double phase = 2.0 * pi * 0.4 * static_cast<double>(element) * std::sin(azimuth) + 0.61;
            const double gain = 1.0 + 0.07 * static_cast<double>((element + cell) % 7);
            iq[cell + static_cast<std::size_t>(cellCount) * element] = {
                static_cast<float>(gain * std::cos(phase) + 0.003 * static_cast<double>((element + cell) % 3)),
                static_cast<float>(gain * std::sin(phase) - 0.002 * static_cast<double>((2 * element + cell) % 5))};
        }
    }
    const RangeDopplerMap map(af::array(af::dim4(dopplerCount, rangeCount, elementCount), iq.data(), afHost),
                              metadata, 100.0, 10.0, 4);
    const std::vector<unsigned> cells{11, 0, 7, 11, 4, 2, 9};
    const af::array selected(static_cast<dim_t>(cells.size()), cells.data(), afHost);
    const auto detections = DetectionList::fromMap(makeSumBeam(map), selected,
        af::constant(1.0f, selected.dims(), f32), af::constant(20.0f, selected.dims(), f32));
    std::vector<double> expected;
    for (const auto cell : cells) {
        const auto value = [&](std::size_t element) {
            const auto& q = iq[cell + static_cast<std::size_t>(cellCount) * element];
            return std::complex<double>(q.real, q.imag);
        };
        std::complex<double> correlation{};
        for (std::size_t element = 0; element + 1 < elementCount; ++element)
            correlation += std::conj(value(element)) * value(element + 1);
        expected.push_back(std::asin(std::arg(correlation) / (2.0 * pi * 0.4)));
    }
    for (std::size_t batch : {1U, 3U, 16U}) {
        const Interferometry1D estimator(0.4 * metadata.getWavelengthMeters(), batch);
        const auto records = estimator.estimate(map, detections).recordsToHost();
        ASSERT_EQ(records.size(), cells.size());
        for (std::size_t k = 0; k < cells.size(); ++k) {
            ASSERT_TRUE(records[k].getAzimuthRadians().has_value());
            EXPECT_FALSE(records[k].getElevationRadians().has_value());
            EXPECT_NEAR(*records[k].getAzimuthRadians(), expected[k], 3e-5);
            EXPECT_EQ(records[k].getRangeIndex(), cells[k] / dopplerCount);
            EXPECT_EQ(records[k].getDopplerIndex(), cells[k] % dopplerCount);
        }
    }
}

// ============================================================================
// Synthetic phase-centered linear array
// ============================================================================

/** @brief Five horizontal half-wavelength phase centers recover 20 degrees of azimuth only. */
TEST(InterferometryTests, SyntheticLinearAzimuth) {
    using namespace radar;
    using namespace radar::interferometry;
    constexpr dim_t dopplerCount = 8, rangeCount = 16, elementCount = 5;
    constexpr unsigned rangeIndex = 5, dopplerIndex = 2;
    const CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6, 7);
    const double azimuth = 20.0 * pi / 180.0;
    std::vector<af::cfloat> iq(dopplerCount * rangeCount * elementCount, {0.0f, 0.0f});
    for (dim_t element = 0; element < elementCount; ++element) {
        const double phase = pi * static_cast<double>(element) * std::sin(azimuth);
        iq[dopplerIndex + dopplerCount * (rangeIndex + rangeCount * element)] = {
            static_cast<float>(std::cos(phase)), static_cast<float>(std::sin(phase))};
    }
    const af::array data(af::dim4(dopplerCount, rangeCount, elementCount), iq.data(), afHost);
    const RangeDopplerMap phaseCenteredRdm(data, metadata, 100.0, 10.0, dopplerCount);
    const RangeDopplerMap sumBeamRdm(af::sum(phaseCenteredRdm.getData(), 2),
                                    metadata, 100.0, 10.0, dopplerCount);
    ASSERT_EQ(sumBeamRdm.getElementCount(), 1);
    const auto detections = DetectionList::fromMap(sumBeamRdm,
        af::constant(dopplerIndex + dopplerCount * rangeIndex, af::dim4(1), u32),
        af::constant(1.0f, af::dim4(1), f32), af::constant(20.0f, af::dim4(1), f32));
    const Interferometry1D estimator(metadata.getWavelengthMeters() / 2.0);
    const DetectionList located = estimator.estimate(phaseCenteredRdm, detections);
    ASSERT_TRUE(located.getHasAzimuth());
    EXPECT_FALSE(located.getHasElevation());
    EXPECT_FALSE(located.getHasAngles());
    EXPECT_FALSE(detections.getHasAzimuth());
    EXPECT_FALSE(detections.getHasElevation());
    EXPECT_EQ(located.getAzimuthRadians().type(), f32);
    EXPECT_EQ(located.getComplexPairs().type(), c32);
    const auto records = located.recordsToHost();
    ASSERT_EQ(records.size(), 1U);
    const auto& record = records.front();
    ASSERT_TRUE(record.getAzimuthRadians().has_value());
    EXPECT_FALSE(record.getElevationRadians().has_value());
    EXPECT_NEAR(*record.getAzimuthRadians(), azimuth, 2e-5);
    EXPECT_EQ(record.getRangeIndex(), rangeIndex);
    EXPECT_EQ(record.getDopplerIndex(), dopplerIndex);
    EXPECT_FLOAT_EQ(record.getAmplitude(), 1.0f);
    EXPECT_FLOAT_EQ(record.getSnrDb(), 20.0f);
    // Representative I/Q remains the detector's sum-beam value, not an element value.
    const auto detectorRecords = detections.recordsToHost();
    ASSERT_EQ(detectorRecords.size(), 1U);
    EXPECT_EQ(record.getComplexPair(), detectorRecords.front().getComplexPair());
    EXPECT_DOUBLE_EQ(located.getMetadata().getBandwidthHz(), metadata.getBandwidthHz());
}

// ============================================================================
// Opt-in azimuth performance test
// ============================================================================

/** @brief Opt-in end-to-end azimuth timing including the internal selected-cell gather. */
TEST(InterferometryPerformance, DISABLED_DeviceResidentAzimuthEstimation) {
    constexpr dim_t dopplers=128,ranges=2048,elements=12,detectionCount=8192;
    const radar::CPI_Metadata metadata(10e6,2000.0,10e9,5e6);
    const radar::RangeDopplerMap phaseCenteredRdm(
        af::constant(1.0f,af::dim4(dopplers,ranges,elements),c32),metadata,0.0,15.0,dopplers);
    const radar::RangeDopplerMap sumBeamRdm(
        af::sum(phaseCenteredRdm.getData(),2),metadata,0.0,15.0,dopplers);
    const af::array cells=af::range(af::dim4(detectionCount),0,u32);
    const auto detections=radar::DetectionList::fromMap(sumBeamRdm,cells,
        af::constant(12.0f,cells.dims(),f32),af::constant(20.0f,cells.dims(),f32));
    phaseCenteredRdm.evaluate(); detections.evaluate(); af::sync();
    const double spacing=metadata.getWavelengthMeters()/2.0;
    const radar::interferometry::Interferometry1D estimator(spacing);
    auto output=detections;
    const double elapsed=meanMilliseconds([&] {
        output=estimator.estimate(phaseCenteredRdm,detections);
        output.evaluate();
    });
    EXPECT_EQ(output.getDetectionCount(),static_cast<std::size_t>(detectionCount));
    EXPECT_TRUE(output.getHasAzimuth());
    EXPECT_FALSE(output.getHasElevation());
    EXPECT_NEAR(output.getAzimuthRadians().scalar<float>(),0.0f,1e-6f);
    RecordProperty("phase_centered_rdm_ms",std::to_string(elapsed));
    std::cout << "8192 sum-beam detections, 12 phase centers, batch 4096, mean ms/call "
              << "including internal gather and fence: " << elapsed << '\n';
}


// Independent scalar oracle only: this does NOT run ArrayFire or the production estimator.
namespace scalar_reference {
using radar::pi;
constexpr double wavelength = 0.03;
/** @brief Generate a positive-exponent uniform-line model with positive unequal gains. */
std::vector<std::complex<double>> synthesize(std::size_t elementCount, double spacing,
                                            double directionCosine) {
    std::vector<std::complex<double>> iq(elementCount);
    for (std::size_t element = 0; element < elementCount; ++element) {
        const double phase = 2.0 * pi / wavelength * static_cast<double>(element) * spacing * directionCosine;
        iq[element] = std::polar(1.0 + 0.05 * static_cast<double>(element), phase + 0.63);
    }
    return iq;
}
/** @brief Independently estimate apparent azimuth; exactly zero correlation is undefined. */
double scalarAzimuth(const std::vector<std::complex<double>>& iq, double spacing) {
    std::complex<double> correlation{};
    for (std::size_t element = 0; element + 1 < iq.size(); ++element)
        correlation += std::conj(iq[element]) * iq[element + 1];
    if (correlation.real() == 0.0 && correlation.imag() == 0.0)
        return std::numeric_limits<double>::quiet_NaN();
    return std::asin(wavelength / (2.0 * pi * spacing) * std::arg(correlation));
}
} // namespace scalar_reference

/** @brief Horizontal positive/negative azimuth is recovered for several counts and spacings. */
using namespace scalar_reference;

TEST(InterferometryReference, HorizontalAzimuth) {
    for (std::size_t count : {2U, 5U, 8U}) {
        for (double spacing : {0.2*wavelength, 0.4*wavelength, 0.5*wavelength}) {
            for (int degrees = -70; degrees <= 70; degrees += 5) {
                const double azimuth = degrees * pi / 180.0;
                EXPECT_NEAR(scalarAzimuth(synthesize(count, spacing, std::sin(azimuth)), spacing),
                            azimuth, 1e-11);
            }
        }
    }
}

/** @brief Conjugation reverses the fixed-convention azimuth; it is not auto-detected. */
TEST(InterferometryReference, ConjugationMirrorsAzimuth) {
    auto iq = synthesize(5, wavelength/2, std::sin(0.3));
    for (auto& value : iq) value = std::conj(value);
    EXPECT_NEAR(scalarAzimuth(iq, wavelength/2), -0.3, 1e-11);
}

/** @brief A horizontal line cannot independently recover true azimuth off the assumed plane. */
TEST(InterferometryReference, OffPlaneDirectionIsApparentAzimuth) {
    for (double azimuth : {-0.5, 0.3}) {
        for (double elevation : {-0.4, 0.2}) {
            const double u = std::cos(elevation) * std::sin(azimuth);
            const double result = scalarAzimuth(synthesize(5, wavelength/2, u), wavelength/2);
            EXPECT_NEAR(result, std::asin(u), 1e-11);
            EXPECT_GT(std::abs(result - azimuth), 1e-3);
        }
    }
}

/** @brief Large effective subarray spacings have only a limited unambiguous field of view. */
TEST(InterferometryReference, LongSpacingHasNoAmbiguityResolution) {
    EXPECT_NEAR(scalarAzimuth(synthesize(5, 2*wavelength, 0.1), 2*wavelength), std::asin(0.1), 1e-11);
    EXPECT_NEAR(scalarAzimuth(synthesize(5, wavelength, 0.75), wavelength), std::asin(-0.25), 1e-11);
}

/** @brief Zero or nonphysical correlation remains undefined rather than clipped to a target. */
TEST(InterferometryReference, UndefinedAzimuth) {
    EXPECT_TRUE(std::isnan(scalarAzimuth(std::vector<std::complex<double>>(5), wavelength/2)));
    // u=1.2 is nonphysical but has an unwrapped phase at this small spacing.
    EXPECT_TRUE(std::isnan(scalarAzimuth(synthesize(5, 0.1*wavelength, 1.2), 0.1*wavelength)));
}

// All five operations remain available; the header audit checks explicit defaults.
static_assert(std::is_destructible_v<radar::interferometry::Interferometry1D> &&
              std::is_copy_constructible_v<radar::interferometry::Interferometry1D> &&
              std::is_copy_assignable_v<radar::interferometry::Interferometry1D> &&
              std::is_move_constructible_v<radar::interferometry::Interferometry1D> &&
              std::is_move_assignable_v<radar::interferometry::Interferometry1D>);

/** @brief Explicit copy/move preserves the small constructor configuration. */
TEST(InterferometryTests, CopyMoveSemantics) {
    const radar::interferometry::Interferometry1D original(0.015, 32);
    radar::interferometry::Interferometry1D copied(original);
    radar::interferometry::Interferometry1D moved(std::move(copied));
    copied = original;
    moved = std::move(copied);
    copied = radar::interferometry::Interferometry1D(0.03, 64);
    EXPECT_DOUBLE_EQ(moved.getElementSpacingMeters(), 0.015);
    EXPECT_EQ(moved.getDetectionBatchSize(), 32U);
    EXPECT_DOUBLE_EQ(original.getElementSpacingMeters(), 0.015);
    EXPECT_EQ(copied.getDetectionBatchSize(), 64U);
}
