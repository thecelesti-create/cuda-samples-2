# Azimuth-only interferometry — v19

One class: `Interferometry1D`, with its own `.hpp`/`.cpp`. Link
`radar::interferometry`. C++20, ArrayFire 3.10+, GoogleTest 1.11+ for opt-in tests.
No two-dimensional estimator, array-geometry classes, sign switches, or elevation prior.

Copy/move/destruction are now explicitly defaulted in the class header; they only
operate on the estimator's two configuration scalars. The phase computation,
internal gather, batch memory policy and single estimate API are unchanged.

## API

```cpp
#include <radar/interferometry/Interferometry1D.hpp>

const radar::interferometry::Interferometry1D estimator(
    elementSpacingMeters,        // Distance between effective phase centers.
    /* detectionBatchSize */ 4096 // Optional; positive integer.
);
radar::DetectionList result = estimator.estimate(phaseCenteredRdm, detections);
```

The constructor allocates no device memory. Spacing and batch size are its only
configuration. `getElementSpacingMeters()` and `getDetectionBatchSize()` expose
these values. Element count is inferred from input; wavelength comes from
`detections.getMetadata().getWavelengthMeters()` on each call. A fixed physical
array can process multiple carriers subject to calibration and ambiguity limits.

There is exactly one public estimate function:

```cpp
DetectionList estimate(const RangeDopplerMap& phaseCenteredRdm,
                       const DetectionList& detections) const;
```

The **phase-centered RDM** is one c32 `[Doppler,range,element]` object. Its third
dimension contains all distinct coherent phase centers, either original elements
or subarray outputs. The word "element" in the data type names this storage axis;
the algorithm does not require a separate API or a tag for subarrays.

The detector uses only a **sum-beam RDM**, `[Doppler,range,1]`, and produces the
DetectionList. Its CPI, range/Doppler grid and bin ordering must match the
phase-centered RDM. Element counts need not match. The estimator reads the
selected indices from that list and gathers IQ at those cells across every
phase-center plane. This `[element,batchDetection]` temporary is private to the
algorithm. No elemental IQ is required from the detector and no full cube is
joined or deliberately cloned.

```text
sum-beam RDM [D,R,1] ---> detector ---> DetectionList ----+
                                                        |
phase-centered RDM [D,R,E], E >= 2 --------------------> estimate()
                                                        |
                                              DetectionList + azimuth
```

The detection's representative complex pair remains the sum-beam value; it is
preserved, not used for the spatial phase calculation. A single combined
sum-beam map does not contain the required multiple coherent phase centers.
The separate-map and pre-gathered-array overloads have been removed.

## Output semantics

Only azimuth is produced: f32 `[K]`, radians. The five input columns are retained
through ArrayFire handles and small calibration values are copied. The estimator
clears old angles on its result, then attaches fresh azimuth. It never attaches a
zero/assumed elevation. The original list and its old angles remain unchanged.

```cpp
result.getHasAzimuth();   // true, even for an empty processed list
result.getHasElevation(); // false
result.getHasAngles();    // false: this existing getter means BOTH columns
result.getAzimuthRadians();
// Do not call getElevationRadians() on this result: that field is absent.
```

The general Detection/DetectionList elevation fields are retained for external
producers; they are not needed by this library. A present NaN azimuth means an
undefined numerical estimate. An absent elevation is not a NaN or a zero estimate.
3D position helpers requiring both angles are not applicable to this output.

Assign `detections = estimator.estimate(input, detections)` to replace an existing
wrapper. There is no in-place overload or promise of reuse of old angle allocations.
`recordsToHost()` is the explicit final transfer. No ordinary getter downloads data.

## Fixed horizontal-array model

Coordinates: **+x boresight, +y positive azimuth, +z up**. At least two effective
phase centers lie at uniform spacing along +y, in increasing input order. The
model assumes one dominant narrowband far-field arrival per selected cell and
arrival in the horizontal plane:

```text
x[e] = A[e] * exp(+j*2*pi*e*spacing*sin(azimuth)/wavelength)
C = sum(conj(x[e]) * x[e+1])
azimuth = asin(arg(C) * wavelength/(2*pi*spacing))
```

After calibration, A[e] can vary in positive amplitude. A common complex phase
cancels; unknown element-specific phase does not. Positive adjacent phase means
positive azimuth. The result uses the forward branch, -pi/2 through +pi/2, with
ambiguous endfire endpoints excluded by the strict phase contract below.
CPI Doppler sign does not change the spatial sign. Correct different receiver or
removed steering-phase conventions upstream without changing detection bin meaning.

**This is not an elevation-insensitive measurement of arbitrary 3D azimuth.**
For an off-plane arrival, the measured direction cosine is
`cos(elevation)*sin(azimuth)` and this algorithm returns its arcsine. There is no
way to resolve both angles from this one line alone. This fixed assumption replaces
the former configurable elevation prior; do not use it to claim independent 3D angles.

Use the spacing between effective subarray phase centers for subarray-beamformed
RDMs, not the underlying radiator spacing. Inputs must retain coherent inter-center
phase with compatible beam patterns/calibration. This is not an arbitrary-layout,
planar-array, multi-source, calibration, or phase-unwrapping algorithm.
The residual phase must satisfy `abs(spacing*sin(azimuth)/wavelength) < 0.5` in the
horizontal model. Half-wavelength spacing covers the visible interior; larger
baselines restrict the unambiguous field of view. Front/back ambiguity is not resolved.

Exactly zero complex correlation becomes a device NaN; tiny nonzero correlations
are not squared merely for zero testing. Out-of-domain asin is not clipped to a
fabricated target. Do not enable fast-math when relying on NaN semantics.

## Memory and execution

IQ scratch is gathered only for detected cells, in blocks. The principal complex
block has `8 * elementCount * min(K,batchSize)` logical bytes. The one output
azimuth array has `4*K` bytes; there is no elevation array. Single-block results
adopt the computed column rather than allocating a second full output.
The zero-count path marks an empty azimuth column without gathering IQ.

The [cell,element] view and wavelength/spacing scaling are prepared once per
estimate. Each block then gathers and reorders only the selected IQ values.
There is no persistent scratch cache. `eval()` bounds deferred expression lifetimes
at block boundaries without explicit `sync()`, `host()`, `scalar()`, or `where()`.
ArrayFire may still allocate, synchronize or retain memory internally. These
logical formulas are not peak-device-memory or speed guarantees.

Contiguous maps are the low-memory gather precondition. Flattening a strided view
may materialize it. Inputs must have valid matching indices/CPI/grid/order, c32
IQ, same active backend/device, positive spacing/batch size and valid dimensions.
No new dtype, shape, value, backend or bounds checks are performed.

## Tests

The GoogleTest runner `radar_arrayfire_tests` covers positive/negative/zero
azimuth, phase-center-count inference from the RDM, batch boundaries, varied CPI
carrier, independent Doppler sign, a separate sum-beam detector, duplicate/nonzero
cells, source calibration, stale-elevation clearing, unchanged inputs, empty lists,
zero/tiny correlation, and a per-cell independent scalar sum. Additional
regressions verify that elemental and coherent subarray cubes use the same API,
and changing the representative sum-beam IQ does not change estimated azimuth.
A compile-time signature check rejects additional estimate overloads. The synthetic
`InterferometryTests.SyntheticLinearAzimuth` case uses five half-wavelength phase
centers and expects 20 degrees azimuth with no elevation field.

The separate scalar reference runner tests the math and its off-plane limitation;
it is not an execution of the ArrayFire estimator. The disabled
`InterferometryPerformance.DISABLED_DeviceResidentAzimuthEstimation` case measures
the sole phase-centered RDM path, including its internal gather. See
../PERFORMANCE.md.

```sh
ctest --test-dir build-tests -C Release -R '^radar_interferometry\.InterferometryTests\.' --no-tests=error --output-on-failure
```

Read ../VALIDATION.md for tests actually executed and unresolved dependency limits.
The phase and ArrayFire reference locations are retained in ../API_REFERENCES.md.

All interferometry tests are now in **`tests/test_interferometry.cpp`**, below
this library directory. The separate **`radar_interferometry_tests`** executable
contains the existing ArrayFire, synthetic, scalar-reference and disabled timing
cases. It links the radar types as a dependency; the radar-types tests do not
link interferometry. The library implementation is unchanged. Run it from the
repository root at `build-tests/interferometry/tests/radar_interferometry_tests`
(or add `Release/` and `.exe` for Visual Studio). See ../tests/README.md.
