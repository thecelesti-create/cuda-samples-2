/** @file test_detection_list.cpp @brief Small, aligned detection-list operations. */
#include <gtest/gtest.h>
#include <utility>
#include <type_traits>
#include <arrayfire.h>
#include <radar/CPI_Metadata.hpp>
#include <radar/Detection.hpp>
#include <radar/DetectionList.hpp>
#include <radar/types.hpp>
#include <array>
#include <complex>
#include <vector>

namespace {
/** @brief Three detached device records; no source RDM or shared test fixture. */
radar::DetectionList makeList() {
    const std::array<unsigned, 3> ranges{1, 2, 3}, dopplers{0, 2, 7};
    const std::array<float, 3> amplitudes{2, 3, 4}, snr{10, 20, 30};
    const std::array<af::cfloat, 3> iq{{{1, 1}, {3, 0}, {0, 4}}};
    return {radar::CPI_Metadata(10e6, 2000.0, 10e9, 5e6), 100.0, 10.0, 8, 4,
        radar::DopplerOrder::Unshifted, af::array(3, ranges.data(), afHost),
        af::array(3, dopplers.data(), afHost), af::array(3, amplitudes.data(), afHost),
        af::array(3, snr.data(), afHost), af::array(3, iq.data(), afHost)};
}
} // namespace

/** @brief Standalone arrays retain integer bins, amplitude, SNR, IQ, and calibration. */
TEST(DetectionListTests, StandaloneColumnsAndCoordinates) {
    const auto list = makeList();
    EXPECT_EQ(list.getDetectionCount(), 3U);
    EXPECT_EQ(list.getPayloadBytes(), 72U);
    EXPECT_EQ(list.getRangeIndices().type(), u32);
    EXPECT_EQ(list.getDopplerIndices().type(), u32);
    EXPECT_EQ(list.getAmplitudes().type(), f32);
    EXPECT_EQ(list.getSnrDb().type(), f32);
    EXPECT_EQ(list.getComplexPairs().type(), c32);
    EXPECT_DOUBLE_EQ(list.getRangeMetersForBin(2), 120.0);
    EXPECT_DOUBLE_EQ(list.getDopplerHzForBin(7), -250.0);
    const auto records = list.recordsToHost();
    ASSERT_EQ(records.size(), 3U);
    EXPECT_EQ(records[1].getRangeIndex(), 2U);
    EXPECT_EQ(records[1].getDopplerIndex(), 2U);
    EXPECT_FLOAT_EQ(records[1].getAmplitude(), 3.0f);
    EXPECT_FLOAT_EQ(records[1].getSnrDb(), 20.0f);
    EXPECT_EQ(records[1].getComplexPair(), std::complex<float>(3, 0));
}

/** @brief Selection moves all fields and both angles together, preserving duplicates. */
TEST(DetectionListTests, SelectionAndOptionalAngles) {
    auto list = makeList();
    list.setAngles(af::constant(0.2f, 3, f32), af::constant(0.1f, 3, f32));
    const std::array<unsigned, 3> order{2, 0, 2};
    const auto selected = list.select(af::array(3, order.data(), afHost));
    const auto records = selected.recordsToHost();
    ASSERT_EQ(records.size(), 3U);
    EXPECT_EQ(records[0].getRangeIndex(), 3U);
    EXPECT_EQ(records[1].getRangeIndex(), 1U);
    EXPECT_EQ(records[2].getDopplerIndex(), 7U);
    EXPECT_FLOAT_EQ(records[2].getAmplitude(), 4.0f);
    ASSERT_TRUE(records[2].getAzimuthRadians());
    ASSERT_TRUE(records[2].getElevationRadians());
    EXPECT_FLOAT_EQ(*records[2].getAzimuthRadians(), 0.2f);
    EXPECT_FLOAT_EQ(*records[2].getElevationRadians(), 0.1f);
    auto copy = selected.clone();
    copy.clearAngles();
    EXPECT_FALSE(copy.getHasAngles());
    EXPECT_TRUE(selected.getHasAngles());
}

/** @brief Whole-list replacement drops stale angles, and an empty selection remains usable. */
TEST(DetectionListTests, ReplacementAndEmptySelection) {
    auto list = makeList();
    list.setAzimuthRadians(af::constant(0.2f, 3, f32));
    const auto saved = list;
    list.setDetections(af::constant(2u, 1, u32), af::constant(3u, 1, u32),
        af::constant(5.0f, 1, f32), af::constant(10.0f, 1, f32), af::constant(2.0f, 1, c32));
    EXPECT_EQ(list.getDetectionCount(), 1U);
    EXPECT_FALSE(list.getHasAzimuth());
    EXPECT_EQ(saved.getDetectionCount(), 3U);
    EXPECT_TRUE(saved.getHasAzimuth());
    const auto empty = saved.select(af::array{});
    EXPECT_TRUE(empty.getIsEmpty());
    EXPECT_TRUE(empty.getHasAzimuth());
    EXPECT_TRUE(empty.recordsToHost().empty());
}

/** @brief Remapping detection bins agrees with odd/even scalar Doppler coordinates. */
TEST(DetectionListTests, OddEvenIndexRemap) {
    for (dim_t count : {4, 5}) {
        radar::DetectionList list(radar::CPI_Metadata(10e6, 2000.0, 10e9, 5e6),
            0.0, 15.0, count, count, radar::DopplerOrder::Unshifted,
            af::constant(0u, count, u32), af::range(af::dim4(count), 0, u32),
            af::constant(1.0f, count, f32), af::constant(10.0f, count, f32),
            af::constant(1.0f, count, c32));
        list.setDopplerOrder(radar::DopplerOrder::Centered);
        std::vector<unsigned> bins(static_cast<std::size_t>(count));
        list.getDopplerIndices().host(bins.data());
        for (dim_t k = 0; k < count; ++k) {
            EXPECT_EQ(bins[k], static_cast<unsigned>((k + count / 2) % count));
            const dim_t signedBin = k < (count + 1) / 2 ? k : k - count;
            EXPECT_DOUBLE_EQ(list.getDopplerHzForBin(bins[k]), signedBin * 2000.0 / count);
        }
        list.setDopplerOrder(radar::DopplerOrder::Unshifted);
        list.getDopplerIndices().host(bins.data());
        for (dim_t k = 0; k < count; ++k) EXPECT_EQ(bins[k], static_cast<unsigned>(k));
    }
}

/** @brief A three-record, two-record-batch export exercises the tail and exact u32 storage. */
TEST(DetectionListTests, BatchedExportKeepsExactIndices) {
    auto list = makeList();
    constexpr unsigned largeIndex = 16'777'217U; // Above f32's exact-integer range.
    list.setDetections(af::constant(largeIndex, 3, u32), list.getDopplerIndices(),
        list.getAmplitudes(), list.getSnrDb(), list.getComplexPairs());
    list.setAngles(af::constant(0.2f, 3, f32), af::constant(0.1f, 3, f32));
    list.evaluate();
    const auto records = list.recordsToHost(2);
    ASSERT_EQ(records.size(), 3U);
    EXPECT_EQ(records.back().getRangeIndex(), largeIndex);
    EXPECT_FLOAT_EQ(records.back().getAmplitude(), 4.0f);
    ASSERT_TRUE(records.back().getAzimuthRadians());
    EXPECT_FLOAT_EQ(*records.back().getAzimuthRadians(), 0.2f);
}

// All five operations remain available; the header audit checks explicit defaults.
static_assert(std::is_destructible_v<radar::DetectionList> &&
              std::is_copy_constructible_v<radar::DetectionList> &&
              std::is_copy_assignable_v<radar::DetectionList> &&
              std::is_move_constructible_v<radar::DetectionList> &&
              std::is_move_assignable_v<radar::DetectionList>);

/** @brief Copy/move retains aligned columns and optional handles after owners exit. */
TEST(DetectionListTests, CopyMoveSemantics) {
    const auto result = [] {
        auto original = makeList();
        original.setAngles(af::constant(0.2f, 3, f32), af::constant(0.1f, 3, f32));
        original.evaluate();
        radar::DetectionList copied(original);
        radar::DetectionList moved(std::move(copied));
        copied = original;
        moved = std::move(copied);
        original.clearAngles(); // The other wrapper's optional handles are independent.
        return moved;
    }();
    EXPECT_EQ(result.getDetectionCount(), 3U);
    ASSERT_TRUE(result.getHasAngles());
    EXPECT_DOUBLE_EQ(result.getRangeBinSpacingMeters(), 10.0);
    const auto records = result.recordsToHost();
    ASSERT_EQ(records.size(), 3U);
    EXPECT_EQ(records.back().getRangeIndex(), 3U);
    EXPECT_EQ(records.back().getDopplerIndex(), 7U);
    EXPECT_FLOAT_EQ(records.back().getAmplitude(), 4.0f);
    EXPECT_EQ(records.back().getComplexPair(), std::complex<float>(0, 4));
    ASSERT_TRUE(records.back().getAzimuthRadians());
    EXPECT_FLOAT_EQ(*records.back().getAzimuthRadians(), 0.2f);
    ASSERT_TRUE(records.back().getElevationRadians());
    EXPECT_FLOAT_EQ(*records.back().getElevationRadians(), 0.1f);
}
