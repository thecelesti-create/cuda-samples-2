# Tests — v19

Tests are opt-in (`RADAR_BUILD_TESTS=ON`). The project uses installed GoogleTest
1.11+ and `GTest::gtest_main`; there is no custom main.cpp or test-support header.
All test translation units follow `test_*.cpp`.

## One file per radar type; one file for interferometry

| Source | Test executable | Scope |
|---|---|---|
| `tests/test_cpi_metadata.cpp` | `radar_metadata_tests` | CPI values, timing, bandwidth and ambiguity helpers |
| `tests/test_detection.cpp` | `radar_metadata_tests` | Host record fields and optional angles |
| `tests/test_sample_pulse_buffer.cpp` | `radar_arrayfire_tests` | Construction, upload, slices, replacement and power |
| `tests/test_range_pulse_buffer.cpp` | `radar_arrayfire_tests` | Calibration, pulse-first reorder and stage adoption |
| `tests/test_range_doppler_map.cpp` | `radar_arrayfire_tests` | Dimensions, power, crops and odd/even FFT ordering |
| `tests/test_detection_list.cpp` | `radar_arrayfire_tests` | Columns, selection, optionals, bin remapping and export |
| `tests/test_arrayfire.cpp` | `radar_arrayfire_tests` | Both pipeline tests, optional core timing and backend setup |
| `interferometry/tests/test_interferometry.cpp` | `radar_interferometry_tests` | All azimuth, synthetic, scalar-reference and timing tests |

The radar test target never links interferometry. The interferometry test target
links `radar::interferometry`, which depends on the radar types. Each runner has
its own GoogleTest-supplied entry point.

The six datatype files use tiny fixtures, focused assertions and bulk readbacks.
Each now adds one short copy/move case; no exhaustive lifecycle permutation loop
or per-record GPU readback was added. They are focused smoke/regression tests rather
than an exhaustive permutation of every getter. Tests do NOT add validation to
library code. The formerly huge mixed datatype cases are replaced, not retained
under new filenames.

The old `OddEvenDopplerOrdering` mixed arrays and lists, 16 FFT lengths and repeated
one-record exports. Now the map and list files each cover lengths 4 and 5 using
four small readbacks total per case. A separate three-record, batch-size-two
list case checks a partial export block and exact u32 values above 2^24.

Interferometry's 16 existing ArrayFire cases (including one disabled timing case)
and five scalar-reference cases retain their bodies. The scalar-reference cases
are now in the same file/executable; there is no separate reference-test runner.
They are independently calculated math, NOT a replacement for testing ArrayFire.
With ArrayFire types disabled, only the two host metadata/record files are built.

## Copy/move regression cases

Every library class has a `CopyMoveSemantics` case in its existing test file plus
`std::type_traits` checks for the five operations' availability. The four
array-backed types check that moved/copied results still own usable data after
local source wrappers leave scope, using a single small final export per case.
Tests never assume a moved-from wrapper is automatically empty; its only reuse
is full assignment. Interferometry tests only its small constructor configuration.
These are correctness tests, not allocation/performance measurements.

```sh
ctest --test-dir build-tests -C Release -R 'CopyMoveSemantics' --no-tests=error --output-on-failure
```

## Build and run

```sh
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release --no-tests=error --output-on-failure
```

Provide ArrayFire/GoogleTest installation paths as needed. Replace cuda with cpu
or opencl for unified-backend tests. A directly linked build uses
`RADAR_ARRAYFIRE_BACKEND=CPU|CUDA|OPENCL`, an empty RADAR_TEST_BACKEND CMake option,
and no RADAR_TEST_BACKEND environment override.

Run all cases within each process (Linux/WSL):

```sh
./build-tests/tests/radar_metadata_tests
./build-tests/tests/radar_arrayfire_tests
./build-tests/interferometry/tests/radar_interferometry_tests
```

Visual Studio / PowerShell:

```powershell
.\build-tests\tests\Release\radar_metadata_tests.exe
.\build-tests\tests\Release\radar_arrayfire_tests.exe
.\build-tests\interferometry\tests\Release\radar_interferometry_tests.exe
```

GoogleTest supplies main; do not append a positional backend argument. Each
ArrayFire runner has a local test-only Environment in its test source that reads
RADAR_TEST_BACKEND from the environment, falling back to the CMake-selected
backend (cpu if empty). SetUp selects device zero only when tests execute; no
ArrayFire calls happen during global registration or test enumeration. TearDown
synchronizes to report pending device errors. Test setup failure is not skipped.

For a temporary override in a unified build:

```powershell
$env:RADAR_TEST_BACKEND = "cuda"
.\build-tests\tests\Release\radar_arrayfire_tests.exe
Remove-Item Env:RADAR_TEST_BACKEND
```

## Useful CTest filters

```sh
# The two pipeline cases, still in the radar-only runner.
ctest --test-dir build-tests -C Release -R 'PipelineTests' -V --no-tests=error
# Only radar ArrayFire cases; never runs interferometry.
ctest --test-dir build-tests -C Release -R '^radar_arrayfire\.' --no-tests=error --output-on-failure
# Only the separate interferometry executable's cases.
ctest --test-dir build-tests -C Release -R '^radar_interferometry\.' --no-tests=error --output-on-failure
```

CTest still registers a separate process invocation per case. Run the executable
with `--gtest_repeat=10 --gtest_filter=PipelineTests.*` to repeat that selection in
one process and distinguish first-use compilation from steady-state work.

## Radar-only build

```sh
cmake -S . -B build-radar-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_BUILD_INTERFEROMETRY=OFF -DRADAR_TEST_BACKEND=cuda
cmake --build build-radar-tests --config Release --parallel
ctest --test-dir build-radar-tests -C Release --no-tests=error --output-on-failure
```

This omits the interferometry library and its test target without changing or
conditionally compiling any radar test body. No test source includes another CPP.
The two disabled timing cases require explicit opt-in; see ../PERFORMANCE.md.
Read ../VALIDATION.md for the exact executed checks and unresolved dependencies.
