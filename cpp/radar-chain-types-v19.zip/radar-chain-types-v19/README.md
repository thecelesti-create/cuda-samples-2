# Radar chain libraries — v19

C++20 / ArrayFire 3.10+, with one separate azimuth-only interferometry algorithm.
GoogleTest 1.11 compatibility is retained. CMake version is 0.19.0.
Each library class now explicitly defaults its destructor, copy constructor,
copy assignment, move constructor and move assignment in its own public header.
Algorithms and data layouts are unchanged from corrected v18. Interferometry has one estimate API:
one phase-centered RDM plus a sum-beam detection list. It supports a uniform
horizontal line with fixed spatial sign and no elevation estimation.
Default builds contain libraries only; opt-in tests use GoogleTest 1.11+.

```text
SamplePulseBuffer -> RangePulseBuffer -> RangeDopplerMap -> DetectionList
                                                              |
                                               interferometry |
                                                              v
                                                      DetectionList
                                                  (azimuth attached)
```

## Explicit defaulted lifetime operations

All seven library classes declare the same five memberwise operations in class:

```cpp
~SamplePulseBuffer() = default;
SamplePulseBuffer(const SamplePulseBuffer&) = default;
SamplePulseBuffer& operator=(const SamplePulseBuffer&) = default;
SamplePulseBuffer(SamplePulseBuffer&&) = default;
SamplePulseBuffer& operator=(SamplePulseBuffer&&) = default;
```

This makes the existing ownership policy visible; it does not add manual cleanup,
array copies, runtime checks, or synchronization. Definitions stay in the header
at their first declaration, so these operations are not user-provided bodies.
Their exception specifications are inferred from their members, not forced by an
unconditional `noexcept`. There is no new zero-argument constructor.

Array-backed wrapper copies retain storage through ArrayFire members; `clone()`
remains the deliberate deep-copy operation. Scalar metadata is copied by value.
Destruction releases the members' ownership; other aliases and the ArrayFire
allocator can retain the backing allocation. No destructor calls `deviceGC()`.

After moving **from an array-backed wrapper**, destroy or completely reassign the
source before using it again. Its scalar dimensions/counts are not zeroed, and
`std::optional<af::array>` can remain engaged around a moved-from array. Do not
read the source's data or interpret its cached count as a usable buffer, and do
not use `setData()` alone to repair an arbitrary moved-from object's metadata.
The destination receives all member state. Self-move is not an extra guarantee.
For metadata, host records and the estimator, default member value semantics apply.

The seven types are `CPI_Metadata`, `Detection`, `SamplePulseBuffer`,
`RangePulseBuffer`, `RangeDopplerMap`, `DetectionList` and `Interferometry1D`.
Test-only GoogleTest Environment classes are not library value/owner types and
are unchanged. Tests remain separated by library.

## Construction and operation names

Use one entry point per construction purpose:

```cpp
#include <radar/SamplePulseBuffer.hpp>
#include <utility>

// Adopt an existing c32 array; the constructor retains/moves its handle.
radar::SamplePulseBuffer adopted(std::move(iq), metadata);
// Allocate or upload explicitly with the named factories.
auto zero = radar::SamplePulseBuffer::zeros(sampleCount, pulseCount, elementCount, metadata);
auto uploaded = radar::SamplePulseBuffer::fromHost(hostIq, sampleCount, pulseCount, elementCount, metadata);
// Same-shape replacement and explicit deep copy remain available.
uploaded.setData(std::move(replacementIq));
auto detached = uploaded.clone();
```

Allocating/uploading constructor overloads and `withData()` have been removed.
Stage-to-stage constructors, slices, `setData()` and `clone()` remain.

Action names distinguish computation and data movement from ordinary getters:

| Action | Meaning |
|---|---|
| `ranges.reorderForDoppler()` | `[range,pulse,element]` to `[pulse,range,element]` |
| `map.reorderToRangeFirst()` | `[Doppler,range,element]` to `[range,Doppler,element]` |
| `cube.computePower()` | f32 squared magnitude, leaving c32 IQ intact |
| `map.computePowerSumElements()` | f32 noncoherent power sum across elements |

`getData()` and the actual metadata/dimension getters retain their names.
No result caching, new validators, CUDA-specific code or changes to data layouts
were introduced. The phase helper uses a direct component zero test rather than
squaring a correlation solely to test for zero. See `MIGRATION.md` for test-runner changes and `VALIDATION.md` for actual execution status.

## Standalone construction (no precursor object required)

Each array-backed type has an array-adopting constructor with ordinary parameter
names. Complex inputs must already be **c32**. The contract is documented, not
encoded in every identifier; no automatic casts or runtime dtype scans are added.

```cpp
#include <arrayfire.h>
#include <radar/CPI_Metadata.hpp>
#include <radar/SamplePulseBuffer.hpp>
#include <radar/RangePulseBuffer.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/DetectionList.hpp>
#include <radar/types.hpp>

radar::CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6, 14);
// rawIq, rangeIq and dopplerIq are independently produced c32 ArrayFire arrays.
radar::SamplePulseBuffer samples(rawIq, metadata);
radar::RangePulseBuffer ranges(rangeIq, metadata, 100.0, 7.5);
radar::RangeDopplerMap map(dopplerIq, metadata, 100.0, 7.5, 800);

// No RDM object is needed to load an already-detected list either.
// ranges/dopplers: u32 [K], amplitude/SNR: f32 [K], pairs: c32 [K].
radar::DetectionList detections(metadata, 100.0, 7.5, 1024, 800,
    radar::DopplerOrder::Unshifted,
    rangeIndices, dopplerIndices, amplitudes, snrDb, complexPairs);
```

The FFT length is taken from the map's own array; a standalone list must receive
that length explicitly because sparse detections do not contain a whole map.
Stage-to-stage constructors are optional conveniences, not prerequisites.
`Detection` remains a host export value, while `CPI_Metadata` is numeric metadata.
Neither represents an IQ cube.

Project `detail/ArrayFire.hpp` has been deleted. Files use the SDK's
`<arrayfire.h>` directly. CMake still discovers the real ArrayFire package.

## Device data, small CPU metadata

| Type | Numerical storage |
|---|---|
| SamplePulseBuffer | c32 `[sample,pulse,element,1]` |
| RangePulseBuffer | c32 `[range,pulse,element,1]` |
| RangeDopplerMap | c32 `[Doppler,range,element,1]` |
| DetectionList | Private u32 range/Doppler columns, f32 amplitude/SNR-dB columns, c32 I/Q column |
| Detection | One ordinary host value returned by explicit `recordsToHost()` |

DetectionList is again ArrayFire-backed: it is **not a host vector or a native
CUDA record buffer**. The logical record has five values, but its device layout
is structure-of-arrays using supported ArrayFire dtypes, not an array of C++
Detection objects. All five columns are `[K,1,1,1]`, share the same ordering, and
are adopted together. List operations `select()`, `getDetection()` and `clone()`
apply to all fields and optional angles together. No hidden host mirror is kept.

Indices retain u32 precision instead of being encoded as floats. Amplitude is
linear magnitude, SNR is detector-supplied dB, and the c32 pair is ONE
representative complex I/Q value per detection, not all element IQ.
`setDetections()` replaces all five columns and clears stale angles. Individual
field setters still require same-count/device input; no runtime validation is added.

Optional f32 azimuth/elevation columns are radians. Absence is list-wide for each
column and allocates no numerical array. A present NaN can represent an invalid
angle for one detection. Empty lists can retain optional-column presence. This
is distinct from arbitrary per-record `std::optional` flags in the old host v11.
The general data model still permits an elevation supplied by other code. The
The interferometer supplies ONLY azimuth and clears any old output elevation.
Use `getHasAzimuth()` after estimation. `getHasAngles()` still means BOTH fields
are present, so it is false for this azimuth-only result. No AzElDetectionList exists.

Selecting CUDA before the initial upload puts numerical data on CUDA; selecting
CPU/OpenCL uses that backend instead. Containers do not select/switch backends,
copy between devices, or introduce CUDA runtime dependencies. ArrayFire and its
backend runtimes must still be installed and configured. CPI metadata, array
handles and scalar dimensions remain on the host.

## No axis classes

Range calibration is directly stored as `firstRangeMeters_` and
`rangeBinSpacingMeters_`. The map also stores `integratedPulseCount_` and
`dopplerOrder_`; its existing `dopplerBinCount_` is the FFT length. DetectionList
copies those few scalars so it can outlive the source RDM without retaining it.
PRF is read from CPI_Metadata, not duplicated in a second grid object.

```cpp
#include <radar/RangePulseBuffer.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/types.hpp>
#include <utility>

radar::RangeDopplerMap doDoppler(const radar::RangePulseBuffer& input) {
    af::array output = af::fft(input.reorderForDoppler());
    return {input, std::move(output), radar::DopplerOrder::Unshifted};
}
```

Construct a range buffer with explicit output calibration:

```cpp
radar::RangePulseBuffer ranges(samples, filteredIq,
                               /* firstRangeMeters */ 300.0,
                               /* rangeBinSpacingMeters */ 7.5);
```

`RangePulseBuffer(samples, filteredIq)` is a convenience ONLY for an output
whose filter delay is already corrected and which retains the original raw
sample timing/spacing. Cropping or resampling may require the explicit overload.
Constructors never perform matched filtering or infer an unknown filter delay.

```cpp
map.getFirstRangeMeters();
map.getRangeBinSpacingMeters();
map.getRangeMeters(rangeBin);
map.getDopplerHz(dopplerBin);
map.getDopplerBinCount();        // Includes zero padding.
map.getIntegratedPulseCount();  // Actual observations, not padding.
map.getDopplerBinSpacingHz();   // PRF/Nfft.
map.getCoherentIntervalSeconds(); // Integrated pulses/PRF.
map.getDopplerOrder();
```

Range crops update their origin. Pulse crops update their first-pulse timestamp.
Changing the map's Doppler order shifts IQ and metadata together, including odd
FFT lengths. Changing a detection list's Doppler order instead remaps its integer
indices on device, retaining detection ordering and physical frequencies. These
are explicit operations, not constructor side effects. To match a shifted RDM,
remap its associated detection list explicitly too.

Changing first range, spacing, pulse count or CPI metadata is a metadata-only
setter; the caller must ensure it describes the actual data. Changing PRF updates
derived Doppler spacing immediately because it is computed from current metadata.
Scalar `DetectionList::getRangeMetersForBin()` / `getDopplerHzForBin()` accept BIN
indices supplied by the caller, not detection positions or device values.
`getRangesMeters()` / `getDopplerHz()` compute whole f32 coordinate arrays on device.

## Detection and azimuth handoff

```cpp
#include <radar/DetectionList.hpp>
#include <radar/interferometry/Interferometry1D.hpp>

// cells = u32 [K], amplitude/SNR = f32 [K]. One representative c32 I/Q is gathered.
auto detections = radar::DetectionList::fromMap(sumBeamRdm, cells, amplitudes, snrDb, 0);

const radar::interferometry::Interferometry1D estimator(
    elementSpacingMeters,       // Real effective phase-center spacing.
    /* detectionBatchSize */ 4096
);
auto located = estimator.estimate(phaseCenteredRdm, detections);
// Or: detections = estimator.estimate(phaseCenteredRdm, detections);

const auto& azimuthDevice = located.getAzimuthRadians(); // f32 [K], radians.
// located.getHasAzimuth() == true; located.getHasElevation() == false.
const auto records = located.recordsToHost(); // EXPLICIT final numerical download.
```

`fromCells()` accepts already-gathered representative c32 IQ and avoids that gather.
`estimate()` takes const-reference inputs, retains the five base column handles,
and attaches only a new azimuth column. It clears old azimuth/elevation fields on
the returned copy, without changing the input list. No zero elevation is fabricated.
Empty results also have azimuth present (empty), and elevation absent.

`getDetection(i)` returns a one-entry DEVICE list, not a host `Detection&`.
`recordsToHost(batchSize)` explicitly exports complete records with bounded staging;
there is no persistent CPU mirror.

There is exactly one public estimate function:

```cpp
DetectionList estimate(const RangeDopplerMap& phaseCenteredRdm,
                       const DetectionList& detections) const;
```

The detector sees only the sum beam, `[Doppler,range,1]`. Interferometry receives
one **phase-centered RDM**, `[Doppler,range,element]`, whose planes retain the
coherent measurements of the individual elements or subarray phase centers.
Both maps must share the same CPI, range/Doppler grid and ordering. Interferometry
gathers just the detected cells into small `[element,batchDetection]` scratch
arrays internally. The detector does not gather or pass elemental IQ, and the
single representative I/Q in a detection is not used to estimate azimuth.

The same API accepts elemental or coherent subarray planes: supply their real
effective phase-center spacing to the constructor. One combined sum-beam plane
alone is not a valid angle-estimation input. Collection-of-maps and pre-gathered
array overloads are removed, with no compatibility wrappers.

## Azimuth-only interferometry

The only algorithm class is `Interferometry1D`, configured with physical spacing
and an optional positive integer batch size (default 4096). Wavelength comes from
detection CPI metadata and element count is inferred from input. No array-geometry
classes, elevation prior, spatial-sign switch, or steering-reference configuration.
The removed two-dimensional estimator is not built or retained as an alias.

Fixed frame: +x boresight, +y positive azimuth, +z up; elements are ordered along +y.
The horizontal-plane model is `x(y) = A * exp(+j*2*pi*y*sin(azimuth)/wavelength)`.
The output is radians on the forward branch. A line alone cannot separate elevation
from azimuth: off the horizontal plane the result is the apparent angle
`asin(cos(elevation)*sin(azimuth))`, not true azimuth at arbitrary elevation.
Normalize other phase conventions/calibration upstream. Effective subarray centers
must be uniformly spaced; ambiguity resolution is not provided. See
`interferometry/README.md` for the exact input and field-of-view contracts.

**Constructor migration:** the second argument is now `detectionBatchSize`, NOT
an elevation angle. Change `(spacing, elevation, batch)` to `(spacing, batch)` only
when the horizontal-plane assumption is valid. Change old `(spacing, 0.0)` calls
to `(spacing)`; do not accidentally pass zero as a batch size.

## Performance

The retained paths prepare RDM views and the wavelength/spacing scale once per
estimate and gather only selected cells in bounded blocks. The phase math,
internal packed gather and batching are unchanged from v16. The obsolete public
input routes and their unused helpers are deleted. Only azimuth is written. No
elevation fill, evaluation, or output allocation is performed. Production sources
contain no explicit host/scalar readback, synchronization or data-dependent `where()`.
No new validators, native CUDA code, persistent caches, or full-map joins were added.

`PERFORMANCE.md` describes logical memory costs and the two disabled timing tests
in their respective radar and interferometry test runners. Actual CPU/GPU speed and peak allocation have
not been measured here; less output work is not a quantified latency guarantee.

## Memory and unchecked contracts

Required logical detection storage is `24*K` bytes. Each present angle column
adds `4*K` bytes (32*K with both). This estimator returns 28*K bytes of logical
record payload (base columns plus azimuth only). This excludes handles, allocator rounding,
shared views and temporary computations. Interferometry's principal c32 block
is `8*E*min(K,batchSize)` bytes; other buffers and asynchronous work also use memory.
No peak-allocation or measured speed guarantee is made.

The wrappers have no dtype, shape, finite-value, index, device or overflow scans.
Supply correct c32 IQ, aligned columns, valid dimensions and the same active
backend/device. Invalid input is a caller precondition violation. `setData()`
requires an unchanged shape because cached dimensions are not re-inferred.
Batch sizes must be positive. Whole-grid linear indices/FFT lengths used by
sparse operations must fit u32, and products/counts must fit dim_t and size_t.

`clone()` is an explicit deep copy; ordinary array copies retain handles. Views
can keep parent allocations alive. `flat()` / `moddims()` of noncontiguous views
may materialize data; use contiguous owned RDMs on the low-memory gather path.
Evaluation, allocation and ArrayFire internals can synchronize (e.g. `where()`
needs a compacted count). Device residency is not a claim of zero host work or
zero implicit backend waits. Explicit `synchronize()` is for intentional fences.

## CPI helpers

CPI_Metadata remains numeric: sample rate, PRF, RF carrier, bandwidth, timing,
CPI ID and Doppler sign convention. The fourth constructor argument is waveform
bandwidth Hz; the optional fifth is CPI ID. Uniform-PRF monostatic helpers remain:

| Getter | Definition |
|---|---|
| getUnambiguousRangeMeters | c/(2*PRF) |
| getMinUnambiguousDopplerHz | -PRF/2 |
| getMaxUnambiguousDopplerHz | +PRF/2, exclusive |
| getUnambiguousDopplerSpanHz | PRF |
| getMaxUnambiguousSpeedMps | wavelength*PRF/4 |
| getNominalRangeResolutionMeters | c/(2*bandwidth), not sample spacing |
| getFirstSampleRangeMeters | c*rawSampleZeroDelay/2 |
| getSampleRangeSpacingMeters | c/(2*ADC sample rate) |

Processed range calibration remains with the stage data, not CPI_Metadata.

## Build

Use a clean directory after extracting `radar-chain-types-v19`.
CMake 3.20+, C++20, ArrayFire 3.10+; GoogleTest 1.11+ only when tests are enabled.
CMake requires ArrayFire 3.10 or newer. There is no project ArrayFire wrapper/version header.
No automatic dependency downloads or test framework in the exported libraries.

```sh
# Libraries only (default).
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release --parallel

# Libraries and GoogleTest suites, using CUDA through ArrayFire's unified backend.
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release --no-tests=error --output-on-failure

# Only the fake/reference chain tests.
ctest --test-dir build-tests -C Release -R "PipelineTests" -V --no-tests=error
```

Windows/Visual Studio: add `-A x64` when configuring and, if needed,
`-DCMAKE_PREFIX_PATH="$env:AF_PATH"`. Linux/WSL uses `-DCMAKE_PREFIX_PATH="$AF_PATH"`.
Supply GTest_DIR/CMAKE_PREFIX_PATH for a nonstandard GoogleTest install. Runtime
libraries must be visible to the loader. Use cpu/opencl instead of cuda as needed.
For a directly linked backend use `RADAR_ARRAYFIRE_BACKEND=CPU|CUDA|OPENCL`, leave
RADAR_TEST_BACKEND empty, unset its environment override, and pass no backend argument.

Consumers link `radar::chain_types` or `radar::interferometry`; these are still
independent targets. `radar::metadata` (CPI_Metadata/host Detection) is available separately. With no
ArrayFire SDK, set `RADAR_BUILD_ARRAYFIRE_TYPES=OFF` to build that host library.
Without ArrayFire, tests cover CPI_Metadata and host Detection only. All
interferometry tests now live in one ArrayFire-linked test executable.
Tests are opt-in even when a parent sets BUILD_TESTING=ON. No examples/executable
applications are part of a default library build. See `tests/README.md`.

All seven classes have individual .hpp/.cpp files, private fields and Doxygen
comments. Include concrete headers: the removed umbrellas/config/alias have not
returned. `radar_docs` is available when Doxygen is installed. Container recipes
are retained in Dockerfile/CONTAINER.md but are not certified as executed here.

See VALIDATION.md for actual build/test status. Source review is not an
ArrayFire CPU/CUDA integration or performance certification.

## Separate library tests

Radar datatype tests have one `test_*.cpp` file per class and CPI_Metadata.
`tests/test_arrayfire.cpp` holds only the fake/reference chains, the optional
radar timing case, and this runner's backend setup. None of these sources or the
`radar_arrayfire_tests` target depends on interferometry.

All interferometry cases, including its scalar reference and disabled timing
case, are in `interferometry/tests/test_interferometry.cpp`, compiled into the
separate `radar_interferometry_tests` executable. Each binary links
`GTest::gtest_main`; there is no separate custom main source or test-support header.

Linux/WSL, after configuring the desired backend:

```sh
./build-tests/tests/radar_arrayfire_tests
./build-tests/interferometry/tests/radar_interferometry_tests
./build-tests/tests/radar_arrayfire_tests --gtest_filter='PipelineTests.*' --gtest_repeat=10
```

Visual Studio / PowerShell:

```powershell
.\build-tests\tests\Release\radar_arrayfire_tests.exe
.\build-tests\interferometry\tests\Release\radar_interferometry_tests.exe
```

Do not append a positional backend argument. RADAR_TEST_BACKEND in the environment
can override the CMake-selected default for unified builds. Disable interferometry
with `RADAR_BUILD_INTERFEROMETRY=OFF` to build and run only the radar tests.
Source mapping, filters and metadata-only tests are documented in tests/README.md.
