# Validation — v19 (0.19.0)

Baseline: the corrected `radar-chain-types-v18-revised.zip` (0.18.1), not the
superseded combined-test v18. Its ZIP CRCs and SHA-256 manifest were verified
before editing. This release changes only special-member declarations and their
documentation/tests, plus the version identifiers and static audit tool.

## Executed here

| Check | Result |
|---|---|
| C++20 metadata-only Release configure/build, GCC 14.2 | Passed, warnings treated as errors |
| Same metadata build, Clang 17 | Passed, warnings treated as errors |
| Real CPI_Metadata/Detection special-member smoke program, GCC | Passed on both baseline and v19 |
| Same smoke program, Clang | Passed on both baseline and v19 |
| v19 smoke program with GCC AddressSanitizer + UndefinedBehaviorSanitizer | Passed, no sanitizer diagnostics |
| Host size/alignment/triviality/noexcept comparison | Same baseline/v19 results on both compilers |
| Source/Doxygen organization audit | 7 library classes, 52 private fields, 232 documented declarations |
| Explicit-default inventory | 35 in-class declarations, exactly five per library class |
| Source scope and existing-test comparison | Passed; details below |
| Docker script shell syntax | All four scripts passed `bash -n` |

The standalone program uses the **actual** CPI_Metadata and Detection headers and
implementations. It exercises copy construction, move construction, copy assignment,
move assignment, complete reassignment, scoped ownership of host values, and optional
angles. It also compiles type-trait assertions. Its source is archived as
`validation/host-special-members.cpp.txt`; it is not a project executable, alternate
test framework, GoogleTest replacement or ArrayFire mock.

Observed host traits on this x86-64 Linux toolchain:

| Class | Size | Alignment | Trivially copyable | Nothrow move construction/assignment |
|---|---:|---:|---|---|
| CPI_Metadata | 64 bytes | 8 bytes | Yes | Yes / yes |
| Detection | 40 bytes | 4 bytes | Yes | Yes / yes |

Both GCC and Clang produced those values for the baseline and revision. This is
not a guarantee about another standard library/platform's ABI, and it does not
measure ArrayFire wrapper size or exception traits.

Compiler logs and commands are under `validation/`. Sanitizers were run with leak
detection and halt-on-error. No new or earlier scalar radar-model check count is
presented as a substitute for executing the actual GPU/GoogleTest cases.

## Scope audit

All seven production CPP files and all three non-class production headers are
byte-for-byte unchanged. Each of the seven class headers differs only by its five
in-class default declarations and Doxygen lifetime notes. After removing comments
and the 35 declarations, production token text matches corrected v18.

No field, data layout, kernel, calculation, constructor body, slice, host-transfer,
array allocation, explicit synchronization or GC policy changed. The root CMake
change is only version `0.18.1 -> 0.19.0`; both libraries' CMake files and both test
CMake files are unchanged. The two test-program Environments are unchanged.

All **44 pre-existing TEST bodies** match the baseline. Seven new
`CopyMoveSemantics` cases were appended to the existing per-class test files; the
remaining file stays unchanged. No custom main, test-support header, dependency,
extra test executable or new test source file was introduced. Interferometry and
its tests remain separate from the radar-types library/tests.

The static audit is text analysis, not a substitute for a C++ compiler or Doxygen.

## Real dependency attempts and limitations

A full CMake configure was attempted and failed because ArrayFire 3.10's config
package is not installed. A metadata-only tests-enabled configure failed because
GoogleTest 1.11's config package is not installed. An official GoogleTest-header
network probe failed at DNS resolution. Exact diagnostics and exit statuses are
in `real-arrayfire-configure.txt`, `real-gtest-configure.txt`, `network-probe.txt`
and `commands.json`.

**The ArrayFire-backed classes, Interferometry1D and actual GoogleTest suites have
NOT been compiled/linked/run against their real dependencies here.** The source
checks do not prove those defaulted special members are usable with every ArrayFire
build; the added trait assertions and runtime regressions will check your SDK.
No stand-in SDK/GoogleTest header was used. No CPU/CUDA/OpenCL integration, Docker
image execution, Windows/MSVC build, latency or device-memory measurement is claimed.

## GoogleTest cases supplied for the installed SDK

| Runner | Cases | Disabled timing cases |
|---|---:|---:|
| radar_metadata_tests | 7 | 0 |
| radar_arrayfire_tests | 22 | 1 |
| radar_interferometry_tests | 22 | 1 |
| Total | 51 | 2 |

These are source counts, **not executed GoogleTest results**. The four new
ArrayFire-owner cases check a small moved/copied result after local source wrappers
leave scope, then make one final export. They do not inspect a moved-from wrapper
except to assign a complete valid object back to it. Metadata, calibration, count
and optional-angle preservation are checked without timing thresholds. The
estimator's new case checks its two scalar configuration values.

```sh
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release -R 'CopyMoveSemantics' --no-tests=error --output-on-failure
ctest --test-dir build-tests -C Release --no-tests=error --output-on-failure
```

Use installed dependency paths as necessary. GoogleTest 1.11 compatibility, C++20,
ArrayFire 3.10 and optional tests remain. Libraries build without test dependencies.

## Archive

`SHA256SUMS` lists all packaged files except itself. The final ZIP was reopened,
its CRCs tested and every manifest entry compared to its actual bytes. No build
products, downloaded SDKs or previous-release test-result logs are shipped.
