# Migration: corrected v18 (0.18.1) -> v19 (0.19.0)

## Explicit defaulted special members in every library class

Each of the seven public library classes declares the destructor, copy constructor,
copy assignment, move constructor and move assignment as `= default` **inside its
own class header**. All 35 declarations have Doxygen comments.

| Class | Header |
|---|---|
| `CPI_Metadata` | `include/radar/CPI_Metadata.hpp` |
| `Detection` | `include/radar/Detection.hpp` |
| `SamplePulseBuffer` | `include/radar/SamplePulseBuffer.hpp` |
| `RangePulseBuffer` | `include/radar/RangePulseBuffer.hpp` |
| `RangeDopplerMap` | `include/radar/RangeDopplerMap.hpp` |
| `DetectionList` | `include/radar/DetectionList.hpp` |
| `Interferometry1D` | `interferometry/include/radar/interferometry/Interferometry1D.hpp` |

Example:

```cpp
~SamplePulseBuffer() = default;
SamplePulseBuffer(const SamplePulseBuffer&) = default;
SamplePulseBuffer& operator=(const SamplePulseBuffer&) = default;
SamplePulseBuffer(SamplePulseBuffer&&) = default;
SamplePulseBuffer& operator=(SamplePulseBuffer&&) = default;
```

There is no hand-written cleanup, virtual destructor, move-reset logic or forced
`noexcept`. The compiler derives exception specifications from the members. Copy
and move operations remain memberwise; declaring all five avoids suppressing move
operations by declaring only a destructor. Defaulting at the first declaration
keeps ordinary triviality eligibility and inlining; it is not an out-of-line body.

No zero-argument constructors were added, no APIs were removed or renamed, and no
call-site migration is required. Rebuild consumers against the revised headers.
Existing `Detection()` construction is unchanged; metadata still needs its required
acquisition values. Class fields and all production CPP/helper bodies are unchanged.

## Ownership and moved-from contract

- ArrayFire members manage retention/release. An ordinary wrapper copy is not an
  explicit numerical clone. `clone()` is still the deep-copy route.
- Defaulted move operations do not reset scalar dimensions/counts in the source.
  Optional array fields may remain engaged around moved-from array handles.
- After moving from an array-backed wrapper, only destroy it or completely reassign
  it before using it for processing. No empty-source or self-move guarantee is added.
- Destruction does not request a host download, explicit `sync()`, raw-pointer free
  or `deviceGC()`. Last-reference and allocator behavior remain ArrayFire's responsibility.

These defaults expose the same policy as the prior implicit special members; they
are not a performance optimization or a new device-memory-management scheme.

## Tests and library boundary

Each existing type test file gains one short `CopyMoveSemantics` case and compile-time
availability checks. Tests cover copy/move construction and assignment, full
reassignment of a moved-from variable, retained calibration/optional fields, and
ArrayFire values surviving their local source wrappers (real SDK execution required).
Interferometry's case stays in its one `interferometry/tests/test_interferometry.cpp`.

No custom main, test-support header, executable, CUDA code or dependency was added.
GoogleTest 1.11+, ArrayFire 3.10+, C++20 and tests-off-by-default are retained.
The two program-level test Environments and all prior TEST bodies are unchanged.
Radar tests do not link or include interferometry.

```sh
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release -R 'CopyMoveSemantics' --no-tests=error --output-on-failure
```

Use `cpu` for the CPU backend, and the actual ArrayFire/GoogleTest paths as needed.
Read `VALIDATION.md`: supplied SDK-dependent tests are not reported as executed
unless the actual dependencies were available.
