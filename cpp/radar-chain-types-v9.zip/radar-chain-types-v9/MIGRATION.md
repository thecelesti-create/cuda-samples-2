# Migration from v8 to v9

## Libraries by default

`RADAR_BUILD_TESTS` is a new project-scoped option, **OFF by default**. A normal
configure/build produces the libraries only. There is no `RADAR_BUILD_EXAMPLES`
option, `examples/` directory, or standalone demo target.

All public class headers and library implementations are byte-for-byte unchanged
from v8. The four link targets remain:

```cmake
radar::chain_types
radar::interferometry
radar::metadata
radar::array_geometry
```

The optional-angle detection model, explicit c32 APIs, Doxygen, C++20, ArrayFire
3.10 requirement, unchecked accessors and library data movement are unchanged.

## New test configuration

Replace the old `-DBUILD_TESTING=ON -DRADAR_BUILD_EXAMPLES=ON` switches with:

```sh
-DRADAR_BUILD_TESTS=ON
```

Neither the parent's `BUILD_TESTING` option nor a previous cached value controls
radar tests. This keeps consumer builds from accidentally adding test binaries.
Use a clean build directory to avoid stale targets/executables from v8.

```sh
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --parallel
ctest --test-dir build-tests --no-tests=error --output-on-failure
```

Add your ArrayFire prefix when necessary. With Visual Studio use `-A x64` when
configuring and `--config Release` / `-C Release` for build / CTest.

## Where the examples went

| v8 program | v9 test source | Existing test runner |
|---|---|---|
| `examples/simple_demo.cpp` | `tests/simple_pipeline_tests.cpp` | `radar_arrayfire_tests` |
| `examples/pipeline.cpp` | `tests/reference_pipeline_tests.cpp` | `radar_arrayfire_tests` |
| `interferometry/examples/interferometry_demo.cpp` | `interferometry/tests/synthetic_array_tests.cpp` | `radar_interferometry_tests` |

The converted files contain test functions, not `main()`. Their helpers are
private to their translation units. All example logic is compiled into the
existing runners only when tests are enabled; it is not exported by the libraries.

The fake chain checks its final five detection values and c32/dimension contracts.
The reference chain now uses a deterministic noiseless echo (instead of seeded
random noise) to assert range bin 18, Doppler bin 3, amplitude 112 and the assumed
noise-model SNR. A high-threshold case checks the empty-result path. The array
case asserts 20/10-degree angles and preservation of the five core fields.

The old output-regex `verify_simple_demo.cmake` is removed. C++ assertions in the
test cases run in Release too, using the existing test helper (not C `assert`).

## Runner locations and containers

All four runners are under `build-tests/tests/`, or
`build-tests/tests/Release/` for Visual Studio. Prefer CTest so paths/backend
arguments are handled automatically. The CTest names are `radar_metadata`,
`radar_arrayfire`, `radar_interferometry_reference` and `radar_interferometry`.

Docker build scripts opt into `RADAR_BUILD_TESTS=ON` and use the new runner paths.
The runtime script runs those four test executables only; there is no separate
sample-verifier or demo step. Unit labels identify the two scalar suites;
ArrayFire-backed pipelines/estimators retain integration labels.

Actual executed checks and SDK limitations are recorded in `VALIDATION.md`.
