#include <radar/interferometry/Interferometry.hpp>
#include "test_support.hpp"
#include "synthetic_array_tests.hpp"
#include <cmath>
#include <limits>
#include <string>
#include <vector>
using namespace radar;
using namespace radar::interferometry;

/** @brief Upload a u32 index column. */
af::array ids(std::initializer_list<unsigned> v) {return af::array(static_cast<dim_t>(v.size()),v.begin(),afHost);}
/** @brief Make a c32 map with uniform phase-center geometry and one source in every cell. */
RangeDopplerMap makePlane(std::size_t ny,std::size_t nz,double az,double el,
                          PhaseSign sign=PhaseSign::Positive,double u0=0,double v0=0) {
    constexpr dim_t D=8,R=6;
    const CPI_Metadata m(10e6,2000,10e9,5e6,12);
    std::vector<af::cfloat> iqC32(static_cast<std::size_t>(D*R)*ny*nz);
    const double u=std::cos(el)*std::sin(az),v=std::sin(el);
    for(std::size_t z=0;z<nz;++z) for(std::size_t y=0;y<ny;++y) {
        const double phase=static_cast<int>(sign)*pi*(static_cast<double>(y)*(u-u0)+static_cast<double>(z)*(v-v0));
        for(dim_t r=0;r<R;++r) for(dim_t d=0;d<D;++d) {
            const double gain=1+0.1*static_cast<double>(y+z);
            iqC32[static_cast<std::size_t>(d+D*r)+static_cast<std::size_t>(D*R)*(y+ny*z)] =
                {static_cast<float>(gain*std::cos(phase)),static_cast<float>(gain*std::sin(phase))};
        }
    }
    return {af::array(af::dim4(D,R,static_cast<dim_t>(ny*nz)),iqC32.data(),afHost),
            m,RangeAxis(100,10),DopplerAxis(D,4,m.getPrfHz())};
}
/** @brief Make five records in nontrivial order, including duplicate cells. */
DetectionList detected(const RangeDopplerMap& map) {
    return DetectionList::fromMap(map,ids({10,45,10,0,35}),
        af::constant(1.0f,af::dim4(5),f32),af::constant(20.0f,af::dim4(5),f32));
}
/** @brief Verify inferred angle columns and preservation of the five original values. */
void checkAngles(const DetectionList& output,double az,double el) {
    test::check(output.getHasAngles(),"optional angles attached");
    test::check(output.getAzimuthRadians().type()==f32 && output.getElevationRadians().type()==f32,"angle f32");
    const auto records=output.recordsToHost();
    test::check(records.size()==5,"detection count");
    for(const auto& r:records) {
        test::near(*r.getAzimuthRadians(),az,3e-5);test::near(*r.getElevationRadians(),el,3e-5);
        test::near(r.getAmplitude(),1);test::near(r.getSnrDb(),20);
    }
    test::check(records[0].getRangeIndex()==1 && records[0].getDopplerIndex()==2,"cell preserved");
    test::check(records[2].getRangeIndex()==1 && records[2].getDopplerIndex()==2,"duplicate preserved");
    test::near(output.getMetadata().getBandwidthHz(),5e6);
}
/** @brief Run the real ArrayFire estimators on packed, separate-map and pre-gathered input. */
int main(int argc,char** argv) {
    try {
#if RADAR_ARRAYFIRE_UNIFIED
        const std::string backend=argc>1?argv[1]:"cpu";
        if(backend=="cpu") af::setBackend(AF_BACKEND_CPU);
        else if(backend=="cuda") af::setBackend(AF_BACKEND_CUDA);
        else if(backend=="opencl") af::setBackend(AF_BACKEND_OPENCL);
        else throw std::invalid_argument("Unknown backend");
#else
        (void)argc;(void)argv;
#endif
        af::setDevice(0);
        test::run("1D both signs, elevation prior and blocks", [] {
            const double az=0.25,el=0.12;
            for(auto sign:{PhaseSign::Positive,PhaseSign::Negative}) {
                const auto map=makePlane(5,1,az,el,sign);
                const auto list=detected(map);
                for(std::size_t block:{1u,2u,8u}) {
                    const Interferometry1D estimator(UniformLinearArray(5,map.getMetadata().getWavelengthMeters()/2,el,sign),block);
                    const auto result=estimator.estimate(map,list);
                    checkAngles(result,az,el);
                    test::check(!list.getHasAngles(),"estimator leaves input unmodified");
                }
            }
        });
        test::run("2D paths, duplicate cells, phase reference and independent list source", [] {
            const double az=0.35,el=0.17,u0=0.1,v0=-0.1;
            const auto map=makePlane(4,3,az,el,PhaseSign::Negative,u0,v0);
            const auto sumBeam=makePlane(1,1,az,el);
            const auto list=detected(sumBeam); // Deliberately not a 12-element source.
            const Interferometry2D estimator(UniformRectangularArray(4,3,
                map.getMetadata().getWavelengthMeters()/2,map.getMetadata().getWavelengthMeters()/2,
                PhaseSign::Negative,u0,v0),2);
            checkAngles(estimator.estimate(map,list),az,el);
            std::vector<RangeDopplerMap> maps;
            for(dim_t e=0;e<12;++e) maps.emplace_back(map.getElementC32(e),map.getMetadata(),map.getRangeAxis(),map.getDopplerAxis());
            checkAngles(estimator.estimate(std::span<const RangeDopplerMap>(maps),list),az,el);
            const auto planes=af::moddims(map.getDataC32(),48,12);
            const af::array elementIqC32=af::reorder(af::lookup(planes,ids({10,45,10,0,35}),0),1,0,2,3);
            checkAngles(estimator.estimate(elementIqC32,list),az,el);
            auto previous=list;previous.setAngles(af::constant(0,af::dim4(5),f32),af::constant(0,af::dim4(5),f32));
            checkAngles(estimator.estimate(map,previous),az,el);
        });
        test::run("empty and undefined angles stay on the standard list", [] {
            auto map=makePlane(2,2,0.0,0.0);
            const Interferometry2D estimator(UniformRectangularArray(2,2,
                map.getMetadata().getWavelengthMeters()/2,map.getMetadata().getWavelengthMeters()/2));
            const auto empty=estimator.estimate(map,DetectionList(map));
            test::check(empty.getIsEmpty() && empty.getHasAngles(),"empty processed list");
            map.setDataC32(af::constant(0.0f,map.getDimensions(),c32));
            const auto output=estimator.estimate(map,detected(map));
            for(const auto& r:output.recordsToHost()) {
                test::check(r.getAzimuthRadians() && std::isnan(*r.getAzimuthRadians()),"present NaN azimuth");
                test::check(r.getElevationRadians() && std::isnan(*r.getElevationRadians()),"present NaN elevation");
            }
        });
        test::runSyntheticArrayTests();
        af::sync();
        std::cout<<test::checks<<" real ArrayFire interferometry checks passed\n";
        return 0;
    } catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
