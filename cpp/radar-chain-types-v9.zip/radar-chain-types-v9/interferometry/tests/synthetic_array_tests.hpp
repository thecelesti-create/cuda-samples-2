#pragma once

namespace test {
/** @brief Check the former 4-by-3 array demo numerically.
 *  @pre The test runner has selected the ArrayFire backend and device. */
void runSyntheticArrayTests();
} // namespace test
