#!/usr/bin/env bash
set -Eeuo pipefail
if (( $# > 1 )); then echo 'Usage: run-tests.sh [cpu|cuda]' >&2; exit 2; fi
backend="${1:-${RADAR_DEFAULT_BACKEND:-cpu}}"
case "$backend" in cpu|cuda) ;; *) echo 'Backend must be cpu or cuda' >&2; exit 2;; esac
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
logs="${RADAR_TEST_LOG_DIR:-/tmp/radar-test-logs}"
mkdir -p "$logs"
# Test executables select the requested backend; failures never trigger fallback.
# The fake/reference pipelines and synthetic angle case are inside these runners.
printf 'Requested backend: %s\n' "$backend" | tee "$logs/requested-backend.txt"
"$root/build/tests/radar_metadata_tests" 2>&1 | tee "$logs/metadata.txt"
"$root/build/tests/radar_arrayfire_tests" "$backend" 2>&1 | tee "$logs/arrayfire-$backend.txt"
"$root/build/tests/radar_interferometry_reference_tests" 2>&1 | tee "$logs/interferometry-reference.txt"
"$root/build/tests/radar_interferometry_tests" "$backend" 2>&1 | tee "$logs/interferometry-$backend.txt"
printf 'All requested %s tests passed. Logs: %s\n' "$backend" "$logs"
