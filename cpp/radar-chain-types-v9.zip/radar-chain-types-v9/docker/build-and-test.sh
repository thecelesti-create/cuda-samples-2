#!/usr/bin/env bash
set -Eeuo pipefail
jobs="${1:-2}"
[[ "$jobs" =~ ^[1-9][0-9]*$ ]] || { echo 'BUILD_JOBS must be positive' >&2; exit 2; }
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$root/build/validation"
cmake -S "$root" -B "$root/build" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_STANDARD=20 \
    -DCMAKE_PREFIX_PATH="${AF_PATH:-/opt/arrayfire}" \
    -DRADAR_ARRAYFIRE_BACKEND=UNIFIED -DRADAR_TEST_BACKEND=cpu \
    -DRADAR_BUILD_TESTS=ON \
    2>&1 | tee "$root/build/validation/configure.txt"
cmake --build "$root/build" --parallel "$jobs" \
    2>&1 | tee "$root/build/validation/build.txt"
# Run real CPU backend checks during BOTH image builds. Never request CUDA here.
ctest --test-dir "$root/build" --no-tests=error --verbose --output-on-failure \
    2>&1 | tee "$root/build/validation/ctest-cpu.txt"
