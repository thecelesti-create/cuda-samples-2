# Tests

No test executable or example application is built by default. Opt in from the
repository root with `-DRADAR_BUILD_TESTS=ON`. No external test framework is
required; these suites use the existing lightweight `test_support.hpp` helpers.
Assertions are ordinary checked functions and remain active in Release builds.

## Source map

| CTest name | Sources | Scope |
|---|---|---|
| `radar_metadata` | `metadata_tests.cpp` | Scalar metadata and host detection values |
| `radar_arrayfire` | `arrayfire_tests.cpp`, `simple_pipeline_tests.cpp`, `reference_pipeline_tests.cpp` | ArrayFire types and complete pipeline handoffs |
| `radar_interferometry_reference` | `interferometry/tests/reference_math_tests.cpp` | Independent scalar phase-model oracle |
| `radar_interferometry` | `interferometry/tests/arrayfire_tests.cpp`, `interferometry/tests/synthetic_array_tests.cpp` | Actual ArrayFire estimators and the former angle demo |

Paths in the last two rows are relative to the repository root. Each former
example lives in a separate test source/header pair and is called by an existing
runner; there is no added application or exported library algorithm.

## Expected fixtures

- Fake pipeline: gain by two, reorder only, cell-zero detector. One record with
  range/Doppler indices 0/0, amplitude 2, SNR 6.0206 dB and I/Q 2+0i. All three
  fake algorithm functions remain visible together in `simple_pipeline_tests.cpp`.
- Reference pipeline: noiseless seven-chip Barker echo starting at sample 18,
  16 pulses with a bin-3 tone. The matched filter removes the correlation delay;
  the unnormalized pulse FFT produces amplitude 112. A power threshold of 3000
  selects the single peak. SNR is 10*log10(112) dB for the explicitly assumed noise
  power 112; it is not a noise estimate from the noiseless data.
- Synthetic angle case: twelve phase centers in a 4x3 grid, half-wavelength
  spacing, detection at range/Doppler indices 5/2, direction 20/10 degrees.

Expected fixture values are not a claim that an ArrayFire backend ran. Consult
`../VALIDATION.md` for the executed checks and remaining limitations.

## Run

```sh
cmake -S . -B build-tests -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --parallel
ctest --test-dir build-tests --no-tests=error --output-on-failure
ctest --test-dir build-tests -L unit --no-tests=error --output-on-failure
ctest --test-dir build-tests -L arrayfire --no-tests=error --output-on-failure
```

Run those commands from the repository root; supply the installed ArrayFire prefix
as needed. For Visual Studio add `--config Release` to the build and `-C Release`
to CTest. Replace `cuda` with `cpu` for CPU tests. Requested backends must exist;
there is no automatic skip or silent fallback when a backend is unavailable.

The former demos are multi-stage integration tests. They are in the test tree but
are not mislabeled as isolated scalar unit tests. CUDA tests do not establish
latency, memory use or production radar accuracy. Test-only host exports and
checks do not change the unchecked library hot paths.
