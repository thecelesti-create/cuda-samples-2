#pragma once

namespace test {
/** @brief Run the deterministic matched-filter, Doppler and detector fixture.
 *  @pre The test runner has selected the ArrayFire backend and device. */
void runReferencePipelineTests();
} // namespace test
