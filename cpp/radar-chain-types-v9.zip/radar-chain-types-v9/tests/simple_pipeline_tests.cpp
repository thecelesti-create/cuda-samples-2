#include "simple_pipeline_tests.hpp"
#include "test_support.hpp"
#include <radar/radar.hpp>
#include <cmath>
#include <utility>
#include <vector>

// Test-only placeholders, not implementations exported by either library.
namespace {
/** @brief FAKE matched filter: multiply c32 IQ by two; no pulse compression. */
radar::RangePulseBuffer fakeMatchedFilter(const radar::SamplePulseBuffer& input) {
    af::array iqC32 = input.getDataC32() * 2.0f;
    return {input, std::move(iqC32), radar::RangeAxis::fromRoundTripTiming(
        input.getMetadata().getFirstSampleDelaySeconds(), input.getMetadata().getSampleRateHz())};
}
/** @brief FAKE Doppler: reorder to [pulse,range,element]; deliberately no FFT. */
radar::RangeDopplerMap fakeDoppler(const radar::RangePulseBuffer& input) {
    return {input, input.getDopplerInputC32(), radar::DopplerOrder::Unshifted};
}
/** @brief FAKE detector: select cell zero in element zero and assume unit noise power. */
radar::DetectionList fakeDetector(const radar::RangeDopplerMap& input) {
    af::array cells = af::constant(0u, af::dim4(1), u32);
    af::array iqC32 = af::lookup(af::flat(input.getElementC32(0)), cells, 0);
    af::array amplitudes = af::abs(iqC32);
    af::array snrDb = 20.0f * af::log10(amplitudes); // 10*log10(amplitude^2 / 1).
    return radar::DetectionList::fromCells(input, std::move(cells),
        std::move(amplitudes), std::move(snrDb), std::move(iqC32));
}
} // namespace

namespace test {
/** @brief Keep the original three-stage usage pattern as a repeatable test. */
void runSimplePipelineTests() {
    run("three fake algorithms preserve types and detection values", [] {
        constexpr dim_t sampleCount = 8, pulseCount = 4, elementCount = 3;
        const radar::CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6, 1);
        const std::vector<af::cfloat> hostIqC32(
            sampleCount * pulseCount * elementCount, {1.0f, 0.0f});
        const auto samples = radar::SamplePulseBuffer::fromHost(
            hostIqC32, sampleCount, pulseCount, elementCount, metadata);

        // One input upload, no numerical host readback between algorithms.
        const auto ranges = fakeMatchedFilter(samples);
        const auto map = fakeDoppler(ranges);
        const auto detections = fakeDetector(map);

        check(samples.getDataC32().type() == c32, "sample IQ is c32");
        check(ranges.getDataC32().type() == c32, "range IQ is c32");
        check(map.getDataC32().type() == c32, "RDM IQ is c32");
        check(ranges.getRangeBinCount() == sampleCount &&
              ranges.getPulseCount() == pulseCount &&
              ranges.getElementCount() == elementCount, "range-stage dimensions");
        check(map.getDopplerBinCount() == pulseCount &&
              map.getRangeBinCount() == sampleCount &&
              map.getElementCount() == elementCount, "Doppler-first dimensions");
        near(detections.getMetadata().getBandwidthHz(), metadata.getBandwidthHz());
        check(!detections.getHasAzimuth() && !detections.getHasElevation(), "no fabricated angles");
        check(detections.getComplexPairsC32().type() == c32, "detection IQ is c32");

        // Assertions read the small final result, not intermediate cubes.
        const auto records = detections.recordsToHost();
        check(records.size() == 1, "fake detector returns one record");
        const auto& record = records.front();
        check(record.getRangeIndex() == 0 && record.getDopplerIndex() == 0, "selected cell zero");
        near(record.getAmplitude(), 2.0, 1e-5);
        near(record.getSnrDb(), 20.0 * std::log10(2.0), 1e-5);
        near(record.getComplexPairC32().real(), 2.0, 1e-5);
        near(record.getComplexPairC32().imag(), 0.0, 1e-5);
        check(!record.getAzimuthRadians() && !record.getElevationRadians(), "host optional fields absent");
    });
}
} // namespace test
