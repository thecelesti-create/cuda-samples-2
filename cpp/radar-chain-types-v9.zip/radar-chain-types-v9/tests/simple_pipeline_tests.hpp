#pragma once

namespace test {
/** @brief Run the three fake algorithms as checked data-flow tests.
 *  @pre The test runner has selected the ArrayFire backend and device. */
void runSimplePipelineTests();
} // namespace test
