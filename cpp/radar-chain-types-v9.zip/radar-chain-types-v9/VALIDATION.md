# Validation report — v0.9

This revision moves example programs into the existing test suites and makes
library-only builds the default. The public API and numerical library source
are unchanged from v8.

## Executed against this revision

| Check | Result |
|---|---|
| GCC 14.2 C++20 scalar suites | 539 metadata + 600 independent phase-model checks passed |
| Clang 17 C++20 scalar suites | 539 metadata + 600 independent phase-model checks passed |
| GCC AddressSanitizer + UndefinedBehaviorSanitizer | Same scalar suites passed; leak detection enabled; no reported sanitizer errors |
| Library-only CMake/Ninja build, ArrayFire types disabled | Metadata + geometry static libraries built; zero executable targets; zero registered tests |
| Opt-in CMake/Ninja tests, ArrayFire types disabled | Both scalar runners built under `build/tests/` and discovered by CTest |
| Core-only build (`RADAR_BUILD_INTERFEROMETRY=OFF`) | Metadata library/test built; its single CTest passed |
| Ninja Multi-Config Release | Both scalar runners built under `tests/Release/`; CTest with `-C Release` passed |
| Parent project with `BUILD_TESTING=ON` | Consumer linked/executed; radar tests stayed OFF and added no executables |
| Production file comparison against v8 | All 34 public/internal library headers and implementations byte-identical |
| Source organization audit | All four `main()` functions and all executable target definitions are below test folders |
| Former example source audit | Three test-function translation units; no standalone main, example target, or regex-output verifier |
| Existing class/API audit | 12 matching class HPP/CPP pairs; 66 private fields; 236 Doxygen-commented public function declarations |
| Container scripts | All four accepted by `bash -n`; syntax only |
| Deterministic echo fixture | Independent NumPy check recovered [Doppler=3, range=18], amplitude 112 and no high-threshold detections |

GCC and Clang builds used the project's Release configuration and `-Werror`.
The sanitizer build used address/undefined-behavior instrumentation and
halt-on-error settings. All tests were compiled as C++20. Ninja Multi-Config was
run on Linux; it is not an MSVC or Windows validation.

The independent scalar phase tests do not call the ArrayFire estimators. The
NumPy check is only a reference calculation for the new deterministic fixture;
it does not compile or execute its C++ test or any ArrayFire code.

## Actual ArrayFire attempt and limitations

A real full configure was attempted with `RADAR_BUILD_TESTS=ON`. It failed at
`find_package(ArrayFire 3.10 CONFIG REQUIRED)` because no installed SDK or
`ArrayFireConfig.cmake` is available here. The exact error is retained in
`validation/real-sdk-configure.txt`.

**The two ArrayFire-backed runners, including the three newly converted cases,
were not compiled, linked or run against an actual ArrayFire SDK in this
revision.** No declaration-only shim, fake backend, or substitute SDK was used.
CPU/CUDA/OpenCL execution, overload resolution, NVIDIA laptop behavior and GPU
performance/memory use remain unverified. Docker builds/runs were not performed.

CMake executable-generation and parent-consumer checks above were performed with
`RADAR_BUILD_ARRAYFIRE_TYPES=OFF`, using real metadata/geometry libraries. They are
not disguised full-SDK builds. The full test targets are prepared for the user's
installed SDK and remain opt-in.

## Logs

All logs in `validation/` were generated for this revision; old v8 test logs are
not carried forward. `commands.json` records the local build/test matrix.
Compiler, configuration, build and verbose CTest outputs use matching prefixes
(`gcc-*`, `clang-*`, `sanitizers-*`, `core-only-*`, `multiconfig-*`, `parent-*`).
Additional source, layout, fixture and shell audits have descriptive filenames.

## Run the complete suite with your SDK

```sh
cmake -S . -B build-tests -DCMAKE_BUILD_TYPE=Release -DRADAR_BUILD_TESTS=ON -DRADAR_TEST_BACKEND=cuda
cmake --build build-tests --config Release --parallel
ctest --test-dir build-tests -C Release --no-tests=error --output-on-failure
```

Supply the installed ArrayFire prefix if CMake does not find it. Replace `cuda`
with `cpu` for the unified CPU backend. The root README includes platform-specific
commands and direct-backend options. Use a fresh build directory for this revision.
