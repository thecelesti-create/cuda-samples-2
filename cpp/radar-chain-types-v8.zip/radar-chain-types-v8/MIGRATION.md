# Migration from v7 to v8

This is a source-breaking cleanup. Rebuild from a fresh build directory.

## Detection fields

The standard detection has five required values: range index, Doppler index,
linear amplitude, SNR in dB, and one complex<float> I/Q pair. `Detection` no longer
wraps `DetectionCell` or carries cached physical coordinates. `DetectionList`
holds aligned ArrayFire columns with the same meaning, plus optional angle columns.

| v7 | v8 |
|---|---|
| `record.getCell().getRangeBin()` | `record.getRangeIndex()` |
| `record.getCell().getDopplerBin()` | `record.getDopplerIndex()` |
| `getRangeBins()` / `getDopplerBins()` | `getRangeIndices()` / `getDopplerIndices()` |
| Stored power | Detector supplies **linear amplitude** via `getAmplitudes()` |
| Stored noise power / derived SNR | Detector supplies **SNR-dB** via `getSnrDb()` |
| No representative I/Q column | Required `getComplexPairsC32()` c32 [K] |
| `getContext().getMetadata()` | `getMetadata()` |
| `AzElDetectionList` | `DetectionList` with optional f32 angle columns |
| `AngleEstimate`, `AzElDetection` | Optional angles on `Detection` host exports |
| `getElementSnapshots()` | No snapshot field; externally owned c32 [element,K] |
| `estimator.estimate(detections)` | `estimator.estimate(elementIqC32, detections)` |

For a compatible old power/noise detector, a typical producer conversion is:
`amplitude = sqrt(power)` and `snrDb = 10*log10(signalPower/noisePower)`, with an
explicit decision whether signalPower is noise-subtracted. The container does not
choose that definition. Power/noise fields were not simply renamed to amplitude/SNR.

`DetectionList::fromMap(map, cells, amplitudes, snrDb, elementIndex=0)` gathers one
representative c32 value per cell, NOT every element. `fromCells(map, cells,
amplitudes, snrDb, complexPairsC32)` accepts values already gathered by the detector.
Both decode u32 linear cells as `d + D*r`. There are no compatibility overloads
accepting old power/noise semantics: update the call sites.

## Optional angles

```cpp
DetectionList output = estimator.estimate(phaseCenterRdm, inputDetections);
if (output.getHasAngles()) {
    const af::array& azimuth = output.getAzimuthRadians();
    const af::array& elevation = output.getElevationRadians();
}
output.clearAngles(); // Only releases optional angle storage.
```

`setAzimuthRadians()` and `setElevationRadians()` can attach one column;
`setAngles()` attaches both. No sentinel zero-filled arrays are allocated for
unestimated angles. `select()`, `getDetection()`, `clone()`, and `recordsToHost()`
preserve independently optional fields. Callers must not access absent columns.
An invalid estimated value is a present NaN, not an absent column. Estimators
return a shallow base-list copy, attach new angles and leave the input unchanged.

## CPI metadata

```cpp
CPI_Metadata m(sampleRateHz, prfHz, carrierFrequencyHz, bandwidthHz, cpiId);
```

**The fourth argument is now required bandwidth, not the CPI ID.** Old four-argument
calls can still compile (the ID converts to double), so update them explicitly.
This change is documented rather than adding a validating/strong-type class.
Bandwidth is the effective transmitted waveform bandwidth, not ADC sample rate.
`getBandwidthHz()` / `setBandwidthHz()` and unambiguous range/Doppler/speed helpers
are available. The PRF interval is `[-PRF/2, PRF/2)` and full span is PRF.
The CPI ID is retained; string waveform IDs and element-name vectors were removed
from this processing metadata to avoid allocating/copying descriptions per stage.
Keep application labels in a separate configuration store keyed by CPI ID.

## Classes and files

Removed `DetectionCell`, `DetectionContext`, `AngleEstimate`, `AzElDetection`,
and `AzElDetectionList`, including their use in interferometry/examples/tests.
`metadata.hpp` is includes only. Every remaining class has its own named HPP/CPP,
including `CPI_Metadata`, `RangeAxis`, `DopplerAxis`, `Detection`, and both geometries.
Getters/simple setters remain inline; actual constructors/nontrivial functions
live in the CPPs. `radar::metadata` is now compiled, not header-only.

## Explicit complex storage

Complex buffer APIs now use `C32`: `getDataC32`, `setDataC32`, `withDataC32`,
`getPulseC32`, `getElementC32`, `getSlowTimeC32`, `getDopplerInputC32`,
`getDopplerSpectrumC32`, `getRangeProfileC32`, `getElementVectorC32`,
`getRangeFirstDataC32`. The `fromHost` cfloat/span interface is unchanged.
There are no old-name aliases or automatic casts. Scalar data such as amplitudes,
SNR and angles are f32, not complex. Doxygen documents every public function.

C++20, ArrayFire 3.10, private fields, named dimensions, uniform-array assumptions,
backend selection and unchecked performance contracts remain unchanged. Numeric
metadata no longer caches derived periods/wavelengths, eliminating duplicated
state. `RangeDopplerMap::setMetadata()` also updates its Doppler-axis PRF; no scan
or validation occurs.
