#pragma once
#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>

namespace test {
inline int checks = 0;
inline void check(bool condition, const std::string& message) {
    ++checks;
    if (!condition) throw std::runtime_error(message);
}
inline void near(double actual, double expected, double tolerance = 1e-10) {
    check(std::isfinite(actual) && std::isfinite(expected) &&
          std::abs(actual - expected) <= tolerance * std::max(1.0, std::abs(expected)),
          "numeric mismatch: " + std::to_string(actual) + " != " + std::to_string(expected));
}
template<class Exception, class Callable>
void throws(Callable&& function) {
    ++checks;
    try { std::forward<Callable>(function)(); }
    catch (const Exception&) { return; }
    throw std::runtime_error("expected exception was not thrown");
}
template<class Callable>
void run(const char* name, Callable&& function) {
    std::forward<Callable>(function)();
    std::cout << "PASS " << name << '\n';
}
} // namespace test
