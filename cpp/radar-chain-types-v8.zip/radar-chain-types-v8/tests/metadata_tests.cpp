#include <radar/metadata.hpp>
#include "test_support.hpp"
#include <complex>
#include <limits>
#include <optional>
#include <type_traits>

static_assert(!std::is_aggregate_v<radar::Detection>);
static_assert(!std::is_polymorphic_v<radar::Detection>);
static_assert(std::is_trivially_copyable_v<radar::CPI_Metadata>);
static_assert(std::is_trivially_copyable_v<radar::RangeAxis>);
static_assert(std::is_trivially_copyable_v<radar::DopplerAxis>);
static_assert(std::is_same_v<decltype(std::declval<radar::Detection>().getComplexPairC32()), std::complex<float>>);
static_assert(std::is_same_v<decltype(std::declval<radar::Detection>().getRangeIndex()), std::uint32_t>);

/** @brief Test numeric metadata, ambiguity formulas, FFT grids and simplified host records. */
int main() {
    using namespace radar;
    try {
        test::run("bandwidth and unambiguous range/Doppler helpers", [] {
            CPI_Metadata m(10e6,2000.0,10e9,5e6,42,1e-6,10.0);
            test::near(m.getSampleRateHz(),10e6); test::near(m.getPrfHz(),2000.0);
            test::near(m.getCarrierFrequencyHz(),10e9); test::near(m.getBandwidthHz(),5e6);
            test::check(m.getCpiId()==42,"CPI id");
            test::near(m.getFirstSampleDelaySeconds(),1e-6); test::near(m.getFirstPulseTimeSeconds(),10.0);
            test::near(m.getSamplePeriodSeconds(),1e-7); test::near(m.getPulsePeriodSeconds(),0.0005);
            test::near(m.getWavelengthMeters(),0.0299792458);
            test::near(m.getUnambiguousRangeMeters(),74948.1145);
            test::near(m.getUnambiguousDopplerSpanHz(),2000.0);
            test::near(m.getMinUnambiguousDopplerHz(),-1000.0);
            test::near(m.getMaxUnambiguousDopplerHz(),1000.0);
            test::near(m.getMaxUnambiguousSpeedMps(),14.9896229);
            test::near(m.getNominalRangeResolutionMeters(),29.9792458);
            test::near(m.getRadialVelocityMps(1000.0),-14.9896229);
            m.setPositiveDoppler(PositiveDoppler::Receding);
            test::near(m.getRadialVelocityMps(1000.0),14.9896229);
            m.setPrfHz(4000.0);
            test::near(m.getUnambiguousRangeMeters(),37474.05725);
            test::near(m.getMaxUnambiguousDopplerHz(),2000.0);
            test::near(m.getMaxUnambiguousSpeedMps(),29.9792458);
            m.setBandwidthHz(10e6); test::near(m.getNominalRangeResolutionMeters(),14.9896229);
            m.setSampleRateHz(20e6); test::near(m.getSamplePeriodSeconds(),5e-8);
            m.setCarrierFrequencyHz(5e9); test::near(m.getWavelengthMeters(),0.0599584916);
            m.setCpiId(8); m.setFirstSampleDelaySeconds(0.25); m.setFirstPulseTimeSeconds(5.0);
            test::check(m.getCpiId()==8,"CPI setter");
            test::near(m.getFirstSampleDelaySeconds(),0.25); test::near(m.getFirstPulseTimeSeconds(),5.0);
        });
        test::run("range grid keeps output timing independent of waveform bandwidth", [] {
            const auto r=RangeAxis::fromRoundTripTiming(2e-6,10e6);
            test::near(r.getFirstBinMeters(),299.792458);
            test::near(r.getBinSpacingMeters(),14.9896229);
            test::near(r.getMeters(3),344.7613267);
            test::near(r.sliced(3).getMeters(2),r.getMeters(5));
            auto changed=r; changed.setFirstBinMeters(100.0); changed.setBinSpacingMeters(2.0);
            test::near(changed.getMeters(6),112.0);
        });
        test::run("odd and even Doppler bins; padding and setters", [] {
            for (BinIndex n=2;n<=17;++n) {
                const DopplerAxis a(n,2,2000.0), b(n,2,2000.0,DopplerOrder::Centered);
                test::near(a.getBinSpacingHz(),2000.0/static_cast<double>(n));
                test::near(a.getCoherentIntervalSeconds(),0.001);
                for(BinIndex k=0;k<n;++k) {
                    const BinIndex signedBin=k < (n+1)/2 ? k : k-n;
                    test::check(a.getSignedBin(k)==signedBin,"unshifted signed bin");
                    test::check(b.getSignedBin(k)==k-n/2,"centered signed bin");
                    test::near(a.getHertz(k),static_cast<double>(signedBin)*2000.0/static_cast<double>(n));
                }
            }
            DopplerAxis a(8,4,2000.0); a.setFftSize(16); a.setPulsesUsed(8); a.setPrfHz(4000.0);
            a.setOrder(DopplerOrder::Centered);
            test::check(a.getFftSize()==16 && a.getPulsesUsed()==8,"axis setters");
            test::near(a.getBinSpacingHz(),250.0); test::near(a.getCoherentIntervalSeconds(),0.002);
            test::near(a.getHertz(8),0.0);
        });
        test::run("five-field record and independent optional angles", [] {
            Detection d(5,2,4.0f,12.0f,{3.0f,4.0f});
            test::check(d.getRangeIndex()==5 && d.getDopplerIndex()==2,"indices");
            test::near(d.getAmplitude(),4.0); test::near(d.getSnrDb(),12.0);
            test::near(d.getComplexPairC32().real(),3.0); test::near(d.getComplexPairC32().imag(),4.0);
            test::check(!d.getAzimuthRadians() && !d.getElevationRadians(),"angles absent");
            d.setAzimuthRadians(0.2f);
            test::check(d.getAzimuthRadians() && !d.getElevationRadians(),"independent azimuth");
            test::near(*d.getAzimuthRadians(),0.2,1e-6);
            d.setElevationRadians(0.1f); test::near(*d.getElevationRadians(),0.1,1e-6);
            d.setRangeIndex(6); d.setDopplerIndex(3); d.setAmplitude(7); d.setSnrDb(-2);
            d.setComplexPairC32({1,-1});
            test::check(d.getRangeIndex()==6 && d.getDopplerIndex()==3,"record setters");
            test::near(d.getAmplitude(),7); test::near(d.getSnrDb(),-2);
            test::near(d.getComplexPairC32().imag(),-1);
            d.setAzimuthRadians(std::nullopt); test::check(!d.getAzimuthRadians(),"clear angle");
            d.setElevationRadians(std::numeric_limits<float>::quiet_NaN());
            test::check(d.getElevationRadians() && std::isnan(*d.getElevationRadians()),"present NaN distinct from absent");
        });
        std::cout << test::checks << " metadata checks passed\n";
        std::cout << "sizeof(CPI_Metadata)=" << sizeof(CPI_Metadata) << ", sizeof(Detection)=" << sizeof(Detection) << '\n';
        return 0;
    } catch(const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
