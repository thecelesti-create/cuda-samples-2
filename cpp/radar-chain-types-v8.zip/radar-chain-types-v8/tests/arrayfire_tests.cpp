#include <radar/radar.hpp>
#include "test_support.hpp"
#include <initializer_list>
#include <limits>
#include <string>
#include <vector>

/** @brief Upload a small u32 test column. */
af::array indices(std::initializer_list<unsigned> values) {
    return af::array(static_cast<dim_t>(values.size()), values.begin(), afHost);
}
/** @brief Upload a small f32 test column. */
af::array floats(std::initializer_list<float> values) {
    return af::array(static_cast<dim_t>(values.size()), values.begin(), afHost);
}
/** @brief Explicitly download a test array using its exact scalar storage type. */
template<class T> std::vector<T> host(const af::array& a) {
    std::vector<T> result(static_cast<std::size_t>(a.elements()));
    if (!result.empty()) a.host(result.data());
    return result;
}
/** @brief Construct a tiny [D=8,R=6,E=3] c32 map with distinct element/cell IQ. */
radar::RangeDopplerMap makeMap() {
    using namespace radar;
    std::vector<af::cfloat> iqC32(8*6*3);
    for(dim_t e=0;e<3;++e) for(dim_t r=0;r<6;++r) for(dim_t d=0;d<8;++d)
        iqC32[d+8*(r+6*e)]={static_cast<float>(100*e+10*r+d),static_cast<float>(e)*0.25f};
    CPI_Metadata m(10e6,2000,10e9,5e6,5);
    m.setPositiveDoppler(PositiveDoppler::Receding);
    return {af::array(af::dim4(8,6,3),iqC32.data(),afHost),m,RangeAxis(100,10),DopplerAxis(8,4,2000)};
}
/** @brief Execute real ArrayFire checks; requires an installed SDK/backend. */
int main(int argc,char** argv) {
    using namespace radar;
    try {
#if RADAR_ARRAYFIRE_UNIFIED
        const std::string backend=argc>1?argv[1]:"cpu";
        if(backend=="cpu") af::setBackend(AF_BACKEND_CPU);
        else if(backend=="cuda") af::setBackend(AF_BACKEND_CUDA);
        else if(backend=="opencl") af::setBackend(AF_BACKEND_OPENCL);
        else throw std::invalid_argument("Unknown backend");
#else
        (void)argc;(void)argv;
#endif
        af::setDevice(0);
        test::run("c32 stage layouts, slices, FFT and bandwidth propagation", [] {
            CPI_Metadata m(10e6,2000,10e9,5e6,2);
            std::vector<af::cfloat> iqC32(8*4*3,{1,0});
            const auto samples=SamplePulseBuffer::fromHost(iqC32,8,4,3,m);
            test::check(samples.getDataC32().type()==c32,"raw c32");
            test::check(samples.getSampleCount()==8 && samples.getPulseCount()==4 && samples.getElementCount()==3,"named counts");
            test::check(samples.getDataC32().elements()==96,"total value count");
            const auto cropped=samples.sliceSamples(2,3).slicePulses(1,2);
            test::check(cropped.getSampleCount()==3 && cropped.getPulseCount()==2,"slice counts");
            test::near(cropped.getSampleDelaySeconds(0),2e-7);
            test::near(cropped.getPulseTimeSeconds(0),0.0005);
            RangePulseBuffer ranges(samples,samples.getDataC32()*2.0f,RangeAxis(100,5));
            test::near(ranges.getMetadata().getBandwidthHz(),5e6);
            const auto ordered=ranges.getDopplerInputC32();
            test::check(ordered.dims(0)==4 && ordered.dims(1)==8 && ordered.dims(2)==3,"pulse-first reorder");
            const RangeDopplerMap map(ranges,af::fft(ordered),DopplerOrder::Unshifted);
            test::check(map.getDataC32().type()==c32 && map.getDopplerBinCount()==4,"FFT c32 shape");
            const auto h=map.toHost();
            test::near(h[0].real,8,1e-5);test::near(h[1].real,0,1e-5);
            test::near(map.getMetadata().getBandwidthHz(),5e6);
            auto shifted=map.withDopplerOrder(DopplerOrder::Centered).withDopplerOrder(DopplerOrder::Unshifted);
            test::near(shifted.toHost()[0].real,8,1e-5);
            auto copy=samples.clone(); copy.setDataC32(af::constant(0,copy.getDimensions(),c32));
            test::near(samples.toHost()[0].real,1); test::near(copy.toHost()[0].real,0);
        });
        test::run("five detection columns, c32 representative IQ, coordinates", [] {
            const auto map=makeMap();
            const auto list=DetectionList::fromMap(map,indices({10,45,10}),floats({7,8,9}),floats({12,13,14}),1);
            test::check(list.getDetectionCount()==3 && list.getPayloadBytes()==72,"five-field payload");
            test::check(list.getRangeIndices().type()==u32 && list.getDopplerIndices().type()==u32,"integer bins");
            test::check(list.getAmplitudes().type()==f32 && list.getSnrDb().type()==f32,"scalar f32");
            test::check(list.getComplexPairsC32().type()==c32,"required c32 I/Q");
            test::check(!list.getHasAzimuth() && !list.getHasElevation(),"angles initially absent");
            const auto r=list.recordsToHost();
            test::check(r[0].getRangeIndex()==1 && r[0].getDopplerIndex()==2,"integer decode");
            test::near(r[0].getAmplitude(),7); test::near(r[0].getSnrDb(),12);
            test::near(r[0].getComplexPairC32().real(),112);test::near(r[0].getComplexPairC32().imag(),0.25);
            test::check(r[1].getRangeIndex()==5 && r[1].getDopplerIndex()==5,"second indices");
            test::near(r[1].getComplexPairC32().real(),155);
            test::near(host<float>(list.getRangesMeters())[0],110);
            test::near(host<float>(list.getDopplerHz())[0],500);
            test::near(host<float>(list.getDopplerHz())[1],-750);
            test::near(host<float>(list.getRadialVelocitiesMps())[0],map.getMetadata().getRadialVelocityMps(500),1e-5);
            test::near(list.getMetadata().getBandwidthHz(),5e6);
        });
        test::run("optional angle lifecycle, selection, clone and export", [] {
            const auto map=makeMap();
            auto base=DetectionList::fromMap(map,indices({10,45,10}),floats({7,8,9}),floats({12,13,14}));
            auto angled=base;
            angled.setAzimuthRadians(floats({0.0f,0.2f,0.4f}));
            test::check(angled.getHasAzimuth() && !angled.getHasAngles(),"azimuth only");
            test::check(!base.getHasAzimuth(),"input unchanged");
            auto azOnly=angled.select(indices({2,0,2}));
            test::check(azOnly.getHasAzimuth() && !azOnly.getHasElevation(),"partial optional selection");
            test::near(*azOnly.recordsToHost()[0].getAzimuthRadians(),0.4,1e-6);
            angled.setElevationRadians(floats({0.0f,0.1f,0.2f}));
            test::check(angled.getHasAngles() && angled.getPayloadBytes()==96,"both angles payload");
            const auto xyz=host<float>(angled.getPositionsMeters());
            test::near(xyz[0],110);test::near(xyz[1],0);test::near(xyz[2],0);
            const auto selected=angled.select(indices({1,0,1}));
            const auto h=selected.recordsToHost();
            test::check(h[0].getRangeIndex()==5 && h[2].getRangeIndex()==5,"duplicate selection");
            test::near(*h[0].getAzimuthRadians(),0.2,1e-6);test::near(*h[2].getElevationRadians(),0.1,1e-6);
            test::near(h[0].getAmplitude(),8);test::near(h[0].getSnrDb(),13);
            auto deep=selected.clone(); deep.clearAngles();
            test::check(!deep.getHasAngles() && selected.getHasAngles(),"independent optional handles");
            deep.setAmplitudes(floats({1,2,3}));deep.setSnrDb(floats({4,5,6}));
            test::near(selected.recordsToHost()[0].getAmplitude(),8);
            test::near(deep.recordsToHost()[0].getAmplitude(),1);
            const auto one=selected.getDetection(2).recordsToHost();
            test::check(one.size()==1 && one[0].getRangeIndex()==5,"single device list");
            auto empty=selected.select(af::array{});
            test::check(empty.getIsEmpty() && empty.getHasAngles(),"empty preserves optional presence");
            test::check(empty.recordsToHost().empty() && empty.getPositionsMeters().isempty(),"empty export/math");
            empty.clearAngles();test::check(!empty.getHasAzimuth(),"clear empty angles");
            DetectionList plain(map);test::check(plain.getIsEmpty() && !plain.getHasAngles(),"empty list");
        });
        test::run("empty fromCells and precise u32 bins above f32 integer range", [] {
            const auto map=makeMap();
            const auto empty=DetectionList::fromCells(map,{},{},{},{});
            test::check(empty.getIsEmpty(),"empty decoded list");
            DetectionList large(map.getMetadata(),map.getRangeAxis(),DopplerAxis(33554440,4,2000),
                indices({1}),indices({16777217}),floats({1}),floats({0}),
                af::constant(1.0f,af::dim4(1),c32));
            test::check(large.recordsToHost()[0].getDopplerIndex()==16777217u,"no float conversion of indices");
        });
        af::sync();
        std::cout << test::checks << " real ArrayFire checks passed\n";
        return 0;
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
