# Radar chain types — v8

C++20 / ArrayFire 3.10, with a separate uniform-array interferometry library.

```text
SamplePulseBuffer -> RangePulseBuffer -> RangeDopplerMap -> DetectionList
                                                              |
                                              interferometry  |
                                                              v
                                                     DetectionList
                                               (optional angles attached)
```

## Small data model

| Type | Numerical payload |
|---|---|
| `SamplePulseBuffer` | **c32** `[sample,pulse,element,1]` |
| `RangePulseBuffer` | **c32** `[range,pulse,element,1]` |
| `RangeDopplerMap` | **c32** `[Doppler,range,element,1]` |
| `DetectionList` | Five device columns: range index **u32**, Doppler index **u32**, amplitude **f32**, SNR-dB **f32**, one complex I/Q pair **c32** |
| `Detection` | Small CPU export of those five values, plus optional angle values |

All detection columns are `[K,1,1,1]`. `DetectionList` optionally owns **f32**
azimuth and elevation columns in radians. Neither optional column allocates
numerical storage until supplied. They can be independently present. The normal
interferometry result has both. An engaged empty column means the stage ran on an
empty list; an absent column means it was not supplied. A present NaN represents an
undefined estimate, not an absent field. There is no separate angle-list type.

"Complex pair" is **one I/Q value per detection**, not a pair of complex numbers
and not an element snapshot. In host records it is `std::complex<float>`; in
ArrayFire it is `c32`. The explicit host conversion copies I and Q components;
it does not reinterpret the two C++ complex representations.

Amplitude is a **linear magnitude**, not power or dB. SNR is explicitly **dB** and
is supplied by the detector; the container does not guess the noise model or
recompute SNR. Amplitude can describe a combined detector signal while the complex
pair is taken from a chosen representative element/beam. Document that choice in
your algorithm; the two quantities need not be numerically coupled.

No `DetectionCell`, `DetectionContext`, `AngleEstimate`, `AzElDetection`, or
`AzElDetectionList` classes remain. `metadata.hpp` is an **include-only umbrella**.
`RangeAxis` (two values) and `DopplerAxis` (four values) retain only the information
needed for correct crop offsets, FFT ordering, and pulse counts.
`CPI_Metadata` is numeric: no strings, vectors, labels, or cached derived values.

## Explicit c32 contract

Complex array methods spell out their storage:

```cpp
const af::array& iqC32 = buffer.getDataC32();
buffer.setDataC32(std::move(replacementC32));
af::array pulseFirstC32 = ranges.getDopplerInputC32();
const af::array& representativeIqC32 = detections.getComplexPairsC32();
```

Every adopted complex array **must already be c32** (two float components). There
is no silent conversion, dtype scan, validation macro, or added check in a hot
helper. `af::array` is dynamically typed; names and Doxygen `@pre` contracts make
this requirement explicit but cannot enforce it at C++ compile time.

Constructors/setters are also unchecked. Dimensions, column alignment, valid
indices, finite positive configuration, and the active owning backend/device are
caller contracts. `setDataC32()` accepts same-shape replacement; it does **not**
recompute named cached dimensions. Use a constructor for a different shape.
Ordinary copies retain array handles; `clone()` is the explicit deep-copy API.
ArrayFire's internal behavior/checks remain. Slices may retain parent storage.

## CPI bandwidth and ambiguity helpers

```cpp
radar::CPI_Metadata metadata(
    10e6,   // ADC sample rate, Hz
    2000.0, // PRF, Hz
    10e9,   // RF carrier, Hz
    5e6,    // waveform bandwidth, Hz -- REQUIRED fourth argument in v8
    42      // CPI identifier
);
metadata.setBandwidthHz(6e6);
auto bandwidth = metadata.getBandwidthHz();
auto maxRange = metadata.getUnambiguousRangeMeters();
auto fdMin = metadata.getMinUnambiguousDopplerHz();
auto fdMax = metadata.getMaxUnambiguousDopplerHz();
auto fdSpan = metadata.getUnambiguousDopplerSpanHz();
```

Uniform-PRF monostatic definitions:

| Method | Value |
|---|---|
| `getUnambiguousRangeMeters()` | `c / (2*PRF)` |
| `getMinUnambiguousDopplerHz()` | `-PRF/2` |
| `getMaxUnambiguousDopplerHz()` | `+PRF/2`, **exclusive upper boundary** |
| `getUnambiguousDopplerSpanHz()` | `PRF`, the full interval width |
| `getMaxUnambiguousSpeedMps()` | `wavelength*PRF/4`, magnitude boundary |
| `getNominalRangeResolutionMeters()` | `c/(2*bandwidth)`, ideal nominal value |

Doppler is represented over `[-PRF/2, PRF/2)`. Exact Nyquist signs are ambiguous;
for even FFT lengths the stored Nyquist bin is negative. Odd FFT bins do not land
on the endpoints. PRF limits are not the instrumented range window, duty-cycle
blanking model, or waveform maximum detection distance. Bandwidth resolution is
not ADC/range-bin spacing and does not account for window broadening. These
helpers do not apply unchanged to staggered PRF, bistatic radar, or FMCW ambiguity
models. See `API_REFERENCES.md`.

## Example APIs

```cpp
radar::RangeDopplerMap doDoppler(const radar::RangePulseBuffer& data) {
    af::array fftC32 = af::fft(data.getDopplerInputC32());
    return {data, std::move(fftC32), radar::DopplerOrder::Unshifted};
}

// cells: u32 [K], amplitude and snrDb: f32 [K], iqC32: c32 [K].
auto detections = radar::DetectionList::fromCells(
    map, std::move(cells), std::move(amplitude), std::move(snrDb), std::move(iqC32));

// Or gather representative element 0 automatically (not all element snapshots).
auto detections2 = radar::DetectionList::fromMap(map, cells2, amplitude2, snrDb2, 0);

using namespace radar::interferometry;
const double wavelength = map.getMetadata().getWavelengthMeters();
const Interferometry2D estimator(UniformRectangularArray(4, 3, wavelength/2, wavelength/2));
radar::DetectionList located = estimator.estimate(phaseCenterMap, detections);
// The five base columns are retained, not deep-copied. Angles are now present.
const af::array& az = located.getAzimuthRadians();
const af::array& el = located.getElevationRadians();
const auto records = located.recordsToHost(); // EXPLICIT numerical download.
```

There are no optional-IQ-snapshot fields in `DetectionList`. To reuse phase-center
IQ, keep a separate **c32 `[element,K]`** array and call
`estimator.estimate(elementIqC32, detections)`. That overload replaces the previous
one-argument snapshot overload. Packed-RDM and separate-RDM overloads remain.

`examples/simple_demo.cpp` has exactly three fake algorithms. Its expected final
record is `(range=0, Doppler=0, amplitude=2, SNR=6.0206 dB, I=2, Q=0)`.
`examples/pipeline.cpp` retains real reference matched filtering / Doppler FFT
and a non-CFAR threshold detector. `interferometry_demo.cpp` has a synthetic 4x3
array whose expected azimuth/elevation are 20/10 degrees. Expected outputs are not
claims of execution here; see `VALIDATION.md`.

## File organization

Every one of the **12 classes** has its own matching `.hpp` and `.cpp`.
Trivial scalar getters/setters stay inline for low call overhead; constructors
and other nontrivial methods are implemented in their class's `.cpp`.

```text
include/radar/                  src/
    CPI_Metadata.hpp                CPI_Metadata.cpp
    RangeAxis.hpp                   RangeAxis.cpp
    DopplerAxis.hpp                 DopplerAxis.cpp
    Detection.hpp                   Detection.cpp
    SamplePulseBuffer.hpp           SamplePulseBuffer.cpp
    RangePulseBuffer.hpp            RangePulseBuffer.cpp
    RangeDopplerMap.hpp              RangeDopplerMap.cpp
    DetectionList.hpp               DetectionList.cpp
    metadata.hpp, radar.hpp         # umbrella includes, no classes

interferometry/include/radar/interferometry/   interferometry/src/
    UniformLinearArray.hpp                       UniformLinearArray.cpp
    UniformRectangularArray.hpp                  UniformRectangularArray.cpp
    Interferometry1D.hpp                          Interferometry1D.cpp
    Interferometry2D.hpp                          Interferometry2D.cpp
```

`PhaseSign.hpp` and `types.hpp` contain only enums/constants/aliases, not classes.
No project class is a struct or has public data members. Public API classes and
functions use Doxygen comments. Generate HTML with `doxygen Doxyfile` or the
`radar_docs` CMake target when Doxygen is installed.

## Build everything

Run from the extracted `radar-chain-types-v8` root. CMake 3.20+, a C++20 compiler
and an actual ArrayFire 3.10 SDK are required. No dependency is mocked by the build.

Windows / Visual Studio PowerShell:

```powershell
cmake -S . -B build -A x64 -DCMAKE_PREFIX_PATH="$env:AF_PATH" -DRADAR_TEST_BACKEND=cuda
cmake --build build --config Release --parallel
ctest --test-dir build -C Release --output-on-failure
.\build\Release\radar_simple_demo.exe cuda
.\build\Release\radar_interferometry_demo.exe cuda
```

Linux / WSL:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="$AF_PATH" -DRADAR_TEST_BACKEND=cuda
cmake --build build --parallel
ctest --test-dir build --output-on-failure
./build/radar_simple_demo cuda
./build/radar_interferometry_demo cuda
```

Replace `cuda` with `cpu` for CPU execution. With the default unified link target,
executables use CPU when no argument is given; requesting CUDA never intentionally
falls back to CPU. For direct linking choose `-DRADAR_ARRAYFIRE_BACKEND=CUDA`
(or CPU/OPENCL), leave `RADAR_TEST_BACKEND` empty, and pass no backend argument.
ArrayFire runtime libraries must be discoverable (PATH on Windows; loader path on
Linux). Omit CMAKE_PREFIX_PATH when CMake already finds the SDK. Use a fresh build
directory when migrating from v7 to avoid obsolete source files/targets.

Consumers use `add_subdirectory(...)` then link `radar::chain_types` or
`radar::interferometry`. `radar::metadata` now links a tiny static library rather
than being header-only. `radar::array_geometry` is also separately available.
The original Docker recipes remain; see `CONTAINER.md`. They are not certified
as executed builds in this environment.

Without ArrayFire, compile only the real value/geometry classes and scalar tests:

```sh
cmake -S . -B build-metadata -DRADAR_BUILD_ARRAYFIRE_TYPES=OFF -DCMAKE_BUILD_TYPE=Release
cmake --build build-metadata --parallel
ctest --test-dir build-metadata --output-on-failure
```

## Memory and timing

The five detection columns use **24*K bytes** of logical payload. Each optional
angle column adds **4*K bytes**; both give **32*K bytes** total. No per-detection
metadata/coordinates/snapshots are persistently stored on the device. This excludes
allocator rounding, handles, temporary computations and retained shared arrays.
The interferometer's c32 scratch block is `8*E*min(K,batchSize)` bytes, plus pair
products, gather indices, math intermediates and output columns. No full RDM is
joined or deliberately cloned by the estimators. Contiguous input is the
no-full-cube-copy precondition. ArrayFire may retain workspace asynchronously.

Constructors and ordinary stage returns do not synchronize or numerically read
back. `toHost()` / `recordsToHost()` are explicit exports; `synchronize()` is an
explicit fence. Underlying operations such as variable-length `where()` can
internally synchronize. GPU-resident data is not a promise of zero host work or
zero internal waits. Benchmark end-to-end with appropriate fences.
