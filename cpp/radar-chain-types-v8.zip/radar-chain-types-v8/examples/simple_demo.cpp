#include <radar/radar.hpp>
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

/** @brief FAKE matched filter: multiply c32 IQ by two; no pulse compression. */
radar::RangePulseBuffer fakeMatchedFilter(const radar::SamplePulseBuffer& input) {
    af::array iqC32 = input.getDataC32() * 2.0f;
    return {input, std::move(iqC32), radar::RangeAxis::fromRoundTripTiming(
        input.getMetadata().getFirstSampleDelaySeconds(), input.getMetadata().getSampleRateHz())};
}
/** @brief FAKE Doppler: reorder to [pulse,range,element]; deliberately no FFT. */
radar::RangeDopplerMap fakeDoppler(const radar::RangePulseBuffer& input) {
    return {input, input.getDopplerInputC32(), radar::DopplerOrder::Unshifted};
}
/** @brief FAKE detector: select cell zero in element zero and assume unit noise power. */
radar::DetectionList fakeDetector(const radar::RangeDopplerMap& input) {
    af::array cells = af::constant(0u, af::dim4(1), u32);
    af::array iqC32 = af::lookup(af::flat(input.getElementC32(0)), cells, 0);
    af::array amplitudes = af::abs(iqC32);
    af::array snrDb = 20.0f * af::log10(amplitudes); // 10*log10(amplitude^2 / 1).
    return radar::DetectionList::fromCells(input, std::move(cells),
        std::move(amplitudes), std::move(snrDb), std::move(iqC32));
}
/** @brief Upload once, pass through three fake algorithms, then explicitly export records. */
int main(int argc, char** argv) {
    try {
#if RADAR_ARRAYFIRE_UNIFIED
        const std::string backend = argc > 1 ? argv[1] : "cpu";
        if (backend == "cuda") af::setBackend(AF_BACKEND_CUDA);
        else if (backend == "cpu") af::setBackend(AF_BACKEND_CPU);
        else if (backend == "opencl") af::setBackend(AF_BACKEND_OPENCL);
        else throw std::invalid_argument("backend must be cuda, cpu or opencl");
#else
        (void)argc; (void)argv;
#endif
        af::setDevice(0);
        af::info();
        constexpr dim_t sampleCount = 8, pulseCount = 4, elementCount = 3;
        const radar::CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6, 1);
        const std::vector<af::cfloat> hostIqC32(sampleCount*pulseCount*elementCount, {1.0f, 0.0f});
        const auto samples = radar::SamplePulseBuffer::fromHost(
            hostIqC32, sampleCount, pulseCount, elementCount, metadata);
        const auto ranges = fakeMatchedFilter(samples);
        const auto map = fakeDoppler(ranges);
        const auto detections = fakeDetector(map);
        const auto records = detections.recordsToHost(); // Final output boundary only.
        std::cout << "Fake chain produced " << records.size() << " detection(s).\n";
        for (const auto& record : records) {
            const auto iqC32 = record.getComplexPairC32();
            std::cout << "range index=" << record.getRangeIndex()
                      << ", Doppler index=" << record.getDopplerIndex()
                      << ", amplitude=" << record.getAmplitude()
                      << ", SNR dB=" << record.getSnrDb()
                      << ", I=" << iqC32.real() << ", Q=" << iqC32.imag() << '\n';
        }
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
