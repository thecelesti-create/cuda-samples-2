#include <radar/radar.hpp>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <limits>
#include <random>
#include <string>
#include <utility>

// Small, readable REFERENCE example, not a performance benchmark or a CFAR/AoA library.
// The container classes themselves never invoke these algorithms in constructors.
namespace {
using namespace radar;

/** @brief Reference linear matched filtering with delay-corrected range axis.
 * @pre waveform is a nonempty c32 column; sizes fit dim_t; configuration is valid. */
RangePulseBuffer matchedFilter(const SamplePulseBuffer& source, const af::array& waveform) {
    const dim_t taps = waveform.dims(0);
    const dim_t linearLength = source.getSampleCount() + taps - 1;
    dim_t fftLength = 1;
    while (fftLength < linearLength) {
        fftLength *= 2;
    }

    // Linear convolution with h[n] = conj(waveform[taps-1-n]).
    // af::fft is unnormalized forward; af::ifft includes inverse normalization.
    const af::array h = af::conjg(af::flip(waveform, 0));
    // Explicit tile is intentionally simple for this tiny demo. A production
    // implementation should broadcast/cache the filter spectrum instead of
    // retaining a full-sized repeated spectrum. Benchmark those costs separately.
    const af::array filterSpectrum = af::tile(af::fft(h, fftLength),
                                              1, source.getPulseCount(), source.getElementCount());
    const af::array full = af::ifft(af::fft(source.getDataC32(), fftLength) * filterSpectrum);
    // Full convolution peak has a taps-1 delay. Retain lags [0, samples-1].
    // Cropping is an actual data selection, not merely a metadata correction.
    const af::array cropped = full(af::seq(static_cast<double>(taps - 1),
                                         static_cast<double>(taps + source.getSampleCount() - 2)),
                                   af::span, af::span);
    const auto axis = RangeAxis::fromRoundTripTiming(source.getMetadata().getFirstSampleDelaySeconds(),
                                                    source.getMetadata().getSampleRateHz());
    return {source, cropped, axis};
}

/** @brief Reference c32 Doppler FFT after pulse-first reorder. */
RangeDopplerMap dopplerProcess(const RangePulseBuffer& source) {
    // Exactly one full-cube reorder; the output stays Doppler-first afterward.
    af::array pulseFirst = source.getDopplerInputC32();
    af::array spectrum = af::fft(pulseFirst);
    return {source, std::move(spectrum), DopplerOrder::Unshifted};
}


/** @brief Fixed-threshold element-zero detector; not CFAR. Numerical results stay on device. */
DetectionList thresholdDemo(const RangeDopplerMap& map, double threshold,
                            double assumedNoisePower) {
    const af::array elementIqC32 = map.getElementC32(0);
    const af::array power = af::real(elementIqC32 * af::conjg(elementIqC32));
    af::array selected = af::where(power > static_cast<float>(threshold));
    if (selected.isempty()) return DetectionList(map);
    af::array iqC32 = af::lookup(af::flat(elementIqC32), selected, 0);
    af::array amplitudes = af::abs(iqC32);
    af::array snrDb = 20.0f * af::log10(amplitudes) -
                     10.0f * static_cast<float>(std::log10(assumedNoisePower));
    return DetectionList::fromCells(map, std::move(selected), std::move(amplitudes),
                                     std::move(snrDb), std::move(iqC32));
}
} // namespace

/** @brief Run the documented reference processing example or test executable. */
int main(int argc, char** argv) {
    try {
        // Arguments are for the unified backend. With a directly linked backend,
        // run without an argument; ArrayFire uses that backend automatically.
        #if RADAR_ARRAYFIRE_UNIFIED
        if (argc > 1) {
            const std::string backend = argv[1];
            if (backend == "cuda") af::setBackend(AF_BACKEND_CUDA);
            else if (backend == "cpu") af::setBackend(AF_BACKEND_CPU);
            else if (backend == "opencl") af::setBackend(AF_BACKEND_OPENCL);
            else throw std::invalid_argument("backend must be cpu, cuda, or opencl");
        }
        #else
        (void)argv;
        if (argc > 1) throw std::invalid_argument("direct-backend build takes no backend argument");
        #endif
        af::info();
        constexpr dim_t samples = 64, pulses = 16, elements = 5;
        constexpr dim_t echoStart = 18, toneBin = 3;
        const std::vector<af::cfloat> chips{{1, 0}, {1, 0}, {1, 0}, {-1, 0},
                                          {-1, 0}, {1, 0}, {-1, 0}};
        const af::array waveform(static_cast<dim_t>(chips.size()), chips.data(), afHost);

        CPI_Metadata capture(10e6, 2000, 10e9, 5e6, 1);

        std::vector<af::cfloat> hostIq(static_cast<std::size_t>(samples * pulses * elements));
        std::mt19937 generator(42);
        std::normal_distribution<float> noise(0.0f, std::sqrt(0.5f)); // E[|noise|^2] = 1.
        for (auto& value : hostIq) value = {noise(generator), noise(generator)};
        for (dim_t elementIndex = 0; elementIndex < elements; ++elementIndex) {
            for (dim_t p = 0; p < pulses; ++p) {
                const double phase = 2.0 * radar::pi * static_cast<double>(toneBin * p) /
                                     static_cast<double>(pulses) + 0.2 * static_cast<double>(elementIndex);
                for (std::size_t n = 0; n < chips.size(); ++n) {
                    const dim_t sample = echoStart + static_cast<dim_t>(n);
                    auto& value = hostIq[static_cast<std::size_t>(sample + samples * (p + pulses * elementIndex))];
                    value.real += chips[n].real * static_cast<float>(std::cos(phase));
                    value.imag += chips[n].real * static_cast<float>(std::sin(phase));
                }
            }
        }

        const auto raw = SamplePulseBuffer::fromHost(hostIq, samples, pulses, elements, capture);
        const auto ranges = matchedFilter(raw, waveform);
        const auto map = dopplerProcess(ranges);

        // Expected element-zero noise power: chips.size() * pulses (no element sum).
        const double assumedNoisePower = static_cast<double>(chips.size() * pulses);
        auto detections = thresholdDemo(map, 3000.0, assumedNoisePower);
        // Optional angles belong to this same list. This example does not estimate them.
        std::cout << "Detected " << detections.getDetectionCount() << " cell(s); angles absent.\n";
        for (const auto& record : detections.recordsToHost()) {
            std::cout << "range index=" << record.getRangeIndex()
                      << ", Doppler index=" << record.getDopplerIndex()
                      << ", amplitude=" << record.getAmplitude()
                      << ", SNR dB=" << record.getSnrDb() << '\n';
        }
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
