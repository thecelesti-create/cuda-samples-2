#pragma once

// Fail clearly even when consumers bypass the supplied CMake targets.
#if defined(_MSVC_LANG)
#  if _MSVC_LANG < 202002L
#    error "radar-chain-types requires C++20 or later (/std:c++20)."
#  endif
#elif __cplusplus < 202002L
#  error "radar-chain-types requires C++20 or later (-std=c++20)."
#endif
