#pragma once
#include <radar/RangeDopplerMap.hpp>
#include <radar/Detection.hpp>
#include <optional>
#include <vector>
namespace radar {
/**
 * @brief Device-resident detection list with five required columns and optional angles.
 * @details Columns are u32 range/Doppler indices, f32 linear amplitudes/SNR-dB,
 * and c32 complex I/Q pairs. Every column has shape [detectionCount,1,1,1].
 * Each complex pair is ONE representative I/Q value, NOT an element snapshot.
 * Optional f32 azimuth/elevation columns use radians; absence allocates no array.
 * Metadata and axes occur once per list. No full RDM or element snapshots are held.
 * @pre Columns are aligned, correctly typed and on the active owning backend/device.
 * No validation, dtype conversion, scalar readback or synchronization is implicit.
 */
class DetectionList final {
public:
    /** @brief Construct an empty list with the source map's metadata/grids. */
    explicit DetectionList(const RangeDopplerMap& source);
    /** @brief Construct an empty list without retaining a source map. */
    DetectionList(CPI_Metadata metadata, RangeAxis rangeAxis, DopplerAxis dopplerAxis);
    /**
     * @brief Adopt five device columns without copying their numerical payloads.
     * @param source Source grid; its IQ is NOT retained.
     * @param rangeIndices u32 [K] range indices in the source grid.
     * @param dopplerIndices u32 [K] Doppler indices in source FFT order.
     * @param amplitudes f32 [K] linear detector magnitudes, not powers.
     * @param snrDb f32 [K] detector-provided SNR in decibels.
     * @param complexPairsC32 c32 [K] representative complex I/Q per detection.
     */
    DetectionList(const RangeDopplerMap& source, af::array rangeIndices, af::array dopplerIndices,
                  af::array amplitudes, af::array snrDb, af::array complexPairsC32);
    /** @brief Adopt columns with detached metadata/grids; same column contracts as above. */
    DetectionList(CPI_Metadata metadata, RangeAxis rangeAxis, DopplerAxis dopplerAxis,
                  af::array rangeIndices, af::array dopplerIndices, af::array amplitudes,
                  af::array snrDb, af::array complexPairsC32);
    /**
     * @brief Decode u32 linear cell indices and adopt already-gathered c32 I/Q.
     * @details cell = Doppler index + Doppler bin count * range index.
     * All numerical arguments are [K]; no RDM gather or host transfer occurs.
     */
    [[nodiscard]] static DetectionList fromCells(const RangeDopplerMap& source,
        af::array linearCellIndices, af::array amplitudes, af::array snrDb, af::array complexPairsC32);
    /**
     * @brief Decode cell indices and gather ONE selected element's c32 I/Q column.
     * @param elementIndex Representative element/beam, default zero.
     * @details Supplied amplitudes/SNR are not recalculated from that element;
     * a detector may have used a different combined signal. No E-by-K snapshot.
     */
    [[nodiscard]] static DetectionList fromMap(const RangeDopplerMap& source,
        af::array linearCellIndices, af::array amplitudes, af::array snrDb, dim_t elementIndex = 0);
    /** @brief Get number of detections, without querying device values. */
    [[nodiscard]] std::size_t getDetectionCount() const noexcept { return detectionCount_; }
    /** @brief Get whether the list is empty. */
    [[nodiscard]] bool getIsEmpty() const noexcept { return detectionCount_ == 0; }
    /** @brief Get CPI metadata stored once per list. */
    [[nodiscard]] const CPI_Metadata& getMetadata() const noexcept { return metadata_; }
    /** @brief Get range-grid calibration. */
    [[nodiscard]] const RangeAxis& getRangeAxis() const noexcept { return rangeAxis_; }
    /** @brief Get FFT grid/order and actual integrated pulse count. */
    [[nodiscard]] const DopplerAxis& getDopplerAxis() const noexcept { return dopplerAxis_; }
    /** @brief Get u32 [K] range indices. */
    [[nodiscard]] const af::array& getRangeIndices() const noexcept { return rangeIndices_; }
    /** @brief Get u32 [K] Doppler indices. */
    [[nodiscard]] const af::array& getDopplerIndices() const noexcept { return dopplerIndices_; }
    /** @brief Get f32 [K] linear amplitudes, not powers. */
    [[nodiscard]] const af::array& getAmplitudes() const noexcept { return amplitudes_; }
    /** @brief Get f32 [K] stored SNR in dB, without recomputation. */
    [[nodiscard]] const af::array& getSnrDb() const noexcept { return snrDb_; }
    /** @brief Get c32 [K] representative I/Q pairs, not per-element vectors. */
    [[nodiscard]] const af::array& getComplexPairsC32() const noexcept { return complexPairsC32_; }
    /** @brief Get whether azimuth has been supplied, even for an empty list. */
    [[nodiscard]] bool getHasAzimuth() const noexcept { return azimuthRadians_.has_value(); }
    /** @brief Get whether elevation has been supplied, even for an empty list. */
    [[nodiscard]] bool getHasElevation() const noexcept { return elevationRadians_.has_value(); }
    /** @brief Get whether both angle columns have been supplied. */
    [[nodiscard]] bool getHasAngles() const noexcept { return getHasAzimuth() && getHasElevation(); }
    /** @brief Get f32 [K] azimuth radians. @pre getHasAzimuth() is true. */
    [[nodiscard]] const af::array& getAzimuthRadians() const noexcept { return *azimuthRadians_; }
    /** @brief Get f32 [K] elevation radians. @pre getHasElevation() is true. */
    [[nodiscard]] const af::array& getElevationRadians() const noexcept { return *elevationRadians_; }
    /** @brief Get logical device payload bytes; excludes allocator overhead/shared storage. */
    [[nodiscard]] std::size_t getPayloadBytes() const noexcept {
        return detectionCount_ * (24u + 4u * static_cast<unsigned>(getHasAzimuth())
                                      + 4u * static_cast<unsigned>(getHasElevation()));
    }
    /** @brief Replace linear amplitudes; same count/device and f32 required. */
    void setAmplitudes(af::array amplitudes);
    /** @brief Replace SNR-dB column; same count/device and f32 required. */
    void setSnrDb(af::array snrDb);
    /** @brief Replace c32 I/Q column; same count/device required. */
    void setComplexPairsC32(af::array complexPairsC32);
    /** @brief Attach f32 [K] azimuth radians; no host data read or dtype conversion. */
    void setAzimuthRadians(af::array azimuthRadians);
    /** @brief Attach f32 [K] elevation radians. */
    void setElevationRadians(af::array elevationRadians);
    /** @brief Attach both f32 [K] angle columns; radians, original detection order. */
    void setAngles(af::array azimuthRadians, af::array elevationRadians);
    /** @brief Release both optional angle handles without touching core columns. */
    void clearAngles() noexcept;
    /** @brief Return a one-entry DEVICE list; all indexing is unchecked. */
    [[nodiscard]] DetectionList getDetection(std::size_t detectionIndex) const;
    /** @brief Subset/reorder all present columns by u32 indices; duplicates allowed. */
    [[nodiscard]] DetectionList select(const af::array& detectionIndices) const;
    /** @brief Explicit deep copy of all present numerical columns. */
    [[nodiscard]] DetectionList clone() const;
    /** @brief Compute f32 range coordinates on device; metadata stays host-side. */
    [[nodiscard]] af::array getRangesMeters() const;
    /** @brief Compute f32 Doppler frequencies on device; signed integer bin decoding. */
    [[nodiscard]] af::array getDopplerHz() const;
    /** @brief Compute f32 monostatic radial velocities, positive receding. */
    [[nodiscard]] af::array getRadialVelocitiesMps() const;
    /** @brief Compute f32 [3,K] sensor-local XYZ; +x boresight, +y azimuth, +z up.
     *  @pre Both angle columns exist. Not a world-coordinate transformation. */
    [[nodiscard]] af::array getPositionsMeters() const;
    /** @brief EXPLICIT blocking export of five fields and any optional angles. */
    [[nodiscard]] std::vector<Detection> recordsToHost() const;
    /** @brief Request evaluation of present columns; no explicit device fence. */
    void evaluate() const;
    /** @brief Evaluate and explicitly wait for the active device. */
    void synchronize() const;
private:
    CPI_Metadata metadata_;
    RangeAxis rangeAxis_;
    DopplerAxis dopplerAxis_;
    std::size_t detectionCount_ = 0;
    af::array rangeIndices_;
    af::array dopplerIndices_;
    af::array amplitudes_;
    af::array snrDb_;
    af::array complexPairsC32_;
    std::optional<af::array> azimuthRadians_;
    std::optional<af::array> elevationRadians_;
};
} // namespace radar
