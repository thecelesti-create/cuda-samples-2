#pragma once
#include <radar/types.hpp>
namespace radar {
/**
 * @brief Small numeric description of one uniform-PRF monostatic CPI.
 * @details No heap-owned labels, cached derived values, or runtime validation.
 * Rates and waveform bandwidth must be positive. Bandwidth is the transmitted
 * waveform's effective bandwidth, not the ADC sampling rate.
 */
class CPI_Metadata final {
public:
    /**
     * @brief Construct CPI metadata; bandwidth is required in v8.
     * @param sampleRateHz ADC sampling frequency in Hz.
     * @param prfHz Pulse repetition frequency in Hz.
     * @param carrierFrequencyHz RF carrier frequency in Hz.
     * @param bandwidthHz Transmitted waveform bandwidth in Hz.
     * @param cpiId Application CPI identifier.
     * @param firstSampleDelaySeconds Round-trip delay of raw sample zero.
     * @param firstPulseTimeSeconds Time of pulse zero in the application epoch.
     * @param positiveDoppler Receiver Doppler sign convention.
     */
    CPI_Metadata(double sampleRateHz, double prfHz, double carrierFrequencyHz,
                 double bandwidthHz, std::uint64_t cpiId = 0,
                 double firstSampleDelaySeconds = 0.0,
                 double firstPulseTimeSeconds = 0.0,
                 PositiveDoppler positiveDoppler = PositiveDoppler::Approaching) noexcept;
    /** @brief Get ADC sample rate in Hz. */
    [[nodiscard]] double getSampleRateHz() const noexcept { return sampleRateHz_; }
    /** @brief Get pulse repetition frequency in Hz. */
    [[nodiscard]] double getPrfHz() const noexcept { return prfHz_; }
    /** @brief Get RF carrier frequency in Hz. */
    [[nodiscard]] double getCarrierFrequencyHz() const noexcept { return carrierFrequencyHz_; }
    /** @brief Get transmitted waveform bandwidth in Hz. */
    [[nodiscard]] double getBandwidthHz() const noexcept { return bandwidthHz_; }
    /** @brief Get application CPI identifier. */
    [[nodiscard]] std::uint64_t getCpiId() const noexcept { return cpiId_; }
    /** @brief Get raw sample-zero round-trip delay in seconds. */
    [[nodiscard]] double getFirstSampleDelaySeconds() const noexcept { return firstSampleDelaySeconds_; }
    /** @brief Get pulse-zero timestamp in application seconds. */
    [[nodiscard]] double getFirstPulseTimeSeconds() const noexcept { return firstPulseTimeSeconds_; }
    /** @brief Get receiver Doppler sign convention. */
    [[nodiscard]] PositiveDoppler getPositiveDoppler() const noexcept { return positiveDoppler_; }
    /** @brief Get sample period, 1 / sampleRateHz, in seconds. */
    [[nodiscard]] double getSamplePeriodSeconds() const noexcept { return 1.0 / sampleRateHz_; }
    /** @brief Get pulse repetition interval, 1 / PRF, in seconds. */
    [[nodiscard]] double getPulsePeriodSeconds() const noexcept { return 1.0 / prfHz_; }
    /** @brief Get carrier wavelength in meters. */
    [[nodiscard]] double getWavelengthMeters() const noexcept { return speedOfLightMps / carrierFrequencyHz_; }
    /** @brief Convert Doppler Hz to monostatic velocity; positive means receding. */
    [[nodiscard]] double getRadialVelocityMps(double dopplerHz) const noexcept {
        return (positiveDoppler_ == PositiveDoppler::Receding ? 0.5 : -0.5)
               * getWavelengthMeters() * dopplerHz;
    }
    /** @brief Get ideal unambiguous range c/(2*PRF), not instrumented coverage. */
    [[nodiscard]] double getUnambiguousRangeMeters() const noexcept { return speedOfLightMps / (2.0 * prfHz_); }
    /** @brief Get full Doppler ambiguity span PRF, in Hz. */
    [[nodiscard]] double getUnambiguousDopplerSpanHz() const noexcept { return prfHz_; }
    /** @brief Get signed Doppler lower bound -PRF/2, in Hz. */
    [[nodiscard]] double getMinUnambiguousDopplerHz() const noexcept { return -0.5 * prfHz_; }
    /** @brief Get exclusive upper bound +PRF/2; interval is [-PRF/2, PRF/2). */
    [[nodiscard]] double getMaxUnambiguousDopplerHz() const noexcept { return 0.5 * prfHz_; }
    /** @brief Get monostatic radial-speed magnitude boundary lambda*PRF/4. */
    [[nodiscard]] double getMaxUnambiguousSpeedMps() const noexcept { return getWavelengthMeters() * prfHz_ / 4.0; }
    /** @brief Get nominal c/(2*bandwidth) resolution; not range-bin spacing. */
    [[nodiscard]] double getNominalRangeResolutionMeters() const noexcept { return speedOfLightMps / (2.0 * bandwidthHz_); }
    /** @brief Set ADC sample rate in Hz; caller supplies a positive value. */
    void setSampleRateHz(double value) noexcept { sampleRateHz_ = value; }
    /** @brief Set PRF in Hz; update dependent processed grids separately. */
    void setPrfHz(double value) noexcept { prfHz_ = value; }
    /** @brief Set carrier frequency in Hz. */
    void setCarrierFrequencyHz(double value) noexcept { carrierFrequencyHz_ = value; }
    /** @brief Set transmitted waveform bandwidth in Hz. */
    void setBandwidthHz(double value) noexcept { bandwidthHz_ = value; }
    /** @brief Set application CPI identifier. */
    void setCpiId(std::uint64_t value) noexcept { cpiId_ = value; }
    /** @brief Set raw sample-zero round-trip delay in seconds. */
    void setFirstSampleDelaySeconds(double value) noexcept { firstSampleDelaySeconds_ = value; }
    /** @brief Set pulse-zero application timestamp in seconds. */
    void setFirstPulseTimeSeconds(double value) noexcept { firstPulseTimeSeconds_ = value; }
    /** @brief Set the receiver Doppler sign convention. */
    void setPositiveDoppler(PositiveDoppler value) noexcept { positiveDoppler_ = value; }
private:
    double sampleRateHz_;
    double prfHz_;
    double carrierFrequencyHz_;
    double bandwidthHz_;
    std::uint64_t cpiId_;
    double firstSampleDelaySeconds_;
    double firstPulseTimeSeconds_;
    PositiveDoppler positiveDoppler_;
};
} // namespace radar
