#pragma once
#include <radar/config.hpp>
#include <arrayfire.h>
#include <af/version.h>

#if AF_VERSION_MAJOR != 3 || AF_VERSION_MINOR < 10
#  error "radar-chain-types requires ArrayFire 3.10 or a later 3.x SDK."
#endif
