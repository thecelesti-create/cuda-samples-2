#pragma once
/** @file radar.hpp @brief Public radar data-type umbrella header. */
#include <radar/metadata.hpp>
#include <radar/SamplePulseBuffer.hpp>
#include <radar/RangePulseBuffer.hpp>
#include <radar/RangeDopplerMap.hpp>
#include <radar/DetectionList.hpp>
