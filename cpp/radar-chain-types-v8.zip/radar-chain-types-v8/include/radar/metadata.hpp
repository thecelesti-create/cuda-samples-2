#pragma once
/** @file metadata.hpp
 *  @brief Convenience includes only. Each value class has its own HPP/CPP pair.
 */
#include <radar/CPI_Metadata.hpp>
#include <radar/RangeAxis.hpp>
#include <radar/DopplerAxis.hpp>
#include <radar/Detection.hpp>
