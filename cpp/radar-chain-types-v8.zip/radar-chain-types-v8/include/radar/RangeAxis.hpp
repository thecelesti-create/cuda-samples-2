#pragma once
#include <radar/types.hpp>
namespace radar {
/** @brief Two-scalar processed range grid, independent of raw acquisition timing. */
class RangeAxis final {
public:
    /** @brief Set output bin-zero range and spacing; both are in meters. */
    RangeAxis(double firstBinMeters, double binSpacingMeters) noexcept;
    /** @brief Get range of output bin zero in meters. */
    [[nodiscard]] double getFirstBinMeters() const noexcept { return firstBinMeters_; }
    /** @brief Get range-bin spacing in meters, not waveform range resolution. */
    [[nodiscard]] double getBinSpacingMeters() const noexcept { return binSpacingMeters_; }
    /** @brief Convert a bin index to meters without bounds checks. */
    [[nodiscard]] double getMeters(BinIndex bin) const noexcept { return firstBinMeters_ + static_cast<double>(bin) * binSpacingMeters_; }
    /** @brief Return a grid whose bin zero corresponds to the given original bin. */
    [[nodiscard]] RangeAxis sliced(BinIndex first) const noexcept;
    /** @brief Set range origin in meters. */
    void setFirstBinMeters(double value) noexcept { firstBinMeters_ = value; }
    /** @brief Set output range-bin spacing in meters. */
    void setBinSpacingMeters(double value) noexcept { binSpacingMeters_ = value; }
    /**
     * @brief Derive range origin/spacing from corrected output timing.
     * @param delaySeconds Round-trip delay of output bin zero AFTER filter delay correction.
     * @param sampleRateHz Actual processed output sample rate, including resampling.
     */
    [[nodiscard]] static RangeAxis fromRoundTripTiming(double delaySeconds, double sampleRateHz) noexcept;
private:
    double firstBinMeters_;
    double binSpacingMeters_;
};
} // namespace radar
