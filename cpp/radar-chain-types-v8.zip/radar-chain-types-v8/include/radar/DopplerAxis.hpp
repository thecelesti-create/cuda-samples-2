#pragma once
#include <radar/types.hpp>
namespace radar {
/** @brief FFT length, actual pulse count, PRF and ordering; no duplicated derived fields. */
class DopplerAxis final {
public:
    /** @brief Construct an FFT grid; fftSize >= pulsesUsed > 0 and prfHz > 0. */
    DopplerAxis(BinIndex fftSize, BinIndex pulsesUsed, double prfHz,
                DopplerOrder order = DopplerOrder::Unshifted) noexcept;
    /** @brief Get transform length, including zero padding. */
    [[nodiscard]] BinIndex getFftSize() const noexcept { return fftSize_; }
    /** @brief Get actual number of integrated pulses, excluding padding. */
    [[nodiscard]] BinIndex getPulsesUsed() const noexcept { return pulsesUsed_; }
    /** @brief Get slow-time sample frequency in Hz. */
    [[nodiscard]] double getPrfHz() const noexcept { return prfHz_; }
    /** @brief Get physical bin storage order. */
    [[nodiscard]] DopplerOrder getOrder() const noexcept { return order_; }
    /** @brief Get PRF/Nfft bin spacing; zero padding does not improve resolution. */
    [[nodiscard]] double getBinSpacingHz() const noexcept { return prfHz_ / static_cast<double>(fftSize_); }
    /** @brief Get integration duration pulsesUsed/PRF in seconds. */
    [[nodiscard]] double getCoherentIntervalSeconds() const noexcept { return static_cast<double>(pulsesUsed_) / prfHz_; }
    /** @brief Convert a valid array bin to a signed bin; even Nyquist is negative. */
    [[nodiscard]] BinIndex getSignedBin(BinIndex bin) const noexcept {
        if (order_ == DopplerOrder::Centered) return bin - fftSize_ / 2;
        return bin <= (fftSize_ - 1) / 2 ? bin : bin - fftSize_;
    }
    /** @brief Convert a valid array bin to Doppler frequency in Hz. */
    [[nodiscard]] double getHertz(BinIndex bin) const noexcept { return static_cast<double>(getSignedBin(bin)) * getBinSpacingHz(); }
    /** @brief Set FFT grid length. */
    void setFftSize(BinIndex value) noexcept { fftSize_ = value; }
    /** @brief Set actual integrated pulse count. */
    void setPulsesUsed(BinIndex value) noexcept { pulsesUsed_ = value; }
    /** @brief Set slow-time sample frequency in Hz. */
    void setPrfHz(double value) noexcept { prfHz_ = value; }
    /** @brief Describe ordering only; use RangeDopplerMap::setDopplerOrder to move data. */
    void setOrder(DopplerOrder value) noexcept { order_ = value; }
private:
    BinIndex fftSize_;
    BinIndex pulsesUsed_;
    double prfHz_;
    DopplerOrder order_;
};
} // namespace radar
