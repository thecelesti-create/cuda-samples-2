#pragma once
#include <radar/types.hpp>
#include <complex>
#include <optional>
namespace radar {
/**
 * @brief Lightweight HOST record: range index, Doppler index, amplitude, SNR, I/Q.
 * @details No nested records, metadata, derived coordinates, or noise-power fields.
 * The complex pair means ONE complex<float> (I,Q), not two complex values.
 * Amplitude is linear magnitude on the detector's scale; SNR is explicitly dB.
 * Optional azimuth/elevation in radians are populated only when available.
 * GPU algorithms use DetectionList instead; host export is explicit.
 */
class Detection final {
public:
    /** @brief Construct the five required values; optional angles default absent. */
    Detection(std::uint32_t rangeIndex = 0, std::uint32_t dopplerIndex = 0,
              float amplitude = 0.0f, float snrDb = 0.0f,
              std::complex<float> complexPairC32 = {},
              std::optional<float> azimuthRadians = std::nullopt,
              std::optional<float> elevationRadians = std::nullopt) noexcept;
    /** @brief Get range-bin index, not meters. */
    [[nodiscard]] std::uint32_t getRangeIndex() const noexcept { return rangeIndex_; }
    /** @brief Get Doppler-bin index in the list's FFT ordering, not Hz. */
    [[nodiscard]] std::uint32_t getDopplerIndex() const noexcept { return dopplerIndex_; }
    /** @brief Get linear detector amplitude, not power or dB. */
    [[nodiscard]] float getAmplitude() const noexcept { return amplitude_; }
    /** @brief Get detector-provided SNR in dB; no recomputation. */
    [[nodiscard]] float getSnrDb() const noexcept { return snrDb_; }
    /** @brief Get one float I/Q pair; real is I, imaginary is Q. */
    [[nodiscard]] std::complex<float> getComplexPairC32() const noexcept { return complexPairC32_; }
    /** @brief Get optional azimuth radians; present NaN denotes an invalid estimate. */
    [[nodiscard]] std::optional<float> getAzimuthRadians() const noexcept { return azimuthRadians_; }
    /** @brief Get optional elevation radians; a 1D estimator uses its configured prior. */
    [[nodiscard]] std::optional<float> getElevationRadians() const noexcept { return elevationRadians_; }
    /** @brief Set the range-bin index. */
    void setRangeIndex(std::uint32_t value) noexcept { rangeIndex_ = value; }
    /** @brief Set the Doppler-bin index. */
    void setDopplerIndex(std::uint32_t value) noexcept { dopplerIndex_ = value; }
    /** @brief Set linear detector amplitude. */
    void setAmplitude(float value) noexcept { amplitude_ = value; }
    /** @brief Set SNR in dB. */
    void setSnrDb(float value) noexcept { snrDb_ = value; }
    /** @brief Set one float I/Q pair. */
    void setComplexPairC32(std::complex<float> value) noexcept { complexPairC32_ = value; }
    /** @brief Set azimuth radians or std::nullopt to remove it. */
    void setAzimuthRadians(std::optional<float> value) noexcept { azimuthRadians_ = value; }
    /** @brief Set elevation radians or std::nullopt to remove it. */
    void setElevationRadians(std::optional<float> value) noexcept { elevationRadians_ = value; }
private:
    std::uint32_t rangeIndex_;
    std::uint32_t dopplerIndex_;
    float amplitude_;
    float snrDb_;
    std::complex<float> complexPairC32_;
    std::optional<float> azimuthRadians_;
    std::optional<float> elevationRadians_;
};
} // namespace radar
