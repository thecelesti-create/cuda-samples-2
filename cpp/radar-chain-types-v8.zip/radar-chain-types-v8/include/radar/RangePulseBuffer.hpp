#pragma once

#include <radar/SamplePulseBuffer.hpp>

namespace radar {

// Range-compressed complex IQ: [range, pulse, element, 1].
// All indexed helpers are UNCHECKED: valid indices/slices and an active owning
// ArrayFire backend/device are caller preconditions. The wrapper performs no runtime validation.
/**
 * @brief c32 complex single-precision IQ stored as [range,pulse,element,1].
 * @details c32 means two float components (I,Q), eight bytes per value. This
 * class never auto-casts f32/c64 input, validates input, or implicitly downloads IQ.
 * @pre All adopted arrays are c32 and satisfy this layout on the active device.
 * Indexed helpers require valid indices/counts. Copies retain ArrayFire handles;
 * use clone() only when an independent allocation is explicitly required.
 */
class RangePulseBuffer final {
public:
    /** @brief Construct or adopt c32 IQ using the documented layout; no implicit dtype conversion or validation. */
    RangePulseBuffer(af::array iqC32, CPI_Metadata metadata, RangeAxis rangeAxis);
    // Adopts an already-computed result. Pulse/element counts must match source;
    // the matched filter may change the range count. No filtering in this class.
    /** @brief Construct or adopt c32 IQ using the documented layout; no implicit dtype conversion or validation. */
    RangePulseBuffer(const SamplePulseBuffer& source, af::array filteredIqC32, RangeAxis rangeAxis);

    /** @brief Get the c32 complex IQ array by const reference; no copy or download. */
    [[nodiscard]] const af::array& getDataC32() const noexcept { return iqC32_; }
    /** @brief Get CPI metadata by const reference. */
    [[nodiscard]] const CPI_Metadata& getMetadata() const noexcept { return metadata_; }
    /** @brief Get the number of processed range bins. */
    [[nodiscard]] dim_t getRangeBinCount() const noexcept { return rangeBinCount_; }
    /** @brief Get the number of slow-time pulses. */
    [[nodiscard]] dim_t getPulseCount() const noexcept { return pulseCount_; }
    // Hardware element count (dim2), not getDataC32().elements() total IQ values.
    /** @brief Get hardware element count, not total ArrayFire value count. */
    [[nodiscard]] dim_t getElementCount() const noexcept { return elementCount_; }
    /** @brief Get the documented four-dimensional storage shape; final dimension is one. */
    [[nodiscard]] af::dim4 getDimensions() const { return af::dim4(rangeBinCount_, pulseCount_, elementCount_); }
    /** @brief Get logical c32 payload bytes, excluding ArrayFire allocator/workspace overhead. */
    [[nodiscard]] std::size_t getBytes() const noexcept {
        return static_cast<std::size_t>(rangeBinCount_) * static_cast<std::size_t>(pulseCount_) *
               static_cast<std::size_t>(elementCount_) * sizeof(af::cfloat);
    }
    // Logical column-major offset; not necessarily a physical offset in a view.
    /** @brief Compute an unchecked logical column-major index; not a pointer offset into a strided view. */
    [[nodiscard]] std::size_t getLinearIndex(dim_t rangeBin, dim_t pulseIndex, dim_t elementIndex) const noexcept {
        return static_cast<std::size_t>(rangeBin) + static_cast<std::size_t>(rangeBinCount_) *
               (static_cast<std::size_t>(pulseIndex) + static_cast<std::size_t>(pulseCount_) *
                static_cast<std::size_t>(elementIndex));
    }
    /** @brief Get the timestamp of a valid pulse index in application seconds. */
    [[nodiscard]] double getPulseTimeSeconds(dim_t pulseIndex) const noexcept {
        return metadata_.getFirstPulseTimeSeconds() + static_cast<double>(pulseIndex) *
               metadata_.getPulsePeriodSeconds();
    }
    /** @brief Get processed range calibration, independent of raw sample timing. */
    [[nodiscard]] const RangeAxis& getRangeAxis() const noexcept { return rangeAxis_; }
    /** @brief Get range in meters for a valid range bin. */
    [[nodiscard]] double getRangeMeters(dim_t rangeBin) const noexcept { return rangeAxis_.getMeters(rangeBin); }
    /** @brief Get rangeBinCount * elementCount independent slow-time vectors. */
    [[nodiscard]] dim_t getDopplerBatchCount() const noexcept { return rangeBinCount_ * elementCount_; }
    /** @brief Get one c32 fast-time/range vector at a valid pulse and element. */
    [[nodiscard]] af::array getPulseC32(dim_t pulseIndex, dim_t elementIndex) const;
    /** @brief Get the c32 two-dimensional plane for one valid element; storage may be shared. */
    [[nodiscard]] af::array getElementC32(dim_t elementIndex) const;
    /** @brief Get the c32 slow-time vector at a valid sample/range and element. */
    [[nodiscard]] af::array getSlowTimeC32(dim_t rangeBin, dim_t elementIndex) const;
    /** @brief Return a c32 range crop with updated range count and origin. */
    [[nodiscard]] RangePulseBuffer sliceRanges(dim_t firstRangeBin, dim_t rangeBinCount) const;
    /** @brief Return a c32 pulse crop with updated pulse count and pulse-zero timestamp. */
    [[nodiscard]] RangePulseBuffer slicePulses(dim_t firstPulse, dim_t pulseCount) const;
    // Explicit reorder [R,P,E] -> [P,R,E] for ArrayFire's leading-axis FFT.
    /** @brief Reorder c32 [range,pulse,element] to [pulse,range,element]; actual device data movement. */
    [[nodiscard]] af::array getDopplerInputC32() const;
    /** @brief Compute f32 squared complex magnitude on the current backend; c32 IQ is preserved. */
    [[nodiscard]] af::array getPower() const;

    // Replacement is unchecked. Shape/layout and
    // backend/device must stay unchanged; constructors support intentional changes.
    /** @brief Adopt c32 replacement IQ; same shape and device are unchecked preconditions. */
    void setDataC32(af::array iqC32);
    /** @brief Replace numeric CPI metadata without validation; acquisition/grid consistency is the caller's responsibility. */
    void setMetadata(CPI_Metadata metadata);
    /** @brief Replace processed range calibration; no numerical data movement. */
    void setRangeAxis(RangeAxis rangeAxis);
    /** @brief Return a wrapper with same-shape c32 replacement IQ and existing metadata. */
    [[nodiscard]] RangePulseBuffer withDataC32(af::array iqC32) const;
    /** @brief Explicitly deep-copy c32 payload; ordinary wrapper copies retain ArrayFire storage. */
    [[nodiscard]] RangePulseBuffer clone() const; // Explicit deep copy, no revalidation.
    /** @brief EXPLICIT blocking download of c32 IQ into float I/Q host pairs. */
    [[nodiscard]] std::vector<af::cfloat> toHost() const;
    /** @brief Request ArrayFire evaluation without an explicit device fence. */
    void evaluate() const;
    /** @brief Evaluate and explicitly wait for the active owning device; no host download. */
    void synchronize() const;

private:
    af::array iqC32_;
    CPI_Metadata metadata_;
    RangeAxis rangeAxis_;
    // Cached at construction and updated by trusted slice helpers only.
    dim_t rangeBinCount_;
    dim_t pulseCount_;
    dim_t elementCount_;
};
} // namespace radar
