#!/usr/bin/env python3
"""Static source-organization/Doxygen audit; not a C++ or ArrayFire compiler."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
headers=sorted((root/'include').rglob('*.hpp'))+sorted((root/'interferometry/include').rglob('*.hpp'))
classes=[]; fields=[]; methods=0; errors=[]
for p in headers:
    text=p.read_text()
    code=re.sub(r'/\*.*?\*/|//[^\n]*','',text,flags=re.S)
    if re.search(r'\bstruct\s+\w+\s*\{',code): errors.append(f'struct in {p}')
    found=re.findall(r'^class (\w+) final\s*\{',code,re.M)
    if len(found)>1: errors.append(f'multiple classes in {p}')
    for name in found:
        classes.append(name)
        if p.stem!=name: errors.append(f'wrong header filename for {name}')
        source=root/('interferometry/src' if 'interferometry/include' in p.as_posix() else 'src')/(name+'.cpp')
        if not source.exists() or f'{name}::{name}(' not in source.read_text(): errors.append(f'missing real CPP constructor for {name}')
    access='private'
    for line in code.splitlines():
        if line.strip() in ('public:','private:','protected:'): access=line.strip()[:-1]
        if re.match(r'\s*[\w:<>, ]+\s+\w+_\s*(?:=[^;]+)?;\s*$',line):
            field=line.strip();fields.append(field)
            if access!='private': errors.append(f'nonprivate field: {p}: {field}')
    # Header functions are the authoritative Doxygen declarations; inline trivial
    # getters are intentionally retained. Inherited compiler special members have
    # no declarations to document.
    lines=text.splitlines()
    if found:
        for i,line in enumerate(lines):
            if re.match(r'^    (?:\[\[nodiscard\]\]|void |explicit |'+found[0]+r'\()',line) and '(' in line:
                methods+=1
                j=i-1
                while j>=0 and not lines[j].strip(): j-=1
                if j<0 or not lines[j].strip().endswith('*/'): errors.append(f'no adjacent Doxygen doc: {p.name}:{i+1}')
        classline=next(i for i,l in enumerate(lines) if l.startswith('class '+found[0]))
        if not lines[classline-1].strip().endswith('*/'):errors.append(f'class lacks Doxygen: {p}')
for p in [*headers,*sorted((root/'src').rglob('*.cpp')),*sorted((root/'interferometry/src').rglob('*.cpp'))]:
    code=re.sub(r'/\*.*?\*/|//[^\n]*','',p.read_text(),flags=re.S)
    for name in ['DetectionCell','DetectionContext','AngleEstimate','AzElDetection','AzElDetectionList']:
        if re.search(r'\b'+name+r'\b',code):errors.append(f'removed type {name} in {p}')
    if re.search(r'\bdim\d+_',code):errors.append(f'numbered dimension in {p}')
    if re.search(r'\bthrow\b|\bassert\s*\(',code):errors.append(f'production runtime validator in {p}')
for p in (root/'interferometry/src').glob('*'):
    code=re.sub(r'/\*.*?\*/|//[^\n]*','',p.read_text(),flags=re.S)
    if re.search(r'\b(?:host|scalar|sync|where)\s*[(<]',code):errors.append(f'host readback/fence in {p}')
print(f'{len(classes)} classes with matching individual HPP/CPP constructor definitions')
print('\n'.join('  '+c for c in classes))
print(f'{len(fields)} fields, all private' if not errors else f'{len(fields)} field declarations examined')
print(f'{methods} public function declarations checked for adjacent Doxygen documentation')
print('No removed types, numbered dimension members or production throw/assert validators')
print('No explicit host/scalar/sync/where calls in interferometry sources')
if errors:
    print('\n'.join(errors));raise SystemExit(1)
print('PASS (static text audit only, not an SDK compile or Doxygen execution)')
