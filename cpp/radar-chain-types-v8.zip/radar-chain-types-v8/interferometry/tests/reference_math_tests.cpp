// Independent scalar oracle for the phase model; NOT an ArrayFire backend test.
#include <radar/interferometry/UniformArray.hpp>
#include <radar/metadata.hpp>
#include "test_support.hpp"
#include <complex>
#include <limits>
#include <array>
#include <vector>
#include <type_traits>
using namespace radar;
using namespace radar::interferometry;
static_assert(!std::is_aggregate_v<UniformLinearArray>);
static_assert(std::is_trivially_copyable_v<UniformLinearArray>);
static_assert(!std::is_polymorphic_v<UniformRectangularArray>);
static_assert(std::is_trivially_copyable_v<UniformRectangularArray>);

/** @brief Create scalar complex test data for the independent far-field phase oracle. */
std::vector<std::complex<double>> synthesize(std::size_t ny, std::size_t nz,
    double dy, double dz, double wavelength, double u, double v,
    PhaseSign sign, double u0, double v0) {
    std::vector<std::complex<double>> iq(ny*nz);
    for (std::size_t z=0; z<nz; ++z)
        for (std::size_t y=0; y<ny; ++y) {
            const double phase = static_cast<int>(sign) * 2*pi/wavelength *
                (static_cast<double>(y)*dy*(u-u0) + static_cast<double>(z)*dz*(v-v0));
            // Positive nonuniform gains and common phase must not change the answer.
            iq[y+ny*z] = std::polar(1.0 + 0.05*static_cast<double>(y+z), phase+0.63);
        }
    return iq;
}
/** @brief Return scalar correlation phase, or NaN for zero correlation. */
double phaseOf(std::complex<double> correlation) {
    return std::norm(correlation) > 0 ? std::arg(correlation) : std::numeric_limits<double>::quiet_NaN();
}
/** @brief Independent scalar oracle for linear-array angle estimation, not an ArrayFire implementation. */
double scalar1D(const std::vector<std::complex<double>>& iq, const UniformLinearArray& g, double wavelength) {
    std::complex<double> correlation{0,0};
    for (std::size_t y=0; y+1<g.getElementCount(); ++y) correlation += std::conj(iq[y])*iq[y+1];
    const double u = g.getReferenceDirectionCosineY() + static_cast<int>(g.getPhaseSign()) *
        wavelength/(2*pi*g.getSpacingMeters()) * phaseOf(correlation);
    return std::asin(u/std::cos(g.getAssumedElevationRadians()));
}
/** @brief Independent scalar oracle for rectangular-array angle estimation. */
std::array<double,2> scalar2D(const std::vector<std::complex<double>>& iq,
                             const UniformRectangularArray& g, double wavelength) {
    const auto ny=g.getAzimuthElementCount(), nz=g.getElevationElementCount();
    std::complex<double> cy{0,0}, cz{0,0};
    for (std::size_t z=0; z<nz; ++z)
        for (std::size_t y=0; y<ny; ++y) {
            if (y+1<ny) cy += std::conj(iq[y+ny*z])*iq[y+1+ny*z];
            if (z+1<nz) cz += std::conj(iq[y+ny*z])*iq[y+ny*(z+1)];
        }
    const double u = g.getReferenceDirectionCosineY() + static_cast<int>(g.getPhaseSign()) *
        wavelength/(2*pi*g.getAzimuthSpacingMeters()) * phaseOf(cy);
    const double v = g.getReferenceDirectionCosineZ() + static_cast<int>(g.getPhaseSign()) *
        wavelength/(2*pi*g.getElevationSpacingMeters()) * phaseOf(cz);
    return {std::atan2(u,std::sqrt(1-u*u-v*v)), std::asin(v)};
}
/** @brief Run the documented reference processing example or test executable. */
int main() {
    try {
        constexpr double wavelength=0.03;
        test::run("geometry value classes and setters", [] {
            UniformLinearArray line(5, 0.015);
            line.setElementCount(8); line.setSpacingMeters(0.01);
            line.setAssumedElevationRadians(0.2); line.setPhaseSign(PhaseSign::Negative);
            line.setReferenceDirectionCosineY(0.1);
            test::check(line.getElementCount()==8,"ULA count");
            test::near(line.getSpacingMeters(),0.01);
            test::near(line.getAssumedElevationRadians(),0.2);
            test::near(line.getReferenceDirectionCosineY(),0.1);
            test::check(line.getPhaseSign()==PhaseSign::Negative,"phase sign");
            UniformRectangularArray grid(4,3,0.01,0.015);
            test::check(grid.getElementCount()==12,"URA flattened count");
            grid.setAzimuthElementCount(3); grid.setElevationElementCount(2);
            grid.setAzimuthSpacingMeters(0.02); grid.setElevationSpacingMeters(0.03);
            grid.setReferenceDirectionCosineY(0.1); grid.setReferenceDirectionCosineZ(-0.2);
            grid.setPhaseSign(PhaseSign::Negative);
            test::check(grid.getElementCount()==6,"URA setters");
            test::near(grid.getAzimuthSpacingMeters(),0.02); test::near(grid.getElevationSpacingMeters(),0.03);
            test::near(grid.getReferenceDirectionCosineY(),0.1); test::near(grid.getReferenceDirectionCosineZ(),-0.2);
        });
        test::run("1D direction cosine model and known elevation", [&] {
            for (auto sign : {PhaseSign::Positive, PhaseSign::Negative})
                for (int azDeg=-70; azDeg<=70; azDeg+=5)
                    for (double el : {0.0,0.3}) {
                        const double az=azDeg*pi/180;
                        UniformLinearArray g(8,0.4*wavelength,el,sign);
                        auto iq=synthesize(8,1,g.getSpacingMeters(),0,wavelength,
                            std::cos(el)*std::sin(az),0,sign,0,0);
                        test::near(scalar1D(iq,g,wavelength),az,1e-11);
                    }
        });
        test::run("2D rectangular grid sign and cross-axis coupling", [&] {
            for (auto sign : {PhaseSign::Positive, PhaseSign::Negative})
                for (int azDeg=-60; azDeg<=60; azDeg+=10)
                    for (int elDeg=-40; elDeg<=40; elDeg+=10) {
                        double az=azDeg*pi/180, el=elDeg*pi/180;
                        UniformRectangularArray g(5,3,wavelength/2,0.4*wavelength,sign);
                        auto iq=synthesize(5,3,g.getAzimuthSpacingMeters(),g.getElevationSpacingMeters(),wavelength,
                            std::cos(el)*std::sin(az),std::sin(el),sign,0,0);
                        auto result=scalar2D(iq,g,wavelength);
                        test::near(result[0],az,1e-11); test::near(result[1],el,1e-11);
                    }
        });
        test::run("subarray spacings and removed reference steering phase", [&] {
            const double az=25*pi/180,el=12*pi/180,u=std::cos(el)*std::sin(az),v=std::sin(el);
            const UniformRectangularArray g(2,2,2*wavelength,1.5*wavelength,PhaseSign::Negative,u-0.04,v+0.03);
            auto iq=synthesize(2,2,g.getAzimuthSpacingMeters(),g.getElevationSpacingMeters(),wavelength,u,v,
                g.getPhaseSign(),g.getReferenceDirectionCosineY(),g.getReferenceDirectionCosineZ());
            auto result=scalar2D(iq,g,wavelength);
            test::near(result[0],az);test::near(result[1],el);
            // Long spacing WITHOUT a phase reference does not magically resolve aliasing.
            const UniformLinearArray longArray(4,wavelength);
            auto aliased=synthesize(4,1,wavelength,0,wavelength,0.75,0,PhaseSign::Positive,0,0);
            test::near(scalar1D(aliased,longArray,wavelength),std::asin(-0.25));
        });
        test::run("zero coherence and nonphysical direction estimates", [&] {
            const UniformLinearArray line(4,wavelength/2);
            test::check(std::isnan(scalar1D(std::vector<std::complex<double>>(4),line,wavelength)),"zero has no angle");
            const UniformRectangularArray grid(3,2,wavelength/2,wavelength/2);
            auto iq=synthesize(3,2,wavelength/2,wavelength/2,wavelength,0.9,0.9,PhaseSign::Positive,0,0);
            test::check(std::isnan(scalar2D(iq,grid,wavelength)[0]),"outside unit disk is invalid");
        });
        std::cout << "All " << test::checks << " independent reference-math checks passed. No ArrayFire kernels executed.\n";
        return 0;
    } catch(const std::exception& e) { std::cerr << e.what() << '\n';return 1; }
}
