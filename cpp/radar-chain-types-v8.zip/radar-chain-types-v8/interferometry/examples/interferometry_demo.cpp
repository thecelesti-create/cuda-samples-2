#include <radar/interferometry/Interferometry.hpp>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

/** @brief Synthetic 4-by-3 half-wavelength array; expected angles are 20 and 10 degrees. */
int main(int argc, char** argv) {
    using namespace radar;
    using namespace radar::interferometry;
    try {
#if RADAR_ARRAYFIRE_UNIFIED
        const std::string backend = argc > 1 ? argv[1] : "cpu";
        if (backend == "cuda") af::setBackend(AF_BACKEND_CUDA);
        else if (backend == "cpu") af::setBackend(AF_BACKEND_CPU);
        else if (backend == "opencl") af::setBackend(AF_BACKEND_OPENCL);
        else throw std::invalid_argument("backend must be cpu, cuda or opencl");
#else
        (void)argc; (void)argv;
#endif
        af::setDevice(0);
        constexpr dim_t dopplerCount=8, rangeCount=16, azimuthCount=4, elevationCount=3;
        constexpr unsigned rangeIndex=5, dopplerIndex=2;
        const CPI_Metadata metadata(10e6, 2000.0, 10e9, 5e6, 7);
        const double az=20.0*pi/180.0, el=10.0*pi/180.0;
        const double u=std::cos(el)*std::sin(az), v=std::sin(el);
        std::vector<af::cfloat> iqC32(dopplerCount*rangeCount*azimuthCount*elevationCount);
        for (dim_t z=0; z<elevationCount; ++z) {
            for (dim_t y=0; y<azimuthCount; ++y) {
                const double phase=pi*(static_cast<double>(y)*u + static_cast<double>(z)*v);
                iqC32[dopplerIndex + dopplerCount*(rangeIndex + rangeCount*(y+azimuthCount*z))] =
                    {static_cast<float>(std::cos(phase)), static_cast<float>(std::sin(phase))};
            }
        }
        const af::array dataC32(af::dim4(dopplerCount,rangeCount,azimuthCount*elevationCount),
                                iqC32.data(), afHost);
        const RangeDopplerMap map(dataC32, metadata, RangeAxis(100.0,10.0),
                                  DopplerAxis(dopplerCount,dopplerCount,metadata.getPrfHz()));
        auto detections=DetectionList::fromMap(map,
            af::constant(dopplerIndex+dopplerCount*rangeIndex,af::dim4(1),u32),
            af::constant(1.0f,af::dim4(1),f32), af::constant(20.0f,af::dim4(1),f32));
        const Interferometry2D estimator(UniformRectangularArray(
            azimuthCount,elevationCount,metadata.getWavelengthMeters()/2.0,metadata.getWavelengthMeters()/2.0));
        // Same type in and out; five base columns are retained, not deep-copied.
        const DetectionList located=estimator.estimate(map,detections);
        for (const auto& record: located.recordsToHost()) {
            std::cout << "azimuth=" << *record.getAzimuthRadians()*180.0/pi
                      << " deg, elevation=" << *record.getElevationRadians()*180.0/pi << " deg\n";
        }
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
