#include <radar/interferometry/UniformRectangularArray.hpp>
namespace radar::interferometry {
UniformRectangularArray::UniformRectangularArray(std::size_t azimuthElementCount, std::size_t elevationElementCount,
                            double azimuthSpacingMeters, double elevationSpacingMeters,
                            PhaseSign phaseSign,
                            double referenceDirectionCosineY,
                            double referenceDirectionCosineZ) noexcept
        : azimuthElementCount_(azimuthElementCount), elevationElementCount_(elevationElementCount),
          azimuthSpacingMeters_(azimuthSpacingMeters), elevationSpacingMeters_(elevationSpacingMeters),
          phaseSign_(phaseSign), referenceDirectionCosineY_(referenceDirectionCosineY),
          referenceDirectionCosineZ_(referenceDirectionCosineZ) {}
} // namespace radar::interferometry
