#include <radar/interferometry/Interferometry1D.hpp>
#include "device_helpers.hpp"
#include <cmath>

namespace radar::interferometry {
Interferometry1D::Interferometry1D(UniformLinearArray geometry, std::size_t detectionBatchSize) noexcept
    : geometry_(geometry), detectionBatchSize_(detectionBatchSize) {}
namespace {
/** @brief Convert summed adjacent c32 correlations to f32 angle columns on device. */
void compute(const af::array& snapshots, const UniformLinearArray& geometry,
             double wavelength, af::array& azimuth, af::array& elevation) {
    const auto elementCount = geometry.getElementCount();
    const af::array lower = snapshots(detail::sequence(0, elementCount - 1), af::span);
    const af::array upper = snapshots(detail::sequence(1, elementCount - 1), af::span);
    const af::array correlation = af::sum(af::conjg(lower) * upper, 0);
    const float scale = static_cast<float>(static_cast<int>(geometry.getPhaseSign()) *
                                           wavelength / (2.0 * radar::pi * geometry.getSpacingMeters()));
    const af::array u = detail::phase(correlation) * scale +
                        static_cast<float>(geometry.getReferenceDirectionCosineY());
    // 1D aperture cannot independently estimate elevation. Explicit prior only.
    azimuth = af::asin(u / static_cast<float>(std::cos(geometry.getAssumedElevationRadians())));
    elevation = af::constant(static_cast<float>(geometry.getAssumedElevationRadians()), azimuth.dims(), f32);
}
} // namespace
DetectionList Interferometry1D::estimate(const RangeDopplerMap& map,
                                               const DetectionList& detections) const {
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return detail::gather(map, detections, first, count); },
        [&](const af::array& iq, af::array& az, af::array& el) {
            compute(iq, geometry_, map.getMetadata().getWavelengthMeters(), az, el);
        });
}
DetectionList Interferometry1D::estimate(std::span<const RangeDopplerMap> maps,
                                               const DetectionList& detections) const {
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) { return detail::gather(maps, detections, first, count); },
        [&](const af::array& iq, af::array& az, af::array& el) {
            compute(iq, geometry_, maps.front().getMetadata().getWavelengthMeters(), az, el);
        });
}
DetectionList Interferometry1D::estimate(const af::array& elementIqC32, const DetectionList& detections) const {
    return detail::estimateBatched(detections, detectionBatchSize_,
        [&](std::size_t first, std::size_t count) {
            return elementIqC32(af::span, detail::sequence(first, count));
        },
        [&](const af::array& iq, af::array& az, af::array& el) {
            compute(iq, geometry_, detections.getMetadata().getWavelengthMeters(), az, el);
        });
}
} // namespace radar::interferometry
