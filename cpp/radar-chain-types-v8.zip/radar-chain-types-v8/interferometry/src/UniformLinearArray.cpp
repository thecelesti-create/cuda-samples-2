#include <radar/interferometry/UniformLinearArray.hpp>
namespace radar::interferometry {
UniformLinearArray::UniformLinearArray(std::size_t elementCount, double spacingMeters,
                       double assumedElevationRadians,
                       PhaseSign phaseSign,
                       double referenceDirectionCosineY) noexcept
        : elementCount_(elementCount), spacingMeters_(spacingMeters),
          assumedElevationRadians_(assumedElevationRadians), phaseSign_(phaseSign),
          referenceDirectionCosineY_(referenceDirectionCosineY) {}
} // namespace radar::interferometry
