#pragma once
#include <radar/DetectionList.hpp>
#include <algorithm>
#include <limits>
#include <span>
#include <utility>

namespace radar::interferometry::detail {
/** @brief Make an unchecked inclusive ArrayFire sequence from first/count; count must be positive. */
inline af::seq sequence(std::size_t first, std::size_t count) {
    return af::seq(static_cast<double>(first), static_cast<double>(first + count - 1));
}
/** @brief Build u32 flattened range-Doppler indices for one block on device. */
inline af::array cellIndices(const DetectionList& detections, dim_t dopplerBinCount,
                              std::size_t first, std::size_t count) {
    const auto bins = sequence(first, count);
    // Explicit u32 operands avoid f32 rounding of integer indices above 2^24.
    const af::array stride = af::constant(static_cast<unsigned>(dopplerBinCount),
                                         af::dim4(static_cast<dim_t>(count)), u32);
    return detections.getDopplerIndices()(bins) + detections.getRangeIndices()(bins) * stride;
}
/** @brief Gather only the selected c32 phase-center values; contiguous RDM layout is required. */
inline af::array gather(const RangeDopplerMap& map, const DetectionList& detections,
                        std::size_t first, std::size_t count) {
    const auto indices = cellIndices(detections, map.getDopplerBinCount(), first, count);
    // Contiguous [D,R,E] input is a precondition for the no-full-cube-copy path.
    const auto planes = af::moddims(map.getDataC32(),
                                    map.getDopplerBinCount() * map.getRangeBinCount(),
                                    map.getElementCount());
    return af::reorder(af::lookup(planes, indices, 0), 1, 0, 2, 3);
}
/** @brief Gather only the selected c32 phase-center values; contiguous RDM layout is required. */
inline af::array gather(std::span<const RangeDopplerMap> maps, const DetectionList& detections,
                        std::size_t first, std::size_t count) {
    const auto indices = cellIndices(detections, maps.front().getDopplerBinCount(), first, count);
    af::array snapshots(af::dim4(static_cast<dim_t>(maps.size()), static_cast<dim_t>(count)), c32);
    // CPU loop is over phase centers, NOT detections. Each lookup stays on device.
    for (std::size_t element = 0; element < maps.size(); ++element) {
        const af::array selected = af::lookup(af::flat(maps[element].getDataC32()), indices, 0);
        snapshots(sequence(element, 1), af::span) = af::reorder(selected, 1, 0, 2, 3);
    }
    return snapshots;
}

// A zero complex correlation has no defined phase: emit NaN, not false boresight.
// Elementwise device math only, no reductions to host / shape or value scans.
/** @brief Get principal correlation phase in radians; zero correlation produces a device NaN. */
inline af::array phase(const af::array& correlation) {
    const auto magnitudeSquared = af::real(correlation * af::conjg(correlation));
    return af::flat(af::select(magnitudeSquared > 0.0f, af::arg(correlation),
                              std::numeric_limits<float>::quiet_NaN()));
}

// Chunk only IQ scratch; output columns are O(K). Evaluation bounds expression
// lifetimes without synchronizing or downloading to host. ArrayFire manages
// stream dependencies and may retain allocations in its memory pool.
/** @brief Estimate angles in blocks and attach optional columns to a shallow list copy. */
template<class Gather, class Compute>
DetectionList estimateBatched(const DetectionList& detections, std::size_t batchSize,
                                 Gather&& gatherBlock, Compute&& computeBlock) {
    const std::size_t detectionCount = detections.getDetectionCount();
    auto result = detections; // Retain only the five column handles and small metadata.
    if (detectionCount == 0) { result.setAngles({}, {}); return result; }
    if (detectionCount <= batchSize) {
        af::array azimuth, elevation;
        computeBlock(gatherBlock(0, detectionCount), azimuth, elevation);
        azimuth.eval(); elevation.eval();
        result.setAngles(std::move(azimuth), std::move(elevation));
        return result;
    }
    af::array azimuth(af::dim4(static_cast<dim_t>(detectionCount)), f32);
    af::array elevation(af::dim4(static_cast<dim_t>(detectionCount)), f32);
    for (std::size_t first = 0; first < detectionCount;) {
        const std::size_t count = std::min(batchSize, detectionCount - first);
        af::array azimuthBlock, elevationBlock;
        computeBlock(gatherBlock(first, count), azimuthBlock, elevationBlock);
        azimuthBlock.eval();
        elevationBlock.eval();
        azimuth(sequence(first, count)) = azimuthBlock;
        elevation(sequence(first, count)) = elevationBlock;
        first += count;
    }
    // A shallow ArrayFire-handle copy of original detections, never a clone.
    result.setAngles(std::move(azimuth), std::move(elevation));
    return result;
}
} // namespace radar::interferometry::detail
