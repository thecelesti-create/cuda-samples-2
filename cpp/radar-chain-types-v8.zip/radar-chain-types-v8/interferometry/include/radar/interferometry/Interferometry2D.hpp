#pragma once
#include <radar/DetectionList.hpp>
#include <radar/interferometry/UniformRectangularArray.hpp>
#include <span>
namespace radar::interferometry {
/**
 * @brief 2D adjacent-baseline phase interferometry; all complex input MUST be c32.
 * @details Returns the same DetectionList type with optional f32 angle columns attached.
 * Only selected cells are gathered, in bounded-size blocks. No explicit numerical
 * host readback, input validation, type conversion, or full-map concatenation.
 * @pre RDMs and detections share CPI, range/Doppler grids and FFT ordering.
 * Uniform calibrated far-field phase centers and a single dominant arrival per
 * cell are assumed. Phase wrapping and front/back ambiguity are not resolved.
 */
class Interferometry2D final {
public:
    /** @brief Configure geometry and maximum detections per IQ scratch block.
     *  @pre detectionBatchSize > 0; geometry meets its documented preconditions. */
    explicit Interferometry2D(UniformRectangularArray geometry, std::size_t detectionBatchSize = 4096) noexcept;
    /** @brief Get uniform effective-phase-center geometry. */
    [[nodiscard]] const UniformRectangularArray& getGeometry() const noexcept { return geometry_; }
    /** @brief Set geometry without validation. */
    void setGeometry(UniformRectangularArray geometry) noexcept { geometry_ = geometry; }
    /** @brief Get detection count per temporary IQ block. */
    [[nodiscard]] std::size_t getDetectionBatchSize() const noexcept { return detectionBatchSize_; }
    /** @brief Set detection block count; value must be positive. */
    void setDetectionBatchSize(std::size_t value) noexcept { detectionBatchSize_ = value; }
    /** @brief Estimate from one c32 [Doppler,range,element] phase-center cube.
     *  @return Shallow copy of detections with newly computed azimuth/elevation radians. */
    [[nodiscard]] DetectionList estimate(const RangeDopplerMap& phaseCenteredRdm,
                                          const DetectionList& detections) const;
    /** @brief Estimate from ordered c32 [Doppler,range,1] phase-center maps.
     *  @pre Maps are contiguous and follow the geometry's element order. */
    [[nodiscard]] DetectionList estimate(std::span<const RangeDopplerMap> phaseCenteredRdms,
                                          const DetectionList& detections) const;
    /** @brief Reuse externally gathered c32 [element,detection] IQ; no RDM gather.
     *  @pre The IQ columns match the detection order, including duplicates.
     *  This is NOT DetectionList::getComplexPairsC32(), which has only one I/Q per cell. */
    [[nodiscard]] DetectionList estimate(const af::array& elementIqC32,
                                          const DetectionList& detections) const;
private:
    UniformRectangularArray geometry_;
    std::size_t detectionBatchSize_;
};
} // namespace radar::interferometry
