#pragma once
#include <radar/types.hpp>
#include <radar/interferometry/PhaseSign.hpp>
#include <cstddef>
namespace radar::interferometry {
/** @brief Uniform +y phase centers; elevation is supplied, not estimated.
 * @pre Count >= 2, spacing > 0, valid phase calibration and unambiguous spatial phase. */
class UniformLinearArray final {
public:
    /** @brief Configure a uniform +y aperture with an explicit elevation prior and phase convention. */
    UniformLinearArray(std::size_t elementCount, double spacingMeters,
                       double assumedElevationRadians = 0.0,
                       PhaseSign phaseSign = PhaseSign::Positive,
                       double referenceDirectionCosineY = 0.0) noexcept;
    /** @brief Get hardware element count, not total ArrayFire value count. */
    [[nodiscard]] std::size_t getElementCount() const noexcept { return elementCount_; }
    /** @brief Get uniform spacing between effective phase centers in meters. */
    [[nodiscard]] double getSpacingMeters() const noexcept { return spacingMeters_; }
    /** @brief Get the 1D elevation prior in radians; it is not independently estimated. */
    [[nodiscard]] double getAssumedElevationRadians() const noexcept { return assumedElevationRadians_; }
    /** @brief Get spatial receiver phase sign, independent of the Doppler convention. */
    [[nodiscard]] PhaseSign getPhaseSign() const noexcept { return phaseSign_; }
    /** @brief Get known removed spatial steering direction cosine along y. */
    [[nodiscard]] double getReferenceDirectionCosineY() const noexcept { return referenceDirectionCosineY_; }
    /** @brief Set linear aperture count; at least two phase centers are required. */
    void setElementCount(std::size_t value) noexcept { elementCount_ = value; }
    /** @brief Set positive uniform spacing between effective phase centers in meters. */
    void setSpacingMeters(double value) noexcept { spacingMeters_ = value; }
    /** @brief Set the 1D elevation prior in radians; absolute value must be below pi/2. */
    void setAssumedElevationRadians(double value) noexcept { assumedElevationRadians_ = value; }
    /** @brief Set the spatial receiver phase convention. */
    void setPhaseSign(PhaseSign value) noexcept { phaseSign_ = value; }
    /** @brief Set known removed y-direction steering; this does not unwrap ambiguous phases. */
    void setReferenceDirectionCosineY(double value) noexcept { referenceDirectionCosineY_ = value; }
private:
    std::size_t elementCount_;
    double spacingMeters_;
    double assumedElevationRadians_;
    PhaseSign phaseSign_;
    double referenceDirectionCosineY_;
};
} // namespace radar::interferometry
