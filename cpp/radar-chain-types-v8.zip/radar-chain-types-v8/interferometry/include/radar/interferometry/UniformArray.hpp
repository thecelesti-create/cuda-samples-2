#pragma once
/** @file UniformArray.hpp @brief Convenience includes; each geometry has its own HPP/CPP. */
#include <radar/interferometry/UniformLinearArray.hpp>
#include <radar/interferometry/UniformRectangularArray.hpp>
