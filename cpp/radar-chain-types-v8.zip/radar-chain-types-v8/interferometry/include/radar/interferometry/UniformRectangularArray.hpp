#pragma once
#include <radar/types.hpp>
#include <radar/interferometry/PhaseSign.hpp>
#include <cstddef>
namespace radar::interferometry {
/** @brief Complete uniform yz grid; elementIndex = y + azimuthElementCount*z.
 * @pre Both counts >= 2; spacings describe calibrated effective phase centers. */
class UniformRectangularArray final {
public:
    /** @brief Configure a complete yz rectangular grid with uniform effective phase-center spacings. */
    UniformRectangularArray(std::size_t azimuthElementCount, std::size_t elevationElementCount,
                            double azimuthSpacingMeters, double elevationSpacingMeters,
                            PhaseSign phaseSign = PhaseSign::Positive,
                            double referenceDirectionCosineY = 0.0,
                            double referenceDirectionCosineZ = 0.0) noexcept;
    /** @brief Get the number of equally spaced phase centers along y. */
    [[nodiscard]] std::size_t getAzimuthElementCount() const noexcept { return azimuthElementCount_; }
    /** @brief Get the number of equally spaced phase centers along z. */
    [[nodiscard]] std::size_t getElevationElementCount() const noexcept { return elevationElementCount_; }
    /** @brief Get hardware element count, not total ArrayFire value count. */
    [[nodiscard]] std::size_t getElementCount() const noexcept { return azimuthElementCount_ * elevationElementCount_; }
    /** @brief Get phase-center spacing along y in meters. */
    [[nodiscard]] double getAzimuthSpacingMeters() const noexcept { return azimuthSpacingMeters_; }
    /** @brief Get phase-center spacing along z in meters. */
    [[nodiscard]] double getElevationSpacingMeters() const noexcept { return elevationSpacingMeters_; }
    /** @brief Get spatial receiver phase sign, independent of the Doppler convention. */
    [[nodiscard]] PhaseSign getPhaseSign() const noexcept { return phaseSign_; }
    /** @brief Get known removed spatial steering direction cosine along y. */
    [[nodiscard]] double getReferenceDirectionCosineY() const noexcept { return referenceDirectionCosineY_; }
    /** @brief Get known removed spatial steering direction cosine along z. */
    [[nodiscard]] double getReferenceDirectionCosineZ() const noexcept { return referenceDirectionCosineZ_; }
    /** @brief Set the rectangular y extent; at least two centers are required. */
    void setAzimuthElementCount(std::size_t value) noexcept { azimuthElementCount_ = value; }
    /** @brief Set the rectangular z extent; at least two centers are required. */
    void setElevationElementCount(std::size_t value) noexcept { elevationElementCount_ = value; }
    /** @brief Set positive phase-center spacing along y in meters. */
    void setAzimuthSpacingMeters(double value) noexcept { azimuthSpacingMeters_ = value; }
    /** @brief Set positive phase-center spacing along z in meters. */
    void setElevationSpacingMeters(double value) noexcept { elevationSpacingMeters_ = value; }
    /** @brief Set the spatial receiver phase convention. */
    void setPhaseSign(PhaseSign value) noexcept { phaseSign_ = value; }
    /** @brief Set known removed y-direction steering; this does not unwrap ambiguous phases. */
    void setReferenceDirectionCosineY(double value) noexcept { referenceDirectionCosineY_ = value; }
    /** @brief Set known removed z-direction steering; this does not unwrap ambiguous phases. */
    void setReferenceDirectionCosineZ(double value) noexcept { referenceDirectionCosineZ_ = value; }
private:
    std::size_t azimuthElementCount_;
    std::size_t elevationElementCount_;
    double azimuthSpacingMeters_;
    double elevationSpacingMeters_;
    PhaseSign phaseSign_;
    double referenceDirectionCosineY_;
    double referenceDirectionCosineZ_;
};
} // namespace radar::interferometry
