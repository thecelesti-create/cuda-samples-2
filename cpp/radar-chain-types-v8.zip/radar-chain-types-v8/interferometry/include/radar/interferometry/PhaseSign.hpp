#pragma once
namespace radar::interferometry {
/** @brief Spatial phase sign in exp(sign*j*2*pi/lambda*(y*u+z*v)); independent of Doppler sign. */
enum class PhaseSign { Positive = 1, Negative = -1 };
} // namespace radar::interferometry
