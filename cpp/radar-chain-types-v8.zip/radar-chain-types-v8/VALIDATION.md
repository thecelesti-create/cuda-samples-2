# Validation report — v0.8

## Executed against this revision

| Suite | GCC 14.2 | Clang 17 | GCC ASan + UBSan |
|---|---:|---:|---:|
| Actual numeric metadata / host Detection / range and Doppler grids | 539 checks passed | 539 checks passed | 539 checks passed |
| Independent scalar interferometry oracle using actual geometry classes | 600 checks passed | 600 checks passed | 600 checks passed |

Both are real compiled/executed C++20 programs. They link the newly separated
class implementation files. Release command-line tests use `-O2 -Wall -Wextra
-Wpedantic -Werror`; sanitizer tests use `-O1 -g -fsanitize=address,undefined
-fno-omit-frame-pointer`, leak detection and halt-on-error. No sanitizer error
was reported. Metadata-only CMake compilation and both CTest entries also passed.

Metadata tests cover required bandwidth, ambiguity/nominal resolution formulas,
positive/negative velocity convention, setters, crop origins, odd/even FFT ordering,
zero-padding pulse-count distinction, the five host fields and independently
optional angles (including absent versus present NaN). No invalid-input exception
checks are reintroduced into production code. On the tested Linux compilers,
`sizeof(CPI_Metadata)` was 64 and `sizeof(Detection)` was 40 bytes; these are host
object sizes for those ABIs, not portable layout/serialization guarantees.

The 600 scalar tests cover the mathematical phase model, both signs, 1D elevation
prior, 2D coupling, rectangular/unequal spacings, removed steering phase, ambiguity,
zero correlation and invalid spatial direction estimates. They do NOT execute
ArrayFire kernels, its proxy/overload machinery, or GPU single-precision behavior.

Logs: `validation/compiler-tests.txt`, `sanitizers.txt`,
`metadata-configure.txt`, `metadata-build.txt`, `metadata-ctest.txt`.

## Source organization and documentation audit

The reproducible `python tools/audit_api.py` static text audit passed:

- **12 classes**, each in its own matching header with an actual constructor
  definition in its own CPP (not an empty placeholder CPP).
- **66 data members**, all private; no project-defined structs.
- **236 public function declarations** with adjacent Doxygen comments, and
  Doxygen documentation on every class.
- No removed record/list types, numbered dimension member names, runtime
  `throw`/`assert` validators in the production class code.
- No explicit `host()`, `scalar()`, `sync()` or `where()` in interferometry sources.

This is a text audit, NOT a full C++ AST/SDK compile, overload verification, Doxygen
parser run or executable performance result. Doxygen is not installed here;
`Doxyfile` and the optional `radar_docs` target are supplied but HTML generation
was not run. The four Docker scripts passed `bash -n`, not a Docker execution.

Logs: `validation/source-audit.txt`, `validation/shell-syntax.txt`.

## Actual ArrayFire SDK attempt and limitation

A full CMake configure was attempted and failed at `find_package(ArrayFire 3.10)`:
this environment does not have `ArrayFireConfig.cmake` or an installed ArrayFire
SDK. Curl could not resolve GitHub when attempting the 3.10 source archive.
There is no exposed NVIDIA device or Docker installation/socket.
See the exact output in `validation/real-sdk-attempt.txt`.

**No real ArrayFire 3.10 compile/link, CPU/CUDA/OpenCL integration execution,
Docker image build/run, Windows/MSVC test, or GPU timing/peak-memory measurement
was completed.** No fake ArrayFire header/backend was used to claim otherwise.
No old declaration-only validation logs are carried into this revision.

## Real-SDK tests supplied, not executed here

`tests/arrayfire_tests.cpp` tests c32 layouts/FFT/crops, five detection columns,
representative IQ gathering, amplitude and SNR semantics, optional angle lifecycle,
independent optional fields, clone/select/duplicate alignment, empty outputs,
explicit host exports and integral indices above f32's exact integer range.

`interferometry/tests/arrayfire_tests.cpp` exercises the actual estimators with
packed maps, separate maps, externally gathered c32 [element,K] IQ, both phase
signs, 1D elevation prior, 2D steering reference, block sizes, duplicate detections,
sum-beam detection origins, optional angle output and undefined/empty cases.
These tests must be built and run on the user's real SDK/backend.

The simple demo expects one record `(range=0, Doppler=0, amplitude=2,
SNR=6.0206 dB, I=2, Q=0)`. The interferometry demo expects azimuth/elevation
20/10 degrees. These are mathematical expectations, not captured executions.

## Run on your environment

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DRADAR_TEST_BACKEND=cuda
cmake --build build --config Release --parallel
ctest --test-dir build -C Release --output-on-failure
```

Supply the actual ArrayFire prefix when needed; see README for Windows and direct
backend variants. Use a new build directory for the v8 class/file changes.
