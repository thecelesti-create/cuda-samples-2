#!/usr/bin/env bash
set -Eeuo pipefail
jobs="${1:-2}"
[[ "$jobs" =~ ^[1-9][0-9]*$ ]] || { echo 'BUILD_JOBS must be positive' >&2; exit 2; }
prefix="${AF_PATH:-/opt/arrayfire}"
work=/tmp/arrayfire-build
mkdir -p "$work/source" "$prefix"
# Official *full* release bundle, not GitHub's incomplete automatic source archive.
# Digest is published on the ArrayFire v3.10.0 release asset page.
url=https://github.com/arrayfire/arrayfire/releases/download/v3.10.0/arrayfire-full-3.10.0.tar.bz2
sha256=74e14b92a3e5a3ed6b79b000c7625b6223400836ec2ba724c3b356282ea741b3
curl --fail --location --retry 3 --connect-timeout 20 "$url" -o "$work/source.tar.bz2"
printf '%s  %s\n' "$sha256" "$work/source.tar.bz2" | sha256sum --check --strict -
tar -xjf "$work/source.tar.bz2" -C "$work/source" --strip-components=1
# ArrayFire's own SDK build uses upstream language settings. Consumer code is C++20.
cmake -S "$work/source" -B "$work/build" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX="$prefix" \
    -DAF_BUILD_CPU=ON -DAF_BUILD_UNIFIED=ON \
    -DAF_BUILD_CUDA=OFF -DAF_BUILD_OPENCL=OFF -DAF_BUILD_ONEAPI=OFF \
    -DAF_BUILD_EXAMPLES=OFF -DAF_BUILD_DOCS=OFF -DBUILD_TESTING=OFF \
    -DAF_BUILD_FORGE=OFF -DAF_WITH_IMAGEIO=OFF -DAF_WITH_CUDNN=OFF \
    '-DAF_COMPUTE_LIBRARY=FFTW/LAPACK/BLAS'
cmake --build "$work/build" --parallel "$jobs"
cmake --install "$work/build"
printf '%s/lib\n%s/lib64\n' "$prefix" "$prefix" > /etc/ld.so.conf.d/arrayfire.conf
ldconfig
test -f "$prefix/include/arrayfire.h"
rm -rf "$work"
