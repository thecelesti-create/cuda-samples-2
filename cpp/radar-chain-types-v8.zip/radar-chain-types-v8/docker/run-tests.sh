#!/usr/bin/env bash
set -Eeuo pipefail
if (( $# > 1 )); then echo 'Usage: run-tests.sh [cpu|cuda]' >&2; exit 2; fi
backend="${1:-${RADAR_DEFAULT_BACKEND:-cpu}}"
case "$backend" in cpu|cuda) ;; *) echo 'Backend must be cpu or cuda' >&2; exit 2;; esac
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
logs="${RADAR_TEST_LOG_DIR:-/tmp/radar-test-logs}"
mkdir -p "$logs"
# Existing test/demo executables explicitly select the requested backend; an
# unavailable backend is an error, not permission to fall back to the CPU.
printf 'Requested backend: %s\n' "$backend" | tee "$logs/requested-backend.txt"
"$root/build/radar_metadata_tests" 2>&1 | tee "$logs/metadata.txt"
"$root/build/radar_arrayfire_tests" "$backend" 2>&1 | tee "$logs/arrayfire-$backend.txt"
cmake "-DPROGRAM=$root/build/radar_simple_demo" "-DBACKEND=$backend" \
    -P "$root/tests/verify_simple_demo.cmake" \
    2>&1 | tee "$logs/simple-demo-$backend.txt"
"$root/build/radar_interferometry_reference_tests" 2>&1 | tee "$logs/interferometry-reference.txt"
"$root/build/radar_interferometry_tests" "$backend" 2>&1 | tee "$logs/interferometry-$backend.txt"
"$root/build/radar_interferometry_demo" "$backend" 2>&1 | tee "$logs/interferometry-demo-$backend.txt"
printf 'All requested %s tests passed. Logs: %s\n' "$backend" "$logs"
