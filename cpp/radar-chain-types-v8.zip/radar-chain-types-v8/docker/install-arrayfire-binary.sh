#!/usr/bin/env bash
set -Eeuo pipefail
prefix="${AF_PATH:-/opt/arrayfire}"
sha256="${1:-}"
installer=/tmp/ArrayFire-3.10.0-Linux.sh
# This is the Linux 3.10.0 link published by arrayfire.com/download/.
# The vendor describes it as built with CUDA 12.8.
url=https://arrayfire.gateway.scarf.sh/linux/3.10.0/ArrayFire.sh
[[ "$(uname -m)" == x86_64 ]] || { echo 'This installer requires linux/amd64' >&2; exit 2; }
curl --fail --location --retry 3 --connect-timeout 20 "$url" -o "$installer"
if [[ -n "$sha256" ]]; then
    [[ "$sha256" =~ ^[0-9a-fA-F]{64}$ ]] || { echo 'Invalid SHA256 argument' >&2; exit 2; }
    printf '%s  %s\n' "$sha256" "$installer" | sha256sum --check --strict -
else
    echo 'Installer uses the official versioned HTTPS URL; no expected digest was supplied.'
    sha256sum "$installer" # Recorded for audit, not an independent integrity check.
fi
mkdir -p "$prefix"
# Standard CPack self-extracting installer flags; this accepts the included license.
bash "$installer" --skip-license --exclude-subdir --prefix="$prefix"
printf '%s/lib\n%s/lib64\n' "$prefix" "$prefix" > /etc/ld.so.conf.d/arrayfire.conf
ldconfig
test -f "$prefix/include/arrayfire.h"
rm "$installer"
