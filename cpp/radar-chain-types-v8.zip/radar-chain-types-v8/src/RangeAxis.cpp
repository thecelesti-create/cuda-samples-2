#include <radar/RangeAxis.hpp>
namespace radar {
RangeAxis::RangeAxis(double firstBinMeters, double binSpacingMeters) noexcept
    : firstBinMeters_(firstBinMeters), binSpacingMeters_(binSpacingMeters) {}
RangeAxis RangeAxis::sliced(BinIndex first) const noexcept { return {getMeters(first), binSpacingMeters_}; }
RangeAxis RangeAxis::fromRoundTripTiming(double delaySeconds, double sampleRateHz) noexcept {
    return {speedOfLightMps * 0.5 * delaySeconds, speedOfLightMps * 0.5 / sampleRateHz};
}
} // namespace radar
