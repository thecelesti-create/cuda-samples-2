#include <radar/DopplerAxis.hpp>
namespace radar {
DopplerAxis::DopplerAxis(BinIndex fftSize, BinIndex pulsesUsed, double prfHz, DopplerOrder order) noexcept
    : fftSize_(fftSize), pulsesUsed_(pulsesUsed), prfHz_(prfHz), order_(order) {}
} // namespace radar
