#include <radar/SamplePulseBuffer.hpp>
#include "array_helpers.hpp"

namespace radar {
SamplePulseBuffer::SamplePulseBuffer(af::array iqC32, CPI_Metadata metadata)
    : iqC32_(std::move(iqC32)), metadata_(std::move(metadata)),
      sampleCount_(iqC32_.dims(0)), pulseCount_(iqC32_.dims(1)), elementCount_(iqC32_.dims(2)) {
}
SamplePulseBuffer::SamplePulseBuffer(dim_t sampleCount, dim_t pulseCount, dim_t elementCount, CPI_Metadata metadata)
    : metadata_(std::move(metadata)), sampleCount_(sampleCount), pulseCount_(pulseCount), elementCount_(elementCount) {
    iqC32_ = af::constant(0, af::dim4(sampleCount, pulseCount, elementCount), c32);
}
SamplePulseBuffer::SamplePulseBuffer(std::span<const af::cfloat> iqC32,
                                     dim_t sampleCount, dim_t pulseCount, dim_t elementCount, CPI_Metadata metadata)
    : metadata_(std::move(metadata)), sampleCount_(sampleCount), pulseCount_(pulseCount), elementCount_(elementCount) {
    iqC32_ = af::array(af::dim4(sampleCount, pulseCount, elementCount), iqC32.data(), afHost);
}
SamplePulseBuffer SamplePulseBuffer::zeros(dim_t sampleCount, dim_t pulseCount, dim_t elementCount, CPI_Metadata metadata) {
    return {sampleCount, pulseCount, elementCount, std::move(metadata)};
}
SamplePulseBuffer SamplePulseBuffer::fromHost(std::span<const af::cfloat> iqC32,
                                             dim_t sampleCount, dim_t pulseCount, dim_t elementCount, CPI_Metadata metadata) {
    return {iqC32, sampleCount, pulseCount, elementCount, std::move(metadata)};
}
af::array SamplePulseBuffer::getPulseC32(dim_t pulseIndex, dim_t elementIndex) const {
    return iqC32_(af::span, detail::sequence(pulseIndex, 1), detail::sequence(elementIndex, 1));
}
af::array SamplePulseBuffer::getElementC32(dim_t elementIndex) const {
    return iqC32_(af::span, af::span, detail::sequence(elementIndex, 1));
}
af::array SamplePulseBuffer::getSlowTimeC32(dim_t sampleIndex, dim_t elementIndex) const {
    return iqC32_(detail::sequence(sampleIndex, 1), af::span, detail::sequence(elementIndex, 1));
}
SamplePulseBuffer SamplePulseBuffer::sliceSamples(dim_t firstSample, dim_t sampleCount) const {
    auto result = *this;
    result.iqC32_ = iqC32_(detail::sequence(firstSample, sampleCount), af::span, af::span);
    result.metadata_.setFirstSampleDelaySeconds(getSampleDelaySeconds(firstSample));
    result.sampleCount_ = sampleCount;
    return result;
}
SamplePulseBuffer SamplePulseBuffer::slicePulses(dim_t firstPulse, dim_t pulseCount) const {
    auto result = *this;
    result.iqC32_ = iqC32_(af::span, detail::sequence(firstPulse, pulseCount), af::span);
    result.metadata_.setFirstPulseTimeSeconds(getPulseTimeSeconds(firstPulse));
    result.pulseCount_ = pulseCount;
    return result;
}
af::array SamplePulseBuffer::getPower() const { return detail::computePower(iqC32_); }
void SamplePulseBuffer::setDataC32(af::array iqC32) {
    iqC32_ = std::move(iqC32);
}
void SamplePulseBuffer::setMetadata(CPI_Metadata metadata) {
    metadata_ = std::move(metadata);
}
SamplePulseBuffer SamplePulseBuffer::withDataC32(af::array iqC32) const {
    auto result = *this;
    result.setDataC32(std::move(iqC32));
    return result;
}
SamplePulseBuffer SamplePulseBuffer::clone() const {
    auto result = *this;
    result.iqC32_ = iqC32_.copy();
    return result;
}
std::vector<af::cfloat> SamplePulseBuffer::toHost() const { return detail::toHost(iqC32_); }
void SamplePulseBuffer::evaluate() const { iqC32_.eval(); }
void SamplePulseBuffer::synchronize() const { detail::synchronize(iqC32_); }
} // namespace radar
