#include <radar/RangePulseBuffer.hpp>
#include "array_helpers.hpp"

namespace radar {
RangePulseBuffer::RangePulseBuffer(af::array iqC32, CPI_Metadata metadata, RangeAxis rangeAxis)
    : iqC32_(std::move(iqC32)), metadata_(std::move(metadata)), rangeAxis_(rangeAxis),
      rangeBinCount_(iqC32_.dims(0)), pulseCount_(iqC32_.dims(1)), elementCount_(iqC32_.dims(2)) {
}
RangePulseBuffer::RangePulseBuffer(const SamplePulseBuffer& source, af::array iqC32, RangeAxis rangeAxis)
    : RangePulseBuffer(std::move(iqC32), source.getMetadata(), rangeAxis) {
}
af::array RangePulseBuffer::getPulseC32(dim_t pulseIndex, dim_t elementIndex) const {
    return iqC32_(af::span, detail::sequence(pulseIndex, 1), detail::sequence(elementIndex, 1));
}
af::array RangePulseBuffer::getElementC32(dim_t elementIndex) const {
    return iqC32_(af::span, af::span, detail::sequence(elementIndex, 1));
}
af::array RangePulseBuffer::getSlowTimeC32(dim_t rangeBin, dim_t elementIndex) const {
    return iqC32_(detail::sequence(rangeBin, 1), af::span, detail::sequence(elementIndex, 1));
}
RangePulseBuffer RangePulseBuffer::sliceRanges(dim_t firstRangeBin, dim_t rangeBinCount) const {
    auto result = *this;
    result.iqC32_ = iqC32_(detail::sequence(firstRangeBin, rangeBinCount), af::span, af::span);
    result.rangeAxis_ = rangeAxis_.sliced(firstRangeBin);
    result.rangeBinCount_ = rangeBinCount;
    return result;
}
RangePulseBuffer RangePulseBuffer::slicePulses(dim_t firstPulse, dim_t pulseCount) const {
    auto result = *this;
    result.iqC32_ = iqC32_(af::span, detail::sequence(firstPulse, pulseCount), af::span);
    result.metadata_.setFirstPulseTimeSeconds(getPulseTimeSeconds(firstPulse));
    result.pulseCount_ = pulseCount;
    return result;
}
af::array RangePulseBuffer::getDopplerInputC32() const { return af::reorder(iqC32_, 1, 0, 2, 3); }
af::array RangePulseBuffer::getPower() const { return detail::computePower(iqC32_); }
void RangePulseBuffer::setDataC32(af::array iqC32) {
    iqC32_ = std::move(iqC32);
}
void RangePulseBuffer::setMetadata(CPI_Metadata metadata) {
    metadata_ = std::move(metadata);
}
void RangePulseBuffer::setRangeAxis(RangeAxis rangeAxis) {
    rangeAxis_ = rangeAxis;
}
RangePulseBuffer RangePulseBuffer::withDataC32(af::array iqC32) const {
    auto result = *this;
    result.setDataC32(std::move(iqC32));
    return result;
}
RangePulseBuffer RangePulseBuffer::clone() const {
    auto result = *this;
    result.iqC32_ = iqC32_.copy();
    return result;
}
std::vector<af::cfloat> RangePulseBuffer::toHost() const { return detail::toHost(iqC32_); }
void RangePulseBuffer::evaluate() const { iqC32_.eval(); }
void RangePulseBuffer::synchronize() const { detail::synchronize(iqC32_); }
} // namespace radar
