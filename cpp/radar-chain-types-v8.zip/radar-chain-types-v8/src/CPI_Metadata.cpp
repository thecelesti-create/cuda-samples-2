#include <radar/CPI_Metadata.hpp>
namespace radar {
CPI_Metadata::CPI_Metadata(double sampleRateHz, double prfHz, double carrierFrequencyHz,
                           double bandwidthHz, std::uint64_t cpiId,
                           double firstSampleDelaySeconds, double firstPulseTimeSeconds,
                           PositiveDoppler positiveDoppler) noexcept
    : sampleRateHz_(sampleRateHz), prfHz_(prfHz), carrierFrequencyHz_(carrierFrequencyHz),
      bandwidthHz_(bandwidthHz), cpiId_(cpiId), firstSampleDelaySeconds_(firstSampleDelaySeconds),
      firstPulseTimeSeconds_(firstPulseTimeSeconds), positiveDoppler_(positiveDoppler) {}
} // namespace radar
