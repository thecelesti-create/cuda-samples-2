#include <radar/RangeDopplerMap.hpp>
#include "array_helpers.hpp"

namespace radar {
RangeDopplerMap::RangeDopplerMap(af::array iqC32, CPI_Metadata metadata,
                               RangeAxis rangeAxis, DopplerAxis dopplerAxis)
    : iqC32_(std::move(iqC32)), metadata_(std::move(metadata)), rangeAxis_(rangeAxis),
      dopplerAxis_(dopplerAxis), dopplerBinCount_(iqC32_.dims(0)), rangeBinCount_(iqC32_.dims(1)), elementCount_(iqC32_.dims(2)) {
}
RangeDopplerMap::RangeDopplerMap(const RangePulseBuffer& source, af::array iqC32, DopplerOrder order)
    : iqC32_(std::move(iqC32)), metadata_(source.getMetadata()), rangeAxis_(source.getRangeAxis()),
      dopplerAxis_(iqC32_.dims(0), source.getPulseCount(), metadata_.getPrfHz(), order),
      dopplerBinCount_(iqC32_.dims(0)), rangeBinCount_(iqC32_.dims(1)), elementCount_(iqC32_.dims(2)) {
}
af::array RangeDopplerMap::getElementC32(dim_t elementIndex) const {
    return iqC32_(af::span, af::span, detail::sequence(elementIndex, 1));
}
af::array RangeDopplerMap::getDopplerSpectrumC32(dim_t rangeBin, dim_t elementIndex) const {
    return iqC32_(af::span, detail::sequence(rangeBin, 1), detail::sequence(elementIndex, 1));
}
af::array RangeDopplerMap::getRangeProfileC32(dim_t dopplerBin, dim_t elementIndex) const {
    return iqC32_(detail::sequence(dopplerBin, 1), af::span, detail::sequence(elementIndex, 1));
}
af::array RangeDopplerMap::getElementVectorC32(dim_t rangeBin, dim_t dopplerBin) const {
    return af::flat(iqC32_(detail::sequence(dopplerBin, 1), detail::sequence(rangeBin, 1), af::span));
}
af::array RangeDopplerMap::getPower() const { return detail::computePower(iqC32_); }
af::array RangeDopplerMap::getPowerSumElements() const { return af::sum(getPower(), 2); }
RangeDopplerMap RangeDopplerMap::sliceRanges(dim_t firstRangeBin, dim_t rangeBinCount) const {
    auto result = *this;
    result.iqC32_ = iqC32_(af::span, detail::sequence(firstRangeBin, rangeBinCount), af::span);
    result.rangeAxis_ = rangeAxis_.sliced(firstRangeBin);
    result.rangeBinCount_ = rangeBinCount;
    return result;
}
void RangeDopplerMap::setDopplerOrder(DopplerOrder order) {
    auto axis = dopplerAxis_;
    axis.setOrder(order);
    if (order == dopplerAxis_.getOrder()) return;
    const int half = static_cast<int>(getDopplerBinCount() / 2); // Must fit int.
    af::array shifted = af::shift(iqC32_, order == DopplerOrder::Centered ? half : -half, 0, 0, 0);
    iqC32_ = std::move(shifted);
    dopplerAxis_ = axis;
}
RangeDopplerMap RangeDopplerMap::withDopplerOrder(DopplerOrder order) const {
    auto result = *this;
    result.setDopplerOrder(order);
    return result;
}
af::array RangeDopplerMap::getRangeFirstDataC32() const { return af::reorder(iqC32_, 1, 0, 2, 3); }
void RangeDopplerMap::setDataC32(af::array iqC32) {
    iqC32_ = std::move(iqC32);
}
void RangeDopplerMap::setMetadata(CPI_Metadata metadata) {
    metadata_ = std::move(metadata);
    dopplerAxis_.setPrfHz(metadata_.getPrfHz());
}
void RangeDopplerMap::setRangeAxis(RangeAxis rangeAxis) {
    rangeAxis_ = rangeAxis;
}
RangeDopplerMap RangeDopplerMap::withDataC32(af::array iqC32) const {
    auto result = *this;
    result.setDataC32(std::move(iqC32));
    return result;
}
RangeDopplerMap RangeDopplerMap::clone() const {
    auto result = *this;
    result.iqC32_ = iqC32_.copy();
    return result;
}
std::vector<af::cfloat> RangeDopplerMap::toHost() const { return detail::toHost(iqC32_); }
void RangeDopplerMap::evaluate() const { iqC32_.eval(); }
void RangeDopplerMap::synchronize() const { detail::synchronize(iqC32_); }
} // namespace radar
