# af_bench

Single executable comparing:

1. Eigen + FFTW (OpenMP)
2. raw CUDA (kernels + cuFFT + CUB)
3. ArrayFire CPU (pure AF operators)
4. ArrayFire CUDA (AF JIT add/mul/fft; CUB sort on `device()`)
5. AF-CPU hybrid last (AF owns buffers; OpenMP add/mul/sort; AF FFT)

Working type is **c32 only**. One host cube is shared by every backend.

| op | data | along | GFLOP formula |
|---|---|---|---|
| `cadd` | c32 + c32 | elementwise | 2N |
| `cmul` | c32 * c32 | elementwise | 6N |
| `fft` | batched 1D C2C, unscaled | **d0** | 5 * d0 * log2(d0) * batch |
| `sort(abs2)` | power of the same cube | **d0** | d0 * log2(d0) * batch (comparison-equivalents) |

## Build

Needs CUDA toolkit, **unified** ArrayFire (`libaf`, not only `libafcuda`), `libfftw3-dev`, `libeigen3-dev`, CMake >= 3.18.

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release \
  -DArrayFire_DIR=/opt/arrayfire/share/ArrayFire/cmake \
  -DCMAKE_CUDA_ARCHITECTURES=86
cmake --build build -j
```

`ldd build/af_bench | grep libaf` should show `libaf.so`.

## Run

```bash
./build/af_bench
./build/af_bench --d0 2048 --d1 256 --d2 16 --warmup 5 --iters 30
```

Warmup excludes JIT and cuFFT planning. Sizes must fit in int32 (CUB/cuFFT).
