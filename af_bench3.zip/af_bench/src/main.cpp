#include "bench_common.hpp"

#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

static void usage(const char* argv0) {
    std::cerr
        << "Usage: " << argv0
        << " [--d0 N] [--d1 N] [--d2 N] [--iters N] [--warmup N]\n"
        << "  Cube is c32 [d0, d1, d2] column-major.\n"
        << "  Always runs Eigen/FFTW, raw CUDA, ArrayFire CPU, ArrayFire CUDA,\n"
        << "  then AF-CPU hybrid (AF owns buffers, OpenMP add/mul/sort).\n"
        << "  Default: 2048 x 128 x 16, warmup 5, iters 20\n";
}

static bool parse_int(int argc, char** argv, int& i, const char* flag, int& dst) {
    if (std::string(argv[i]) != flag) return false;
    if (i + 1 >= argc) throw std::runtime_error(std::string("missing value for ") + flag);
    dst = std::atoi(argv[++i]);
    return true;
}

int main(int argc, char** argv) {
    BenchConfig cfg;
    try {
        for (int i = 1; i < argc; ++i) {
            if (std::string(argv[i]) == "-h" || std::string(argv[i]) == "--help") {
                usage(argv[0]);
                return 0;
            }
            if (parse_int(argc, argv, i, "--d0", cfg.d0)) continue;
            if (parse_int(argc, argv, i, "--d1", cfg.d1)) continue;
            if (parse_int(argc, argv, i, "--d2", cfg.d2)) continue;
            if (parse_int(argc, argv, i, "--iters", cfg.iters)) continue;
            if (parse_int(argc, argv, i, "--warmup", cfg.warmup)) continue;
            usage(argv[0]);
            return 1;
        }
        require_fits_int32(cfg);
    } catch (const std::exception& e) {
        std::cerr << e.what() << "\n";
        return 1;
    }

    if (cfg.iters <= 0 || cfg.warmup < 0) {
        std::cerr << "iters must be > 0 and warmup >= 0\n";
        return 1;
    }

    const long long n = numel(cfg);
    std::vector<float> ha(static_cast<size_t>(2 * n)), hb(static_cast<size_t>(2 * n));
    fill_c32(ha.data(), n, 1);
    fill_c32(hb.data(), n, 2);

    std::cout << "cube: c32 [" << cfg.d0 << " " << cfg.d1 << " " << cfg.d2 << "]  "
              << "elements=" << n << "  "
              << "bytes=" << std::fixed << std::setprecision(2) << (n * 8.0 / 1e6)
              << " MB  warmup=" << cfg.warmup << " iters=" << cfg.iters << "\n"
              << "shared host buffers for all backends. sort keys = abs2(c32).\n"
              << "work: cadd=2N, cmul=6N, fft=5*d0*log2(d0)*batch,\n"
              << "      sort = d0*log2(d0)*batch comparison-equivalents as GFLOP.\n"
              << "notes: AF fft is fftNorm(*, 1.0) out-of-place (same scale as cuFFT/FFTW).\n"
              << "       arrayfire-cpu/cuda use AF operators (CUDA sort = CUB on device()).\n"
              << "       af-cpu-hybrid (last): AF buffers + OpenMP add/mul/sort; FFT still AF.\n"
              << "       sort algorithms: CUB radix vs af::sort vs OpenMP std::sort.\n\n";

    std::vector<Result> all;
    try {
        auto cpu = run_cpu(cfg, ha.data(), hb.data());
        all.insert(all.end(), cpu.begin(), cpu.end());
    } catch (const std::exception& e) {
        std::cerr << "CPU bench failed: " << e.what() << "\n";
    }

    try {
        auto cu = run_cuda(cfg, ha.data(), hb.data());
        all.insert(all.end(), cu.begin(), cu.end());
    } catch (const std::exception& e) {
        std::cerr << "CUDA bench failed: " << e.what() << "\n";
    }

    // CPU first, then CUDA: setBackend(CUDA) after a finished CPU run is the
    // usual direction. Arrays from the first call are destroyed before the second.
    for (AfBackend be : {AfBackend::Cpu, AfBackend::Cuda}) {
        try {
            auto af = run_arrayfire(cfg, ha.data(), hb.data(), be);
            all.insert(all.end(), af.begin(), af.end());
        } catch (const std::exception& e) {
            std::cerr << "ArrayFire bench (" 
                      << (be == AfBackend::Cpu ? "cpu" : "cuda")
                      << ") failed: " << e.what() << "\n";
        }
    }

    try {
        auto hy = run_af_cpu_hybrid(cfg, ha.data(), hb.data());
        all.insert(all.end(), hy.begin(), hy.end());
    } catch (const std::exception& e) {
        std::cerr << "AF-CPU hybrid bench failed: " << e.what() << "\n";
    }

    std::cout << std::left
              << std::setw(18) << "backend"
              << std::setw(12) << "op"
              << std::right
              << std::setw(12) << "ms"
              << std::setw(12) << "GFLOP"
              << std::setw(12) << "GFLOP/s"
              << std::setw(12) << "GB/s"
              << "\n"
              << std::string(78, '-') << "\n";

    std::cout << std::fixed << std::setprecision(3);
    for (const auto& r : all) {
        std::cout << std::left
                  << std::setw(18) << r.backend
                  << std::setw(12) << r.op
                  << std::right
                  << std::setw(12) << r.ms
                  << std::setw(12) << r.gwork
                  << std::setw(12) << r.gwork_s
                  << std::setw(12) << r.gb_s
                  << "\n";
    }
    return 0;
}
