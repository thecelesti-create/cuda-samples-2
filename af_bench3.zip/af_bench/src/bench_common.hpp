#pragma once

#include <chrono>
#include <cmath>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

struct BenchConfig {
    int d0     = 2048;  // samples / FFT + sort length (dim 0)
    int d1     = 128;   // pulses
    int d2     = 16;    // elements
    int warmup = 5;
    int iters  = 20;
};

inline long long numel(const BenchConfig& c) {
    return static_cast<long long>(c.d0) * c.d1 * c.d2;
}

inline long long batch64(const BenchConfig& c) {
    return static_cast<long long>(c.d1) * c.d2;
}

// CUB / cuFFT / many kernel grids still take 32-bit sizes.
inline void require_fits_int32(const BenchConfig& c) {
    const long long n = numel(c);
    const long long b = batch64(c);
    const long long imax = std::numeric_limits<int>::max();
    if (c.d0 <= 0 || c.d1 <= 0 || c.d2 <= 0)
        throw std::runtime_error("dimensions must be positive");
    if (n > imax)
        throw std::runtime_error("d0*d1*d2 does not fit in int32 (CUB/cuFFT limit)");
    if (b > imax)
        throw std::runtime_error("d1*d2 does not fit in int32");
    if (b * c.d0 != n)
        throw std::runtime_error("internal size mismatch");
}

inline double flops_cadd(long long n) { return 2.0 * n; }
inline double flops_cmul(long long n) { return 6.0 * n; }
inline double flops_fft(int n, int howmany) {
    if (n <= 1) return 0.0;
    return 5.0 * howmany * n * std::log2(static_cast<double>(n));
}
// Sort has no real FLOPs. Report n*log2(n)*batch comparison-equivalents as FLOPs
// so every row can use the same GFLOP / GFLOP/s columns.
inline double flops_sort(int n, int howmany) {
    if (n <= 1) return 0.0;
    return howmany * n * std::log2(static_cast<double>(n));
}

inline double bytes_c32_rw2in(long long n) { return n * 8.0 * 3.0; }
inline double bytes_c32_fft(long long n)   { return n * 8.0 * 2.0; }
// Out-of-place f32 sort: read keys, write keys.
inline double bytes_sort_oop(long long n)  { return n * 4.0 * 2.0; }
// CPU std::sort is in-place, so we memcpy unsorted -> work each iter.
inline double bytes_sort_cpu(long long n)  { return n * 4.0 * 3.0; }

struct Result {
    std::string backend;
    std::string op;
    double ms     = 0;
    double gwork  = 0;     // GFLOP in one call
    double gwork_s = 0;    // GFLOP/s
    double gb_s   = 0;
};

inline Result make_result(const char* backend, const char* op, double ms,
                          double work, double bytes) {
    Result r;
    r.backend = backend;
    r.op      = op;
    r.ms      = ms;
    r.gwork   = work / 1e9;
    r.gwork_s = (ms > 0) ? (work / 1e9) / (ms * 1e-3) : 0;
    r.gb_s    = (ms > 0) ? (bytes / 1e9) / (ms * 1e-3) : 0;
    return r;
}

template <typename Fn>
double time_ms(int warmup, int iters, Fn&& fn) {
    for (int i = 0; i < warmup; ++i) fn();
    const auto t0 = std::chrono::steady_clock::now();
    for (int i = 0; i < iters; ++i) fn();
    const auto t1 = std::chrono::steady_clock::now();
    return std::chrono::duration<double, std::milli>(t1 - t0).count() / iters;
}

void fill_c32(float* interleaved, long long n, uint32_t seed);
void abs2_c32(const float* interleaved, float* keys, long long n);

enum class AfBackend { Cuda, Cpu, OpenCL };

// a, b: interleaved c32 host buffers, length 2*numel
std::vector<Result> run_cpu(const BenchConfig& cfg, const float* a, const float* b);
std::vector<Result> run_cuda(const BenchConfig& cfg, const float* a, const float* b);
std::vector<Result> run_arrayfire(const BenchConfig& cfg, const float* a, const float* b,
                                 AfBackend backend = AfBackend::Cuda);
std::vector<Result> run_af_cpu_hybrid(const BenchConfig& cfg, const float* a, const float* b);

// CUB segmented radix sort along dim 0 (device pointers). Used by raw CUDA
// and by ArrayFire-CUDA via af::array::device().
struct CubSegSort {
    void* temp = nullptr;
    size_t temp_bytes = 0;
    int* offsets = nullptr;
    int n = 0;
    int batch = 0;
};
void cub_sort_dim0_init(CubSegSort& h, int d0, int batch);
void cub_sort_dim0_run(CubSegSort& h, float* d_in, float* d_out);
void cub_sort_dim0_free(CubSegSort& h);
