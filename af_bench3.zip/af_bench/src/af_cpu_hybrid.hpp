#pragma once

#include <arrayfire.h>

// ArrayFire owns A, B, C / P, S. OpenMP does the work on device() pointers.
// Arrays must already live on AF_BACKEND_CPU and be eval()'d before the call.
// Helpers do not eval() so the timer is not charged for it.
void af_cpu_cadd(af::array& A, af::array& B, af::array& C);
void af_cpu_cmul(af::array& A, af::array& B, af::array& C);
void af_cpu_sort_dim0(af::array& P, af::array& S);
