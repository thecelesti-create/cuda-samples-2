#include "bench_common.hpp"

#include <cuda_runtime.h>
#include <cufft.h>
#include <cub/cub.cuh>

#include <stdexcept>
#include <string>
#include <vector>

#define CUDA_CHECK(expr)                                                       \
    do {                                                                       \
        cudaError_t _err = (expr);                                             \
        if (_err != cudaSuccess) {                                             \
            throw std::runtime_error(std::string("CUDA ") + __FILE__ + ":" +   \
                                     std::to_string(__LINE__) + " " +          \
                                     cudaGetErrorString(_err));                \
        }                                                                      \
    } while (0)

#define CUFFT_CHECK(expr)                                                      \
    do {                                                                       \
        cufftResult _err = (expr);                                             \
        if (_err != CUFFT_SUCCESS) {                                           \
            throw std::runtime_error("cuFFT error " + std::to_string(_err));   \
        }                                                                      \
    } while (0)

#define CUB_CHECK(expr)                                                        \
    do {                                                                       \
        cudaError_t _err = (expr);                                             \
        if (_err != cudaSuccess) {                                             \
            throw std::runtime_error(std::string("CUB ") +                     \
                                     cudaGetErrorString(_err));                \
        }                                                                      \
    } while (0)

__global__ void cadd_kernel(const float2* a, const float2* b, float2* c, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) {
        float2 x = a[i], y = b[i];
        c[i] = make_float2(x.x + y.x, x.y + y.y);
    }
}

__global__ void cmul_kernel(const float2* a, const float2* b, float2* c, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) {
        float2 x = a[i], y = b[i];
        c[i] = make_float2(x.x * y.x - x.y * y.y, x.x * y.y + x.y * y.x);
    }
}

static void sync_launch() {
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());
}

void cub_sort_dim0_init(CubSegSort& h, int d0, int batch) {
    if (d0 <= 0 || batch <= 0)
        throw std::runtime_error("cub_sort_dim0_init: d0 and batch must be > 0");
    h.n = d0 * batch;
    h.batch = batch;
    h.temp = nullptr;
    h.temp_bytes = 0;
    h.offsets = nullptr;

    CUDA_CHECK(cudaMalloc(&h.offsets, static_cast<size_t>(batch + 1) * sizeof(int)));
    try {
        std::vector<int> offsets(static_cast<size_t>(batch + 1));
        for (int i = 0; i <= batch; ++i)
            offsets[static_cast<size_t>(i)] = i * d0;
        CUDA_CHECK(cudaMemcpy(h.offsets, offsets.data(),
                              static_cast<size_t>(batch + 1) * sizeof(int),
                              cudaMemcpyHostToDevice));

        CUB_CHECK(cub::DeviceSegmentedRadixSort::SortKeys(
            nullptr, h.temp_bytes, static_cast<float*>(nullptr),
            static_cast<float*>(nullptr), h.n, h.batch, h.offsets, h.offsets + 1));
        if (h.temp_bytes > 0)
            CUDA_CHECK(cudaMalloc(&h.temp, h.temp_bytes));
    } catch (...) {
        cudaFree(h.offsets);
        cudaFree(h.temp);
        h.offsets = nullptr;
        h.temp = nullptr;
        throw;
    }
}

void cub_sort_dim0_run(CubSegSort& h, float* d_in, float* d_out) {
    if (!d_in || !d_out || !h.offsets)
        throw std::runtime_error("cub_sort_dim0_run: null pointer");
    CUB_CHECK(cub::DeviceSegmentedRadixSort::SortKeys(
        h.temp, h.temp_bytes, d_in, d_out, h.n, h.batch, h.offsets, h.offsets + 1));
    CUDA_CHECK(cudaDeviceSynchronize());
}

void cub_sort_dim0_free(CubSegSort& h) {
    if (h.temp) CUDA_CHECK(cudaFree(h.temp));
    if (h.offsets) CUDA_CHECK(cudaFree(h.offsets));
    h.temp = nullptr;
    h.offsets = nullptr;
    h.temp_bytes = 0;
    h.n = 0;
    h.batch = 0;
}

std::vector<Result> run_cuda(const BenchConfig& cfg, const float* a, const float* b) {
    require_fits_int32(cfg);
    const long long n64 = numel(cfg);
    const int n       = static_cast<int>(n64);
    const int howmany = static_cast<int>(batch64(cfg));
    const int threads = 256;
    const int blocks  = (n + threads - 1) / threads;

    float2 *dA = nullptr, *dB = nullptr, *dC = nullptr;
    auto cuda_free_abc = [&]() {
        if (dA) cudaFree(dA);
        if (dB) cudaFree(dB);
        if (dC) cudaFree(dC);
        dA = dB = dC = nullptr;
    };
    try {
        CUDA_CHECK(cudaMalloc(&dA, static_cast<size_t>(n) * sizeof(float2)));
        CUDA_CHECK(cudaMalloc(&dB, static_cast<size_t>(n) * sizeof(float2)));
        CUDA_CHECK(cudaMalloc(&dC, static_cast<size_t>(n) * sizeof(float2)));
        CUDA_CHECK(cudaMemcpy(dA, a, static_cast<size_t>(n) * sizeof(float2),
                              cudaMemcpyHostToDevice));
        CUDA_CHECK(cudaMemcpy(dB, b, static_cast<size_t>(n) * sizeof(float2),
                              cudaMemcpyHostToDevice));
    } catch (...) {
        cuda_free_abc();
        throw;
    }

    std::vector<Result> out;
    try {
        {
            const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
                cadd_kernel<<<blocks, threads>>>(dA, dB, dC, n);
                sync_launch();
            });
            out.push_back(make_result("cuda", "cadd", ms, flops_cadd(n64),
                                      bytes_c32_rw2in(n64)));
        }

        {
            const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
                cmul_kernel<<<blocks, threads>>>(dA, dB, dC, n);
                sync_launch();
            });
            out.push_back(make_result("cuda", "cmul", ms, flops_cmul(n64),
                                      bytes_c32_rw2in(n64)));
        }

        {
            cufftHandle plan = 0;
            int nn = cfg.d0;
            CUFFT_CHECK(cufftPlanMany(&plan, 1, &nn,
                                      nullptr, 1, cfg.d0,
                                      nullptr, 1, cfg.d0,
                                      CUFFT_C2C, howmany));
            try {
                const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
                    CUFFT_CHECK(cufftExecC2C(plan, dA, dC, CUFFT_FORWARD));
                    CUDA_CHECK(cudaDeviceSynchronize());
                });
                out.push_back(make_result("cuda", "fft", ms, flops_fft(cfg.d0, howmany),
                                          bytes_c32_fft(n64)));
            } catch (...) {
                cufftDestroy(plan);
                throw;
            }
            CUFFT_CHECK(cufftDestroy(plan));
        }

        {
            std::vector<float> keys(static_cast<size_t>(n));
            abs2_c32(a, keys.data(), n64);

            float *dIn = nullptr, *dOut = nullptr;
            CubSegSort h;
            try {
                CUDA_CHECK(cudaMalloc(&dIn, static_cast<size_t>(n) * sizeof(float)));
                CUDA_CHECK(cudaMalloc(&dOut, static_cast<size_t>(n) * sizeof(float)));
                CUDA_CHECK(cudaMemcpy(dIn, keys.data(),
                                      static_cast<size_t>(n) * sizeof(float),
                                      cudaMemcpyHostToDevice));
                cub_sort_dim0_init(h, cfg.d0, howmany);
                const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
                    cub_sort_dim0_run(h, dIn, dOut);
                });
                out.push_back(make_result("cuda", "sort(abs2)", ms,
                                          flops_sort(cfg.d0, howmany),
                                          bytes_sort_oop(n64)));
            } catch (...) {
                cub_sort_dim0_free(h);
                cudaFree(dIn);
                cudaFree(dOut);
                throw;
            }
            cub_sort_dim0_free(h);
            CUDA_CHECK(cudaFree(dIn));
            CUDA_CHECK(cudaFree(dOut));
        }
    } catch (...) {
        cuda_free_abc();
        throw;
    }

    cuda_free_abc();
    return out;
}
