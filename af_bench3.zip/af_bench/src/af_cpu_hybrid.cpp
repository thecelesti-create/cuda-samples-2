#include "af_cpu_hybrid.hpp"
#include "bench_common.hpp"

#include <algorithm>
#include <cstring>
#include <stdexcept>
#include <string>

#ifdef _OPENMP
#include <omp.h>
#endif

struct UnlockGuard {
    af::array* a = nullptr;
    explicit UnlockGuard(af::array& x) : a(&x) {}
    ~UnlockGuard() {
        if (a) {
            try { a->unlock(); } catch (...) {}
        }
    }
    UnlockGuard(const UnlockGuard&) = delete;
    UnlockGuard& operator=(const UnlockGuard&) = delete;
};

static void require_same_c32(const af::array& A, const af::array& B, const af::array& C,
                             const char* what) {
    if (A.type() != c32 || B.type() != c32 || C.type() != c32)
        throw std::runtime_error(std::string(what) + ": expected c32 arrays");
    if (A.elements() != B.elements() || A.elements() != C.elements())
        throw std::runtime_error(std::string(what) + ": size mismatch");
}

static void require_same_f32(const af::array& P, const af::array& S, const char* what) {
    if (P.type() != f32 || S.type() != f32)
        throw std::runtime_error(std::string(what) + ": expected f32 arrays");
    if (P.elements() != S.elements() || P.dims()[0] != S.dims()[0])
        throw std::runtime_error(std::string(what) + ": size/dim0 mismatch");
}

void af_cpu_cadd(af::array& A, af::array& B, af::array& C) {
    require_same_c32(A, B, C, "af_cpu_cadd");
    const int n = static_cast<int>(A.elements());
    const af::cfloat* pa = A.device<af::cfloat>();
    UnlockGuard ga(A);
    const af::cfloat* pb = B.device<af::cfloat>();
    UnlockGuard gb(B);
    af::cfloat* pc = C.device<af::cfloat>();
    UnlockGuard gc(C);
#ifdef _OPENMP
#pragma omp parallel for
#endif
    for (int i = 0; i < n; ++i) pc[i] = pa[i] + pb[i];
}

void af_cpu_cmul(af::array& A, af::array& B, af::array& C) {
    require_same_c32(A, B, C, "af_cpu_cmul");
    const int n = static_cast<int>(A.elements());
    const af::cfloat* pa = A.device<af::cfloat>();
    UnlockGuard ga(A);
    const af::cfloat* pb = B.device<af::cfloat>();
    UnlockGuard gb(B);
    af::cfloat* pc = C.device<af::cfloat>();
    UnlockGuard gc(C);
#ifdef _OPENMP
#pragma omp parallel for
#endif
    for (int i = 0; i < n; ++i) pc[i] = pa[i] * pb[i];
}

void af_cpu_sort_dim0(af::array& P, af::array& S) {
    require_same_f32(P, S, "af_cpu_sort_dim0");
    const int d0 = static_cast<int>(P.dims()[0]);
    const int n = static_cast<int>(P.elements());
    if (d0 <= 0 || n % d0 != 0)
        throw std::runtime_error("af_cpu_sort_dim0: dim0 does not divide elements");
    const int batch = n / d0;

    const float* src = P.device<float>();
    UnlockGuard gp(P);
    float* dst = S.device<float>();
    UnlockGuard gs(S);
    std::memcpy(dst, src, static_cast<size_t>(n) * sizeof(float));
#ifdef _OPENMP
#pragma omp parallel for
#endif
    for (int s = 0; s < batch; ++s) {
        float* col = dst + static_cast<long long>(s) * d0;
        std::sort(col, col + d0);
    }
}

std::vector<Result> run_af_cpu_hybrid(const BenchConfig& cfg, const float* a, const float* b) {
    require_fits_int32(cfg);
    const long long n = numel(cfg);
    const int howmany = static_cast<int>(batch64(cfg));

    af::setBackend(AF_BACKEND_CPU);
    if (af::getActiveBackend() != AF_BACKEND_CPU)
        throw std::runtime_error("run_af_cpu_hybrid: could not activate AF_BACKEND_CPU");

    const af::cfloat* ha = reinterpret_cast<const af::cfloat*>(a);
    const af::cfloat* hb = reinterpret_cast<const af::cfloat*>(b);
    af::array A(cfg.d0, cfg.d1, cfg.d2, ha, afHost);
    af::array B(cfg.d0, cfg.d1, cfg.d2, hb, afHost);
    af::array C(A.dims(), c32);
    af::array M(A.dims(), c32);
    af::array P = A.real() * A.real() + A.imag() * A.imag();
    af::array S(P.dims(), f32);
    A.eval();
    B.eval();
    C.eval();
    M.eval();
    P.eval();
    S.eval();
    af::sync();

    {
        af_cpu_cadd(A, B, C);
        af_cpu_cmul(A, B, M);
        af::array F = af::fftNorm(A, 1.0);
        F.eval();
        af_cpu_sort_dim0(P, S);
        af::sync();
    }

    std::vector<Result> out;
    const char* tag = "af-cpu-hybrid";

    {
        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            af_cpu_cadd(A, B, C);
        });
        out.push_back(make_result(tag, "cadd", ms, flops_cadd(n),
                                  bytes_c32_rw2in(n)));
    }
    {
        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            af_cpu_cmul(A, B, M);
        });
        out.push_back(make_result(tag, "cmul", ms, flops_cmul(n),
                                  bytes_c32_rw2in(n)));
    }
    {
        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            af::array F = af::fftNorm(A, 1.0);
            F.eval();
            af::sync();
        });
        out.push_back(make_result(tag, "fft", ms,
                                  flops_fft(cfg.d0, howmany),
                                  bytes_c32_fft(n)));
    }
    {
        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            af_cpu_sort_dim0(P, S);
        });
        out.push_back(make_result(tag, "sort(abs2)", ms,
                                  flops_sort(cfg.d0, howmany),
                                  bytes_sort_cpu(n)));
    }
    return out;
}
