#include "bench_common.hpp"

#include <arrayfire.h>

#include <stdexcept>
#include <string>
#include <vector>

static af_backend to_af_backend(AfBackend b) {
    switch (b) {
        case AfBackend::Cpu:    return AF_BACKEND_CPU;
        case AfBackend::OpenCL: return AF_BACKEND_OPENCL;
        case AfBackend::Cuda:
        default:                return AF_BACKEND_CUDA;
    }
}

static const char* af_backend_label(AfBackend b) {
    switch (b) {
        case AfBackend::Cpu:    return "arrayfire-cpu";
        case AfBackend::OpenCL: return "arrayfire-opencl";
        case AfBackend::Cuda:
        default:                return "arrayfire-cuda";
    }
}

std::vector<Result> run_arrayfire(const BenchConfig& cfg, const float* a, const float* b,
                                 AfBackend backend) {
    require_fits_int32(cfg);
    const long long n = numel(cfg);
    const int howmany = static_cast<int>(batch64(cfg));

    const af_backend want = to_af_backend(backend);

    // setBackend must be the first ArrayFire call. Probing first can lock
    // the unified default (CUDA) and make AF_BACKEND_CPU throw AF_ERR_ARG.
    try {
        af::setBackend(want);
    } catch (const std::exception& e) {
        int avail = 0;
        try { avail = af::getAvailableBackends(); } catch (...) {}
        throw std::runtime_error(
            std::string("setBackend(") + af_backend_label(backend) + ") failed: " + e.what() +
            " getAvailableBackends()=" + std::to_string(avail) +
            ". Need unified libaf + libafcpu/libafcuda on LD_LIBRARY_PATH.");
    }
    if (af::getActiveBackend() != want) {
        throw std::runtime_error(
            std::string("setBackend did not stick; active=") +
            std::to_string(static_cast<int>(af::getActiveBackend())) +
            " requested=" + std::to_string(static_cast<int>(want)));
    }
    af::setFftPlanCacheSize(32);
    af::info();
    const char* tag = af_backend_label(backend);

    const af::cfloat* ha = reinterpret_cast<const af::cfloat*>(a);
    const af::cfloat* hb = reinterpret_cast<const af::cfloat*>(b);
    af::array A(cfg.d0, cfg.d1, cfg.d2, ha, afHost);
    af::array B(cfg.d0, cfg.d1, cfg.d2, hb, afHost);

    af::array P = A.real() * A.real() + A.imag() * A.imag();

    A.eval();
    B.eval();
    P.eval();
    af::sync();

    {
        af::array C = A + B;
        af::array M = A * B;
        af::array F = af::fftNorm(A, 1.0);
        af::array S = af::sort(P, 0);
        C.eval();
        M.eval();
        F.eval();
        S.eval();
        af::sync();
    }

    std::vector<Result> out;

    {
        double ms = 0;
        ms = time_ms(cfg.warmup, cfg.iters, [&] {
            af::array C = A + B;
            C.eval();
            af::sync();
        });
        out.push_back(make_result(tag, "cadd", ms, flops_cadd(n),
                                  bytes_c32_rw2in(n)));
    }

    {
        double ms = 0;
        ms = time_ms(cfg.warmup, cfg.iters, [&] {
            af::array M = A * B;
            M.eval();
            af::sync();
        });
        out.push_back(make_result(tag, "cmul", ms, flops_cmul(n),
                                  bytes_c32_rw2in(n)));
    }

    {
        // Out-of-place, unscaled, same as cufftExec / FFTW. Input A is unchanged.
        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            af::array F = af::fftNorm(A, 1.0);
            F.eval();
            af::sync();
        });
        out.push_back(make_result(tag, "fft", ms,
                                  flops_fft(cfg.d0, howmany),
                                  bytes_c32_fft(n)));
    }

    {
        double ms = 0;
        if (backend == AfBackend::Cuda) {
            af::array S(P.dims(), f32);
            S.eval();
            af::sync();
            CubSegSort h;
            try {
                cub_sort_dim0_init(h, cfg.d0, howmany);
                ms = time_ms(cfg.warmup, cfg.iters, [&] {
                    float* in  = P.device<float>();
                    float* outp = S.device<float>();
                    try {
                        cub_sort_dim0_run(h, in, outp);
                    } catch (...) {
                        P.unlock();
                        S.unlock();
                        throw;
                    }
                    P.unlock();
                    S.unlock();
                });
            } catch (...) {
                cub_sort_dim0_free(h);
                throw;
            }
            cub_sort_dim0_free(h);
        } else {
            ms = time_ms(cfg.warmup, cfg.iters, [&] {
                af::array S = af::sort(P, 0);
                S.eval();
                af::sync();
            });
        }
        out.push_back(make_result(tag, "sort(abs2)", ms,
                                  flops_sort(cfg.d0, howmany),
                                  bytes_sort_oop(n)));
    }

    return out;
}
