#define EIGEN_USE_OPENMP

#include "bench_common.hpp"

#include <algorithm>
#include <complex>
#include <cstring>
#include <random>
#include <stdexcept>
#include <vector>

#include <Eigen/Core>
#include <fftw3.h>

#ifdef _OPENMP
#include <omp.h>
#endif

void fill_c32(float* interleaved, long long n, uint32_t seed) {
    std::mt19937 rng(seed);
    std::uniform_real_distribution<float> dist(-1.f, 1.f);
    for (long long i = 0; i < n; ++i) {
        interleaved[2 * i]     = dist(rng);
        interleaved[2 * i + 1] = dist(rng);
    }
}

void abs2_c32(const float* interleaved, float* keys, long long n) {
    for (long long i = 0; i < n; ++i) {
        const float re = interleaved[2 * i];
        const float im = interleaved[2 * i + 1];
        keys[i] = re * re + im * im;
    }
}

std::vector<Result> run_cpu(const BenchConfig& cfg, const float* a, const float* b) {
    require_fits_int32(cfg);
    const long long n = numel(cfg);
    const int howmany = static_cast<int>(batch64(cfg));

#ifdef AFBENCH_HAVE_FFTW_OMP
    fftwf_init_threads();
#ifdef _OPENMP
    fftwf_plan_with_nthreads(omp_get_max_threads());
#else
    fftwf_plan_with_nthreads(4);
#endif
#endif

#ifdef _OPENMP
    Eigen::setNbThreads(omp_get_max_threads());
#endif

    using Cplx = std::complex<float>;
    std::vector<Cplx> A(n), B(n), C(n);
    std::memcpy(A.data(), a, static_cast<size_t>(n) * sizeof(Cplx));
    std::memcpy(B.data(), b, static_cast<size_t>(n) * sizeof(Cplx));

    Eigen::Map<Eigen::ArrayXcf> eA(A.data(), n);
    Eigen::Map<Eigen::ArrayXcf> eB(B.data(), n);
    Eigen::Map<Eigen::ArrayXcf> eC(C.data(), n);

    std::vector<Result> out;

    {
        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            eC = eA + eB;
            asm volatile("" ::"g"(C.data()) : "memory");
        });
        out.push_back(make_result("cpu-eigen/fftw", "cadd", ms, flops_cadd(n),
                                  bytes_c32_rw2in(n)));
    }

    {
        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            eC = eA * eB;
            asm volatile("" ::"g"(C.data()) : "memory");
        });
        out.push_back(make_result("cpu-eigen/fftw", "cmul", ms, flops_cmul(n),
                                  bytes_c32_rw2in(n)));
    }

    {
        fftwf_complex* in = fftwf_alloc_complex(n);
        fftwf_complex* ou = fftwf_alloc_complex(n);
        if (!in || !ou) {
            fftwf_free(in);
            fftwf_free(ou);
            throw std::runtime_error("fftwf_alloc_complex failed");
        }
        std::memcpy(in, a, static_cast<size_t>(n) * sizeof(Cplx));

        int nn = cfg.d0;
        fftwf_plan plan = fftwf_plan_many_dft(
            1, &nn, howmany,
            in, nullptr, 1, cfg.d0,
            ou, nullptr, 1, cfg.d0,
            FFTW_FORWARD, FFTW_MEASURE);
        if (!plan) {
            fftwf_free(in);
            fftwf_free(ou);
            throw std::runtime_error("fftwf_plan_many_dft failed");
        }

        std::memcpy(in, a, static_cast<size_t>(n) * sizeof(Cplx));
        try {
            const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
                fftwf_execute(plan);
            });
            out.push_back(make_result("cpu-eigen/fftw", "fft", ms,
                                      flops_fft(cfg.d0, howmany),
                                      bytes_c32_fft(n)));
        } catch (...) {
            fftwf_destroy_plan(plan);
            fftwf_free(in);
            fftwf_free(ou);
            throw;
        }
        fftwf_destroy_plan(plan);
        fftwf_free(in);
        fftwf_free(ou);
        // Do not fftwf_cleanup_threads(): AF-CPU FFT later in this process
        // uses FFTW and would see a torn thread pool.
    }

    {
        std::vector<float> keys(n), work(n);
        abs2_c32(a, keys.data(), n);
        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            std::memcpy(work.data(), keys.data(), static_cast<size_t>(n) * sizeof(float));
#ifdef _OPENMP
#pragma omp parallel for
#endif
            for (int s = 0; s < howmany; ++s) {
                float* p = work.data() + static_cast<long long>(s) * cfg.d0;
                std::sort(p, p + cfg.d0);
            }
        });
        out.push_back(make_result("cpu-eigen/fftw", "sort(abs2)", ms,
                                  flops_sort(cfg.d0, howmany),
                                  bytes_sort_cpu(n)));
    }

    return out;
}
