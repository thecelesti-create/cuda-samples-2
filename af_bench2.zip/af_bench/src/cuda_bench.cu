#include "bench_common.hpp"

#include <cuda_runtime.h>
#include <cufft.h>
#include <cub/cub.cuh>

#include <stdexcept>
#include <string>
#include <vector>

#define CUDA_CHECK(expr)                                                       \
    do {                                                                       \
        cudaError_t _err = (expr);                                             \
        if (_err != cudaSuccess) {                                             \
            throw std::runtime_error(std::string("CUDA ") + __FILE__ + ":" +   \
                                     std::to_string(__LINE__) + " " +          \
                                     cudaGetErrorString(_err));                \
        }                                                                      \
    } while (0)

#define CUFFT_CHECK(expr)                                                      \
    do {                                                                       \
        cufftResult _err = (expr);                                             \
        if (_err != CUFFT_SUCCESS) {                                           \
            throw std::runtime_error("cuFFT error " + std::to_string(_err));   \
        }                                                                      \
    } while (0)

#define CUB_CHECK(expr)                                                        \
    do {                                                                       \
        cudaError_t _err = (expr);                                             \
        if (_err != cudaSuccess) {                                             \
            throw std::runtime_error(std::string("CUB ") +                     \
                                     cudaGetErrorString(_err));                \
        }                                                                      \
    } while (0)

__global__ void cadd_kernel(const float2* a, const float2* b, float2* c, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) {
        float2 x = a[i], y = b[i];
        c[i] = make_float2(x.x + y.x, x.y + y.y);
    }
}

__global__ void cmul_kernel(const float2* a, const float2* b, float2* c, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) {
        float2 x = a[i], y = b[i];
        c[i] = make_float2(x.x * y.x - x.y * y.y, x.x * y.y + x.y * y.x);
    }
}

static void sync_launch() {
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());
}

std::vector<Result> run_cuda(const BenchConfig& cfg, const float* a, const float* b) {
    require_fits_int32(cfg);
    const long long n64 = numel(cfg);
    const int n       = static_cast<int>(n64);
    const int howmany = static_cast<int>(batch64(cfg));
    const int threads = 256;
    const int blocks  = (n + threads - 1) / threads;

    float2 *dA = nullptr, *dB = nullptr, *dC = nullptr;
    CUDA_CHECK(cudaMalloc(&dA, static_cast<size_t>(n) * sizeof(float2)));
    CUDA_CHECK(cudaMalloc(&dB, static_cast<size_t>(n) * sizeof(float2)));
    CUDA_CHECK(cudaMalloc(&dC, static_cast<size_t>(n) * sizeof(float2)));
    CUDA_CHECK(cudaMemcpy(dA, a, static_cast<size_t>(n) * sizeof(float2),
                          cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(dB, b, static_cast<size_t>(n) * sizeof(float2),
                          cudaMemcpyHostToDevice));

    std::vector<Result> out;

    {
        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            cadd_kernel<<<blocks, threads>>>(dA, dB, dC, n);
            sync_launch();
        });
        out.push_back(make_result("cuda", "cadd", ms, flops_cadd(n64),
                                  bytes_c32_rw2in(n64), WorkKind::Gflop));
    }

    {
        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            cmul_kernel<<<blocks, threads>>>(dA, dB, dC, n);
            sync_launch();
        });
        out.push_back(make_result("cuda", "cmul", ms, flops_cmul(n64),
                                  bytes_c32_rw2in(n64), WorkKind::Gflop));
    }

    {
        cufftHandle plan = 0;
        int nn = cfg.d0;
        CUFFT_CHECK(cufftPlanMany(&plan, 1, &nn,
                                  nullptr, 1, cfg.d0,
                                  nullptr, 1, cfg.d0,
                                  CUFFT_C2C, howmany));
        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            CUFFT_CHECK(cufftExecC2C(plan, dA, dC, CUFFT_FORWARD));
            CUDA_CHECK(cudaDeviceSynchronize());
        });
        out.push_back(make_result("cuda", "fft", ms, flops_fft(cfg.d0, howmany),
                                  bytes_c32_fft(n64), WorkKind::Gflop));
        CUFFT_CHECK(cufftDestroy(plan));
    }

    {
        std::vector<float> keys(static_cast<size_t>(n));
        abs2_c32(a, keys.data(), n64);

        float *dIn = nullptr, *dOut = nullptr;
        int* dOffsets = nullptr;
        CUDA_CHECK(cudaMalloc(&dIn, static_cast<size_t>(n) * sizeof(float)));
        CUDA_CHECK(cudaMalloc(&dOut, static_cast<size_t>(n) * sizeof(float)));
        CUDA_CHECK(cudaMalloc(&dOffsets, static_cast<size_t>(howmany + 1) * sizeof(int)));
        CUDA_CHECK(cudaMemcpy(dIn, keys.data(), static_cast<size_t>(n) * sizeof(float),
                              cudaMemcpyHostToDevice));

        std::vector<int> offsets(howmany + 1);
        for (int i = 0; i <= howmany; ++i)
            offsets[i] = i * cfg.d0;
        CUDA_CHECK(cudaMemcpy(dOffsets, offsets.data(),
                              static_cast<size_t>(howmany + 1) * sizeof(int),
                              cudaMemcpyHostToDevice));

        void* dTemp = nullptr;
        size_t temp_bytes = 0;
        CUB_CHECK(cub::DeviceSegmentedRadixSort::SortKeys(
            dTemp, temp_bytes, dIn, dOut, n, howmany, dOffsets, dOffsets + 1));
        CUDA_CHECK(cudaMalloc(&dTemp, temp_bytes));

        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            CUB_CHECK(cub::DeviceSegmentedRadixSort::SortKeys(
                dTemp, temp_bytes, dIn, dOut, n, howmany, dOffsets, dOffsets + 1));
            CUDA_CHECK(cudaDeviceSynchronize());
        });
        out.push_back(make_result("cuda", "sort(abs2)", ms,
                                  ops_sort(cfg.d0, howmany),
                                  bytes_sort_oop(n64), WorkKind::Gcmp));

        CUDA_CHECK(cudaFree(dTemp));
        CUDA_CHECK(cudaFree(dIn));
        CUDA_CHECK(cudaFree(dOut));
        CUDA_CHECK(cudaFree(dOffsets));
    }

    CUDA_CHECK(cudaFree(dA));
    CUDA_CHECK(cudaFree(dB));
    CUDA_CHECK(cudaFree(dC));
    return out;
}
