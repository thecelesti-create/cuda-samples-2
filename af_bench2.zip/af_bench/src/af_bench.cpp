#include "bench_common.hpp"

#include <arrayfire.h>

#include <vector>

std::vector<Result> run_arrayfire(const BenchConfig& cfg, const float* a, const float* b) {
    require_fits_int32(cfg);
    const long long n = numel(cfg);
    const int howmany = static_cast<int>(batch64(cfg));

    af::setBackend(AF_BACKEND_CUDA);
    af::info();

    const af::cfloat* ha = reinterpret_cast<const af::cfloat*>(a);
    const af::cfloat* hb = reinterpret_cast<const af::cfloat*>(b);
    af::array A(cfg.d0, cfg.d1, cfg.d2, ha, afHost);
    af::array B(cfg.d0, cfg.d1, cfg.d2, hb, afHost);

    std::vector<float> keys(static_cast<size_t>(n));
    abs2_c32(a, keys.data(), n);
    af::array P(cfg.d0, cfg.d1, cfg.d2, keys.data(), afHost);

    A.eval();
    B.eval();
    P.eval();
    af::sync();

    {
        af::array C = A + B;
        af::array M = A * B;
        af::array F = af::fftNorm(A, 1.0);
        af::array S = af::sort(P, 0);
        C.eval();
        M.eval();
        F.eval();
        S.eval();
        af::sync();
    }

    std::vector<Result> out;

    {
        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            af::array C = A + B;
            C.eval();
            af::sync();
        });
        out.push_back(make_result("arrayfire", "cadd", ms, flops_cadd(n),
                                  bytes_c32_rw2in(n), WorkKind::Gflop));
    }

    {
        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            af::array M = A * B;
            M.eval();
            af::sync();
        });
        out.push_back(make_result("arrayfire", "cmul", ms, flops_cmul(n),
                                  bytes_c32_rw2in(n), WorkKind::Gflop));
    }

    {
        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            af::array F = af::fftNorm(A, 1.0);
            F.eval();
            af::sync();
        });
        out.push_back(make_result("arrayfire", "fft", ms,
                                  flops_fft(cfg.d0, howmany),
                                  bytes_c32_fft(n), WorkKind::Gflop));
    }

    {
        const double ms = time_ms(cfg.warmup, cfg.iters, [&] {
            af::array S = af::sort(P, 0);
            S.eval();
            af::sync();
        });
        out.push_back(make_result("arrayfire", "sort(abs2)", ms,
                                  ops_sort(cfg.d0, howmany),
                                  bytes_sort_oop(n), WorkKind::Gcmp));
    }

    return out;
}
