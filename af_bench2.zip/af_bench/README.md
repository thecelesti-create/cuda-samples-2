# af_bench

Single executable: ArrayFire (CUDA) vs raw CUDA (kernels + cuFFT + CUB) vs Eigen + FFTW.

Working type is **c32 only**. One host cube is shared by every backend.

| op | data | along |
|---|---|---|
| `cadd` | c32 + c32 | elementwise |
| `cmul` | c32 * c32 | elementwise |
| `fft` | batched 1D C2C, unscaled | **d0** |
| `sort(abs2)` | `re^2+im^2` of the same c32 cube | **d0** |

`sort` ranks power of the IQ cube: ArrayFire/CUB have no useful c32-key sort, and TM-CFAR ranks power.

## Build

CUDA toolkit, ArrayFire, `libfftw3-dev`, `libeigen3-dev`, CMake >= 3.18.

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release \
  -DArrayFire_DIR=/opt/arrayfire/share/ArrayFire/cmake \
  -DCMAKE_CUDA_ARCHITECTURES=86
cmake --build build -j
```

## Run

```bash
./build/af_bench
./build/af_bench --d0 2048 --d1 256 --d2 16 --warmup 5 --iters 30
```

`unit` is **GFLOP** for add/mul/fft and **Gcmp** for sort (`N log2 N` comparisons, not flops).

Warmup excludes JIT and cuFFT planning. Sizes must fit in int32 (CUB/cuFFT).
