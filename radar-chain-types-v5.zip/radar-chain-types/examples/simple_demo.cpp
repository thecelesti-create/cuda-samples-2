#include <radar/radar.hpp>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

// THREE FAKE ALGORITHMS: API/dataflow demonstration ONLY, not radar processing.
// With CUDA selected, all array arithmetic/reorders/gathers below run on device.
radar::RangePulseBuffer fakeMatchedFilter(const radar::SamplePulseBuffer& input) {
    // Placeholder: apply a gain, not a real matched filter.
    af::array output = input.getData() * 2.0f;
    auto rangeAxis = radar::RangeAxis::fromRoundTripTiming(
        input.getMetadata().getFirstSampleDelaySeconds(),
        input.getMetadata().getSampleRateHz());
    return {input, std::move(output), rangeAxis};
}

radar::RangeDopplerMap fakeDoppler(const radar::RangePulseBuffer& input) {
    // Placeholder: just change [range,pulse,element] to [pulse,range,element].
    // A real version would use af::fft(input.getDopplerInput()).
    return {input, input.getDopplerInput(), radar::DopplerOrder::Unshifted};
}

radar::DetectionList fakeDetector(const radar::RangeDopplerMap& input) {
    // Placeholder: always select cell zero, not CFAR or a real detector.
    af::array cellIndices = af::constant(0u, af::dim4(1), u32);
    af::array powers = af::lookup(af::flat(input.getPowerSumElements()), cellIndices, 0);
    af::array noisePowers = af::constant(1.0f, af::dim4(1), f32);
    return radar::DetectionList::fromMap(
        input, std::move(cellIndices), std::move(powers), std::move(noisePowers));
}

int main(int argc, char** argv) {
    try {
#if RADAR_ARRAYFIRE_UNIFIED
        const std::string backend = argc > 1 ? argv[1] : "cuda";
        if (backend == "cuda") af::setBackend(AF_BACKEND_CUDA);
        else if (backend == "cpu") af::setBackend(AF_BACKEND_CPU);
        else if (backend == "opencl") af::setBackend(AF_BACKEND_OPENCL);
        else throw std::invalid_argument("backend must be cuda, cpu, or opencl");
#else
        (void)argv;
        if (argc > 1) throw std::invalid_argument("direct-backend build takes no backend argument");
#endif
        af::setDevice(0);
        af::info();
        constexpr dim_t sampleCount = 8, pulseCount = 4, elementCount = 3;
        radar::CPI_Metadata metadata(10e6, 2000.0, 10e9, 1);
        metadata.setElementNames({"element0", "element1", "element2"});
        const std::vector<af::cfloat> hostIq(
            sampleCount * pulseCount * elementCount, af::cfloat(1.0f, 0.0f));

        // Initial upload. fromHost accepts a C++20 span (vector converts directly).
        const auto samples = radar::SamplePulseBuffer::fromHost(
            hostIq, sampleCount, pulseCount, elementCount, std::move(metadata));

        // The complete three-stage API chain. No host data export between stages.
        const auto ranges = fakeMatchedFilter(samples);
        const auto map = fakeDoppler(ranges);
        const auto detections = fakeDetector(map);

        // FINAL OUTPUT ONLY: explicitly download the tiny CPU records for printing.
        const auto records = detections.recordsToHost();
        std::cout << "Fake chain produced " << records.size() << " detection(s).\n";
        for (const auto& record : records) {
            std::cout << "range bin=" << record.getCell().getRangeBin()
                      << ", Doppler bin=" << record.getCell().getDopplerBin()
                      << ", power=" << record.getCell().getPower() << '\n';
        }
        // Expected: one fabricated detection at (0,0), power = 3 * |2|^2 = 12.
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
