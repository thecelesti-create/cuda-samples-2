#pragma once

#include <radar/RangeDopplerMap.hpp>

namespace radar {

// Device-resident detection columns: u32 bins, f32 powers, c32 element IQ.
// Scalar columns are [detection,1,1,1]; snapshots are [element,detection,1,1].
// Constructors/setters check STRUCTURE only (shape/type/context), not GPU values.
// Producer preconditions: in-range bins, finite power >= 0, finite noise > 0,
// nonnegative physical ranges, and snapshots aligned with the supplied cells.
// Accessors/selectors add no bounds checks and never download a scalar record.
class DetectionList final {
public:
    // Explicit empty list, retaining only small host-side context.
    explicit DetectionList(DetectionContext context);

    // Adopt results already produced on the selected ArrayFire device.
    DetectionList(DetectionContext context, af::array rangeBins, af::array dopplerBins,
                  af::array powers, af::array noisePowers, af::array elementSnapshots);
    DetectionList(const RangeDopplerMap& source, af::array rangeBins, af::array dopplerBins,
                  af::array powers, af::array noisePowers, af::array elementSnapshots);

    // Gather IQ using u32 linear cells in the [Doppler,range] plane:
    // cell = dopplerBin + dopplerBinCount * rangeBin. No host index-vector upload.
    // Also derives the separate bin columns with integer arithmetic on device.
    DetectionList(const RangeDopplerMap& source, af::array linearCellIndices,
                  af::array powers, af::array noisePowers);
    [[nodiscard]] static DetectionList fromMap(const RangeDopplerMap& source,
                                               af::array linearCellIndices,
                                               af::array powers, af::array noisePowers);

    [[nodiscard]] std::size_t getDetectionCount() const noexcept { return detectionCount_; }
    [[nodiscard]] bool getIsEmpty() const noexcept { return detectionCount_ == 0; }
    [[nodiscard]] BinIndex getElementCount() const noexcept { return context_.getElementCount(); }
    [[nodiscard]] const DetectionContext& getContext() const noexcept { return context_; }
    [[nodiscard]] const af::array& getRangeBins() const noexcept { return rangeBins_; }
    [[nodiscard]] const af::array& getDopplerBins() const noexcept { return dopplerBins_; }
    [[nodiscard]] const af::array& getPowers() const noexcept { return powers_; }
    [[nodiscard]] const af::array& getNoisePowers() const noexcept { return noisePowers_; }
    [[nodiscard]] const af::array& getElementSnapshots() const noexcept { return snapshots_; }
    [[nodiscard]] af::array getElementSnapshot(std::size_t detectionIndex) const;
    // Returns a ONE-ENTRY DEVICE LIST, not a downloaded CPU Detection.
    [[nodiscard]] DetectionList getDetection(std::size_t detectionIndex) const;

    // Derived device columns. f32 avoids default FP64 arithmetic on laptop GPUs.
    // Scalar conversion of metadata to f32 must be representable for these helpers.
    // recordsToHost() instead derives coordinates in double precision on the CPU.
    [[nodiscard]] af::array getRangesMeters() const;
    [[nodiscard]] af::array getDopplerHz() const;
    [[nodiscard]] af::array getRadialVelocitiesMps() const;
    [[nodiscard]] af::array getSnrDb() const;
    [[nodiscard]] std::size_t getSnapshotBytes() const noexcept {
        return detectionCount_ * static_cast<std::size_t>(getElementCount()) * sizeof(af::cfloat);
    }

    // Checked same-count/context replacement. Bins and snapshots remain aligned.
    void setPowers(af::array powers, af::array noisePowers);
    void setElementSnapshots(af::array snapshots);
    // Unchecked u32 [selectedDetectionCount] indices on the same active device.
    // Duplicates are allowed. All columns and snapshots move together.
    [[nodiscard]] DetectionList select(const af::array& detectionIndices) const;
    [[nodiscard]] DetectionList clone() const;

    // EXPLICIT blocking host-download boundaries. No full map is retained/downloaded.
    [[nodiscard]] std::vector<Detection> recordsToHost() const;
    [[nodiscard]] std::vector<af::cfloat> snapshotsToHost() const;
    void evaluate() const;
    void synchronize() const;

private:
    enum class TrustedColumns { Yes };
    DetectionList(DetectionContext context, std::size_t detectionCount,
                  af::array rangeBins, af::array dopplerBins, af::array powers,
                  af::array noisePowers, af::array snapshots, TrustedColumns);
    DetectionContext context_;
    std::size_t detectionCount_ = 0;
    af::array rangeBins_;
    af::array dopplerBins_;
    af::array powers_;
    af::array noisePowers_;
    af::array snapshots_;
};
} // namespace radar
