#pragma once

#include <radar/CPI_Metadata.hpp>
#include <array>
#include <utility>

namespace radar {

class RangeAxis final {
public:
    RangeAxis(double firstBinMeters, double binSpacingMeters)
        : firstBinMeters_(firstBinMeters), binSpacingMeters_(binSpacingMeters) {
        detail::requireFinite(firstBinMeters_, "firstBinMeters");
        detail::requirePositive(binSpacingMeters_, "binSpacingMeters");
    }
    [[nodiscard]] double getFirstBinMeters() const noexcept { return firstBinMeters_; }
    [[nodiscard]] double getBinSpacingMeters() const noexcept { return binSpacingMeters_; }
    // Unchecked: the owning container/caller supplies a valid, representable bin.
    [[nodiscard]] double getMeters(BinIndex bin) const noexcept {
        return firstBinMeters_ + static_cast<double>(bin) * binSpacingMeters_;
    }
    [[nodiscard]] RangeAxis sliced(BinIndex first) const noexcept {
        auto result = *this;
        result.firstBinMeters_ = getMeters(first);
        return result;
    }
    void setFirstBinMeters(double value) {
        detail::requireFinite(value, "firstBinMeters");
        firstBinMeters_ = value;
    }
    void setBinSpacingMeters(double value) {
        detail::requirePositive(value, "binSpacingMeters");
        binSpacingMeters_ = value;
    }
    // Factory delegates all validation to a constructor. Timing must already
    // account for matched-filter delay/cropping and any resampling.
    [[nodiscard]] static RangeAxis fromRoundTripTiming(double delaySeconds, double sampleRateHz) {
        return RangeAxis(delaySeconds, sampleRateHz, TimingInput::RoundTrip);
    }
private:
    enum class TimingInput { RoundTrip };
    RangeAxis(double delay, double sampleRate, TimingInput)
        : firstBinMeters_(speedOfLightMps * 0.5 * delay),
          binSpacingMeters_(speedOfLightMps * 0.5 / sampleRate) {
        detail::requireFinite(delay, "output bin-zero delay");
        detail::requirePositive(sampleRate, "output sample rate");
        detail::requireFinite(firstBinMeters_, "computed range origin");
        detail::requirePositive(binSpacingMeters_, "computed range spacing");
    }
    double firstBinMeters_;
    double binSpacingMeters_;
};

class DopplerAxis final {
public:
    DopplerAxis(BinIndex fftSize, BinIndex pulsesUsed, double prfHz,
                DopplerOrder order = DopplerOrder::Unshifted)
        : fftSize_(fftSize), pulsesUsed_(pulsesUsed), prfHz_(prfHz), order_(order) {
        detail::requirePositive(prfHz_, "Doppler PRF");
        if (fftSize_ <= 0 || pulsesUsed_ <= 0 || pulsesUsed_ > fftSize_)
            throw std::invalid_argument("require 0 < pulsesUsed <= fftSize");
        detail::requireOrder(order_);
        binSpacingHz_ = prfHz_ / static_cast<double>(fftSize_);
        coherentIntervalSeconds_ = static_cast<double>(pulsesUsed_) / prfHz_;
        detail::requirePositive(binSpacingHz_, "Doppler bin spacing");
        detail::requirePositive(coherentIntervalSeconds_, "coherent interval");
    }
    [[nodiscard]] BinIndex getFftSize() const noexcept { return fftSize_; }
    [[nodiscard]] BinIndex getPulsesUsed() const noexcept { return pulsesUsed_; }
    [[nodiscard]] double getPrfHz() const noexcept { return prfHz_; }
    [[nodiscard]] DopplerOrder getOrder() const noexcept { return order_; }
    [[nodiscard]] double getBinSpacingHz() const noexcept { return binSpacingHz_; }
    [[nodiscard]] double getCoherentIntervalSeconds() const noexcept { return coherentIntervalSeconds_; }
    // Unchecked: 0 <= bin < getFftSize(). Even-N Nyquist is the negative bin.
    [[nodiscard]] BinIndex getSignedBin(BinIndex bin) const noexcept {
        if (order_ == DopplerOrder::Centered) return bin - fftSize_ / 2;
        return bin <= (fftSize_ - 1) / 2 ? bin : bin - fftSize_;
    }
    [[nodiscard]] double getHertz(BinIndex bin) const noexcept {
        return static_cast<double>(getSignedBin(bin)) * binSpacingHz_;
    }
    void setFftSize(BinIndex value) { *this = DopplerAxis(value, pulsesUsed_, prfHz_, order_); }
    void setPulsesUsed(BinIndex value) { *this = DopplerAxis(fftSize_, value, prfHz_, order_); }
    void setPrfHz(double value) { *this = DopplerAxis(fftSize_, pulsesUsed_, value, order_); }
    void setOrder(DopplerOrder value) {
        detail::requireOrder(value);
        order_ = value;
    }
private:
    BinIndex fftSize_;
    BinIndex pulsesUsed_;
    double prfHz_;
    DopplerOrder order_;
    double binSpacingHz_;
    double coherentIntervalSeconds_;
};

// CPU export/serialization value. Bounds within a specific map are checked
// when constructing a CPU Detection; this value class validates its own scalars.
// Device list constructors do not scan GPU values.
class DetectionCell final {
public:
    DetectionCell(BinIndex rangeBin = 0, BinIndex dopplerBin = 0,
                  double power = 0.0, double noisePower = 1.0)
        : rangeBin_(rangeBin), dopplerBin_(dopplerBin), power_(power), noisePower_(noisePower) {
        if (rangeBin_ < 0 || dopplerBin_ < 0)
            throw std::out_of_range("detection bins must be nonnegative");
        detail::requireNonnegative(power_, "detection power");
        detail::requirePositive(noisePower_, "detection noise power");
    }
    [[nodiscard]] BinIndex getRangeBin() const noexcept { return rangeBin_; }
    [[nodiscard]] BinIndex getDopplerBin() const noexcept { return dopplerBin_; }
    [[nodiscard]] double getPower() const noexcept { return power_; }
    [[nodiscard]] double getNoisePower() const noexcept { return noisePower_; }
    void setRangeBin(BinIndex value) {
        if (value < 0) throw std::out_of_range("range bin must be nonnegative");
        rangeBin_ = value;
    }
    void setDopplerBin(BinIndex value) {
        if (value < 0) throw std::out_of_range("Doppler bin must be nonnegative");
        dopplerBin_ = value;
    }
    void setPower(double value) {
        detail::requireNonnegative(value, "detection power");
        power_ = value;
    }
    void setNoisePower(double value) {
        detail::requirePositive(value, "detection noise power");
        noisePower_ = value;
    }
private:
    BinIndex rangeBin_;
    BinIndex dopplerBin_;
    double power_;
    double noisePower_;
};

class DetectionContext;

class Detection final {
public:
    Detection(const DetectionContext& context, DetectionCell cell);
    // Explicit physical values, e.g. a deserialized record. Coordinates are
    // read-only afterwards so changing a bin cannot leave stale coordinates.
    Detection(DetectionCell cell, double rangeMeters, double dopplerHz, double radialVelocityMps)
        : cell_(cell), rangeMeters_(rangeMeters), dopplerHz_(dopplerHz),
          radialVelocityMps_(radialVelocityMps) {
        detail::requireNonnegative(rangeMeters_, "detection range");
        detail::requireFinite(dopplerHz_, "detection Doppler");
        detail::requireFinite(radialVelocityMps_, "detection radial velocity");
    }
    [[nodiscard]] const DetectionCell& getCell() const noexcept { return cell_; }
    [[nodiscard]] double getRangeMeters() const noexcept { return rangeMeters_; }
    [[nodiscard]] double getDopplerHz() const noexcept { return dopplerHz_; }
    [[nodiscard]] double getRadialVelocityMps() const noexcept { return radialVelocityMps_; }
    // Cell-to-noise ratio, not noise-subtracted SNR. Zero power is valid (-inf dB).
    [[nodiscard]] double getSnrDb() const noexcept {
        return cell_.getPower() == 0.0 ? -std::numeric_limits<double>::infinity()
             : 10.0 * (std::log10(cell_.getPower()) - std::log10(cell_.getNoisePower()));
    }
private:
    DetectionCell cell_;
    double rangeMeters_;
    double dopplerHz_;
    double radialVelocityMps_;
};

// Detached description; never retains a full IQ cube. Construct a new context
// for changes to coupled metadata/axes rather than mutating one field in place.
class DetectionContext final {
public:
    DetectionContext(CPI_Metadata metadata, RangeAxis rangeAxis, DopplerAxis dopplerAxis,
                     BinIndex rangeBinCount, BinIndex elementCount)
        : metadata_(std::move(metadata)), rangeAxis_(rangeAxis), dopplerAxis_(dopplerAxis),
          rangeBinCount_(rangeBinCount), elementCount_(elementCount) {
        detail::checkedProduct(rangeBinCount_, dopplerAxis_.getFftSize(), elementCount_);
        if (!metadata_.getElementNames().empty() &&
            metadata_.getElementNames().size() != static_cast<std::size_t>(elementCount_))
            throw std::invalid_argument("element labels must match element count");
        if (dopplerAxis_.getPrfHz() != metadata_.getPrfHz())
            throw std::invalid_argument("CPI and Doppler PRFs disagree");
        detail::requireFinite(rangeAxis_.getMeters(rangeBinCount_ - 1), "last range bin");
    }
    [[nodiscard]] const CPI_Metadata& getMetadata() const noexcept { return metadata_; }
    [[nodiscard]] const RangeAxis& getRangeAxis() const noexcept { return rangeAxis_; }
    [[nodiscard]] const DopplerAxis& getDopplerAxis() const noexcept { return dopplerAxis_; }
    [[nodiscard]] BinIndex getRangeBinCount() const noexcept { return rangeBinCount_; }
    [[nodiscard]] BinIndex getElementCount() const noexcept { return elementCount_; }
    [[nodiscard]] Detection makeDetection(DetectionCell cell) const { return Detection(*this, cell); }
private:
    CPI_Metadata metadata_;
    RangeAxis rangeAxis_;
    DopplerAxis dopplerAxis_;
    BinIndex rangeBinCount_;
    BinIndex elementCount_;
};

inline Detection::Detection(const DetectionContext& context, DetectionCell cell)
    : cell_(cell), rangeMeters_(context.getRangeAxis().getMeters(cell.getRangeBin())),
      dopplerHz_(context.getDopplerAxis().getHertz(cell.getDopplerBin())),
      radialVelocityMps_(context.getMetadata().getRadialVelocityMps(dopplerHz_)) {
    detail::requireIndex(cell_.getRangeBin(), context.getRangeBinCount(), "range bin");
    detail::requireIndex(cell_.getDopplerBin(), context.getDopplerAxis().getFftSize(), "Doppler bin");
    detail::requireNonnegative(rangeMeters_, "detection range");
    detail::requireFinite(dopplerHz_, "detection Doppler");
    detail::requireFinite(radialVelocityMps_, "detection radial velocity");
}

class AngleEstimate final {
public:
    AngleEstimate(double azimuthRadians = 0.0, double elevationRadians = 0.0)
        : azimuthRadians_(azimuthRadians), elevationRadians_(elevationRadians) {
        setAzimuthRadians(azimuthRadians);
        setElevationRadians(elevationRadians);
    }
    [[nodiscard]] double getAzimuthRadians() const noexcept { return azimuthRadians_; }
    [[nodiscard]] double getElevationRadians() const noexcept { return elevationRadians_; }
    void setAzimuthRadians(double value) {
        detail::requireFinite(value, "azimuthRadians");
        if (value < -pi || value > pi) throw std::invalid_argument("azimuth must be in [-pi, pi]");
        azimuthRadians_ = value;
    }
    void setElevationRadians(double value) {
        detail::requireFinite(value, "elevationRadians");
        if (value < -pi / 2.0 || value > pi / 2.0)
            throw std::invalid_argument("elevation must be in [-pi/2, pi/2]");
        elevationRadians_ = value;
    }
    [[nodiscard]] static AngleEstimate fromDegrees(double azimuth, double elevation) {
        return {azimuth * (pi / 180.0), elevation * (pi / 180.0)};
    }
private:
    double azimuthRadians_;
    double elevationRadians_;
};

class AzElDetection final {
public:
    AzElDetection(Detection detection, AngleEstimate angles) noexcept
        : detection_(detection), angles_(angles) {}
    [[nodiscard]] const Detection& getDetection() const noexcept { return detection_; }
    [[nodiscard]] const AngleEstimate& getAngles() const noexcept { return angles_; }
    // Sensor-local right-handed frame: +x boresight, +y positive azimuth, +z up.
    [[nodiscard]] std::array<double, 3> getPositionMeters() const noexcept {
        const double r = detection_.getRangeMeters();
        const double horizontal = r * std::cos(angles_.getElevationRadians());
        return {horizontal * std::cos(angles_.getAzimuthRadians()),
                horizontal * std::sin(angles_.getAzimuthRadians()),
                r * std::sin(angles_.getElevationRadians())};
    }
private:
    Detection detection_;
    AngleEstimate angles_;
};
} // namespace radar
