#pragma once

#include <radar/types.hpp>
#include <cmath>
#include <cstddef>
#include <initializer_list>
#include <limits>
#include <stdexcept>
#include <string>

namespace radar::detail {
// Boundary-only utilities: constructors and setters, never hot-path accessors.
inline void requireFinite(double value, const char* name) {
    if (!std::isfinite(value))
        throw std::invalid_argument(std::string(name) + " must be finite");
}
inline void requirePositive(double value, const char* name) {
    if (!std::isfinite(value) || value <= 0.0)
        throw std::invalid_argument(std::string(name) + " must be finite and positive");
}
inline void requireNonnegative(double value, const char* name) {
    if (!std::isfinite(value) || value < 0.0)
        throw std::invalid_argument(std::string(name) + " must be finite and nonnegative");
}
inline void requireIndex(BinIndex index, BinIndex size, const char* name) {
    if (index < 0 || index >= size)
        throw std::out_of_range(std::string(name) + " is out of range");
}
inline void requireOrder(DopplerOrder order) {
    if (order != DopplerOrder::Unshifted && order != DopplerOrder::Centered)
        throw std::invalid_argument("invalid Doppler order");
}
inline void requireSign(PositiveDoppler sign) {
    if (sign != PositiveDoppler::Approaching && sign != PositiveDoppler::Receding)
        throw std::invalid_argument("invalid Doppler sign convention");
}
inline std::size_t checkedProduct(BinIndex a, BinIndex b, BinIndex c = 1) {
    std::size_t result = 1;
    for (const auto value : {a, b, c}) {
        if (value <= 0) throw std::invalid_argument("dimensions must be positive");
        const auto u = static_cast<std::uint64_t>(value);
        if (u > std::numeric_limits<std::size_t>::max() / result)
            throw std::overflow_error("dimension product exceeds size_t");
        result *= static_cast<std::size_t>(u);
    }
    if (result > static_cast<std::uint64_t>(std::numeric_limits<BinIndex>::max()))
        throw std::overflow_error("dimension product exceeds signed index range");
    return result;
}
} // namespace radar::detail
