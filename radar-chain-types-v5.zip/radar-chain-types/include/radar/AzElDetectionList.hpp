#pragma once

#include <radar/DetectionList.hpp>

namespace radar {

// Device detections plus aligned f32 [detection,1,1,1] angle columns in radians.
// Structural checks only at constructor/setter boundaries; no device-value scan.
// Producer preconditions: finite azimuth in [-pi,pi], elevation in [-pi/2,pi/2].
class AzElDetectionList final {
public:
    AzElDetectionList(DetectionList detections, af::array azimuthRadians,
                      af::array elevationRadians);

    [[nodiscard]] std::size_t getDetectionCount() const noexcept { return detections_.getDetectionCount(); }
    [[nodiscard]] bool getIsEmpty() const noexcept { return detections_.getIsEmpty(); }
    [[nodiscard]] BinIndex getElementCount() const noexcept { return detections_.getElementCount(); }
    [[nodiscard]] const DetectionList& getDetections() const noexcept { return detections_; }
    [[nodiscard]] const DetectionContext& getContext() const noexcept { return detections_.getContext(); }
    [[nodiscard]] const af::array& getAzimuthRadians() const noexcept { return azimuthRadians_; }
    [[nodiscard]] const af::array& getElevationRadians() const noexcept { return elevationRadians_; }
    [[nodiscard]] const af::array& getElementSnapshots() const noexcept {
        return detections_.getElementSnapshots();
    }
    // One-entry device list, no scalar readback.
    [[nodiscard]] AzElDetectionList getDetection(std::size_t detectionIndex) const;
    // f32 [3,detection,1,1], rows x/y/z in a sensor-local right-handed frame.
    [[nodiscard]] af::array getPositionsMeters() const;
    [[nodiscard]] af::array getPositionMeters(std::size_t detectionIndex) const;

    void setAngles(af::array azimuthRadians, af::array elevationRadians);
    [[nodiscard]] AzElDetectionList select(const af::array& detectionIndices) const;
    [[nodiscard]] AzElDetectionList clone() const;
    // Explicit final CPU export; retains the existing lightweight CPU value classes.
    [[nodiscard]] std::vector<AzElDetection> recordsToHost() const;
    void evaluate() const;
    void synchronize() const;

private:
    enum class TrustedAlignment { Yes };
    AzElDetectionList(DetectionList detections, af::array azimuthRadians,
                      af::array elevationRadians, TrustedAlignment);
    DetectionList detections_;
    af::array azimuthRadians_;
    af::array elevationRadians_;
};
} // namespace radar
