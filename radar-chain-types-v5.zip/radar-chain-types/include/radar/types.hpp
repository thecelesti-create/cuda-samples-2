#pragma once

#include <radar/config.hpp>
#include <cstdint>

namespace radar {
using BinIndex = std::int64_t;
inline constexpr double speedOfLightMps = 299792458.0;
inline constexpr double pi = 3.141592653589793238462643383279502884;

enum class DopplerOrder { Unshifted, Centered };
// Configure this to match your receiver's I/Q convention.
enum class PositiveDoppler { Approaching, Receding };
} // namespace radar
