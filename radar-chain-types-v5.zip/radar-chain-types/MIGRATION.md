# Migration from v0.4 to v0.5

## C++20 / ArrayFire 3.10

CMake minimum is 3.20; all targets require C++20 (also propagated to consumers).
ArrayFire discovery requests the 3.10 CONFIG package. Public headers reject
older C++ language modes and ArrayFire SDKs below 3.10 (or non-3 major versions).
Use a clean build directory rather than cached 3.9 paths. The supplied code does
not require compiling ArrayFire itself with C++20, but the installed library
must be compatible with your application compiler/toolchain and runtime.

`SamplePulseBuffer::fromHost()` and its upload constructor now accept
`std::span<const af::cfloat>` instead of requiring `std::vector`. Existing vector
calls still work; so do std::array and explicit spans over acquisition buffers.
The upload does not retain the span or host pointer after construction returns.

## Detection payloads are now device arrays

The five class/file names, element terminology, `CPI_Metadata` spelling, named
dimensions, private members, and get/set naming are unchanged.

`DetectionList` no longer stores `std::vector<Detection>`, and `AzElDetectionList`
no longer stores `std::vector<AngleEstimate>`. CPU scalar classes remain available
for explicitly downloaded records and serialization.

| Old use | Replacement |
|---|---|
| `DetectionList::fromMap(map, cpuCells)` | `fromMap(map, deviceCellIndices, devicePowers, deviceNoisePowers)` |
| CPU cell constructor plus snapshots | Constructor accepting device u32 range/Doppler bins, f32 powers/noise, and c32 snapshots |
| `getRecords()` | `recordsToHost()` for explicit CPU export; device column getters for processing |
| `getDetection(i)` returning a CPU record | Now returns a ONE-ENTRY device list of the same stage type |
| `select(cpuIndexVector)` | `select(deviceU32IndexColumn)` |
| `AzElDetectionList(list, cpuAngles)` | `AzElDetectionList(list, deviceAzimuthRadians, deviceElevationRadians)` |
| `getAngles()` on the angle list | `getAzimuthRadians()` / `getElevationRadians()` device columns |
| `setAngles(cpuAngles)` | `setAngles(deviceAzimuthRadians, deviceElevationRadians)` |
| `getPositionsMeters()` returning a CPU vector | f32 device `[3,detection]` matrix |
| CPU position of one detection | `located.recordsToHost()[i].getPositionMeters()` at an explicit export boundary |

Powers/noise/angles are **f32**; bins/selection indices are **u32**; element IQ
is **c32**. All scalar arrays are column vectors, not row vectors. Snapshots remain
`[element,detection]`. Empty results use empty arrays (dtype/shape unspecified).

`getDetection()` no longer has `noexcept`: ArrayFire slicing can allocate or
throw. It remains unchecked at the wrapper level and does not download a record.
Scalar count getters remain cached, inline, and `noexcept`.

## Validation policy for GPU inputs

This revision intentionally checks only host-visible structure at constructor
and setter boundaries. It does not read GPU bins/powers/angles back to validate
each value. Your producer supplies valid bins, finite nonnegative power, finite
positive noise power, and valid finite angles. Invalid device values are
precondition violations. Structural checks still reject dtype, shape, length,
and backend/device mismatches. CPU value classes still validate scalar values.

Explicit CPU record export invokes those scalar constructors; it can reject
invalid values that deliberately were not scanned on the GPU fast path.

## Examples

`examples/simple_demo.cpp` is the requested three-fake-algorithm demonstration.
It is NOT a radar implementation. It uploads once, runs a gain/reorder/fixed-cell
selection, and explicitly downloads final records for printing.

`examples/pipeline.cpp` retains the separate reference filtering/FFT/threshold
example, updated to device-resident detection/angle arrays. It no longer downloads
detection indices/powers between stages. ArrayFire's dynamic `where()` can still
read a count/synchronize internally; residency is not a no-synchronization promise.

## Build/run

See README for Windows/CUDA commands and CMake integration. The simple unified
backend demo defaults to `cuda`; pass `cpu` explicitly for a CPU-only machine.
Direct-backend builds take no runtime backend argument. Integration tests accept
`RADAR_TEST_BACKEND=cuda` in a unified CMake build. GPU execution is not validated
in the generation environment; `VALIDATION.md` reports actual coverage.
