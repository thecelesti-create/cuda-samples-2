# Validation report — v0.5

## What was actually executed

The delivered metadata source was compiled/executed as **C++20**, not C++17.
All **143 metadata checks passed** in each configuration:

- GCC 14.2.0, `-std=c++20 -O2 -Wall -Wextra -Wpedantic -Werror`.
- Clang 17.0.0, same C++20/warning/optimization settings.
- GCC, `-std=c++20 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer`.

No sanitizer errors were reported. The metadata-only CMake Release build and
CTest also passed. The public language guard was independently tested: a C++17
translation unit including `CPI_Metadata.hpp` fails with the intended diagnostic.
These are real compiled/executed tests against the repository's metadata code.

Logs are in `validation/metadata-*.txt`, `cmake-metadata.txt`,
`ctest-metadata.txt`, and `cxx20-guard.txt`. They were regenerated for v0.5.

## Source and declaration consistency checks

Clang C++20 AST inspection identified **13 repository-defined classes and 66
fields, all private**, without virtual methods. The five matching HPP/CPP pairs,
semantic dimensions, element terminology, and get/set naming are retained.
`DetectionList` and `AzElDetectionList` have no vector fields. Their constructors
and device getters contain no `.host()` or `.scalar<T>()` numerical readbacks.

Both GCC and Clang accepted all five implementation files, both examples, and
the integration-test source with `-fsyntax-only -Werror` using an **isolated
declaration-only ArrayFire syntax aid**. This checks internal C++20 syntax,
renamed members, access control, span usage, and declaration/call consistency.
It is not linked or executed and is not included in this repository. It does
not replace the real ArrayFire headers or participate in the CMake build.

**This is NOT a compile against the actual ArrayFire SDK.** It cannot certify
actual overload resolution, ABI, backend behavior, runtime results, or speed.
See `validation/source-audit.txt` and `syntax-declarations.txt`.

## ArrayFire 3.10 source review

The version requirement, CMake imported target names, and interfaces used by
array storage, constants, indexing/lookup, reorder/moddims, arithmetic, and
angle-coordinate operations were reviewed against the official 3.10 source/API.
In particular, the bin decode uses same-type u32 array operands for division
rather than converting indices through f32. ArrayFire 3.10 dispatches this integer
arithmetic as integer arithmetic. Relevant reference locations are listed in
`API_REFERENCES.md`.

The 3.10 CUDA `where()` implementation obtains the compacted count on the host
before allocation; the README explicitly distinguishes device-resident results
from a promise of no internal synchronization. No such promise is made.

## Real SDK build attempt and limitation

An actual default CMake configure was attempted. It fails because this environment
has no `ArrayFireConfig.cmake` / installed ArrayFire SDK. Its exact output is
retained in `validation/arrayfire-configure.txt`. Attempts to obtain a local SDK
source/header bundle also did not succeed; online source review is not a locally
compiled SDK.

Therefore **no real ArrayFire 3.10 build/link or CPU/CUDA/OpenCL run was completed
here**. The simple demo's shown output is expected from its arithmetic, not
captured execution. Windows/MSVC builds, NVIDIA laptop execution, GPU memory
consumption, and performance remain unverified. The version guards and CMake
requirements establish a build contract, not proof of deployment compatibility.

## Integration tests included for an installed SDK

The ArrayFire test source now covers device column dtypes/counts, integer bin
decoding, snapshot gather including sliced source maps and singleton elements,
explicit CPU exports, device coordinate arrays, ordered/duplicate device
selection, deep clones, empty lists, aligned angles/XYZ, f32 angular endpoints,
structural rejection with unchanged setter state, odd/even Doppler order, and
integer bin storage above f32's exact-integer range. Previous raw cube, slice,
matched-filter adoption, reorder, FFT, and setter tests remain.

These integration tests are supplied, not reported as executed. Invalid GPU
*values* are producer precondition violations and deliberately are not scanned
by constructors; tests do not expect invalid indices to be caught by getters.

For your Windows CUDA installation, from the extracted repository:

```powershell
cmake -S . -B build -A x64 -DCMAKE_PREFIX_PATH="$env:AF_PATH" -DRADAR_TEST_BACKEND=cuda
cmake --build build --config Release --parallel
ctest --test-dir build -C Release --output-on-failure
.\build\Release\radar_simple_demo.exe cuda
```

Use the actual ArrayFire prefix/config path. See README for direct backend,
Linux, CPU-only test, and metadata-only build options.
