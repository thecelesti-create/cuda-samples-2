#pragma once

#include <radar/detail/ArrayFire.hpp>
#include <radar/metadata.hpp>
#include <climits>
#include <utility>

namespace radar::detail {
// These validation functions are used at construction/replacement boundaries.
inline void requireActiveContext(const af::array& array) {
    if (af::getBackendId(array) != af::getActiveBackend() ||
        af::getDeviceId(array) != af::getDevice())
        throw std::invalid_argument("array must belong to the active ArrayFire backend/device");
}
inline void requireSameContext(const af::array& a, const af::array& b) {
    if (af::getBackendId(a) != af::getBackendId(b) || af::getDeviceId(a) != af::getDeviceId(b))
        throw std::invalid_argument("stage input and output must use the same backend/device");
}
inline void validateElementCount(const CPI_Metadata& metadata, dim_t elementCount) {
    if (elementCount <= 0) throw std::invalid_argument("element count must be positive");
    if (!metadata.getElementNames().empty() &&
        metadata.getElementNames().size() != static_cast<std::size_t>(elementCount))
        throw std::invalid_argument("elementNames must match the cube element count");
}
inline std::size_t validateDimensions(dim_t leadingAxisExtent, dim_t middleAxisExtent, dim_t trailingAxisExtent) {
    const auto valueCount = checkedProduct(leadingAxisExtent, middleAxisExtent, trailingAxisExtent);
    constexpr BinIndex exactSequenceLimit = BinIndex{1} << 53;
    if (leadingAxisExtent > exactSequenceLimit || middleAxisExtent > exactSequenceLimit || trailingAxisExtent > exactSequenceLimit)
        throw std::overflow_error("axis exceeds exact ArrayFire sequence range");
    if (valueCount > std::numeric_limits<std::size_t>::max() / sizeof(af::cfloat))
        throw std::overflow_error("IQ byte count exceeds size_t");
    return valueCount;
}
inline void validateCube(const af::array& data, const CPI_Metadata& metadata) {
    requireActiveContext(data);
    if (data.isempty() || data.issparse() || data.type() != c32 || data.dims(3) != 1)
        throw std::invalid_argument("IQ must be a nonempty dense c32 cube with dim3 == 1");
    validateDimensions(data.dims(0), data.dims(1), data.dims(2));
    validateElementCount(metadata, data.dims(2));
}
inline void validatePulseTimes(const CPI_Metadata& metadata, dim_t pulseCount) {
    requireFinite(metadata.getFirstPulseTimeSeconds() + static_cast<double>(pulseCount - 1) *
                  metadata.getPulsePeriodSeconds(), "last pulse time");
}
inline void validateSampleTimes(const CPI_Metadata& metadata, dim_t sampleCount, dim_t pulseCount) {
    validatePulseTimes(metadata, pulseCount);
    requireFinite(metadata.getFirstSampleDelaySeconds() + static_cast<double>(sampleCount - 1) *
                  metadata.getSamplePeriodSeconds(), "last sample delay");
}
inline void requireShape(const af::array& data, const af::dim4& shape) {
    for (unsigned d = 0; d < 4; ++d)
        if (data.dims(d) != shape[d]) throw std::invalid_argument("replacement shape mismatch");
}
inline dim_t checkedDim(std::size_t value) {
    if (value > static_cast<std::uint64_t>(std::numeric_limits<dim_t>::max()))
        throw std::overflow_error("length exceeds dim_t");
    return static_cast<dim_t>(value);
}
inline void validateDetectionCount(std::size_t count) {
    // Each selectable list index must fit the u32 lookup representation.
    if (count != 0 && count - 1 > std::numeric_limits<unsigned>::max())
        throw std::overflow_error("list indices exceed u32 lookup range");
    (void)checkedDim(count);
}
inline void validateSnapshots(const af::array& data, BinIndex elementCount, std::size_t count) {
    validateDetectionCount(count);
    if (count == 0) {
        if (!data.isempty()) throw std::invalid_argument("empty detections require empty snapshots");
        return;
    }
    requireActiveContext(data);
    if (data.isempty() || data.issparse() || data.type() != c32)
        throw std::invalid_argument("element snapshots must be nonempty dense c32");
    const auto n = checkedDim(count);
    validateDimensions(elementCount, n, 1);
    requireShape(data, af::dim4(elementCount, n));
}

// Host metadata inspection only. These functions NEVER reduce or download values.
inline void validateColumn(const af::array& column, af::dtype type,
                           std::size_t count, const char* name) {
    validateDetectionCount(count);
    if (count == 0) {
        if (!column.isempty()) throw std::invalid_argument(std::string(name) + " must be empty");
        return; // Empty handles need not have a meaningful dtype/device.
    }
    requireActiveContext(column);
    if (column.issparse() || column.type() != type)
        throw std::invalid_argument(std::string(name) + " has the wrong storage/type");
    requireShape(column, af::dim4(checkedDim(count)));
}
inline void validateDetectionGrid(const DetectionContext& context) {
    const auto limit = static_cast<BinIndex>(std::numeric_limits<unsigned>::max());
    if (context.getRangeBinCount() > limit || context.getDopplerAxis().getFftSize() > limit)
        throw std::overflow_error("detection bin extents exceed u32 representation");
}
inline void validateLinearCellGrid(const DetectionContext& context) {
    validateDetectionGrid(context);
    const auto cellCount = checkedProduct(context.getRangeBinCount(),
                                          context.getDopplerAxis().getFftSize(), 1);
    if (cellCount - 1 > std::numeric_limits<unsigned>::max())
        throw std::overflow_error("linear cell indices exceed u32; use pre-gathered constructor");
}

// Unchecked execution helpers. Preconditions: valid indices/nonempty slices,
// representable sizes, and the owning backend/device is active. ArrayFire's own
// API checks still apply; this wrapper adds no per-access checks.
inline af::seq sequence(BinIndex first, BinIndex count) {
    return af::seq(static_cast<double>(first), static_cast<double>(first + count - 1));
}
inline af::array computePower(const af::array& data) { return af::real(data * af::conjg(data)); }
inline void synchronize(const af::array& data) {
    data.eval();
    af::sync(); // Caller keeps the owning device active.
}
inline std::vector<af::cfloat> toHost(const af::array& data) {
    std::vector<af::cfloat> result(static_cast<std::size_t>(data.elements()));
    if (!result.empty()) data.host(result.data());
    return result;
}
} // namespace radar::detail
