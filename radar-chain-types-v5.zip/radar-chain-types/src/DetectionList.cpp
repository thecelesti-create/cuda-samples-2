#include <radar/DetectionList.hpp>
#include "array_helpers.hpp"

namespace radar {
DetectionList::DetectionList(DetectionContext context) : context_(std::move(context)) {
    static_assert(sizeof(unsigned) == 4, "ArrayFire u32 host storage requires 32-bit unsigned");
    detail::validateDetectionGrid(context_);
}

DetectionList::DetectionList(DetectionContext context, af::array rangeBins,
                             af::array dopplerBins, af::array powers, af::array noisePowers,
                             af::array elementSnapshots)
    : context_(std::move(context)),
      detectionCount_(static_cast<std::size_t>(rangeBins.elements())),
      rangeBins_(std::move(rangeBins)), dopplerBins_(std::move(dopplerBins)),
      powers_(std::move(powers)), noisePowers_(std::move(noisePowers)),
      snapshots_(std::move(elementSnapshots)) {
    detail::validateDetectionGrid(context_);
    detail::validateColumn(rangeBins_, u32, detectionCount_, "range bins");
    detail::validateColumn(dopplerBins_, u32, detectionCount_, "Doppler bins");
    detail::validateColumn(powers_, f32, detectionCount_, "powers");
    detail::validateColumn(noisePowers_, f32, detectionCount_, "noise powers");
    detail::validateSnapshots(snapshots_, getElementCount(), detectionCount_);
    if (!getIsEmpty()) {
        detail::requireSameContext(rangeBins_, dopplerBins_);
        detail::requireSameContext(rangeBins_, powers_);
        detail::requireSameContext(rangeBins_, noisePowers_);
        detail::requireSameContext(rangeBins_, snapshots_);
    }
}
DetectionList::DetectionList(const RangeDopplerMap& source, af::array rangeBins,
                             af::array dopplerBins, af::array powers, af::array noisePowers,
                             af::array elementSnapshots)
    : DetectionList(source.getDetectionContext(), std::move(rangeBins), std::move(dopplerBins),
                    std::move(powers), std::move(noisePowers), std::move(elementSnapshots)) {
    if (!getIsEmpty()) detail::requireSameContext(source.getData(), rangeBins_);
}
DetectionList::DetectionList(const RangeDopplerMap& source, af::array linearCellIndices,
                             af::array powers, af::array noisePowers)
    : context_(source.getDetectionContext()),
      detectionCount_(static_cast<std::size_t>(linearCellIndices.elements())),
      powers_(std::move(powers)), noisePowers_(std::move(noisePowers)) {
    detail::requireActiveContext(source.getData());
    detail::validateLinearCellGrid(context_);
    detail::validateColumn(linearCellIndices, u32, detectionCount_, "linear cell indices");
    detail::validateColumn(powers_, f32, detectionCount_, "powers");
    detail::validateColumn(noisePowers_, f32, detectionCount_, "noise powers");
    if (getIsEmpty()) return;
    detail::validateDimensions(getElementCount(), detail::checkedDim(detectionCount_), 1);
    detail::requireSameContext(source.getData(), linearCellIndices);
    detail::requireSameContext(source.getData(), powers_);
    detail::requireSameContext(source.getData(), noisePowers_);

    // Both operands are u32: integer quotient/remainder, no float index rounding.
    const auto dopplerBinCount = static_cast<unsigned>(source.getDopplerBinCount());
    const af::array divisors = af::constant(dopplerBinCount, linearCellIndices.dims(), u32);
    rangeBins_ = linearCellIndices / divisors;
    dopplerBins_ = linearCellIndices - rangeBins_ * divisors;

    // View [D,R,E] as [D*R,E], gather K rows -> [K,E], reorder -> [E,K].
    // Indices address one range-Doppler plane, not the entire E-plane cube.
    const dim_t cellCount = source.getDopplerBinCount() * source.getRangeBinCount();
    const af::array cellByElement = af::moddims(source.getData(), cellCount, getElementCount());
    snapshots_ = af::reorder(af::lookup(cellByElement, linearCellIndices, 0), 1, 0, 2, 3);
}
DetectionList::DetectionList(DetectionContext context, std::size_t detectionCount,
                             af::array rangeBins, af::array dopplerBins, af::array powers,
                             af::array noisePowers, af::array snapshots, TrustedColumns)
    : context_(std::move(context)), detectionCount_(detectionCount),
      rangeBins_(std::move(rangeBins)), dopplerBins_(std::move(dopplerBins)),
      powers_(std::move(powers)), noisePowers_(std::move(noisePowers)), snapshots_(std::move(snapshots)) {}

DetectionList DetectionList::fromMap(const RangeDopplerMap& source, af::array linearCellIndices,
                                     af::array powers, af::array noisePowers) {
    return {source, std::move(linearCellIndices), std::move(powers), std::move(noisePowers)};
}
af::array DetectionList::getElementSnapshot(std::size_t detectionIndex) const {
    return snapshots_(af::span, detail::sequence(static_cast<BinIndex>(detectionIndex), 1));
}
DetectionList DetectionList::getDetection(std::size_t detectionIndex) const {
    const auto one = detail::sequence(static_cast<BinIndex>(detectionIndex), 1);
    return {context_, 1, rangeBins_(one), dopplerBins_(one), powers_(one), noisePowers_(one),
            snapshots_(af::span, one), TrustedColumns::Yes};
}
af::array DetectionList::getRangesMeters() const {
    if (getIsEmpty()) return af::array{};
    const auto& axis = context_.getRangeAxis();
    return rangeBins_.as(f32) * static_cast<float>(axis.getBinSpacingMeters()) +
           static_cast<float>(axis.getFirstBinMeters());
}
af::array DetectionList::getDopplerHz() const {
    if (getIsEmpty()) return af::array{};
    const auto& axis = context_.getDopplerAxis();
    // Shift as signed integers before converting to f32, avoiding unsigned wrap.
    const af::array bins = dopplerBins_.as(s64);
    af::array signedBins;
    if (axis.getOrder() == DopplerOrder::Centered) {
        signedBins = bins - static_cast<long long>(axis.getFftSize() / 2);
    } else {
        signedBins = af::select(bins <= static_cast<long long>((axis.getFftSize() - 1) / 2),
                                bins, bins - static_cast<long long>(axis.getFftSize()));
    }
    return signedBins.as(f32) * static_cast<float>(axis.getBinSpacingHz());
}
af::array DetectionList::getRadialVelocitiesMps() const {
    if (getIsEmpty()) return af::array{};
    return getDopplerHz() * static_cast<float>(context_.getMetadata().getRadialVelocityMps(1.0));
}
af::array DetectionList::getSnrDb() const {
    if (getIsEmpty()) return af::array{};
    return 10.0f * (af::log10(powers_) - af::log10(noisePowers_));
}
void DetectionList::setPowers(af::array powers, af::array noisePowers) {
    detail::validateColumn(powers, f32, detectionCount_, "powers");
    detail::validateColumn(noisePowers, f32, detectionCount_, "noise powers");
    if (!getIsEmpty()) {
        detail::requireSameContext(rangeBins_, powers);
        detail::requireSameContext(rangeBins_, noisePowers);
    }
    powers_ = std::move(powers);
    noisePowers_ = std::move(noisePowers);
}
void DetectionList::setElementSnapshots(af::array snapshots) {
    detail::validateSnapshots(snapshots, getElementCount(), detectionCount_);
    if (!getIsEmpty()) detail::requireSameContext(rangeBins_, snapshots);
    snapshots_ = std::move(snapshots);
}
DetectionList DetectionList::select(const af::array& detectionIndices) const {
    const auto count = static_cast<std::size_t>(detectionIndices.elements());
    if (count == 0) return {context_, 0, {}, {}, {}, {}, {}, TrustedColumns::Yes};
    return {context_, count, af::lookup(rangeBins_, detectionIndices, 0),
            af::lookup(dopplerBins_, detectionIndices, 0), af::lookup(powers_, detectionIndices, 0),
            af::lookup(noisePowers_, detectionIndices, 0), af::lookup(snapshots_, detectionIndices, 1),
            TrustedColumns::Yes};
}
DetectionList DetectionList::clone() const {
    if (getIsEmpty()) return *this;
    return {context_, detectionCount_, rangeBins_.copy(), dopplerBins_.copy(), powers_.copy(),
            noisePowers_.copy(), snapshots_.copy(), TrustedColumns::Yes};
}
std::vector<Detection> DetectionList::recordsToHost() const {
    if (getIsEmpty()) return {};
    std::vector<unsigned> rangeBins(detectionCount_), dopplerBins(detectionCount_);
    std::vector<float> powers(detectionCount_), noisePowers(detectionCount_);
    rangeBins_.host(rangeBins.data());
    dopplerBins_.host(dopplerBins.data());
    powers_.host(powers.data());
    noisePowers_.host(noisePowers.data());
    std::vector<Detection> records;
    records.reserve(detectionCount_);
    for (std::size_t i = 0; i < detectionCount_; ++i)
        records.emplace_back(context_, DetectionCell(rangeBins[i], dopplerBins[i], powers[i], noisePowers[i]));
    return records;
}
std::vector<af::cfloat> DetectionList::snapshotsToHost() const {
    return getIsEmpty() ? std::vector<af::cfloat>{} : detail::toHost(snapshots_);
}
void DetectionList::evaluate() const {
    if (getIsEmpty()) return;
    rangeBins_.eval(); dopplerBins_.eval(); powers_.eval(); noisePowers_.eval(); snapshots_.eval();
}
void DetectionList::synchronize() const {
    evaluate();
    af::sync(); // Always fence, including an empty result after queued work.
}
} // namespace radar
