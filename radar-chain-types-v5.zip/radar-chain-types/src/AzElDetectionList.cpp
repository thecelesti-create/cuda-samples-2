#include <radar/AzElDetectionList.hpp>
#include "array_helpers.hpp"

namespace radar {
AzElDetectionList::AzElDetectionList(DetectionList detections, af::array azimuthRadians,
                                     af::array elevationRadians)
    : detections_(std::move(detections)), azimuthRadians_(std::move(azimuthRadians)),
      elevationRadians_(std::move(elevationRadians)) {
    detail::validateColumn(azimuthRadians_, f32, getDetectionCount(), "azimuth radians");
    detail::validateColumn(elevationRadians_, f32, getDetectionCount(), "elevation radians");
    if (!getIsEmpty()) {
        detail::requireSameContext(detections_.getRangeBins(), azimuthRadians_);
        detail::requireSameContext(detections_.getRangeBins(), elevationRadians_);
    }
}
AzElDetectionList::AzElDetectionList(DetectionList detections, af::array azimuthRadians,
                                     af::array elevationRadians, TrustedAlignment)
    : detections_(std::move(detections)), azimuthRadians_(std::move(azimuthRadians)),
      elevationRadians_(std::move(elevationRadians)) {}
AzElDetectionList AzElDetectionList::getDetection(std::size_t detectionIndex) const {
    const auto one = detail::sequence(static_cast<BinIndex>(detectionIndex), 1);
    return {detections_.getDetection(detectionIndex), azimuthRadians_(one), elevationRadians_(one),
            TrustedAlignment::Yes};
}
af::array AzElDetectionList::getPositionsMeters() const {
    if (getIsEmpty()) return af::array{};
    const af::array ranges = detections_.getRangesMeters();
    const af::array horizontal = ranges * af::cos(elevationRadians_);
    const af::array xyz = af::join(1, horizontal * af::cos(azimuthRadians_),
                                 horizontal * af::sin(azimuthRadians_), ranges * af::sin(elevationRadians_));
    return af::reorder(xyz, 1, 0, 2, 3);
}
af::array AzElDetectionList::getPositionMeters(std::size_t detectionIndex) const {
    return getDetection(detectionIndex).getPositionsMeters();
}
void AzElDetectionList::setAngles(af::array azimuthRadians, af::array elevationRadians) {
    detail::validateColumn(azimuthRadians, f32, getDetectionCount(), "azimuth radians");
    detail::validateColumn(elevationRadians, f32, getDetectionCount(), "elevation radians");
    if (!getIsEmpty()) {
        detail::requireSameContext(detections_.getRangeBins(), azimuthRadians);
        detail::requireSameContext(detections_.getRangeBins(), elevationRadians);
    }
    azimuthRadians_ = std::move(azimuthRadians);
    elevationRadians_ = std::move(elevationRadians);
}
AzElDetectionList AzElDetectionList::select(const af::array& detectionIndices) const {
    auto selected = detections_.select(detectionIndices);
    if (selected.getIsEmpty()) return {std::move(selected), {}, {}, TrustedAlignment::Yes};
    return {std::move(selected), af::lookup(azimuthRadians_, detectionIndices, 0),
            af::lookup(elevationRadians_, detectionIndices, 0), TrustedAlignment::Yes};
}
AzElDetectionList AzElDetectionList::clone() const {
    if (getIsEmpty()) return *this;
    return {detections_.clone(), azimuthRadians_.copy(), elevationRadians_.copy(), TrustedAlignment::Yes};
}
std::vector<AzElDetection> AzElDetectionList::recordsToHost() const {
    if (getIsEmpty()) return {};
    const auto detections = detections_.recordsToHost();
    std::vector<float> azimuth(getDetectionCount()), elevation(getDetectionCount());
    azimuthRadians_.host(azimuth.data());
    elevationRadians_.host(elevation.data());
    std::vector<AzElDetection> records;
    records.reserve(getDetectionCount());
    for (std::size_t i = 0; i < getDetectionCount(); ++i) {
        // Inclusive f32 endpoints can round very slightly beyond double pi.
        // Map ONLY representable endpoint values to the exact double endpoints;
        // genuinely out-of-contract device values remain invalid.
        const auto endpoint = [](float value, double bound) {
            const auto bound32 = static_cast<float>(bound);
            return value == bound32 ? bound : value == -bound32 ? -bound : static_cast<double>(value);
        };
        records.emplace_back(detections[i], AngleEstimate(endpoint(azimuth[i], pi), endpoint(elevation[i], pi / 2.0)));
    }
    return records;
}
void AzElDetectionList::evaluate() const {
    detections_.evaluate();
    if (!getIsEmpty()) { azimuthRadians_.eval(); elevationRadians_.eval(); }
}
void AzElDetectionList::synchronize() const { evaluate(); af::sync(); }
} // namespace radar
