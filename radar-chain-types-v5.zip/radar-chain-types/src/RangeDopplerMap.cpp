#include <radar/RangeDopplerMap.hpp>
#include "array_helpers.hpp"

namespace radar {
RangeDopplerMap::RangeDopplerMap(af::array iq, CPI_Metadata metadata,
                               RangeAxis rangeAxis, DopplerAxis dopplerAxis)
    : iq_(std::move(iq)), metadata_(std::move(metadata)), rangeAxis_(rangeAxis),
      dopplerAxis_(dopplerAxis), dopplerBinCount_(iq_.dims(0)), rangeBinCount_(iq_.dims(1)), elementCount_(iq_.dims(2)) {
    detail::validateCube(iq_, metadata_);
    if (dopplerAxis_.getFftSize() != getDopplerBinCount())
        throw std::invalid_argument("Doppler FFT size must match the Doppler bin count");
    if (dopplerAxis_.getPrfHz() != metadata_.getPrfHz())
        throw std::invalid_argument("CPI and Doppler PRFs disagree");
    if (getDopplerBinCount() / 2 > INT_MAX)
        throw std::overflow_error("Doppler axis exceeds ArrayFire shift range");
    detail::requireFinite(rangeAxis_.getMeters(getRangeBinCount() - 1), "last range bin");
    detail::validatePulseTimes(metadata_, dopplerAxis_.getPulsesUsed());
}
RangeDopplerMap::RangeDopplerMap(const RangePulseBuffer& source, af::array iq, DopplerOrder order)
    : iq_(std::move(iq)), metadata_(source.getMetadata()), rangeAxis_(source.getRangeAxis()),
      dopplerAxis_(iq_.dims(0), source.getPulseCount(), metadata_.getPrfHz(), order),
      dopplerBinCount_(iq_.dims(0)), rangeBinCount_(iq_.dims(1)), elementCount_(iq_.dims(2)) {
    detail::validateCube(iq_, metadata_);
    detail::requireSameContext(source.getData(), iq_);
    if (getRangeBinCount() != source.getRangeBinCount() || getElementCount() != source.getElementCount())
        throw std::invalid_argument("Doppler result must preserve range/element counts");
    if (getDopplerBinCount() / 2 > INT_MAX)
        throw std::overflow_error("Doppler axis exceeds ArrayFire shift range");
}
DetectionContext RangeDopplerMap::getDetectionContext() const {
    return {metadata_, rangeAxis_, dopplerAxis_, getRangeBinCount(), getElementCount()};
}
af::array RangeDopplerMap::getElement(dim_t elementIndex) const {
    return iq_(af::span, af::span, detail::sequence(elementIndex, 1));
}
af::array RangeDopplerMap::getDopplerSpectrum(dim_t rangeBin, dim_t elementIndex) const {
    return iq_(af::span, detail::sequence(rangeBin, 1), detail::sequence(elementIndex, 1));
}
af::array RangeDopplerMap::getRangeProfile(dim_t dopplerBin, dim_t elementIndex) const {
    return iq_(detail::sequence(dopplerBin, 1), af::span, detail::sequence(elementIndex, 1));
}
af::array RangeDopplerMap::getElementVector(dim_t rangeBin, dim_t dopplerBin) const {
    return af::flat(iq_(detail::sequence(dopplerBin, 1), detail::sequence(rangeBin, 1), af::span));
}
af::array RangeDopplerMap::getPower() const { return detail::computePower(iq_); }
af::array RangeDopplerMap::getPowerSumElements() const { return af::sum(getPower(), 2); }
RangeDopplerMap RangeDopplerMap::sliceRanges(dim_t firstRangeBin, dim_t rangeBinCount) const {
    auto result = *this;
    result.iq_ = iq_(af::span, detail::sequence(firstRangeBin, rangeBinCount), af::span);
    result.rangeAxis_ = rangeAxis_.sliced(firstRangeBin);
    result.rangeBinCount_ = rangeBinCount;
    return result;
}
void RangeDopplerMap::setDopplerOrder(DopplerOrder order) {
    auto axis = dopplerAxis_;
    axis.setOrder(order); // Validate once before touching data.
    if (order == dopplerAxis_.getOrder()) return;
    const int half = static_cast<int>(getDopplerBinCount() / 2); // Representability established by constructor.
    af::array shifted = af::shift(iq_, order == DopplerOrder::Centered ? half : -half, 0, 0, 0);
    iq_ = std::move(shifted);
    dopplerAxis_ = axis;
}
RangeDopplerMap RangeDopplerMap::withDopplerOrder(DopplerOrder order) const {
    auto result = *this;
    result.setDopplerOrder(order);
    return result;
}
af::array RangeDopplerMap::getRangeFirstData() const { return af::reorder(iq_, 1, 0, 2, 3); }
void RangeDopplerMap::setData(af::array iq) {
    detail::validateCube(iq, metadata_);
    detail::requireSameContext(iq_, iq);
    detail::requireShape(iq, getDimensions());
    iq_ = std::move(iq);
}
void RangeDopplerMap::setMetadata(CPI_Metadata metadata) {
    detail::validateElementCount(metadata, getElementCount());
    detail::validatePulseTimes(metadata, dopplerAxis_.getPulsesUsed());
    if (metadata.getPrfHz() != dopplerAxis_.getPrfHz())
        throw std::invalid_argument("CPI and Doppler PRFs disagree");
    metadata_ = std::move(metadata);
}
void RangeDopplerMap::setRangeAxis(RangeAxis rangeAxis) {
    detail::requireFinite(rangeAxis.getMeters(getRangeBinCount() - 1), "last range bin");
    rangeAxis_ = rangeAxis;
}
RangeDopplerMap RangeDopplerMap::withData(af::array iq) const {
    auto result = *this;
    result.setData(std::move(iq));
    return result;
}
RangeDopplerMap RangeDopplerMap::clone() const {
    auto result = *this;
    result.iq_ = iq_.copy();
    return result;
}
std::vector<af::cfloat> RangeDopplerMap::toHost() const { return detail::toHost(iq_); }
void RangeDopplerMap::evaluate() const { iq_.eval(); }
void RangeDopplerMap::synchronize() const { detail::synchronize(iq_); }
} // namespace radar
