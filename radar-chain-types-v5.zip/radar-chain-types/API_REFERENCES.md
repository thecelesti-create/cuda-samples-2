# API references reviewed for v0.5

These are upstream references, not vendored dependencies or runtime test results.
The ArrayFire runtime/SDK must be installed separately. This repository does not
modify third-party ArrayFire class definitions or public members.

## ArrayFire 3.10 release and CMake integration

- Release: `https://github.com/arrayfire/arrayfire/releases/tag/v3.10.0`
- Windows/CMake imported targets: `https://arrayfire.org/docs/using_on_windows.htm`
- Generated version header template: `https://raw.githubusercontent.com/arrayfire/arrayfire/v3.10.0/CMakeModules/version.h.in`

## Pinned 3.10 interfaces / implementation

- Array storage, move/copy, dtype/shape, eval/host: `https://raw.githubusercontent.com/arrayfire/arrayfire/v3.10.0/include/af/array.h`
- Host complex float representation: `https://raw.githubusercontent.com/arrayfire/arrayfire/v3.10.0/include/af/complex.h`
- Constants, reorder, moddims, join, select, range: `https://raw.githubusercontent.com/arrayfire/arrayfire/v3.10.0/include/af/data.h`
- Lookup/indexing: `https://raw.githubusercontent.com/arrayfire/arrayfire/v3.10.0/include/af/index.h`
- Trigonometry and elementwise arithmetic: `https://raw.githubusercontent.com/arrayfire/arrayfire/v3.10.0/include/af/arith.h`
- Integer division dispatch: `https://raw.githubusercontent.com/arrayfire/arrayfire/v3.10.0/src/api/c/binary.cpp`
- CUDA dynamic-compaction/count behavior: `https://raw.githubusercontent.com/arrayfire/arrayfire/v3.10.0/src/backend/cuda/kernel/where.hpp`

C++20 is a requirement of this consumer library, propagated through
`target_compile_features(... cxx_std_20)`, not a claim that all ArrayFire builds
were themselves compiled in that language mode. Real SDK/compiler/library ABI
compatibility still needs the full local build described in `VALIDATION.md`.
