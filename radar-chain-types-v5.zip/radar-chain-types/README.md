# Radar chain types — v0.5

C++20 intermediate data types targeting the ArrayFire 3.10 C++ API. Algorithms
accept a typed input by const reference and return the next type by value:

```cpp
radar::RangeDopplerMap doDoppler(const radar::RangePulseBuffer& input) {
    af::array output = af::fft(input.getDopplerInput());
    return {input, std::move(output), radar::DopplerOrder::Unshifted};
}
```

The wrapper and small metadata live on the CPU. All five stages' **numerical
payloads** use `af::array`, so they remain on CUDA when created/processed using
the CUDA backend. CPU and OpenCL builds use the same container API. There is no
implicit CPU numerical fallback implemented by this repository.

## Start with the very simple demo

`examples/simple_demo.cpp` contains exactly three deliberately fake algorithms:

```cpp
const auto ranges = fakeMatchedFilter(samples);  // Gain only; NOT a matched filter.
const auto map = fakeDoppler(ranges);             // Reorder only; NOT a Doppler FFT.
const auto detections = fakeDetector(map);        // Always choose cell zero; NOT CFAR.
const auto records = detections.recordsToHost();  // Explicit final CPU export.
```

A tiny `[8 samples, 4 pulses, 3 elements]` array is uploaded at the start. The
algorithms pass ArrayFire results between types, without numerical host exports
between stages. The final record printout is expected to be:

```text
Fake chain produced 1 detection(s).
range bin=0, Doppler bin=0, power=12
```

This is expected output derived from the example, **not a captured runtime test**.
The fake intermediate values are not meaningful radar measurements. Replace the
three bodies with your actual algorithms; their signatures need not change.

`examples/pipeline.cpp` is a separate, more involved reference: padded linear
matched filtering, a pulse FFT, and fixed-threshold detection. It now keeps the
selected bins/powers and placeholder angles on the device. Its final angles are
fixed demonstration values, not estimates from array geometry.

## Build with C++20 and ArrayFire 3.10

Requirements: CMake 3.20+, a C++20 compiler, and an installed ArrayFire 3.10 SDK
and matching runtime/backend dependencies. The supported SDK major is 3; later
3.x patch/minor packages are accepted but are not separately certified.

CMake requests `find_package(ArrayFire 3.10 CONFIG REQUIRED)`, sets C++20 with
extensions disabled, and propagates `cxx_std_20` to library consumers. Public
headers reject pre-C++20 builds and pre-3.10 ArrayFire headers. MSVC builds use
`/Zc:__cplusplus`, `/permissive-`, and `NOMINMAX`. No NVCC/.cu compilation is needed
for these ordinary ArrayFire C++ calls.

The default target is the unified `ArrayFire::af`. On Windows/Visual Studio:

```powershell
cmake -S . -B build -A x64 -DCMAKE_PREFIX_PATH="$env:AF_PATH" -DRADAR_TEST_BACKEND=cuda
cmake --build build --config Release --parallel
ctest --test-dir build -C Release --output-on-failure
.\build\Release\radar_simple_demo.exe cuda
.\build\Release\radar_pipeline_example.exe cuda
```

`AF_PATH` must point to your actual ArrayFire installation. Alternatively set
`ArrayFire_DIR` to the directory containing `ArrayFireConfig.cmake`. Ensure the
installed ArrayFire runtime/dependency DLLs are on `PATH` before running.

Linux, assuming ArrayFire is discoverable:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DRADAR_TEST_BACKEND=cuda
cmake --build build --parallel
ctest --test-dir build --output-on-failure
./build/radar_simple_demo cuda
```

The simple demo defaults to CUDA with the unified backend. Pass `cpu` or `opencl`
explicitly to test a different installed backend. `RADAR_TEST_BACKEND` optionally
selects the backend for CTest's ArrayFire integration suite; leave it empty to
use ArrayFire's default active backend. It does not alter the library's backend.

Direct linking is also available:

```sh
cmake -S . -B build-cuda -DRADAR_ARRAYFIRE_BACKEND=CUDA -DCMAKE_BUILD_TYPE=Release
cmake --build build-cuda --config Release --parallel
```

Run directly linked demos/tests **without a backend argument**. Build selections
are `UNIFIED`, `CPU`, `CUDA`, and `OPENCL`. With a direct build, leave
`RADAR_TEST_BACKEND` empty. The library itself never silently switches devices.

For an existing application:

```cmake
add_subdirectory(radar-chain-types)
target_link_libraries(your_application PRIVATE radar::chain_types)
```

The library is static; no DLL-export annotations or external download/build
scripts are required. Choose backend/device before initial uploads. The same
owning context must remain active during the chain, including helper calls.

## Layouts and private storage

| Type | Numeric payload |
|---|---|
| `SamplePulseBuffer` | c32 `[sample, pulse, element, 1]` |
| `RangePulseBuffer` | c32 `[range, pulse, element, 1]` |
| `RangeDopplerMap` | c32 `[Doppler, range, element, 1]` |
| `DetectionList` | u32 range/Doppler bin columns and f32 power/noise columns, each `[detection,1,1,1]`; c32 IQ `[element,detection,1,1]` |
| `AzElDetectionList` | A device `DetectionList` plus f32 azimuth/elevation columns, each `[detection,1,1,1]` |

The cubes reject an active fourth dimension and empty data. Singleton dimensions
are valid. Detection lists may be empty; empty array handles have no guaranteed
shape/type/device meaning beyond zero values. Counts/context still describe the
list. Select/clone/coordinate/download operations handle empty lists.

No repository-defined structs, public data members, virtual methods, or mutable
references to private fields are exposed. Getters use `get...`, setters use
`set...`; action/factory methods retain names such as `clone`, `select`, `fromMap`,
`toHost`, `recordsToHost`, and `synchronize`. Class words are capitalized; the
explicitly requested spelling `CPI_Metadata` is preserved.

Cube dimensions are cached as `sampleCount_`, `pulseCount_`, `rangeBinCount_`,
`dopplerBinCount_`, and `elementCount_`, as appropriate. `DetectionList` caches
`detectionCount_`. There are no independently writable count setters.
`getElementCount()` counts hardware elements, while ArrayFire's own
`getData().elements()` counts all array values.

## Pipeline constructors and ownership

Constructors adopt **already computed** output arrays. They do not run a matched
filter, FFT, detector, or angle estimator. The explicitly named `fromMap()`
factory/gathering constructor is the exception for data gathering, not detection.

Range processing preserves pulse/element counts and accepts a different output
range count plus a corrected `RangeAxis`. Doppler processing adopts `[D,R,E]`,
retains the input integration length, and permits zero padding, not truncation.
The `getDopplerInput()` helper explicitly reorders `[R,P,E]` to `[P,R,E]` for
ArrayFire's leading-axis FFT. The map stays Doppler-first afterward.

Detection algorithms can use either construction path:

```cpp
// Selected device indices in the [Doppler,range] plane, plus selected f32 powers.
auto detections = radar::DetectionList::fromMap(
    map, std::move(cellIndices), std::move(powers), std::move(noisePowers));

// Already have bins and gathered element IQ? Adopt them directly instead.
radar::DetectionList adopted(map.getDetectionContext(),
    std::move(rangeBins), std::move(dopplerBins),
    std::move(powers), std::move(noisePowers), std::move(elementIq));

// Angle estimator returns two f32 arrays, in the same detection order.
radar::AzElDetectionList located(
    std::move(adopted), std::move(azimuthRadians), std::move(elevationRadians));
```

`cellIndex = dopplerBin + dopplerBinCount * rangeBin`. The gathering constructor
decodes these integers on device and gathers `[K,E]` from a `[D*R,E]` view, then
reorders only that compact matrix to `[E,K]`. No CPU index-vector upload or full
cube download is involved. `fromMap()` requires one plane's maximum offset to
fit u32. For larger planes, supply separate u32 bins and already gathered IQ to
the direct constructor. Bin-axis extents must be at most `UINT_MAX` in either
path. Selection indices are u32 device columns too.

A normal copy copies small metadata and ArrayFire handles; it does not explicitly
deep-copy an IQ allocation. Return values and rvalue array inputs support moves.
`clone()` explicitly copies every stored device array. Use const-reference inputs
for read-only algorithms to avoid needless metadata copies.

Detection objects do not store the full source map. ArrayFire views/lazy work or
in-flight operations can nevertheless retain upstream storage until no longer
needed. Reorders, gathers, FFT outputs/workspaces, and deep copies can allocate
and move data **within device memory**. GPU residency is not zero allocation,
zero memory traffic, or a guarantee of no synchronization.

## Hot-path contract and validation

Construction/setter checks inspect shape, dtype, lengths, metadata, and owning
backend/device. GPU constructors **do not scan values or read back min/max/all**.
The producer must supply valid in-range indices, aligned snapshots, finite
nonnegative powers, finite strictly positive noise powers, nonnegative detection
ranges, and finite angles in the stated domains. Supplying invalid GPU values
violates the API preconditions; a constructor is not promised to detect it.

Read/index/select helpers do not repeat wrapper bounds/context checks. For a
slice require `first >= 0`, `count > 0`, `count <= extent - first`. Selection
indices and their result size must fit the documented types/storage. ArrayFire's
own API checks remain. Do not call helpers on moved-from wrappers.

`setData()` preserves a cube's shape/type/context. `setPowers()` replaces aligned
power/noise columns together; `setAngles()` replaces both angle columns together.
All replacement inputs are structurally checked before committing. Bins are
read-only because independently editing them would misalign IQ snapshots; build
a new detection list to replace bins plus their data consistently.

Scalar host metadata/value-class constructors/setters still check their values.
The CPU `DetectionCell`, `Detection`, `AngleEstimate`, and `AzElDetection` classes
are retained for final exports/serialization, not intermediate list storage.
`recordsToHost()` creates these checked CPU values after an explicit download.

## Device getters and explicit downloads

`DetectionList` exposes `getRangeBins()`, `getDopplerBins()`, `getPowers()`,
`getNoisePowers()`, and `getElementSnapshots()` as const ArrayFire references.
`getRangesMeters()`, `getDopplerHz()`, `getRadialVelocitiesMps()`, and `getSnrDb()`
produce f32 device columns. `getDetection(index)` returns a **one-entry device
list**, not a CPU scalar. `select(deviceIndices)` aligns every column/snapshot.

`AzElDetectionList` adds `getAzimuthRadians()`, `getElevationRadians()`, and
`getPositionsMeters()` (f32 `[3,detection]`, rows x/y/z). Its `getDetection(index)`
also returns a one-entry device list. Angles are radians, with azimuth `[-pi,pi]`
and elevation `[-pi/2,pi/2]`. Inclusive endpoints use the corresponding f32
representation; explicit CPU export maps only those endpoints to double pi.

GPU coordinate helpers use f32 to avoid default FP64 on the laptop GPU. Metadata
and final CPU coordinates use double. Metadata used in device coordinate helpers
must be representable at f32 precision; bin storage/gather arithmetic remain
integer and do not round through f32. Derived device coordinates are computed
on demand rather than redundantly stored in each list.

`recordsToHost()` is the explicit record export on both list types;
`snapshotsToHost()` exports compact IQ; `toHost()` on a cube exports its full IQ.
ArrayFire `.host()`, `.scalar<T>()`, and printing array contents are also potential
readback boundaries if used directly by application algorithms. No normal
constructor/getter silently creates CPU detection records.

`evaluate()` submits stored expressions; `synchronize()` evaluates then fences
the active owning device. Neither intentionally downloads the numerical arrays.
No wrapper constructor calls `af::sync()`. This does NOT guarantee asynchronous
execution of every underlying operation: notably, ArrayFire 3.10 CUDA `where()`
reads a compacted count back internally before allocating its result. The
reference threshold detector uses `where()`; the fake demo uses a fixed one-cell
selection. This repo uses exact-length lists, not fixed-capacity device queues.

## Radar interpretation

Assumptions: uniform PRF, monostatic narrowband pulse-Doppler radar. Waveform,
array geometry, calibration, CFAR settings, beamforming, and ambiguity resolution
belong to algorithm configuration, not these data containers.

Range origin/spacing are explicit: `RangeAxis::fromRoundTripTiming(delay, fs)`
uses `c*delay/2` and `c/(2*fs)`. Use corrected filter-output timing, accounting for
filter delay/cropping/resampling. Grid spacing is not physical range resolution.
Raw sample/pulse slices update their timing; processed range slices update the
range origin. Acquisition sample-rate metadata remain acquisition metadata.

Doppler spacing is `PRF/Nfft`, while coherent duration uses `pulsesUsed/PRF`.
Zero padding does not add observation time. `Unshifted` is native FFT order;
`Centered` has DC at `floor(N/2)`. Even-N Nyquist is negative. `setDopplerOrder()`
and `withDopplerOrder()` shift both samples and metadata, including odd sizes.

Radial velocity is positive for receding. `CPI_Metadata` specifies whether
positive spectral Doppler means approaching or receding for your IQ convention.
`getSnrDb()` is cell/noise power ratio in dB, not noise-subtracted SNR; zero cell
power yields negative infinity. XYZ is sensor-local: +x boresight, +y positive
azimuth, +z up; no world/geodetic transform or full 3D velocity is implied.

## Validation status

See `VALIDATION.md` for executed checks and limitations. Metadata tests pass in
C++20, but this environment has no ArrayFire SDK/runtime: do not mistake metadata
tests or source/declaration reviews for a linked CPU/CUDA build or a GPU run.

Metadata-only validation, useful without ArrayFire:

```sh
cmake -S . -B build-metadata -DRADAR_BUILD_ARRAYFIRE_TYPES=OFF -DCMAKE_BUILD_TYPE=Release
cmake --build build-metadata --parallel
ctest --test-dir build-metadata --output-on-failure
```
